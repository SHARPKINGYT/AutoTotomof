
package com.example.autototem;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public class AutoTotem implements ModInitializer {

    @Override
    public void onInitialize() {
        ServerPlayerEvents.ALLOW_DEATH.register((player, damageSource, damageAmount) -> {
            if (tryConsumeTotem(player)) {
                player.setHealth(1.0F);
                player.getWorld().sendEntityStatus(player, (byte) 35);
                player.getWorld().getServer().getPlayerManager().sendMessage(player.getName().copy().append(" activated a Totem from inventory!"));
                return false; // Cancel death
            }
            return true; // Allow death
        });
    }

    private boolean tryConsumeTotem(ServerPlayerEntity player) {
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }
}
