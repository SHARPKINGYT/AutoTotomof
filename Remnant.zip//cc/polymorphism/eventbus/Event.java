package cc.polymorphism.eventbus;

import chorus0.Chorus;
import java.util.ConcurrentModificationException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Event {
   private boolean cancelled;

   public void cancel() {
      this.cancelled = true;
   }

   public boolean equals(Class<? extends Event> eventClass) {
      return this.getClass() == eventClass;
   }

   public <T> T run() {
      try {
         Chorus.getInstance().getEventManager().post(this);
      } catch (ConcurrentModificationException var2) {
      }

      return this;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean cancelled) {
      this.cancelled = cancelled;
   }
}
