package cc.polymorphism.eventbus;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class EventBus {
   private final Map<Class<? extends Event>, List<EventBus.MethodData>> LISTENERS = new HashMap();

   public void register(Object object) {
      Method[] var2 = object.getClass().getDeclaredMethods();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Method method = var2[var4];
         if (!this.isMethodBad(method)) {
            this.register(method, object);
         }
      }

   }

   public void register(Object object, Class<? extends Event> eventClass) {
      Method[] var3 = object.getClass().getDeclaredMethods();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         Method method = var3[var5];
         if (!this.isMethodBad(method, eventClass)) {
            this.register(method, object);
         }
      }

   }

   public void unregister(Object object) {
      Iterator var2 = this.LISTENERS.values().iterator();

      while(var2.hasNext()) {
         List<EventBus.MethodData> dataList = (List)var2.next();
         dataList.removeIf((data) -> {
            return data.source().equals(object);
         });
      }

      this.cleanMap(true);
   }

   private void register(Method method, Object object) {
      Class<? extends Event> indexClass = method.getParameterTypes()[0];
      final EventBus.MethodData data = new EventBus.MethodData(object, method, ((RegisterEvent)method.getAnnotation(RegisterEvent.class)).value());
      if (!data.target().canAccess(object)) {
         data.target().setAccessible(true);
      }

      if (this.LISTENERS.containsKey(indexClass)) {
         if (!((List)this.LISTENERS.get(indexClass)).contains(data)) {
            ((List)this.LISTENERS.get(indexClass)).add(data);
            this.sortListValue(indexClass);
         }
      } else {
         this.LISTENERS.put(indexClass, new CopyOnWriteArrayList<EventBus.MethodData>() {
            {
               this.add(data);
            }
         });
      }

   }

   public void cleanMap(boolean onlyEmptyEntries) {
      Iterator mapIterator = this.LISTENERS.entrySet().iterator();

      while(true) {
         do {
            if (!mapIterator.hasNext()) {
               return;
            }
         } while(onlyEmptyEntries && !((List)((Entry)mapIterator.next()).getValue()).isEmpty());

         mapIterator.remove();
      }
   }

   private void sortListValue(Class<? extends Event> indexClass) {
      List<EventBus.MethodData> sortedList = new CopyOnWriteArrayList();
      byte[] var3 = EventPriority.VALUE_ARRAY;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         byte priority = var3[var5];
         Iterator var7 = ((List)this.LISTENERS.get(indexClass)).iterator();

         while(var7.hasNext()) {
            EventBus.MethodData data = (EventBus.MethodData)var7.next();
            if (data.priority() == priority) {
               sortedList.add(data);
            }
         }
      }

      this.LISTENERS.put(indexClass, sortedList);
   }

   private boolean isMethodBad(Method method) {
      return method.getParameterTypes().length != 1 || !method.isAnnotationPresent(RegisterEvent.class);
   }

   private boolean isMethodBad(Method method, Class<? extends Event> eventClass) {
      return this.isMethodBad(method) || !method.getParameterTypes()[0].equals(eventClass);
   }

   public Event post(Event event) {
      List<EventBus.MethodData> dataList = (List)this.LISTENERS.get(event.getClass());
      if (dataList != null) {
         Iterator var3 = dataList.iterator();

         while(var3.hasNext()) {
            EventBus.MethodData data = (EventBus.MethodData)var3.next();
            this.invoke(data, event);
         }
      }

      return event;
   }

   private void invoke(EventBus.MethodData data, Event argument) {
      try {
         data.target().invoke(data.source(), argument);
      } catch (IllegalArgumentException | InvocationTargetException | IllegalAccessException var4) {
      }

   }

   @Environment(EnvType.CLIENT)
   private static record MethodData(Object source, Method target, byte priority) {
      private MethodData(Object source, Method target, byte priority) {
         this.source = source;
         this.target = target;
         this.priority = priority;
      }

      public Object source() {
         return this.source;
      }

      public Method target() {
         return this.target;
      }

      public byte priority() {
         return this.priority;
      }
   }
}
