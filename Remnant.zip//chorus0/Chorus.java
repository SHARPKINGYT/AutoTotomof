package chorus0;

import cc.polymorphism.annot.IncludeReference;
import cc.polymorphism.eventbus.EventBus;
import com.chorus.api.command.CommandManager;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.Module;
import com.chorus.api.module.ModuleManager;
import com.chorus.api.module.setting.SettingManager;
import com.chorus.api.repository.bot.BotRepository;
import com.chorus.api.repository.friend.FriendRepository;
import com.chorus.api.repository.team.TeamRepository;
import com.chorus.api.system.notification.NotificationManager;
import com.chorus.api.system.render.font.Fonts;
import com.chorus.api.system.rotation.RotationComponent;
import com.chorus.core.client.ClientInfo;
import com.chorus.core.client.ConcreteClientInfoProvider;
import com.chorus.core.client.config.ConfigManager;
import com.chorus.core.listener.ListenerRepository;
import com.chorus.impl.modules.client.Capes;
import com.chorus.impl.modules.client.ClickGUI;
import com.chorus.impl.modules.client.Friends;
import com.chorus.impl.modules.client.SelfDestruct;
import com.chorus.impl.modules.client.Teams;
import com.chorus.impl.modules.combat.AimAssist;
import com.chorus.impl.modules.combat.AnchorMacro;
import com.chorus.impl.modules.combat.AutoCrystal;
import com.chorus.impl.modules.combat.AutoStun;
import com.chorus.impl.modules.combat.Backtrack;
import com.chorus.impl.modules.combat.Criticals;
import com.chorus.impl.modules.combat.HitCrystal;
import com.chorus.impl.modules.combat.HitSelection;
import com.chorus.impl.modules.combat.Hitboxes;
import com.chorus.impl.modules.combat.MaceSwap;
import com.chorus.impl.modules.combat.Piercing;
import com.chorus.impl.modules.combat.SprintReset;
import com.chorus.impl.modules.combat.TickBase;
import com.chorus.impl.modules.combat.TriggerBot;
import com.chorus.impl.modules.combat.Velocity;
import com.chorus.impl.modules.movement.GuiMove;
import com.chorus.impl.modules.movement.MoveFix;
import com.chorus.impl.modules.movement.NoPush;
import com.chorus.impl.modules.movement.SnapTap;
import com.chorus.impl.modules.movement.Speed;
import com.chorus.impl.modules.movement.Sprint;
import com.chorus.impl.modules.movement.TargetStrafe;
import com.chorus.impl.modules.movement.WaterSpeed;
import com.chorus.impl.modules.other.AntiBot;
import com.chorus.impl.modules.other.AntiResourcePack;
import com.chorus.impl.modules.other.FlagDetector;
import com.chorus.impl.modules.other.Insults;
import com.chorus.impl.modules.other.MultiTask;
import com.chorus.impl.modules.other.NoDelay;
import com.chorus.impl.modules.other.NoRotate;
import com.chorus.impl.modules.other.Prevent;
import com.chorus.impl.modules.other.Streamer;
import com.chorus.impl.modules.other.Target;
import com.chorus.impl.modules.other.Timer;
import com.chorus.impl.modules.utility.AutoArmor;
import com.chorus.impl.modules.utility.AutoTool;
import com.chorus.impl.modules.utility.AutoTotem;
import com.chorus.impl.modules.utility.BridgeAssist;
import com.chorus.impl.modules.utility.ChestStealer;
import com.chorus.impl.modules.utility.ElytraSwap;
import com.chorus.impl.modules.utility.FakePlayer;
import com.chorus.impl.modules.utility.FastPlace;
import com.chorus.impl.modules.utility.InventoryManager;
import com.chorus.impl.modules.utility.Safety;
import com.chorus.impl.modules.utility.Scaffold;
import com.chorus.impl.modules.visual.AimCrosshair;
import com.chorus.impl.modules.visual.AntiDebuff;
import com.chorus.impl.modules.visual.Arraylist;
import com.chorus.impl.modules.visual.AspectRatio;
import com.chorus.impl.modules.visual.Atmosphere;
import com.chorus.impl.modules.visual.BedPlates;
import com.chorus.impl.modules.visual.Chams;
import com.chorus.impl.modules.visual.ElytraPredict;
import com.chorus.impl.modules.visual.ItemTransforms;
import com.chorus.impl.modules.visual.Keybinds;
import com.chorus.impl.modules.visual.Nametags;
import com.chorus.impl.modules.visual.NoToast;
import com.chorus.impl.modules.visual.Notifications;
import com.chorus.impl.modules.visual.PlayerESP;
import com.chorus.impl.modules.visual.Radar;
import com.chorus.impl.modules.visual.Scoreboard;
import com.chorus.impl.modules.visual.StorageESP;
import com.chorus.impl.modules.visual.TargetHud;
import com.chorus.impl.modules.visual.TotemAnimation;
import com.chorus.impl.modules.visual.Tracers;
import com.chorus.impl.modules.visual.Trajectories;
import com.chorus.impl.modules.visual.Watermark;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@IncludeReference
@Environment(EnvType.CLIENT)
public final class Chorus implements ModInitializer {
   private static final Logger log = LoggerFactory.getLogger(Chorus.class);
   private static Chorus instance;
   public final Object authLock = new Object();
   public volatile boolean isAuthenticated;
   private ClientInfo clientInfo;
   private EventBus eventManager;
   private ModuleManager moduleManager;
   private SettingManager settingManager;
   private Fonts fonts;
   private FriendRepository friendRepository;
   private BotRepository npcRepository;
   private TeamRepository teamRepository;
   private CommandManager commandManager;
   private ConfigManager configManager;
   private ListenerRepository listenerRepository;
   private RotationComponent rotationComponent;
   private NotificationManager NotificationManager;

   public void onInitialize() {
      instance = this;
      log.info("Initializing Chorus...");
      this.clientInfo = (new ConcreteClientInfoProvider()).provideClientInfo();
      log.info("Client info loaded: {} v{}", this.clientInfo.name(), this.clientInfo.version());
      this.fonts = new Fonts();
      this.eventManager = new EventBus();
      this.commandManager = new CommandManager();
      this.moduleManager = new ModuleManager();
      this.settingManager = new SettingManager();
      this.configManager = new ConfigManager(this.clientInfo);
      this.friendRepository = new FriendRepository();
      this.npcRepository = new BotRepository();
      this.teamRepository = new TeamRepository();
      this.listenerRepository = new ListenerRepository();
      this.rotationComponent = new RotationComponent();
      this.NotificationManager = new NotificationManager();
      log.info("Managers initialized successfully");
      List<Class<? extends BaseModule>> moduleClasses = Arrays.asList(ClickGUI.class, AimAssist.class, Chams.class, TriggerBot.class, AutoTotem.class, AutoCrystal.class, Teams.class, Friends.class, AntiBot.class, Sprint.class, AntiDebuff.class, Atmosphere.class, HitSelection.class, SprintReset.class, AntiResourcePack.class, FastPlace.class, BridgeAssist.class, Arraylist.class, Speed.class, Watermark.class, ElytraSwap.class, AutoStun.class, MultiTask.class, Velocity.class, PlayerESP.class, Backtrack.class, SnapTap.class, HitCrystal.class, AnchorMacro.class, TargetStrafe.class, Nametags.class, ChestStealer.class, FlagDetector.class, MoveFix.class, AimCrosshair.class, StorageESP.class, BedPlates.class, Timer.class, NoDelay.class, AutoTool.class, Target.class, TargetHud.class, Tracers.class, Keybinds.class, GuiMove.class, AutoArmor.class, Hitboxes.class, InventoryManager.class, Scaffold.class, NoPush.class, Streamer.class, NoRotate.class, Notifications.class, MaceSwap.class, FakePlayer.class, Piercing.class, Insults.class, Scoreboard.class, Radar.class, Trajectories.class, WaterSpeed.class, NoToast.class, ElytraPredict.class, TotemAnimation.class, Safety.class, Capes.class, AspectRatio.class, ItemTransforms.class, Criticals.class, SelfDestruct.class, TickBase.class, Prevent.class);
      moduleClasses.stream().sorted(Comparator.comparing(Class::getSimpleName)).forEach((moduleClass) -> {
         try {
            this.moduleManager.registerModule((Module)moduleClass.getDeclaredConstructor().newInstance());
         } catch (Exception var3) {
         }

      });
      this.listenerRepository.setup();
      this.commandManager.init();
      log.info("Chorus initialized successfully!");
   }

   public static Chorus getInstance() {
      return instance;
   }

   public ClientInfo getClientInfo() {
      return this.clientInfo;
   }

   public EventBus getEventManager() {
      return this.eventManager;
   }

   public ModuleManager getModuleManager() {
      return this.moduleManager;
   }

   public SettingManager getSettingManager() {
      return this.settingManager;
   }

   public Fonts getFonts() {
      return this.fonts;
   }

   public FriendRepository getFriendRepository() {
      return this.friendRepository;
   }

   public BotRepository getNpcRepository() {
      return this.npcRepository;
   }

   public TeamRepository getTeamRepository() {
      return this.teamRepository;
   }

   public CommandManager getCommandManager() {
      return this.commandManager;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public ListenerRepository getListenerRepository() {
      return this.listenerRepository;
   }

   public RotationComponent getRotationComponent() {
      return this.rotationComponent;
   }

   public NotificationManager getNotificationManager() {
      return this.NotificationManager;
   }
}
