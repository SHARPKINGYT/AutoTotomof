package chorus0.asm.accessors;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2797;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_2797.class})
public interface ChatMessageC2SPacketAccessor {
   @Mutable
   @Accessor("chatMessage")
   void setChatMessage(String var1);
}
