package chorus0.asm.accessors;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_759.class})
public interface HeldItemRendererAccessor {
   @Accessor
   float getEquipProgressMainHand();

   @Accessor
   void setEquipProgressMainHand(float var1);

   @Accessor
   float getEquipProgressOffHand();

   @Accessor
   void setEquipProgressOffHand(float var1);

   @Accessor
   class_1799 getMainHand();

   @Accessor
   void setMainHand(class_1799 var1);

   @Accessor
   class_1799 getOffHand();

   @Accessor
   void setOffHand(class_1799 var1);
}
