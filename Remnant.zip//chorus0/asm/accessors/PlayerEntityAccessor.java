package chorus0.asm.accessors;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_1657.class})
public interface PlayerEntityAccessor {
   @Invoker("getDamageAgainst")
   float invokeGetDamageAgainst(class_1297 var1, float var2, class_1282 var3);
}
