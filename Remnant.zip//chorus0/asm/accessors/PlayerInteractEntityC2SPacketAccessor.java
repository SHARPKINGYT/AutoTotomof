package chorus0.asm.accessors;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2824;
import net.minecraft.class_2824.class_5906;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_2824.class})
public interface PlayerInteractEntityC2SPacketAccessor {
   @Accessor("type")
   class_5906 getType();

   @Accessor("entityId")
   int getEntityId();
}
