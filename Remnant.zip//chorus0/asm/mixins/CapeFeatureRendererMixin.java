package chorus0.asm.mixins;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_8685;
import net.minecraft.class_972;
import net.minecraft.class_10186.class_10190;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_972.class})
public abstract class CapeFeatureRendererMixin extends class_3887<class_10055, class_591> {
   @Final
   @Shadow
   private class_572<class_10055> field_53206;

   public CapeFeatureRendererMixin(class_3883<class_10055, class_591> context) {
      super(context);
   }

   @Shadow
   protected abstract boolean method_64257(class_1799 var1, class_10190 var2);

   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void render(class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, class_10055 playerEntityRenderState, float f, float g, CallbackInfo ci) {
      if (!playerEntityRenderState.field_53333 && playerEntityRenderState.field_53532) {
         class_8685 skinTextures = playerEntityRenderState.field_53520;
         if (skinTextures.comp_1627() != null && !this.method_64257(playerEntityRenderState.field_53418, class_10190.field_54127)) {
            matrixStack.method_22903();
            if (this.method_64257(playerEntityRenderState.field_53418, class_10190.field_54125)) {
               matrixStack.method_46416(0.0F, -0.063125F, 0.06875F);
            }

            class_4588 vertexConsumer = vertexConsumerProvider.getBuffer(class_1921.method_23580(skinTextures.comp_1627()));
            ((class_591)this.method_17165()).method_64254(this.field_53206);
            this.field_53206.method_17087(playerEntityRenderState);
            this.field_53206.method_60879(matrixStack, vertexConsumer, i, class_4608.field_21444);
            matrixStack.method_22909();
         }
      }

      ci.cancel();
   }
}
