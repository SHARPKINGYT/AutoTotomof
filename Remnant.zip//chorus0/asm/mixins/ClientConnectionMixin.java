package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.network.PacketReceiveEvent;
import com.chorus.impl.events.network.PacketSendEvent;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import net.minecraft.class_7648;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_2535.class})
public class ClientConnectionMixin implements QuickImports {
   @Inject(
      method = {"handlePacket"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static <T extends class_2547> void onPacketReceive(class_2596<T> packet, class_2547 listener, CallbackInfo ci) {
      PacketReceiveEvent prePacketReceive = new PacketReceiveEvent(packet, PacketReceiveEvent.Mode.PRE);
      Chorus.getInstance().getEventManager().post(prePacketReceive);
      if (prePacketReceive.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"handlePacket"},
      at = {@At("TAIL")}
   )
   private static <T extends class_2547> void onPacketReceivePost(class_2596<T> packet, class_2547 listener, CallbackInfo ci) {
      PacketReceiveEvent postPacketReceive = new PacketReceiveEvent(packet, PacketReceiveEvent.Mode.POST);
      Chorus.getInstance().getEventManager().post(postPacketReceive);
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPacketSend(class_2596<?> packet, CallbackInfo ci) {
      PacketSendEvent prePacketSend = new PacketSendEvent(PacketSendEvent.Mode.PRE, packet);
      Chorus.getInstance().getEventManager().post(prePacketSend);
      if (prePacketSend.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;)V"},
      at = {@At("TAIL")}
   )
   private void onPacketSendPost(class_2596<?> packet, CallbackInfo ci) {
      PacketSendEvent postPacketSend = new PacketSendEvent(PacketSendEvent.Mode.POST, packet);
      Chorus.getInstance().getEventManager().post(postPacketSend);
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void send(class_2596<?> packet, class_7648 callbacks, boolean flush, CallbackInfo ci) {
      if (packet instanceof class_2797 && ((class_2797)packet).comp_945().startsWith(Chorus.getInstance().getCommandManager().getPrefix())) {
         try {
            Chorus.getInstance().getCommandManager().dispatch(((class_2797)packet).comp_945().substring(Chorus.getInstance().getCommandManager().getPrefix().length()));
         } catch (CommandSyntaxException var6) {
            var6.printStackTrace();
            mc.execute(() -> {
               mc.field_1705.method_1743().method_1812(class_2561.method_30163(var6.getMessage()));
            });
         }

         ci.cancel();
      }

   }
}
