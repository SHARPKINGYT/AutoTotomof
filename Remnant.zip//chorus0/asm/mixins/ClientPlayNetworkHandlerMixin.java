package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.modules.visual.TargetHud;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2663;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_745;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_634.class})
public abstract class ClientPlayNetworkHandlerMixin {
   @Unique
   private boolean ignoreSendChatMsg = false;
   @Shadow
   private class_638 field_3699;

   @Shadow
   public abstract void method_45729(String var1);

   @Inject(
      method = {"sendChatMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSendChatMessage(String content, CallbackInfo ci) {
      if (!this.ignoreSendChatMsg) {
         if (Chorus.getInstance().getCommandManager().getPrefix() == null || !content.startsWith(Chorus.getInstance().getCommandManager().getPrefix())) {
            this.ignoreSendChatMsg = true;
            this.method_45729(content);
            this.ignoreSendChatMsg = false;
            ci.cancel();
         }
      }
   }

   @Inject(
      method = {"onEntityStatus"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/particle/ParticleManager;addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V"
)}
   )
   public void updateCounter(class_2663 packet, CallbackInfo ci) {
      class_1297 var4 = packet.method_11469(class_310.method_1551().field_1687);
      if (var4 instanceof class_745) {
         class_745 player = (class_745)var4;
         if (SocialManager.getTarget() != null && packet.method_11469(class_310.method_1551().field_1687) == SocialManager.getTarget()) {
            ++((TargetHud)Chorus.getInstance().getModuleManager().getModule(TargetHud.class)).totemPops;
         }
      }

   }
}
