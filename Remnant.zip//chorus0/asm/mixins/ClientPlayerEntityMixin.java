package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.core.listener.impl.TickEventListener;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({class_746.class})
public class ClientPlayerEntityMixin implements QuickImports {
   @ModifyExpressionValue(
      method = {"sendMovementPackets", "tick"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F"
)}
   )
   private float sendMovementPacketsTickInjectYaw(float original) {
      TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
      float[] rotation = rotationManager.getCurrentRotation();
      return rotation != null && rotationManager.isRotating() ? rotation[0] : original;
   }

   @ModifyExpressionValue(
      method = {"sendMovementPackets", "tick"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F"
)}
   )
   private float sendMovementPacketsTickInjectPitch(float original) {
      TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
      float[] rotation = rotationManager.getCurrentRotation();
      return rotation != null && rotationManager.isRotating() ? rotation[1] : original;
   }
}
