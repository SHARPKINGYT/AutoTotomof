package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.modules.other.NoDelay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_636.class})
public class ClientPlayerInteractionManagerMixin {
   @ModifyConstant(
      method = {"updateBlockBreakingProgress"},
      constant = {@Constant(
   intValue = 5
)}
   )
   private int noBreakDelay(int value) {
      return (Integer)((NoDelay)Chorus.getInstance().getModuleManager().getModule(NoDelay.class)).miningDelay.getValue();
   }

   @Inject(
      method = {"attackEntity"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;syncSelectedSlot()V",
   shift = Shift.AFTER
)}
   )
   private void onPreAttack(class_1657 player, class_1297 target, CallbackInfo ci) {
      Chorus.getInstance().getEventManager().post(new AttackEvent(AttackEvent.Mode.PRE, target));
   }

   @Inject(
      method = {"attackEntity"},
      at = {@At("RETURN")}
   )
   private void onPostAttack(class_1657 player, class_1297 target, CallbackInfo ci) {
      Chorus.getInstance().getEventManager().post(new AttackEvent(AttackEvent.Mode.POST, target));
   }
}
