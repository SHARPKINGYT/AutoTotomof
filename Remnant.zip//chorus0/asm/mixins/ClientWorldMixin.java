package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.impl.modules.visual.AntiDebuff;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_638.class})
public class ClientWorldMixin {
   @Inject(
      method = {"addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void noExplosionParticle(class_2394 parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfo ci) {
      if (((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).isEnabled() && ((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).mode.getSpecificValue("Nausea") && (parameters.method_10295() == class_2398.field_11236 || parameters.method_10295() == class_2398.field_11221)) {
         ci.cancel();
      }

   }
}
