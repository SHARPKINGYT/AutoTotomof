package chorus0.asm.mixins;

import com.chorus.common.QuickImports;
import com.chorus.impl.events.misc.WebSlowdownEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2560;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_2560.class})
public class CobwebBlockMixin implements QuickImports {
   @Inject(
      method = {"onEntityCollision"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onWebSlowdown(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, CallbackInfo ci) {
      WebSlowdownEvent cobwebEvent = new WebSlowdownEvent(WebSlowdownEvent.Mode.PRE);
      cobwebEvent.run();
      if (cobwebEvent.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"onEntityCollision"},
      at = {@At("RETURN")}
   )
   public void onWebSlowdownPost(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, CallbackInfo ci) {
      WebSlowdownEvent cobwebEvent = new WebSlowdownEvent(WebSlowdownEvent.Mode.POST);
      cobwebEvent.run();
   }
}
