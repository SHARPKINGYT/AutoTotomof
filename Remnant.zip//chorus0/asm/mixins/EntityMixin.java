package chorus0.asm.mixins;

import chorus0.Chorus;
import chorus0.asm.accessors.WorldRendererAccessor;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.misc.EntityHitboxEvent;
import com.chorus.impl.events.player.MoveFixEvent;
import com.chorus.impl.modules.movement.NoPush;
import com.chorus.impl.modules.visual.Nametags;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_1297.class})
public class EntityMixin implements QuickImports {
   @Shadow
   private class_238 field_6005;

   @Shadow
   private static class_243 method_18795(class_243 movementInput, float speed, float yaw) {
      return null;
   }

   @Inject(
      method = {"shouldRenderName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void shouldRenderNameInject(CallbackInfoReturnable<Boolean> cir) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null) {
         if (((Nametags)Chorus.getInstance().getModuleManager().getModule(Nametags.class)).isEnabled()) {
            class_1297 entity = (class_1297)this;
            if (!(entity instanceof class_1309)) {
               return;
            }

            if (entity instanceof class_1657 && entity == mc.field_1724 && mc.field_1690.method_31044().method_31034()) {
               return;
            }

            if (!((WorldRendererAccessor)mc.field_1769).getFrustum().method_23093(entity.method_5829())) {
               cir.setReturnValue(false);
            }
         }

      }
   }

   @Redirect(
      method = {"updateVelocity"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;movementInputToVelocity(Lnet/minecraft/util/math/Vec3d;FF)Lnet/minecraft/util/math/Vec3d;"
)
   )
   public class_243 updateVelocityInject(class_243 movementInput, float speed, float yaw) {
      if (mc.field_1724 != null && Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         MoveFixEvent eventYawMoveFix = new MoveFixEvent(yaw);
         Chorus.getInstance().getEventManager().post(eventYawMoveFix);
         yaw = eventYawMoveFix.getYaw();
      }

      return method_18795(movementInput, speed, yaw);
   }

   @Inject(
      method = {"pushAwayFrom"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void pushAwayFrom(class_1297 entity, CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null) {
         if (((NoPush)Chorus.getInstance().getModuleManager().getModule(NoPush.class)).isEnabled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"getBoundingBox"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getBoundBox(CallbackInfoReturnable<class_238> cir) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         EntityHitboxEvent eventHitBox = (EntityHitboxEvent)(new EntityHitboxEvent((class_1297)this, this.field_6005)).run();
         cir.setReturnValue(eventHitBox.getBox());
      }
   }

   @ModifyExpressionValue(
      method = {"move"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;isControlledByPlayer()Z"
)}
   )
   private boolean fallDistanceFix(boolean original) {
      return this == mc.field_1724 ? false : original;
   }
}
