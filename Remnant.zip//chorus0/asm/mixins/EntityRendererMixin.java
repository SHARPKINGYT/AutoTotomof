package chorus0.asm.mixins;

import com.chorus.common.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;

@Environment(EnvType.CLIENT)
@Mixin({class_897.class})
public abstract class EntityRendererMixin<T extends class_1297, S extends class_10017> implements QuickImports {
}
