package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.core.listener.impl.TickEventListener;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(EnvType.CLIENT)
@Mixin({class_1671.class})
public class FireworkRocketEntityMixin implements QuickImports {
   @Shadow
   private class_1309 field_7616;

   @Redirect(
      method = {"tick"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;"
)
   )
   private class_243 fireworkMoveFix(class_1309 instance) {
      TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
      return rotationManager.isRotating() ? mc.field_1724.method_5631(rotationManager.getPitch(), rotationManager.getYaw()) : instance.method_5720();
   }
}
