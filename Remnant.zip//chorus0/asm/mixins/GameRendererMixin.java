package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.rotation.RotationUtils;
import com.chorus.core.listener.impl.TickEventListener;
import com.chorus.impl.events.render.Render3DEvent;
import com.chorus.impl.modules.visual.AspectRatio;
import com.chorus.impl.modules.visual.TotemAnimation;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.BiFunction;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_757.class})
public abstract class GameRendererMixin implements QuickImports {
   @Shadow
   private float field_4005;
   @Shadow
   private float field_3988;
   @Shadow
   private float field_4004;
   @Shadow
   private float field_4025;
   @Shadow
   @Final
   private class_4599 field_20948;
   @Shadow
   private int field_4007;
   @Unique
   private static final float RAD_TO_DEG = 0.017453292F;

   @Invoker("getFov")
   public abstract float invokeGetActualFov(class_4184 var1, float var2, boolean var3);

   @Accessor("floatingItemTimeLeft")
   public abstract void setFloatingItemTimeLeft(int var1);

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void onRender(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
      this.setFloatingItemTimeLeft(this.field_4007 == 40 ? (int)((float)this.field_4007 - 40.0F * (float)(Integer)((TotemAnimation)Chorus.getInstance().getModuleManager().getModule(TotemAnimation.class)).time.getValue() * 0.01F) : this.field_4007);
   }

   @Inject(
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z",
   opcode = 180,
   ordinal = 0
)},
      method = {"renderWorld"}
   )
   private void onWorldRender(class_9779 tickCounter, CallbackInfo ci) {
      class_310 mc = class_310.method_1551();
      class_4184 camera = mc.field_1773.method_19418();
      class_4587 matrixStack = new class_4587();
      RenderSystem.getModelViewStack().pushMatrix().mul(matrixStack.method_23760().method_23761());
      matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
      Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
      Render3DEvent event = new Render3DEvent(Render3DEvent.Mode.PRE, matrixStack, tickCounter.method_60637(false), camera, (class_757)this, projectionMatrix, mc.field_1769);
      Chorus.getInstance().getEventManager().post(event);
      RenderSystem.getModelViewStack().popMatrix();
   }

   @ModifyExpressionValue(
      method = {"findCrosshairTarget"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;raycast(DFZ)Lnet/minecraft/util/hit/HitResult;"
)}
   )
   private class_239 findCrosshairTargetInject(class_239 original, class_1297 camera, double blockInteractionRange, double entityInteractionRange, float tickDelta) {
      return camera != mc.field_1724 ? original : (class_239)this.handleRotation(original, camera, (yaw, pitch) -> {
         return RotationUtils.rayTrace(yaw, pitch, (float)Math.max(blockInteractionRange, entityInteractionRange), tickDelta);
      });
   }

   @ModifyExpressionValue(
      method = {"findCrosshairTarget"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;getRotationVec(F)Lnet/minecraft/util/math/Vec3d;"
)}
   )
   private class_243 findCrosshairTargetInject(class_243 original, class_1297 camera, double blockInteractionRange, double entityInteractionRange, float tickDelta) {
      return camera != mc.field_1724 ? original : (class_243)this.handleRotation(original, camera, this::getRotationVec);
   }

   @Unique
   private <T> T handleRotation(T original, class_1297 camera, BiFunction<Float, Float, T> rotationHandler) {
      if (camera != mc.field_1724) {
         return original;
      } else {
         TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
         if (!rotationManager.isRotating()) {
            return rotationHandler.apply(camera.method_36454(), camera.method_36455());
         } else {
            float[] rotation = rotationManager.getCurrentRotation();
            return rotationHandler.apply(rotation[0], rotation[1]);
         }
      }
   }

   @Unique
   private class_243 getRotationVec(float yaw, float pitch) {
      float f = pitch * 0.017453292F;
      float g = -yaw * 0.017453292F;
      float h = class_3532.method_15362(g);
      float i = class_3532.method_15374(g);
      float j = class_3532.method_15362(f);
      float k = class_3532.method_15374(f);
      return new class_243((double)(i * j), (double)(-k), (double)(h * j));
   }

   @Inject(
      method = {"getBasicProjectionMatrix"},
      at = {@At("TAIL")},
      cancellable = true
   )
   public void getBasicProjectionMatrixHook(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
      if (((AspectRatio)Chorus.getInstance().getModuleManager().getModule(AspectRatio.class)).isEnabled()) {
         class_4587 matrixStack = new class_4587();
         matrixStack.method_23760().method_23761().identity();
         if (this.field_4005 != 1.0F) {
            matrixStack.method_46416(this.field_3988, -this.field_4004, 0.0F);
            matrixStack.method_22905(this.field_4005, this.field_4005, 1.0F);
         }

         matrixStack.method_23760().method_23761().mul((new Matrix4f()).setPerspective((float)((double)fovDegrees * 0.01745329238474369D), (Float)((AspectRatio)Chorus.getInstance().getModuleManager().getModule(AspectRatio.class)).getSettingRepository().getSetting("Aspect Ratio").getValue(), 0.05F, this.field_4025 * 4.0F));
         cir.setReturnValue(matrixStack.method_23760().method_23761());
      }

   }
}
