package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.impl.events.render.Render2DEvent;
import com.chorus.impl.modules.visual.Scoreboard;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_266;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_329.class})
public class InGameHudMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onWorldRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      Render2DEvent preRender2DEvent = new Render2DEvent(context, Render2DEvent.Mode.PRE);
      Chorus.getInstance().getEventManager().post(preRender2DEvent);
      if (preRender2DEvent.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")},
      cancellable = true
   )
   public void onWorldRenderPost(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      Render2DEvent postRender2DEvent = new Render2DEvent(context, Render2DEvent.Mode.POST);
      Chorus.getInstance().getEventManager().post(postRender2DEvent);
      if (postRender2DEvent.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void renderScoreboardSidebar(class_332 context, class_266 objective, CallbackInfo ci) {
      if (((Scoreboard)Chorus.getInstance().getModuleManager().getModule(Scoreboard.class)).isEnabled()) {
         ci.cancel();
      }

   }
}
