package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.impl.modules.visual.AntiDebuff;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4588;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(EnvType.CLIENT)
@Mixin({class_4603.class})
public class InGameOverlayRendererMixin {
   @Redirect(
      method = {"renderFireOverlay"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/VertexConsumer;color(FFFF)Lnet/minecraft/client/render/VertexConsumer;"
)
   )
   private static class_4588 antiDebuffFire(class_4588 vertexConsumer, float red, float green, float blue, float alpha) {
      return ((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).isEnabled() && ((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).mode.getSpecificValue("Fire") ? vertexConsumer.method_22915(red, green, blue, 0.0F) : vertexConsumer.method_22915(red, green, blue, alpha);
   }
}
