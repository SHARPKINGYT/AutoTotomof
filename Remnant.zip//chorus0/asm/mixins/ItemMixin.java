package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.core.listener.impl.TickEventListener;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3959.class_242;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({class_1792.class})
public class ItemMixin implements QuickImports {
   @ModifyExpressionValue(
      method = {"raycast"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/PlayerEntity;getRotationVector(FF)Lnet/minecraft/util/math/Vec3d;"
)}
   )
   private static class_243 silentRotationItemUse(class_243 original, class_1937 world, class_1657 player, class_242 fluidHandling) {
      TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
      return rotationManager.isRotating() ? mc.field_1724.method_5631(rotationManager.getPitch(), rotationManager.getYaw()) : player.method_5720();
   }
}
