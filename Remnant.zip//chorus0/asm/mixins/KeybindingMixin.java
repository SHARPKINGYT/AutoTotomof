package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.impl.modules.movement.SnapTap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_3675.class_306;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_304.class})
public class KeybindingMixin {
   @Final
   @Shadow
   private class_306 field_1654;
   @Shadow
   private boolean field_1653;
   @Unique
   private static final int[] KEY_CODES = new int[]{65, 68, 87, 83};

   @Inject(
      method = {"isPressed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onGetPressed(CallbackInfoReturnable<Boolean> cir) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null && Chorus.getInstance().getModuleManager().isModuleEnabled(SnapTap.class) && this.field_1653) {
         int keyCode = this.field_1654.method_1444();

         for(int i = 0; i < KEY_CODES.length; ++i) {
            if (keyCode == KEY_CODES[i]) {
               long currentTime = this.getCurrentTime(i);
               long oppositeTime = this.getOppositeTime(i);
               if (oppositeTime == 0L) {
                  cir.setReturnValue(true);
               } else {
                  cir.setReturnValue(oppositeTime <= currentTime);
               }

               cir.cancel();
               return;
            }
         }
      }

   }

   @Inject(
      method = {"setPressed"},
      at = {@At("HEAD")}
   )
   public void setPressed(boolean pressed, CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null && Chorus.getInstance().getModuleManager().isModuleEnabled(SnapTap.class)) {
         int keyCode = this.field_1654.method_1444();

         for(int i = 0; i < KEY_CODES.length; ++i) {
            if (keyCode == KEY_CODES[i]) {
               this.setCurrentTime(i, pressed ? System.currentTimeMillis() : 0L);
               return;
            }
         }
      }

   }

   @Unique
   private long getCurrentTime(int index) {
      switch(index) {
      case 0:
         return SnapTap.LEFT_STRAFE_LAST_PRESS_TIME;
      case 1:
         return SnapTap.RIGHT_STRAFE_LAST_PRESS_TIME;
      case 2:
         return SnapTap.FORWARD_STRAFE_LAST_PRESS_TIME;
      case 3:
         return SnapTap.BACKWARD_STRAFE_LAST_PRESS_TIME;
      default:
         return 0L;
      }
   }

   @Unique
   private long getOppositeTime(int index) {
      switch(index) {
      case 0:
         return SnapTap.RIGHT_STRAFE_LAST_PRESS_TIME;
      case 1:
         return SnapTap.LEFT_STRAFE_LAST_PRESS_TIME;
      case 2:
         return SnapTap.BACKWARD_STRAFE_LAST_PRESS_TIME;
      case 3:
         return SnapTap.FORWARD_STRAFE_LAST_PRESS_TIME;
      default:
         return 0L;
      }
   }

   @Unique
   private void setCurrentTime(int index, long time) {
      switch(index) {
      case 0:
         SnapTap.LEFT_STRAFE_LAST_PRESS_TIME = time;
         break;
      case 1:
         SnapTap.RIGHT_STRAFE_LAST_PRESS_TIME = time;
         break;
      case 2:
         SnapTap.FORWARD_STRAFE_LAST_PRESS_TIME = time;
         break;
      case 3:
         SnapTap.BACKWARD_STRAFE_LAST_PRESS_TIME = time;
      }

   }
}
