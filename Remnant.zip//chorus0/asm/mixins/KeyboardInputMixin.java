package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.impl.events.input.MovementInputEvent;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({class_743.class})
public abstract class KeyboardInputMixin extends InputMixin {
   @ModifyExpressionValue(
      method = {"tick"},
      at = {@At(
   value = "NEW",
   target = "(ZZZZZZZ)Lnet/minecraft/util/PlayerInput;"
)}
   )
   private class_10185 playerInput(class_10185 original) {
      float movementForward = class_743.method_40218(original.comp_3159(), original.comp_3160());
      float movementSideways = class_743.method_40218(original.comp_3161(), original.comp_3162());
      MovementInputEvent inputEvent = new MovementInputEvent(original.comp_3159(), original.comp_3160(), original.comp_3161(), original.comp_3162(), original.comp_3163(), original.comp_3164(), original.comp_3165(), movementForward, movementSideways);
      Chorus.getInstance().getEventManager().post(inputEvent);
      return new class_10185(inputEvent.getMovementForward() > 0.0F, inputEvent.getMovementForward() < 0.0F, inputEvent.getMovementSideways() > 0.0F, inputEvent.getMovementSideways() < 0.0F, inputEvent.isJumping(), inputEvent.isSneaking(), inputEvent.isSprinting());
   }
}
