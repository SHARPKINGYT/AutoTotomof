package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.api.module.ModuleSwitcher;
import com.chorus.impl.events.input.KeyPressEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_309.class})
public class KeyboardMixin {
   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")}
   )
   public void onKey(long window, int key, int scancode, int action, int mods, CallbackInfo info) {
      if (scancode >= 0 && key != -1) {
         if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null) {
            if (!(class_310.method_1551().field_1755 instanceof class_408)) {
               if (action == 1) {
                  Chorus.getInstance().getModuleManager().getModules().forEach((module) -> {
                     if (module.getKey() == key) {
                        (new ModuleSwitcher(Chorus.getInstance().getModuleManager())).toggleModule(module.getClass());
                     }

                  });
               }

               KeyPressEvent event = new KeyPressEvent(key, scancode, action, mods);
               if (!(class_310.method_1551().field_1755 instanceof class_408)) {
                  if (Chorus.getInstance().getEventManager() != null) {
                     Chorus.getInstance().getEventManager().post(event);
                  }

               }
            }
         }
      }
   }
}
