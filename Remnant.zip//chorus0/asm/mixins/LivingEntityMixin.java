package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.core.listener.impl.TickEventListener;
import com.chorus.impl.events.player.MoveFixEvent;
import com.chorus.impl.events.player.TickAIEvent;
import com.chorus.impl.modules.other.NoDelay;
import com.chorus.impl.modules.visual.AntiDebuff;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_1309.class})
public class LivingEntityMixin implements QuickImports {
   @Shadow
   public int field_6228;

   @ModifyConstant(
      method = {"getBlockingItem"},
      constant = {@Constant(
   intValue = 5
)}
   )
   private int noShieldDelay(int originalValue) {
      return (Integer)((NoDelay)Chorus.getInstance().getModuleManager().getModule(NoDelay.class)).shieldDelay.getValue();
   }

   @Inject(
      method = {"tickNewAi"},
      at = {@At("HEAD")}
   )
   private void hookAITIck(CallbackInfo callbackInfo) {
      Chorus.getInstance().getEventManager().post(new TickAIEvent());
   }

   @ModifyExpressionValue(
      method = {"tick"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getYaw()F"
)},
      slice = {@Slice(
   to = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getYaw()F",
   ordinal = 1
)
)}
   )
   private float tickInject(float original) {
      if (this != mc.field_1724) {
         return original;
      } else {
         TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
         return rotationManager.isRotating() ? rotationManager.getCurrentRotation()[0] : original;
      }
   }

   @ModifyExpressionValue(
      method = {"turnHead"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getYaw()F"
)}
   )
   private float turnHeadInject(float original) {
      if (this != mc.field_1724) {
         return original;
      } else {
         TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
         return rotationManager.isRotating() ? rotationManager.getCurrentRotation()[0] : original;
      }
   }

   @Inject(
      method = {"tickMovement"},
      at = {@At("HEAD")}
   )
   private void jumpDelay(CallbackInfo callbackInfo) {
      if (((NoDelay)Chorus.getInstance().getModuleManager().getModule(NoDelay.class)).jumpDelay.getValue()) {
         this.field_6228 = 0;
      }

   }

   @Redirect(
      method = {"jump"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getYaw()F",
   ordinal = 0
)
   )
   private float hookJump(class_1309 entity) {
      if (mc.field_1724 != null) {
         MoveFixEvent eventJump = new MoveFixEvent(entity.method_36454());
         Chorus.getInstance().getEventManager().post(eventJump);
         return eventJump.getYaw();
      } else {
         return entity.method_36454();
      }
   }

   @ModifyExpressionValue(
      method = {"calcGlidingVelocity"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getPitch()F"
)}
   )
   private float setElytraPitch(float original) {
      if (this != mc.field_1724) {
         return original;
      } else {
         TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
         return rotationManager.isRotating() ? rotationManager.getCurrentRotation()[1] : original;
      }
   }

   @ModifyExpressionValue(
      method = {"calcGlidingVelocity"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;"
)}
   )
   private class_243 setElytraDirection(class_243 original) {
      if (this != mc.field_1724) {
         return original;
      } else {
         TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
         return rotationManager.isRotating() ? mc.field_1724.method_5631(rotationManager.getPitch(), rotationManager.getYaw()) : original;
      }
   }

   @Inject(
      method = {"hasStatusEffect"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void antiDebuffNausea(class_6880<class_1291> potionEffect, CallbackInfoReturnable<Boolean> cir) {
      if (((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).isEnabled()) {
         if (potionEffect == class_1294.field_5916 && ((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).mode.getSpecificValue("Nausea")) {
            cir.cancel();
            cir.setReturnValue(false);
         }

         if (potionEffect == class_1294.field_5919 && ((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).mode.getSpecificValue("Blindness")) {
            cir.cancel();
            cir.setReturnValue(false);
         }

         if (potionEffect == class_1294.field_38092 && ((AntiDebuff)Chorus.getInstance().getModuleManager().getModule(AntiDebuff.class)).mode.getSpecificValue("Darkness")) {
            cir.cancel();
            cir.setReturnValue(false);
         }
      }

   }
}
