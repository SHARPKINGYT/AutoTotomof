package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.core.listener.impl.TickEventListener;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_3532;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({class_922.class})
public class LivingEntityRendererMixin<T extends class_1309, S extends class_10042> implements QuickImports {
   @ModifyExpressionValue(
      method = {"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;getLerpedPitch(F)F"
)}
   )
   private float setPitch(float original, class_1309 entity, S state, float tickDelta) {
      if (mc.field_1724 != entity) {
         return original;
      } else {
         TickEventListener rotationManager = (TickEventListener)Chorus.getInstance().getListenerRepository().getListeners().get(0);
         return rotationManager.isRotating() && rotationManager.getCurrentRotation() != null ? class_3532.method_16439(tickDelta, rotationManager.getPrevPitch(), rotationManager.getPitch()) : original;
      }
   }
}
