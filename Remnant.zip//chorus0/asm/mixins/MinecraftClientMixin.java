package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.BlockBreakingEvent;
import com.chorus.impl.events.player.ItemUseCooldownEvent;
import com.chorus.impl.events.player.ItemUseEvent;
import com.chorus.impl.events.player.SwingEvent;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.events.world.WorldChangeEvent;
import com.chorus.impl.modules.other.MultiTask;
import com.chorus.impl.modules.visual.PlayerESP;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_310.class})
public class MinecraftClientMixin implements QuickImports {
   @Shadow
   private int field_1752;
   @Shadow
   @Final
   public class_315 field_1690;
   @Shadow
   @Nullable
   public class_636 field_1761;
   @Shadow
   @Nullable
   public class_746 field_1724;

   @Inject(
      at = {@At("HEAD")},
      method = {"doItemUse"},
      cancellable = true
   )
   private void onDoItemUse(CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         ItemUseEvent preItemUseEvent = new ItemUseEvent(ItemUseEvent.Mode.PRE);
         Chorus.getInstance().getEventManager().post(preItemUseEvent);
         if (preItemUseEvent.isCancelled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/MinecraftClient;itemUseCooldown:I",
   shift = Shift.AFTER
)}
   )
   private void ItemUseCooldown(CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         ItemUseCooldownEvent event = new ItemUseCooldownEvent(this.field_1752);
         Chorus.getInstance().getEventManager().post(event);
         this.field_1752 = event.getSpeed();
      }
   }

   @Inject(
      at = {@At("TAIL")},
      method = {"doItemUse"},
      cancellable = true
   )
   private void onDoItemUsePost(CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         ItemUseEvent postItemUseEvent = new ItemUseEvent(ItemUseEvent.Mode.POST);
         Chorus.getInstance().getEventManager().post(postItemUseEvent);
         if (postItemUseEvent.isCancelled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      at = {@At("HEAD")},
      method = {"doAttack"},
      cancellable = true
   )
   private void onAttack(CallbackInfoReturnable<Boolean> cir) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         SwingEvent preSwingEvent = new SwingEvent(SwingEvent.Mode.PRE);
         Chorus.getInstance().getEventManager().post(preSwingEvent);
         if (preSwingEvent.isCancelled()) {
            cir.setReturnValue(false);
         }

      }
   }

   @Inject(
      at = {@At("TAIL")},
      method = {"doAttack"}
   )
   private void onAttackPost(CallbackInfoReturnable<Boolean> cir) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         SwingEvent postSwingEvent = new SwingEvent(SwingEvent.Mode.POST);
         Chorus.getInstance().getEventManager().post(postSwingEvent);
         if (postSwingEvent.isCancelled()) {
            cir.cancel();
         }

      }
   }

   @Inject(
      at = {@At("HEAD")},
      method = {"tick"},
      cancellable = true
   )
   private void onTick(CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         TickEvent preTickEvent = new TickEvent(TickEvent.Mode.PRE);
         Chorus.getInstance().getEventManager().post(preTickEvent);
         if (preTickEvent.isCancelled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      at = {@At("TAIL")},
      method = {"tick"},
      cancellable = true
   )
   private void onTickPost(CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         TickEvent postTickEvent = new TickEvent(TickEvent.Mode.POST);
         Chorus.getInstance().getEventManager().post(postTickEvent);
         if (postTickEvent.isCancelled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"handleBlockBreaking"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onBlockBreakingPre(boolean breaking, CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         BlockBreakingEvent blockBreakingEvent = new BlockBreakingEvent(BlockBreakingEvent.Mode.PRE);
         Chorus.getInstance().getEventManager().post(blockBreakingEvent);
         if (blockBreakingEvent.isCancelled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"handleBlockBreaking"},
      at = {@At("TAIL")},
      cancellable = true
   )
   private void onBlockBreakingPost(boolean breaking, CallbackInfo ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getEventManager() != null) {
         BlockBreakingEvent blockBreakingEvent = new BlockBreakingEvent(BlockBreakingEvent.Mode.POST);
         Chorus.getInstance().getEventManager().post(blockBreakingEvent);
         if (blockBreakingEvent.isCancelled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"hasOutline"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hasOutline(class_1297 entity, CallbackInfoReturnable<Boolean> ci) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null) {
         PlayerESP module = (PlayerESP)Chorus.getInstance().getModuleManager().getModule(PlayerESP.class);
         if (module != null && module.isEnabled()) {
            if (module.espMode.getValue().equals("Glow Minecraft")) {
               if (entity.method_31747()) {
                  if (!module.exclude.getSpecificValue("Friends") || !friendRepository.isFriend(entity.method_5667())) {
                     if (!module.exclude.getSpecificValue("Bots") || !npcRepository.isNPC(entity.method_5820())) {
                        if (!module.exclude.getSpecificValue("Teams") || !teamRepository.isMemberOfCurrentTeam(entity.method_5820())) {
                           ci.setReturnValue(true);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @ModifyExpressionValue(
      method = {"doItemUse"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;isBreakingBlock()Z"
)}
   )
   private boolean doItemUseModifyIsBreakingBlock(boolean original) {
      return (Chorus.getInstance().getModuleManager() == null || !Chorus.getInstance().getModuleManager().isModuleEnabled(MultiTask.class)) && original;
   }

   @ModifyExpressionValue(
      method = {"handleBlockBreaking"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"
)}
   )
   private boolean handleBlockBreakingModifyIsUsingItem(boolean original) {
      return (Chorus.getInstance().getModuleManager() == null || !Chorus.getInstance().getModuleManager().isModuleEnabled(MultiTask.class)) && original;
   }

   @ModifyExpressionValue(
      method = {"handleInputEvents"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z",
   ordinal = 0
)}
   )
   private boolean handleInputEventsModifyIsUsingItem(boolean original) {
      return (Chorus.getInstance().getModuleManager() == null || !Chorus.getInstance().getModuleManager().isModuleEnabled(MultiTask.class)) && original;
   }

   @Inject(
      method = {"handleInputEvents"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z",
   ordinal = 0,
   shift = Shift.BEFORE
)}
   )
   private void handleInputEventsInjectStopUsingItem(CallbackInfo info) {
      if (Chorus.getInstance().getModuleManager() != null && Chorus.getInstance().getModuleManager().isModuleEnabled(MultiTask.class) && mc.field_1724.method_6115()) {
         if (!mc.field_1690.field_1904.method_1434()) {
            mc.field_1761.method_2897(mc.field_1724);
         }

         while(true) {
            if (mc.field_1690.field_1904.method_1436()) {
               continue;
            }
         }
      }

   }

   @Inject(
      method = {"setWorld"},
      at = {@At("HEAD")}
   )
   private void setWorldInject(class_638 world, CallbackInfo ci) {
      Chorus.getInstance().getEventManager().post(new WorldChangeEvent(world));
   }
}
