package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.api.module.ModuleManager;
import com.chorus.common.QuickImports;
import com.chorus.impl.modules.client.Capes;
import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_640.class})
public class PlayerListEntryMixin implements QuickImports {
   @Shadow
   @Final
   private GameProfile field_3741;

   @Inject(
      method = {"getSkinTextures"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void getSkinTextures(CallbackInfoReturnable<class_8685> ci) {
      class_310 mc = class_310.method_1551();
      class_8685 textures = (class_8685)ci.getReturnValue();
      if (((Capes)Chorus.getInstance().getModuleManager().getModule(Capes.class)).isEnabled() && (mc.field_1724 == null || this.field_3741.getId().equals(mc.field_1724.method_7334().getId()))) {
         ModuleManager var10001 = Chorus.getInstance().getModuleManager();
         class_2960 customCape = class_2960.method_60655("chorus", "capes/" + ((Capes)var10001.getModule(Capes.class)).cape + ".png");
         ci.setReturnValue(new class_8685(textures.comp_1626(), textures.comp_1911(), customCape, textures.comp_1628(), textures.comp_1629(), textures.comp_1630()));
      }

   }
}
