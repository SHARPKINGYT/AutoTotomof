package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.impl.modules.other.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_9779.class_9781;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_9781.class})
public class RenderTickCounterMixin {
   @Shadow
   private float field_51958;

   @Inject(
      method = {"beginRenderTick(J)I"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/render/RenderTickCounter$Dynamic;lastFrameDuration:F",
   shift = Shift.AFTER
)}
   )
   private void beginRenderTickInject(CallbackInfoReturnable<Integer> callback) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null) {
         if (((Timer)Chorus.getInstance().getModuleManager().getModule(Timer.class)).isEnabled()) {
            float timerSpeed = (float)(Double)((Timer)Chorus.getInstance().getModuleManager().getModule(Timer.class)).getSettingRepository().getSetting("Speed").getValue();
            if (timerSpeed > 0.0F) {
               this.field_51958 *= timerSpeed;
            }

         }
      }
   }
}
