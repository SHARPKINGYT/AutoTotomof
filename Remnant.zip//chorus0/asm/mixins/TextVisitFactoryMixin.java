package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.impl.modules.other.Streamer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_5223;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Environment(EnvType.CLIENT)
@Mixin({class_5223.class})
public class TextVisitFactoryMixin implements QuickImports {
   @ModifyArg(
      method = {"visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/text/TextVisitFactory;visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
   ordinal = 0
),
      index = 0
   )
   private static String injectVisitFormatted(String string) {
      if (Chorus.getInstance() != null && Chorus.getInstance().getModuleManager() != null) {
         if (!((Streamer)Chorus.getInstance().getModuleManager().getModule(Streamer.class)).isEnabled()) {
            return string;
         } else {
            return mc.field_1724 == null ? string : string.replace(mc.field_1724.method_5820(), "Chorus User");
         }
      } else {
         return string;
      }
   }
}
