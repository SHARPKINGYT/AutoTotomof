package chorus0.asm.mixins;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.impl.modules.visual.PlayerESP;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Environment(EnvType.CLIENT)
@Mixin({class_761.class})
public abstract class WorldRendererMixin implements QuickImports {
   @Unique
   private boolean shouldRenderOutline(class_1297 entity) {
      PlayerESP module = (PlayerESP)Chorus.getInstance().getModuleManager().getModule(PlayerESP.class);
      entity.method_5834(true);
      return true;
   }
}
