package com.chorus.api.command;

import chorus0.Chorus;
import com.chorus.api.command.exception.CommandException;
import com.chorus.common.QuickImports;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.util.Arrays;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;
import org.apache.commons.lang3.StringUtils;

@Environment(EnvType.CLIENT)
public abstract class BaseCommand implements QuickImports {
   private final CommandInfo commandInfo = (CommandInfo)this.getClass().getAnnotation(CommandInfo.class);
   public static final int SINGLE_SUCCESS = 1;

   public BaseCommand() {
      if (this.commandInfo == null) {
         throw new CommandException("Command missing @CommandInfo annotation: " + this.getClass().getName());
      }
   }

   public abstract void build(LiteralArgumentBuilder<class_2172> var1);

   public void registerTo(CommandDispatcher<class_2172> dispatcher) {
      this.register(dispatcher, this.commandInfo.name());
      String[] var2 = this.commandInfo.aliases();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String alias = var2[var4];
         this.register(dispatcher, alias);
      }

   }

   protected void register(CommandDispatcher<class_2172> dispatcher, String name) {
      LiteralArgumentBuilder<class_2172> builder = literal(name);
      this.build(builder);
      dispatcher.register(builder);
   }

   protected static <T> RequiredArgumentBuilder<class_2172, T> argument(String name, ArgumentType<T> type) {
      return RequiredArgumentBuilder.argument(name, type);
   }

   protected static LiteralArgumentBuilder<class_2172> literal(String name) {
      return LiteralArgumentBuilder.literal(name);
   }

   public static String nameToTitle(String name) {
      return (String)Arrays.stream(name.split("-")).map(StringUtils::capitalize).collect(Collectors.joining(" "));
   }

   public String toString() {
      String var10000 = Chorus.getInstance().getCommandManager().getPrefix();
      return var10000 + this.commandInfo.name();
   }

   public String toString(String... args) {
      StringBuilder base = new StringBuilder(this.toString());
      String[] var3 = args;
      int var4 = args.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String arg = var3[var5];
         base.append(' ').append(arg);
      }

      return base.toString();
   }

   public CommandInfo getCommandInfo() {
      return this.commandInfo;
   }
}
