package com.chorus.api.command;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Environment(EnvType.CLIENT)
public @interface CommandInfo {
   String name();

   String description() default "";

   String[] aliases() default {};
}
