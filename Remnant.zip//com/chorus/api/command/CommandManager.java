package com.chorus.api.command;

import com.chorus.api.command.exception.CommandException;
import com.chorus.impl.commands.BindCommand;
import com.chorus.impl.commands.ConfigCommand;
import com.chorus.impl.commands.FriendCommand;
import com.chorus.impl.commands.PrefixCommand;
import com.chorus.impl.commands.ToggleCommand;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Arrays;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_637;

@Environment(EnvType.CLIENT)
public class CommandManager {
   private String prefix = ".";
   private final CommandDispatcher<class_2172> dispatcher = new CommandDispatcher();
   private final class_2172 commandSource = new CommandManager.ChatCommandSource(class_310.method_1551());
   private final CommandRepository repository;
   private static final List<Class<? extends BaseCommand>> COMMAND_REGISTRATIONS = Arrays.asList(PrefixCommand.class, ConfigCommand.class, BindCommand.class, FriendCommand.class, ToggleCommand.class);

   public CommandManager() {
      this.repository = new CommandRepository(this.dispatcher);
   }

   public void init() {
      this.registerCommands();
   }

   private void registerCommands() {
      COMMAND_REGISTRATIONS.forEach((commandClass) -> {
         try {
            BaseCommand command = (BaseCommand)commandClass.getDeclaredConstructor().newInstance();
            this.repository.register(command);
         } catch (Exception var3) {
            throw new CommandException("Failed to initialize command: " + commandClass.getSimpleName(), var3);
         }
      });
   }

   public void registerCommand(Class<? extends BaseCommand> commandClass) {
      try {
         BaseCommand command = (BaseCommand)commandClass.getDeclaredConstructor().newInstance();
         this.repository.register(command);
      } catch (Exception var3) {
         throw new CommandException("Failed to register command: " + commandClass.getSimpleName(), var3);
      }
   }

   public void dispatch(String message) throws CommandSyntaxException {
      ParseResults<class_2172> results = this.dispatcher.parse(message, this.commandSource);
      this.dispatcher.execute(results);
   }

   public String getPrefix() {
      return this.prefix;
   }

   public CommandDispatcher<class_2172> getDispatcher() {
      return this.dispatcher;
   }

   public class_2172 getCommandSource() {
      return this.commandSource;
   }

   public CommandRepository getRepository() {
      return this.repository;
   }

   public CommandManager setPrefix(String prefix) {
      this.prefix = prefix;
      return this;
   }

   @Environment(EnvType.CLIENT)
   private static final class ChatCommandSource extends class_637 {
      public ChatCommandSource(class_310 client) {
         super((class_634)null, client);
      }
   }
}
