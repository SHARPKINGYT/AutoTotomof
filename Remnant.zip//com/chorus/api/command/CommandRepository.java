package com.chorus.api.command;

import com.chorus.api.command.exception.CommandException;
import com.mojang.brigadier.CommandDispatcher;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class CommandRepository {
   private static final Logger log = LogManager.getLogger(CommandRepository.class);
   private final Map<String, BaseCommand> commands = new HashMap();
   private final CommandDispatcher<class_2172> dispatcher;

   public void register(BaseCommand command) {
      CommandInfo info = command.getCommandInfo();
      if (this.commands.containsKey(info.name())) {
         throw new CommandException("Duplicate command registration: " + info.name());
      } else {
         this.commands.put(info.name(), command);
         command.registerTo(this.dispatcher);
         String[] var3 = info.aliases();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String alias = var3[var5];
            this.commands.put(alias, command);
         }

         log.info("Registered command: {} with aliases: {}", info.name(), Arrays.toString(info.aliases()));
      }
   }

   public CommandRepository(CommandDispatcher<class_2172> dispatcher) {
      this.dispatcher = dispatcher;
   }
}
