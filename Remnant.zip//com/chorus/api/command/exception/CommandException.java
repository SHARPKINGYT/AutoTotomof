package com.chorus.api.command.exception;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CommandException extends RuntimeException {
   private final String message;
   private final Throwable cause;

   public CommandException(String message) {
      this(message, (Throwable)null);
   }

   public String getMessage() {
      return this.message;
   }

   public Throwable getCause() {
      return this.cause;
   }

   public CommandException(String message, Throwable cause) {
      this.message = message;
      this.cause = cause;
   }
}
