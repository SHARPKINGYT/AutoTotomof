package com.chorus.api.module;

import chorus0.Chorus;
import com.chorus.api.module.exception.ModuleException;
import com.chorus.api.module.setting.SettingRepository;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.impl.modules.visual.Notifications;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class BaseModule implements Module {
   private boolean enabled = false;
   private final SettingRepository settingRepository = new SettingRepository();
   private final ModuleInfo moduleInfo = (ModuleInfo)this.getClass().getAnnotation(ModuleInfo.class);
   private int keyBind;
   private SettingCategory parent;
   private String suffix;
   private float width;
   private float height = 0.0F;
   private boolean isDraggable = false;

   protected BaseModule() {
      if (this.moduleInfo == null) {
         throw new ModuleException("ModuleInfo annotation is missing on " + this.getClass().getName());
      } else {
         this.keyBind = this.moduleInfo.key();
         this.suffix = this.moduleInfo.suffix().isEmpty() ? null : this.moduleInfo.suffix();
      }
   }

   public void onDisable() {
      if (this.enabled) {
         this.enabled = false;
         Chorus.getInstance().getEventManager().unregister(this);
         this.onModuleDisabled();
         if (((Notifications)Chorus.getInstance().getModuleManager().getModule(Notifications.class)).isEnabled() && ((Notifications)Chorus.getInstance().getModuleManager().getModule(Notifications.class)).enableNotifications.getValue()) {
            Chorus.getInstance().getNotificationManager().addNotification("Disabled Module", this.getName(), 2500);
         }
      }

   }

   public void onEnable() {
      if (!this.enabled) {
         this.enabled = true;
         Chorus.getInstance().getEventManager().register(this);
         this.onModuleEnabled();
         if (((Notifications)Chorus.getInstance().getModuleManager().getModule(Notifications.class)).isEnabled() && ((Notifications)Chorus.getInstance().getModuleManager().getModule(Notifications.class)).enableNotifications.getValue()) {
            Chorus.getInstance().getNotificationManager().addNotification("Enabled Module", this.getName(), 2500);
         }
      }

   }

   protected void onModuleDisabled() {
   }

   protected void onModuleEnabled() {
   }

   public ModuleCategory getCategory() {
      return this.moduleInfo.category();
   }

   public String getDescription() {
      return this.moduleInfo.description();
   }

   public int getKey() {
      return this.keyBind;
   }

   public void setKey(int key) {
      this.keyBind = key;
   }

   public String getName() {
      return this.moduleInfo.name();
   }

   public String getSuffix() {
      return this.suffix == null ? "" : this.suffix;
   }

   public float getWidth() {
      return this.width;
   }

   public float getHeight() {
      return this.height;
   }

   public boolean isDraggable() {
      return this.isDraggable;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public SettingRepository getSettingRepository() {
      return this.settingRepository;
   }

   public int getKeyBind() {
      return this.keyBind;
   }

   public void setKeyBind(int keyBind) {
      this.keyBind = keyBind;
   }

   public SettingCategory getParent() {
      return this.parent;
   }

   public void setSuffix(String suffix) {
      this.suffix = suffix;
   }

   public void setWidth(float width) {
      this.width = width;
   }

   public void setHeight(float height) {
      this.height = height;
   }

   public void setDraggable(boolean isDraggable) {
      this.isDraggable = isDraggable;
   }
}
