package com.chorus.api.module;

import com.chorus.api.module.setting.SettingRepository;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface Module {
   void onDisable();

   void onEnable();

   ModuleCategory getCategory();

   String getDescription();

   boolean isEnabled();

   int getKey();

   void setKey(int var1);

   String getName();

   String getSuffix();

   SettingRepository getSettingRepository();

   float getWidth();

   float getHeight();

   boolean isDraggable();
}
