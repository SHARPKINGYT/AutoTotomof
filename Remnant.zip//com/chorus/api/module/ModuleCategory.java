package com.chorus.api.module;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum ModuleCategory {
   COMBAT("Combat", "A", "\ue2b3"),
   MOVEMENT("Movement", "C", "\ue424"),
   VISUAL("Visual", "D", "\ue0be"),
   UTILITY("Utility", "B", "\ue4f5"),
   OTHER("Other", "F", "\ue104"),
   CLIENT("Client", "B", "\ue19e");

   private final String name;
   private final String icon;
   private final String lucideIcon;

   private ModuleCategory(final String name, final String icon, final String lucideIcon) {
      this.name = name;
      this.icon = icon;
      this.lucideIcon = lucideIcon;
   }

   public final String toString() {
      return this.name;
   }

   public String getName() {
      return this.name;
   }

   public String getIcon() {
      return this.icon;
   }

   public String getLucideIcon() {
      return this.lucideIcon;
   }

   // $FF: synthetic method
   private static ModuleCategory[] $values() {
      return new ModuleCategory[]{COMBAT, MOVEMENT, VISUAL, UTILITY, OTHER, CLIENT};
   }
}
