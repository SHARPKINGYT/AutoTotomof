package com.chorus.api.module;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Environment(EnvType.CLIENT)
public @interface ModuleInfo {
   String name();

   String description() default "";

   ModuleCategory category();

   int key() default -1;

   String suffix() default "";
}
