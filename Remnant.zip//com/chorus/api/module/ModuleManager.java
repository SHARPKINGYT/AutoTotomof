package com.chorus.api.module;

import com.chorus.api.module.exception.ModuleException;
import com.chorus.api.module.setting.SettingManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class ModuleManager implements ModuleProvider {
   private static final Logger log = LoggerFactory.getLogger(ModuleManager.class);
   private static final ModuleManager INSTANCE = new ModuleManager();
   private final Map<Class<? extends Module>, Module> modules = Collections.synchronizedMap(new LinkedHashMap());
   private final SettingManager settingManager = new SettingManager();
   private final ModuleSwitcher moduleSwitcher = new ModuleSwitcher(this);

   public <T extends Module> void disableModule(Class<T> moduleClass) {
      T module = this.getModule(moduleClass);
      if (module != null) {
         this.moduleSwitcher.disableModule(moduleClass);
         log.info("Disabled module: {}", module.getName());
      }

   }

   public <T extends Module> void enableModule(Class<T> moduleClass) {
      T module = this.getModule(moduleClass);
      if (module != null) {
         this.moduleSwitcher.enableModule(moduleClass);
         log.info("Enabled module: {}", module.getName());
      }

   }

   public void registerModule(Module module) {
      if (module == null) {
         throw new ModuleException("Attempted to register a null module.");
      } else {
         Class<? extends Module> moduleClass = module.getClass();
         if (this.modules.containsKey(moduleClass)) {
            throw new ModuleException("Module '" + module.getName() + "' is already registered.");
         } else {
            this.modules.put(moduleClass, module);

            try {
               this.settingManager.registerSettings(module);
               log.info("Registered module: {}", module.getName());
            } catch (ModuleException var4) {
               log.error("Failed to register settings for module '{}': {}", module.getName(), var4.getMessage());
               throw var4;
            }
         }
      }
   }

   public <T extends Module> void toggleModule(Class<T> moduleClass) {
      T module = this.getModule(moduleClass);
      if (module != null) {
         this.moduleSwitcher.toggleModule(moduleClass);
         log.info("Toggled module: {}", module.getName());
      }

   }

   public void unregisterModule(Module module) {
      if (module == null) {
         throw new ModuleException("Attempted to unregister a null module.");
      } else {
         Class<? extends Module> moduleClass = module.getClass();
         if (this.modules.remove(moduleClass) != null) {
            this.settingManager.unregisterSettings(module);
            log.info("Unregistered module: {}", module.getName());
         } else {
            log.warn("Module '{}' was not found for unregistration.", module.getName());
            throw new ModuleException("Module '" + module.getName() + "' was not found for unregistration.");
         }
      }
   }

   public <T extends Module> T getModule(Class<T> moduleClass) {
      return (Module)this.modules.get(moduleClass);
   }

   public <T extends Module> boolean isModuleEnabled(Class<T> moduleClass) {
      T module = this.getModule(moduleClass);
      return module != null && module.isEnabled();
   }

   public List<Module> getModules() {
      return new ArrayList(this.modules.values());
   }

   public List<Module> getModulesByCategory(ModuleCategory category) {
      List<Module> categorizedModules = new ArrayList();
      Iterator var3 = this.modules.values().iterator();

      while(var3.hasNext()) {
         Module module = (Module)var3.next();
         if (module.getCategory() == category) {
            categorizedModules.add(module);
         }
      }

      return categorizedModules;
   }

   public Module getModuleByName(String name) {
      Iterator var2 = this.modules.values().iterator();

      Module module;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         module = (Module)var2.next();
      } while(!module.getName().equalsIgnoreCase(name));

      return module;
   }

   public static ModuleManager getINSTANCE() {
      return INSTANCE;
   }
}
