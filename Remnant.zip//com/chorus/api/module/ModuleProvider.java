package com.chorus.api.module;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface ModuleProvider {
   void registerModule(Module var1);

   void unregisterModule(Module var1);

   <T extends Module> T getModule(Class<T> var1);

   List<Module> getModules();
}
