package com.chorus.api.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ModuleRepository implements ModuleProvider {
   private final Map<Class<? extends Module>, Module> modules = new ConcurrentHashMap();

   public void registerModule(Module module) {
      this.modules.put(module.getClass(), module);
   }

   public void unregisterModule(Module module) {
      this.modules.remove(module.getClass());
   }

   public <T extends Module> T getModule(Class<T> moduleClass) {
      return (Module)this.modules.get(moduleClass);
   }

   public List<Module> getModules() {
      return new ArrayList(this.modules.values());
   }
}
