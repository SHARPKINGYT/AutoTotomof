package com.chorus.api.module.exception;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ModuleException extends RuntimeException {
   private final String message;
   private final Throwable cause;

   public ModuleException(String message) {
      this(message, (Throwable)null);
   }

   public String getMessage() {
      return this.message;
   }

   public Throwable getCause() {
      return this.cause;
   }

   public ModuleException(String message, Throwable cause) {
      this.message = message;
      this.cause = cause;
   }
}
