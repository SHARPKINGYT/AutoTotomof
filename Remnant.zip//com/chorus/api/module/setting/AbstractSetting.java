package com.chorus.api.module.setting;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class AbstractSetting<T> implements Setting<T> {
   private Supplier<Boolean> renderCondition = () -> {
      return true;
   };

   public Supplier<Boolean> getRenderCondition() {
      return this.renderCondition;
   }

   public void setRenderCondition(Supplier<Boolean> condition) {
      this.renderCondition = condition;
   }
}
