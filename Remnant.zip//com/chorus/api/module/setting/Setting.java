package com.chorus.api.module.setting;

import com.chorus.api.module.setting.implement.SettingCategory;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface Setting<T> {
   T getDefaultValue();

   String getDescription();

   String getName();

   T getValue();

   void setValue(T var1);

   SettingCategory getParent();

   Supplier<Boolean> getRenderCondition();

   void setRenderCondition(Supplier<Boolean> var1);

   default boolean shouldRender() {
      return this.getParent() != null && !this.getParent().shouldRender() ? false : (Boolean)this.getRenderCondition().get();
   }
}
