package com.chorus.api.module.setting;

import com.chorus.api.module.exception.ModuleException;
import java.lang.reflect.Field;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SettingManager {
   private final SettingRepository settingRepository = new SettingRepository();

   public void registerSettings(Object module) {
      Field[] var2 = module.getClass().getDeclaredFields();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Field field = var2[var4];
         if (Setting.class.isAssignableFrom(field.getType())) {
            field.setAccessible(true);

            try {
               Setting<?> setting = (Setting)field.get(module);
               if (setting == null) {
                  String var10002 = field.getName();
                  throw new ModuleException("Setting field " + var10002 + " is null in " + module.getClass().getName());
               }

               this.settingRepository.registerSetting(setting);
            } catch (IllegalAccessException var7) {
               throw new ModuleException("Failed to access setting field: " + field.getName(), var7);
            }
         }
      }

   }

   public void unregisterSettings(Object module) {
      Field[] var2 = module.getClass().getDeclaredFields();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Field field = var2[var4];
         if (Setting.class.isAssignableFrom(field.getType())) {
            field.setAccessible(true);

            try {
               Setting<?> setting = (Setting)field.get(module);
               if (setting == null) {
                  String var10002 = field.getName();
                  throw new ModuleException("Setting field " + var10002 + " is null in " + module.getClass().getName());
               }

               this.settingRepository.unregisterSetting(setting);
            } catch (IllegalAccessException var7) {
               throw new ModuleException("Failed to access setting field: " + field.getName(), var7);
            }
         }
      }

   }

   public SettingRepository getSettingRepository() {
      return this.settingRepository;
   }
}
