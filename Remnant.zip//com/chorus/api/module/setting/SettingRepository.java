package com.chorus.api.module.setting;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SettingRepository {
   private final Map<String, Setting<?>> settings = Collections.synchronizedMap(new LinkedHashMap());

   public void registerSetting(Setting<?> setting) {
      if (setting != null) {
         this.settings.put(setting.getName(), setting);
      } else {
         throw new IllegalArgumentException("Cannot register a null setting.");
      }
   }

   public void registerSettings(Setting<?>... settings) {
      if (settings == null) {
         throw new IllegalArgumentException("Cannot register a null array of settings.");
      } else {
         Setting[] var2 = settings;
         int var3 = settings.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Setting<?> setting = var2[var4];
            this.registerSetting(setting);
         }

      }
   }

   public void unregisterSetting(Setting<?> setting) {
      if (setting != null) {
         this.settings.remove(setting.getName());
      } else {
         throw new IllegalArgumentException("Cannot unregister a null setting.");
      }
   }

   public Setting<?> getSetting(String name) {
      return (Setting)this.settings.get(name);
   }

   public Map<String, Setting<?>> getSettings() {
      return this.settings;
   }
}
