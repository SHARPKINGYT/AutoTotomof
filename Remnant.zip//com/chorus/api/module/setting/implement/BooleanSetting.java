package com.chorus.api.module.setting.implement;

import com.chorus.api.module.setting.AbstractSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class BooleanSetting extends AbstractSetting<Boolean> {
   private final String name;
   private final String description;
   private Boolean value;
   private final Boolean defaultValue;
   private SettingCategory parent;

   public BooleanSetting(String name, String description, Boolean defaultValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
   }

   public BooleanSetting(SettingCategory parent, String name, String description, Boolean defaultValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
      this.parent = parent;
   }

   public void toggle() {
      this.value = !this.value;
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public Boolean getValue() {
      return this.value;
   }

   public Boolean getDefaultValue() {
      return this.defaultValue;
   }

   public SettingCategory getParent() {
      return this.parent;
   }

   public void setValue(Boolean value) {
      this.value = value;
   }

   public void setParent(SettingCategory parent) {
      this.parent = parent;
   }
}
