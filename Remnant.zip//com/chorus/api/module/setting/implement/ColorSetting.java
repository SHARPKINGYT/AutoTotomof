package com.chorus.api.module.setting.implement;

import com.chorus.api.module.setting.AbstractSetting;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ColorSetting extends AbstractSetting<Color> {
   private final String name;
   private final String description;
   private Color value;
   private final Color defaultValue;
   private SettingCategory parent;

   public ColorSetting(String name, String description, Color defaultValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
   }

   public ColorSetting(SettingCategory parent, String name, String description, Color defaultValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
      this.parent = parent;
   }

   public void setColor(int red, int green, int blue, int alpha) {
      this.value = new Color(red, green, blue, alpha);
   }

   public void setColor(int red, int green, int blue) {
      this.value = new Color(red, green, blue);
   }

   public int getRed() {
      return this.value.getRed();
   }

   public int getGreen() {
      return this.value.getGreen();
   }

   public int getBlue() {
      return this.value.getBlue();
   }

   public int getAlpha() {
      return this.value.getAlpha();
   }

   public int getRGB() {
      return this.value.getRGB();
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public Color getValue() {
      return this.value;
   }

   public Color getDefaultValue() {
      return this.defaultValue;
   }

   public SettingCategory getParent() {
      return this.parent;
   }

   public void setValue(Color value) {
      this.value = value;
   }

   public void setParent(SettingCategory parent) {
      this.parent = parent;
   }
}
