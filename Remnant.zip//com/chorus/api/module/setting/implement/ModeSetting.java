package com.chorus.api.module.setting.implement;

import com.chorus.api.module.exception.ModuleException;
import com.chorus.api.module.setting.AbstractSetting;
import java.util.Arrays;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ModeSetting extends AbstractSetting<String> {
   private final String name;
   private final String description;
   private String value;
   private final String defaultValue;
   private final List<String> modes;
   private SettingCategory parent;

   public ModeSetting(String name, String description, String defaultValue, String... modes) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
      this.modes = Arrays.asList(modes);
   }

   public ModeSetting(SettingCategory parent, String name, String description, String defaultValue, String... modes) {
      this.parent = parent;
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
      this.modes = Arrays.asList(modes);
   }

   public void cycle() {
      int index = this.modes.indexOf(this.value);
      index = (index + 1) % this.modes.size();
      this.value = (String)this.modes.get(index);
   }

   public String getDefaultValue() {
      return this.defaultValue;
   }

   public void setMode(String mode) {
      if (this.modes.contains(mode)) {
         this.value = mode;
      } else {
         throw new ModuleException("Invalid mode: " + mode + " for setting: " + this.name);
      }
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public List<String> getModes() {
      return this.modes;
   }

   public SettingCategory getParent() {
      return this.parent;
   }

   public void setValue(String value) {
      this.value = value;
   }

   public void setParent(SettingCategory parent) {
      this.parent = parent;
   }

   public String getValue() {
      return this.value;
   }
}
