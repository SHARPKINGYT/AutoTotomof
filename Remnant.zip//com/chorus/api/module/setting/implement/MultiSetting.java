package com.chorus.api.module.setting.implement;

import com.chorus.api.module.exception.ModuleException;
import com.chorus.api.module.setting.AbstractSetting;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MultiSetting extends AbstractSetting<Set<String>> {
   private final String name;
   private final String description;
   private final List<String> modes;
   private Set<String> selectedModes;
   private SettingCategory parent;

   public MultiSetting(String name, String description, String... modes) {
      this.name = name;
      this.description = description;
      this.modes = Arrays.asList(modes);
      this.selectedModes = new HashSet();
   }

   public MultiSetting(SettingCategory parent, String name, String description, String... modes) {
      this.name = name;
      this.description = description;
      this.modes = Arrays.asList(modes);
      this.selectedModes = new HashSet();
      this.parent = parent;
   }

   public void deselectMode(String mode) {
      if (!this.modes.contains(mode)) {
         throw new ModuleException("Cannot deselect invalid mode: " + mode + " for MultiSetting: " + this.name);
      } else {
         this.selectedModes.remove(mode);
      }
   }

   public void selectMode(String mode) {
      if (this.modes.contains(mode)) {
         this.selectedModes.add(mode);
      } else {
         throw new ModuleException("Invalid mode: " + mode + " for MultiSetting: " + this.name);
      }
   }

   public Set<String> getDefaultValue() {
      return new HashSet(this.selectedModes);
   }

   public Boolean getSpecificValue(String string) {
      return this.selectedModes.contains(string);
   }

   public Set<String> getValue() {
      return this.selectedModes;
   }

   public void setValue(Set<String> value) {
      Iterator var2 = value.iterator();

      String mode;
      do {
         if (!var2.hasNext()) {
            this.selectedModes = value;
            return;
         }

         mode = (String)var2.next();
      } while(this.modes.contains(mode));

      throw new ModuleException("Invalid mode: " + mode + " in set for MultiSetting: " + this.name);
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public List<String> getModes() {
      return this.modes;
   }

   public Set<String> getSelectedModes() {
      return this.selectedModes;
   }

   public SettingCategory getParent() {
      return this.parent;
   }
}
