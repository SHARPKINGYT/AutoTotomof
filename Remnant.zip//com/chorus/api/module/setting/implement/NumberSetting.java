package com.chorus.api.module.setting.implement;

import com.chorus.api.module.exception.ModuleException;
import com.chorus.api.module.setting.AbstractSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.jodah.typetools.TypeResolver;

@Environment(EnvType.CLIENT)
public class NumberSetting<T extends Number & Comparable<T>> extends AbstractSetting<T> {
   private final String name;
   private final String description;
   private T value;
   private final T defaultValue;
   private final T minValue;
   private final T maxValue;
   private SettingCategory parent;

   public NumberSetting(String name, String description, T defaultValue, T minValue, T maxValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
      this.minValue = minValue;
      this.maxValue = maxValue;
      Class<?>[] typeArgs = TypeResolver.resolveRawArguments(NumberSetting.class, this.getClass());
   }

   public NumberSetting(SettingCategory parent, String name, String description, T defaultValue, T minValue, T maxValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
      this.minValue = minValue;
      this.maxValue = maxValue;
      this.parent = parent;
      Class<?>[] typeArgs = TypeResolver.resolveRawArguments(NumberSetting.class, this.getClass());
   }

   public T getDefaultValue() {
      return this.defaultValue;
   }

   public void setValue(T value) {
      if (((Comparable)value).compareTo(this.minValue) >= 0 && ((Comparable)value).compareTo(this.maxValue) <= 0) {
         this.value = value;
      } else {
         String var10002 = String.valueOf(value);
         throw new ModuleException("Value " + var10002 + " is out of bounds for setting: " + this.name + ". Must be between " + String.valueOf(this.minValue) + " and " + String.valueOf(this.maxValue));
      }
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public T getValue() {
      return this.value;
   }

   public T getMinValue() {
      return this.minValue;
   }

   public T getMaxValue() {
      return this.maxValue;
   }

   public SettingCategory getParent() {
      return this.parent;
   }
}
