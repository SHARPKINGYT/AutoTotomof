package com.chorus.api.module.setting.implement;

import com.chorus.api.module.exception.ModuleException;
import com.chorus.api.module.setting.AbstractSetting;
import com.chorus.common.util.math.MathUtils;
import java.util.Arrays;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.jodah.typetools.TypeResolver;

@Environment(EnvType.CLIENT)
public class RangeSetting<T extends Number & Comparable<T>> extends AbstractSetting<Number[]> {
   private final String name;
   private final String description;
   private T min;
   private T max;
   private T valueMin;
   private T valueMax;
   private SettingCategory parent;

   public RangeSetting(String name, String description, T min, T max, T valueMin, T valueMax) {
      this.name = name;
      this.description = description;
      this.min = min;
      this.max = max;
      this.valueMin = valueMin;
      this.valueMax = valueMax;
      Class<?>[] typeArgs = TypeResolver.resolveRawArguments(RangeSetting.class, this.getClass());
      System.out.println("Resolved type arguments: " + Arrays.toString(typeArgs));
   }

   public RangeSetting(SettingCategory parent, String name, String description, T min, T max, T valueMin, T valueMax) {
      this.parent = parent;
      this.name = name;
      this.description = description;
      this.min = min;
      this.max = max;
      this.valueMin = valueMin;
      this.valueMax = valueMax;
      Class<?>[] typeArgs = TypeResolver.resolveRawArguments(RangeSetting.class, this.getClass());
   }

   public Number[] getDefaultValue() {
      return new Number[]{this.min, this.max};
   }

   public Number[] getValue() {
      return new Number[]{this.valueMin, this.valueMax};
   }

   public Number getRandomValue() {
      return MathUtils.randomNumber(this.valueMin, this.valueMax);
   }

   public void setValue(Number[] values) {
      if (values.length == 2 && values[0] instanceof Number && values[1] instanceof Number) {
         if (((Comparable)values[0]).compareTo(this.min) >= 0 && ((Comparable)values[1]).compareTo(this.max) <= 0) {
            this.valueMin = values[0];
            this.valueMax = values[1];
         } else {
            String var10002 = String.valueOf(this.min);
            throw new ModuleException("Values must be within bounds [" + var10002 + ", " + String.valueOf(this.max) + "] for RangeSetting: " + this.name);
         }
      } else {
         throw new ModuleException("Values must be an array of two Numbers for RangeSetting: " + this.name);
      }
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public T getMin() {
      return this.min;
   }

   public T getMax() {
      return this.max;
   }

   public T getValueMin() {
      return this.valueMin;
   }

   public T getValueMax() {
      return this.valueMax;
   }

   public SettingCategory getParent() {
      return this.parent;
   }
}
