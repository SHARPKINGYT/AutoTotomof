package com.chorus.api.module.setting.implement;

import com.chorus.api.module.setting.AbstractSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SettingCategory extends AbstractSetting<Object> {
   private final String name;

   public SettingCategory(String name) {
      this.name = name;
   }

   public Object getDefaultValue() {
      return null;
   }

   public String getDescription() {
      return null;
   }

   public Object getValue() {
      return null;
   }

   public void setValue(Object value) {
   }

   public SettingCategory getParent() {
      return null;
   }

   public String getName() {
      return this.name;
   }
}
