package com.chorus.api.module.setting.implement;

import com.chorus.api.module.setting.AbstractSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class StringSetting extends AbstractSetting<String> {
   private final String name;
   private final String description;
   private String value;
   private final String defaultValue;
   private SettingCategory parent;

   public StringSetting(String name, String description, String defaultValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
   }

   public StringSetting(SettingCategory parent, String name, String description, String defaultValue) {
      this.name = name;
      this.description = description;
      this.value = defaultValue;
      this.defaultValue = defaultValue;
      this.parent = parent;
   }

   public String getDefaultValue() {
      return this.defaultValue;
   }

   public void setValue(String value) {
      this.value = value;
   }

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public String getValue() {
      return this.value;
   }

   public SettingCategory getParent() {
      return this.parent;
   }
}
