package com.chorus.api.repository.bot;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
class Bot {
   private final UUID uuid;
   private final String name;
   private final Set<BotRepository.Flag> flags;

   public Bot(UUID uuid, String name, Set<BotRepository.Flag> flags) {
      this.uuid = uuid;
      this.name = name;
      this.flags = flags;
   }

   public void addFlags(BotRepository.Flag... flagsToAdd) {
      this.flags.addAll(Arrays.asList(flagsToAdd));
   }

   public boolean hasFlags(BotRepository.Flag... flagsToCheck) {
      return this.flags.containsAll(Arrays.asList(flagsToCheck));
   }

   public boolean hasFlags(List<BotRepository.Flag> flags) {
      return this.flags.containsAll(flags);
   }

   public UUID getUuid() {
      return this.uuid;
   }

   public Set<BotRepository.Flag> getFlags() {
      return this.flags;
   }

   public String toString() {
      String var10000 = String.valueOf(this.getUuid());
      return "Bot(uuid=" + var10000 + ", name=" + this.getName() + ", flags=" + String.valueOf(this.getFlags()) + ")";
   }

   public String getName() {
      return this.name;
   }
}
