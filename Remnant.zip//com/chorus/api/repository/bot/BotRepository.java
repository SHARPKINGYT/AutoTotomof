package com.chorus.api.repository.bot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class BotRepository {
   private final List<Bot> npcs = new ArrayList();
   private final List<Bot> players = new ArrayList();

   public void registerPlayer(String name, UUID uuid, BotRepository.Flag... flags) {
      Set<BotRepository.Flag> flagSet = new HashSet(Arrays.asList(flags));
      if (this.players.stream().noneMatch((player) -> {
         return player.getName().equals(name);
      })) {
         this.players.add(new Bot(uuid, name, flagSet));
      }

   }

   public boolean isRegistered(String name) {
      return this.players.stream().anyMatch((player) -> {
         return player.getName().equals(name);
      });
   }

   public void registerNPC(String name, UUID uuid, BotRepository.Flag... flags) {
      Set<BotRepository.Flag> flagSet = new HashSet(Arrays.asList(flags));
      if (this.npcs.stream().noneMatch((npc) -> {
         return npc.getName().equals(name);
      })) {
         this.npcs.add(new Bot(uuid, name, flagSet));
      }

   }

   public boolean isNPC(String name) {
      return this.npcs.stream().anyMatch((npc) -> {
         return npc.getName().equals(name);
      });
   }

   public void addFlags(String name, BotRepository.Flag... flags) {
      BotRepository.Flag[] var3 = flags;
      int var4 = flags.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         BotRepository.Flag flag = var3[var5];
         this.players.stream().filter((player) -> {
            return player.getName().equals(name) && !player.hasFlags(flag);
         }).forEach((player) -> {
            player.addFlags(flag);
         });
         this.npcs.stream().filter((npc) -> {
            return npc.getName().equals(name) && !npc.hasFlags(flag);
         }).forEach((npc) -> {
            npc.addFlags(flag);
         });
      }

   }

   public void meetsCriteria(List<BotRepository.Flag> criteria) {
      List<Bot> makePlayer = new ArrayList();
      List<Bot> makeNPC = new ArrayList();
      Iterator var4 = this.players.iterator();

      Bot npc;
      while(var4.hasNext()) {
         npc = (Bot)var4.next();
         if (!npc.hasFlags(criteria) && !this.npcs.contains(npc)) {
            makeNPC.add(npc);
         }
      }

      var4 = this.npcs.iterator();

      while(var4.hasNext()) {
         npc = (Bot)var4.next();
         if (npc.hasFlags(criteria) && !this.players.contains(npc)) {
            makePlayer.add(npc);
         }
      }

      this.npcs.addAll(makeNPC);
      this.npcs.removeAll(makePlayer);
   }

   public void clear(boolean NPCS, boolean Players) {
      if (Players) {
         this.players.clear();
      }

      if (NPCS) {
         this.npcs.clear();
      }

   }

   public List<Bot> getNpcs() {
      return this.npcs;
   }

   public List<Bot> getPlayers() {
      return this.players;
   }

   @Environment(EnvType.CLIENT)
   public static enum Flag {
      MOVED,
      TOUCHED_GROUND,
      TOUCHED_AIR,
      SWUNG,
      DAMAGED,
      ROTATED;

      // $FF: synthetic method
      private static BotRepository.Flag[] $values() {
         return new BotRepository.Flag[]{MOVED, TOUCHED_GROUND, TOUCHED_AIR, SWUNG, DAMAGED, ROTATED};
      }
   }
}
