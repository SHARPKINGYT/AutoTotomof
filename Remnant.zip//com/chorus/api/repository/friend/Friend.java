package com.chorus.api.repository.friend;

import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Friend {
   private final UUID id;
   private final String name;

   public UUID getId() {
      return this.id;
   }

   public String getName() {
      return this.name;
   }

   public String toString() {
      String var10000 = String.valueOf(this.getId());
      return "Friend(id=" + var10000 + ", name=" + this.getName() + ")";
   }

   public Friend(UUID id, String name) {
      this.id = id;
      this.name = name;
   }
}
