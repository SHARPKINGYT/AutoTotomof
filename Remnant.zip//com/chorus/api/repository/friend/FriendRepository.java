package com.chorus.api.repository.friend;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class FriendRepository {
   private final List<Friend> friends = new ArrayList();

   public boolean addFriend(Friend friend) {
      return !this.friends.contains(friend) ? this.friends.add(friend) : false;
   }

   public boolean removeFriend(UUID id) {
      return this.friends.removeIf((friend) -> {
         return friend.getId().equals(id);
      });
   }

   public boolean removeFriend(String name) {
      return this.friends.removeIf((friend) -> {
         return friend.getName().equals(name);
      });
   }

   public void clear() {
      this.friends.clear();
   }

   public List<UUID> getAllFriends() {
      List<UUID> friendIds = new ArrayList();
      Iterator var2 = this.friends.iterator();

      while(var2.hasNext()) {
         Friend friend = (Friend)var2.next();
         friendIds.add(friend.getId());
      }

      return friendIds;
   }

   public boolean isFriend(UUID id) {
      return this.friends.stream().anyMatch((friend) -> {
         return friend.getId().equals(id);
      });
   }

   public boolean isFriend(String name) {
      return this.friends.stream().anyMatch((friend) -> {
         return friend.getName().equals(name);
      });
   }

   public List<Friend> getFriends() {
      return this.friends;
   }
}
