package com.chorus.api.repository.team;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Team {
   private final String name;
   private final List<String> members;

   public Team(String name) {
      this.name = name;
      this.members = new ArrayList();
   }

   public void addMember(String member) {
      if (!this.members.contains(member)) {
         this.members.add(member);
      }

   }

   public void removeMember(String member) {
      this.members.remove(member);
   }

   public void clear() {
      this.members.clear();
   }

   public boolean isMember(String member) {
      return this.members.contains(member);
   }

   public String getName() {
      return this.name;
   }

   public List<String> getMembers() {
      return this.members;
   }
}
