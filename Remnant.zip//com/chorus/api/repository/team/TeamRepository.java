package com.chorus.api.repository.team;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TeamRepository {
   public Team currentTeam;

   public void addMemberToCurrentTeam(String member) {
      if (this.currentTeam != null) {
         this.currentTeam.addMember(member);
      }

   }

   public void removeMemberFromCurrentTeam(String member) {
      if (this.currentTeam != null) {
         this.currentTeam.removeMember(member);
      }

   }

   public void clear() {
      if (this.currentTeam != null) {
         this.currentTeam.clear();
      }
   }

   public List<String> getCurrentTeamMembers() {
      return (List)(this.currentTeam != null ? this.currentTeam.getMembers() : new ArrayList());
   }

   public boolean isMemberOfCurrentTeam(String member) {
      return this.currentTeam != null && this.currentTeam.isMember(member);
   }

   public void setTeam(String name) {
      if (this.currentTeam == null || !this.currentTeam.getName().equalsIgnoreCase(name)) {
         this.currentTeam = new Team(name);
      }

   }

   public Team getCurrentTeam() {
      return this.currentTeam;
   }
}
