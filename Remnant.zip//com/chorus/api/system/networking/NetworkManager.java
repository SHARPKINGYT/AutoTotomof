package com.chorus.api.system.networking;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.auth.AuthenticationService;
import com.chorus.api.system.networking.auth.UserData;
import com.chorus.api.system.networking.connection.ConnectionManager;
import com.chorus.api.system.networking.connection.HeartbeatManager;
import com.chorus.api.system.networking.packet.Packet;
import com.chorus.api.system.networking.packet.PacketProcessor;
import com.chorus.api.system.networking.service.JarSizeService;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@IncludeReference
@Environment(EnvType.CLIENT)
public class NetworkManager {
   private static NetworkManager instance = new NetworkManager();
   private final ConnectionManager connectionManager = ConnectionManager.builder().build();
   private final HeartbeatManager heartbeatManager;
   private final PacketProcessor packetProcessor;
   private final AuthenticationService authService;
   private final JarSizeService jarSizeService;
   private final ScheduledExecutorService heartbeatExecutor = this.createScheduledExecutor(this.createHeartbeatThreadFactory());
   private final ExecutorService networkExecutor = this.createCachedExecutor(this.createNetworkThreadFactory());

   private NetworkManager() {
      this.heartbeatManager = HeartbeatManager.builder().connectionManager(this.connectionManager).heartbeatExecutor(this.heartbeatExecutor).build();
      this.packetProcessor = PacketProcessor.builder().connectionManager(this.connectionManager).networkExecutor(this.networkExecutor).build();
      this.authService = AuthenticationService.builder().connectionManager(this.connectionManager).networkExecutor(this.networkExecutor).build();
      this.jarSizeService = JarSizeService.builder().connectionManager(this.connectionManager).networkExecutor(this.networkExecutor).build();
      this.packetProcessor.start();
   }

   private ThreadFactory createHeartbeatThreadFactory() {
      return (r) -> {
         Thread t = new Thread(r, "Heartbeat-Thread");
         t.setDaemon(true);
         return t;
      };
   }

   private ThreadFactory createNetworkThreadFactory() {
      return (r) -> {
         Thread t = new Thread(r, "Network-Thread");
         t.setDaemon(true);
         return t;
      };
   }

   public CompletableFuture<Void> connect() {
      CompletableFuture<Void> connectFuture = this.connectionManager.connect();
      connectFuture.thenRun(() -> {
         this.heartbeatManager.startHeartbeat();
      });
      return connectFuture;
   }

   public void disconnect() {
      if (this.connectionManager.isConnected()) {
         this.connectionManager.disconnect();
         class_310.method_1551().execute(() -> {
            class_310.method_1551().method_1592();
         });
      }

   }

   public CompletableFuture<UserData> login(String username, String password, String hwid) {
      return this.authService.login(username, password, hwid);
   }

   public CompletableFuture<Boolean> checkJarSize(String version) {
      return this.jarSizeService.checkJarSize(version);
   }

   public static void queuePacket(String packet) {
      getInstance().packetProcessor.queuePacket(packet);
   }

   public static void queuePacket(Packet packet) {
      getInstance().packetProcessor.queuePacket(packet);
   }

   public boolean isConnected() {
      return this.connectionManager.isConnected();
   }

   public String readResponse() throws IOException {
      String response = this.connectionManager.readResponse();
      if (response == null) {
         String lastLoginResponse = this.authService.getLastLoginResponse();
         if (lastLoginResponse != null) {
            return lastLoginResponse;
         }
      }

      return response;
   }

   public void sendPacket(String packet) {
      this.connectionManager.sendPacket(packet);
   }

   public void sendPacket(Packet packet) {
      this.connectionManager.sendPacket(packet.serialize());
   }

   public void shutdown() {
      this.disconnect();
      this.heartbeatExecutor.shutdownNow();
      this.networkExecutor.shutdownNow();
   }

   public UserData getCurrentUser() {
      return this.authService.getCurrentUser();
   }

   public static NetworkManager.Builder builder() {
      return new NetworkManager.Builder();
   }

   private ScheduledExecutorService createScheduledExecutor(ThreadFactory factory) {
      return Executors.newSingleThreadScheduledExecutor(factory);
   }

   private ExecutorService createCachedExecutor(ThreadFactory factory) {
      return Executors.newCachedThreadPool(factory);
   }

   public static NetworkManager getInstance() {
      return instance;
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      public NetworkManager build() {
         return NetworkManager.getInstance();
      }
   }
}
