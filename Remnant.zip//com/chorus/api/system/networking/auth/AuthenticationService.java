package com.chorus.api.system.networking.auth;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.connection.ConnectionManager;
import com.chorus.api.system.networking.packet.factory.PacketFactory;
import com.chorus.api.system.networking.response.factory.ResponseHandlerFactory;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import sun.misc.Unsafe;

@IncludeReference
@Environment(EnvType.CLIENT)
public class AuthenticationService {
   private final ConnectionManager connectionManager;
   private final ExecutorService networkExecutor;
   private volatile String lastLoginResponse;
   private volatile UserData currentUser;

   private AuthenticationService(AuthenticationService.Builder builder) {
      this.connectionManager = builder.connectionManager;
      this.networkExecutor = builder.networkExecutor;

      try {
         String[] debugFlags = new String[]{"-javaagent", "-Xdebug", "-agentlib", "-Xrunjdwp", "-Xnoagent", "-DproxySet", "-DproxyHost", "-DproxyPort", "-Djavax.net.ssl.trustStorePassword"};
         Iterator var3 = ManagementFactory.getRuntimeMXBean().getInputArguments().iterator();

         while(var3.hasNext()) {
            String vmArg = (String)var3.next();
            int length = debugFlags.length;

            for(int i = 0; i < length; ++i) {
               if (vmArg.toLowerCase(Locale.ROOT).contains(debugFlags[i].toLowerCase(Locale.ROOT))) {
                  Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
                  unsafeField.setAccessible(true);
                  ((Unsafe)unsafeField.get((Object)null)).putAddress(0L, 0L);
               }
            }
         }

      } catch (Exception var8) {
         throw new RuntimeException();
      }
   }

   public CompletableFuture<UserData> login(String username, String password, String hwid) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            this.connectionManager.sendPacket(PacketFactory.createLoginPacket(username, password, hwid).serialize());
            String response = this.waitForResponse();
            if (response == null) {
               return null;
            } else {
               UserData userData = (UserData)ResponseHandlerFactory.getLoginResponseHandler().handle(response);
               if (userData == null && response.contains("expiry=N/A")) {
                  this.lastLoginResponse = response;
               }

               if (userData != null) {
                  this.currentUser = userData;
               }

               return userData;
            }
         } catch (IOException var6) {
            var6.printStackTrace();
            return null;
         }
      }, this.networkExecutor);
   }

   private String waitForResponse() throws IOException {
      long startTime = System.currentTimeMillis();
      String response = null;

      while(System.currentTimeMillis() - startTime < 10000L && this.connectionManager.isConnected()) {
         response = this.connectionManager.readResponse();
         if (response != null) {
            break;
         }

         try {
            Thread.sleep(100L);
         } catch (InterruptedException var5) {
            Thread.currentThread().interrupt();
            break;
         }
      }

      return response;
   }

   public String getLastLoginResponse() {
      String temp = this.lastLoginResponse;
      this.lastLoginResponse = null;
      return temp;
   }

   public static AuthenticationService.Builder builder() {
      return new AuthenticationService.Builder();
   }

   public UserData getCurrentUser() {
      return this.currentUser;
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private ConnectionManager connectionManager;
      private ExecutorService networkExecutor;

      public AuthenticationService.Builder connectionManager(ConnectionManager connectionManager) {
         this.connectionManager = connectionManager;
         return this;
      }

      public AuthenticationService.Builder networkExecutor(ExecutorService networkExecutor) {
         this.networkExecutor = networkExecutor;
         return this;
      }

      public AuthenticationService build() {
         if (this.connectionManager == null) {
            throw new IllegalStateException("ConnectionManager must be set");
         } else if (this.networkExecutor == null) {
            throw new IllegalStateException("NetworkExecutor must be set");
         } else {
            return new AuthenticationService(this);
         }
      }
   }
}
