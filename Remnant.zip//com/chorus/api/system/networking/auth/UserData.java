package com.chorus.api.system.networking.auth;

import cc.polymorphism.annot.IncludeReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class UserData {
   private String username;
   private String email;
   private String licenseKey;
   private String expiryDate;
   private String licenseType;

   private UserData() {
   }

   public boolean isLicenseValid() {
      if (this.licenseType != null && this.licenseType.equalsIgnoreCase("Lifetime")) {
         return true;
      } else {
         return this.expiryDate != null && !this.expiryDate.equals("N/A");
      }
   }

   public static UserData.UserDataBuilder builder() {
      return new UserData.UserDataBuilder();
   }

   public String getUsername() {
      return this.username;
   }

   public String getEmail() {
      return this.email;
   }

   public String getLicenseKey() {
      return this.licenseKey;
   }

   public String getExpiryDate() {
      return this.expiryDate;
   }

   public String getLicenseType() {
      return this.licenseType;
   }

   public void setUsername(String username) {
      this.username = username;
   }

   public void setEmail(String email) {
      this.email = email;
   }

   public void setLicenseKey(String licenseKey) {
      this.licenseKey = licenseKey;
   }

   public void setExpiryDate(String expiryDate) {
      this.expiryDate = expiryDate;
   }

   public void setLicenseType(String licenseType) {
      this.licenseType = licenseType;
   }

   @Environment(EnvType.CLIENT)
   public static class UserDataBuilder {
      private final UserData userData = new UserData();

      private UserDataBuilder() {
      }

      public UserData.UserDataBuilder username(String username) {
         this.userData.setUsername(username);
         return this;
      }

      public UserData.UserDataBuilder email(String email) {
         this.userData.setEmail(email);
         return this;
      }

      public UserData.UserDataBuilder licenseKey(String licenseKey) {
         this.userData.setLicenseKey(licenseKey);
         return this;
      }

      public UserData.UserDataBuilder expiryDate(String expiryDate) {
         this.userData.setExpiryDate(expiryDate);
         return this;
      }

      public UserData.UserDataBuilder licenseType(String licenseType) {
         this.userData.setLicenseType(licenseType);
         return this;
      }

      public UserData build() {
         return this.userData;
      }
   }
}
