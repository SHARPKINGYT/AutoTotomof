package com.chorus.api.system.networking.connection;

import cc.polymorphism.annot.IncludeReference;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class ConnectionManager {
   private static final String SERVER_HOST = "146.71.78.242";
   private static final int SERVER_PORT = 1234;
   private SSLSocket socket;
   private BufferedReader in;
   private PrintWriter out;
   private final AtomicBoolean isConnected = new AtomicBoolean(false);
   private final ReentrantLock socketLock = new ReentrantLock();
   private static SSLSocketFactory sslSocketFactory;

   public static void staticInit() {
      try {
         TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] chain, String authType) {
            }

            public X509Certificate[] getAcceptedIssuers() {
               return new X509Certificate[0];
            }
         }};
         SSLContext sc = SSLContext.getInstance("TLSv1.2");
         sc.init((KeyManager[])null, trustAllCerts, new SecureRandom());
         sslSocketFactory = sc.getSocketFactory();
         HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
         HostnameVerifier allHostsValid = (hostname, session) -> {
            return true;
         };
         HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
      } catch (Exception var3) {
         System.err.println("Failed to initialize SSL context");
      }

   }

   public CompletableFuture<Void> connect() {
      return CompletableFuture.runAsync(() -> {
         try {
            this.socketLock.lock();

            try {
               this.closeExistingConnection();
               System.out.println("Attempting to connect to the auth server...");
               this.socket = (SSLSocket)sslSocketFactory.createSocket("146.71.78.242", 1234);
               this.configureSocket();
               this.in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
               this.out = new PrintWriter(this.socket.getOutputStream(), true);
               this.isConnected.set(true);
               System.out.println("Connected to the auth server");
            } finally {
               this.socketLock.unlock();
            }
         } catch (SSLHandshakeException var6) {
            System.err.println("SSL Handshake failed");
            this.disconnect();
         } catch (Exception var7) {
            System.err.println("Connection failed");
            this.disconnect();
         }

      });
   }

   private void closeExistingConnection() {
      if (this.socket != null) {
         try {
            this.socket.close();
         } catch (Exception var2) {
         }
      }

   }

   private void configureSocket() throws IOException {
      SSLParameters sslParams = new SSLParameters();
      sslParams.setEndpointIdentificationAlgorithm((String)null);
      sslParams.setProtocols(new String[]{"TLSv1.2"});
      sslParams.setCipherSuites(this.socket.getSupportedCipherSuites());
      sslParams.setNeedClientAuth(false);
      sslParams.setWantClientAuth(false);
      this.socket.setSSLParameters(sslParams);
      this.socket.setSoTimeout(5000);

      try {
         this.socket.startHandshake();
      } catch (SSLHandshakeException var3) {
         System.err.println("Failed to configure socket");
      }

   }

   public void disconnect() {
      if (this.isConnected.compareAndSet(true, false)) {
         this.socketLock.lock();

         try {
            if (this.socket != null) {
               this.socket.close();
            }

            if (this.in != null) {
               this.in.close();
            }

            if (this.out != null) {
               this.out.close();
            }
         } catch (IOException var5) {
            var5.printStackTrace();
         } finally {
            this.socketLock.unlock();
         }
      }

   }

   public String readResponse() throws IOException {
      this.socketLock.lock();

      String var1;
      try {
         if (this.in != null && this.isConnected.get()) {
            var1 = this.in.readLine();
            return var1;
         }

         var1 = null;
      } finally {
         this.socketLock.unlock();
      }

      return var1;
   }

   public void sendPacket(String packet) {
      this.socketLock.lock();

      try {
         if (this.isConnected.get() && this.out != null) {
            this.out.println(packet);
         }
      } finally {
         this.socketLock.unlock();
      }

   }

   public void setTimeout(int timeout) {
      this.socketLock.lock();

      try {
         if (this.socket != null && this.isConnected.get()) {
            this.socket.setSoTimeout(timeout);
         }
      } catch (Exception var6) {
         System.err.println("Failed to set timeout");
         this.disconnect();
      } finally {
         this.socketLock.unlock();
      }

   }

   public boolean isConnected() {
      return this.isConnected.get();
   }

   public static ConnectionManager.Builder builder() {
      return new ConnectionManager.Builder();
   }

   public ReentrantLock getSocketLock() {
      return this.socketLock;
   }

   static {
      staticInit();
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private String host = "146.71.78.242";
      private int port = 1234;

      public ConnectionManager.Builder host(String host) {
         this.host = host;
         return this;
      }

      public ConnectionManager.Builder port(int port) {
         this.port = port;
         return this;
      }

      public ConnectionManager build() {
         return new ConnectionManager();
      }
   }
}
