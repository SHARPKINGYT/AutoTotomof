package com.chorus.api.system.networking.connection;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.packet.factory.PacketFactory;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@IncludeReference
@Environment(EnvType.CLIENT)
public class HeartbeatManager {
   private static final long HEARTBEAT_INTERVAL = 5000L;
   private static final int MAX_MISSED_HEARTBEATS = 3;
   private final ConnectionManager connectionManager;
   private final ScheduledExecutorService heartbeatExecutor;
   private final Random random = new SecureRandom();
   private volatile String lastHeartbeat;
   private int missedHeartbeats = 0;

   public HeartbeatManager(ConnectionManager connectionManager, ScheduledExecutorService heartbeatExecutor) {
      this.connectionManager = connectionManager;
      this.heartbeatExecutor = heartbeatExecutor;
   }

   public void startHeartbeat() {
      this.heartbeatExecutor.scheduleAtFixedRate(() -> {
         if (!this.connectionManager.isConnected()) {
            class_310.method_1551().method_1592();
         } else {
            this.connectionManager.getSocketLock().lock();

            try {
               int heartbeatNumber = this.random.nextInt();
               this.connectionManager.sendPacket(PacketFactory.createHeartbeatPacket(heartbeatNumber).serialize());
               this.connectionManager.setTimeout(3000);

               try {
                  String response = this.connectionManager.readResponse();
                  if (this.lastHeartbeat != null && this.lastHeartbeat.equals(response)) {
                     class_310.method_1551().method_1592();
                  }

                  if (response == null) {
                     ++this.missedHeartbeats;
                     if (this.missedHeartbeats >= 3) {
                        class_310.method_1551().method_1592();
                     }
                  } else {
                     this.missedHeartbeats = 0;
                     this.lastHeartbeat = response;
                  }
               } catch (IOException var21) {
                  ++this.missedHeartbeats;
                  if (this.missedHeartbeats >= 3) {
                     class_310.method_1551().method_1592();
                  }
               } finally {
                  try {
                     this.connectionManager.setTimeout(0);
                  } catch (Exception var20) {
                  }

               }
            } catch (Exception var23) {
               ++this.missedHeartbeats;
               if (this.missedHeartbeats >= 3) {
                  class_310.method_1551().method_1592();
               }
            } finally {
               this.connectionManager.getSocketLock().unlock();
            }

         }
      }, 5000L, 5000L, TimeUnit.MILLISECONDS);
   }

   public static HeartbeatManager.Builder builder() {
      return new HeartbeatManager.Builder();
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private ConnectionManager connectionManager;
      private ScheduledExecutorService heartbeatExecutor;

      public HeartbeatManager.Builder connectionManager(ConnectionManager connectionManager) {
         this.connectionManager = connectionManager;
         return this;
      }

      public HeartbeatManager.Builder heartbeatExecutor(ScheduledExecutorService heartbeatExecutor) {
         this.heartbeatExecutor = heartbeatExecutor;
         return this;
      }

      public HeartbeatManager build() {
         return new HeartbeatManager(this.connectionManager, this.heartbeatExecutor);
      }
   }
}
