package com.chorus.api.system.networking.packet;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.connection.ConnectionManager;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class PacketProcessor {
   private final BlockingQueue<String> packetQueue;
   private final ConnectionManager connectionManager;
   private final ExecutorService networkExecutor;

   private PacketProcessor(PacketProcessor.Builder builder) {
      this.packetQueue = builder.packetQueue;
      this.connectionManager = builder.connectionManager;
      this.networkExecutor = builder.networkExecutor;
   }

   public void start() {
      this.networkExecutor.submit(this::packetProcessingLoop);
   }

   private void packetProcessingLoop() {
      while(true) {
         if (!Thread.currentThread().isInterrupted()) {
            try {
               String packet = (String)this.packetQueue.poll(100L, TimeUnit.MILLISECONDS);
               if (packet != null) {
                  this.connectionManager.sendPacket(packet);
               }
               continue;
            } catch (InterruptedException var2) {
               Thread.currentThread().interrupt();
            }
         }

         return;
      }
   }

   public void queuePacket(String packet) {
      this.packetQueue.offer(packet);
   }

   public void queuePacket(Packet packet) {
      this.packetQueue.offer(packet.serialize());
   }

   public static PacketProcessor.Builder builder() {
      return new PacketProcessor.Builder();
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private BlockingQueue<String> packetQueue = new LinkedBlockingQueue();
      private ConnectionManager connectionManager;
      private ExecutorService networkExecutor;

      public PacketProcessor.Builder packetQueue(BlockingQueue<String> packetQueue) {
         this.packetQueue = packetQueue;
         return this;
      }

      public PacketProcessor.Builder connectionManager(ConnectionManager connectionManager) {
         this.connectionManager = connectionManager;
         return this;
      }

      public PacketProcessor.Builder networkExecutor(ExecutorService networkExecutor) {
         this.networkExecutor = networkExecutor;
         return this;
      }

      public PacketProcessor build() {
         if (this.connectionManager == null) {
            throw new IllegalStateException("ConnectionManager must be set");
         } else if (this.networkExecutor == null) {
            throw new IllegalStateException("NetworkExecutor must be set");
         } else {
            return new PacketProcessor(this);
         }
      }
   }
}
