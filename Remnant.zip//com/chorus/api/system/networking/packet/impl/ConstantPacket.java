package com.chorus.api.system.networking.packet.impl;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.packet.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class ConstantPacket implements Packet {
   private final String constantName;

   private ConstantPacket(ConstantPacket.Builder builder) {
      this.constantName = builder.constantName;
   }

   public String serialize() {
      return "CONST" + this.constantName;
   }

   public static ConstantPacket.Builder builder() {
      return new ConstantPacket.Builder();
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private String constantName;

      public ConstantPacket.Builder constantName(String constantName) {
         this.constantName = constantName;
         return this;
      }

      public ConstantPacket build() {
         return new ConstantPacket(this);
      }
   }
}
