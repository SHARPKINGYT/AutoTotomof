package com.chorus.api.system.networking.packet.impl;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.packet.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class HeartbeatPacket implements Packet {
   private final int heartbeatNumber;

   private HeartbeatPacket(HeartbeatPacket.Builder builder) {
      this.heartbeatNumber = builder.heartbeatNumber;
   }

   public String serialize() {
      return "HEARTBEAT" + this.heartbeatNumber;
   }

   public static HeartbeatPacket.Builder builder() {
      return new HeartbeatPacket.Builder();
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private int heartbeatNumber;

      public HeartbeatPacket.Builder heartbeatNumber(int heartbeatNumber) {
         this.heartbeatNumber = heartbeatNumber;
         return this;
      }

      public HeartbeatPacket build() {
         return new HeartbeatPacket(this);
      }
   }
}
