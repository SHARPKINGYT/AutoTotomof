package com.chorus.api.system.networking.packet.impl;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.packet.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class JarSizePacket implements Packet {
   private final String version;

   private JarSizePacket(JarSizePacket.Builder builder) {
      this.version = builder.version;
   }

   public String serialize() {
      return "JAR_SIZE" + this.version;
   }

   public static JarSizePacket.Builder builder() {
      return new JarSizePacket.Builder();
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private String version;

      public JarSizePacket.Builder version(String version) {
         this.version = version;
         return this;
      }

      public JarSizePacket build() {
         if (this.version != null && !this.version.isEmpty()) {
            return new JarSizePacket(this);
         } else {
            throw new IllegalStateException("Version must be set");
         }
      }
   }
}
