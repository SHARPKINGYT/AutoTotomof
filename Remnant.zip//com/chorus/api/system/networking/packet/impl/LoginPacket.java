package com.chorus.api.system.networking.packet.impl;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.packet.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class LoginPacket implements Packet {
   private final String username;
   private final String password;
   private final String hwid;

   private LoginPacket(LoginPacket.Builder builder) {
      this.username = builder.username;
      this.password = builder.password;
      this.hwid = builder.hwid;
   }

   public String serialize() {
      return "LOGINuser=" + this.username + ",pass=" + this.password + ",hwid=" + this.hwid;
   }

   public static LoginPacket.Builder builder() {
      return new LoginPacket.Builder();
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private String username;
      private String password;
      private String hwid;

      public LoginPacket.Builder username(String username) {
         this.username = username;
         return this;
      }

      public LoginPacket.Builder password(String password) {
         this.password = password;
         return this;
      }

      public LoginPacket.Builder hwid(String hwid) {
         this.hwid = hwid;
         return this;
      }

      public LoginPacket build() {
         if (this.username != null && !this.username.isEmpty()) {
            if (this.password != null && !this.password.isEmpty()) {
               if (this.hwid != null && !this.hwid.isEmpty()) {
                  return new LoginPacket(this);
               } else {
                  throw new IllegalStateException("HWID must be set");
               }
            } else {
               throw new IllegalStateException("Password must be set");
            }
         } else {
            throw new IllegalStateException("Username must be set");
         }
      }
   }
}
