package com.chorus.api.system.networking.response;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface ResponseHandler<T> {
   T handle(String var1);
}
