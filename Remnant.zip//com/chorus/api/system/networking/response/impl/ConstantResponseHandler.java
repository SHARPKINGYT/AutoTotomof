package com.chorus.api.system.networking.response.impl;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.response.ResponseHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class ConstantResponseHandler implements ResponseHandler<Double> {
   public Double handle(String response) {
      return response != null && response.startsWith("CONST") ? Double.parseDouble(response.substring(5)) : 0.0D;
   }
}
