package com.chorus.api.system.networking.response.impl;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.response.ResponseHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class JarSizeResponseHandler implements ResponseHandler<Boolean> {
   public Boolean handle(String response) {
      if (response != null) {
         String[] parts = response.split(":");
         return Boolean.parseBoolean(parts[0]);
      } else {
         return false;
      }
   }
}
