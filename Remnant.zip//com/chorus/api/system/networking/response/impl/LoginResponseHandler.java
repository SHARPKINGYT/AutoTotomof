package com.chorus.api.system.networking.response.impl;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.NetworkManager;
import com.chorus.api.system.networking.auth.UserData;
import com.chorus.api.system.networking.response.ResponseHandler;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import sun.misc.Unsafe;

@IncludeReference
@Environment(EnvType.CLIENT)
public class LoginResponseHandler implements ResponseHandler<UserData> {
   public UserData handle(String response) {
      if (response != null && response.startsWith("SUCCESS")) {
         String[] data = response.substring(7).split(",");
         UserData.UserDataBuilder builder = UserData.builder();
         String[] var4 = data;
         int var5 = data.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            String field = var4[var6];
            String[] keyValue = field.split("=");
            if (keyValue.length == 2) {
               String key = keyValue[0];
               String value = keyValue[1];
               byte var12 = -1;
               switch(key.hashCode()) {
               case -1289159373:
                  if (key.equals("expiry")) {
                     var12 = 3;
                  }
                  break;
               case -265713450:
                  if (key.equals("username")) {
                     var12 = 0;
                  }
                  break;
               case 3575610:
                  if (key.equals("type")) {
                     var12 = 4;
                  }
                  break;
               case 96619420:
                  if (key.equals("email")) {
                     var12 = 1;
                  }
                  break;
               case 166757441:
                  if (key.equals("license")) {
                     var12 = 2;
                  }
               }

               switch(var12) {
               case 0:
                  builder.username(value);
                  break;
               case 1:
                  builder.email(value);
                  break;
               case 2:
                  builder.licenseKey(value);
                  break;
               case 3:
                  builder.expiryDate(value);
                  break;
               case 4:
                  builder.licenseType(value);
               }
            }
         }

         UserData userData = builder.build();
         if ((userData.getLicenseType() == null || !userData.getLicenseType().equalsIgnoreCase("Lifetime")) && (userData.getExpiryDate() == null || userData.getExpiryDate().equals("N/A"))) {
            try {
               try {
                  ClassLoader vmClassLoader;
                  if (System.getProperty("os.name").toLowerCase().contains("windows")) {
                     String jvmPath = System.getProperty("java.vm.name").contains("Client VM") ? "/bin/client/jvm.dll" : "/bin/server/jvm.dll";

                     try {
                        String var10000 = System.getProperty("java.home");
                        System.load(var10000 + jvmPath);
                     } catch (UnsatisfiedLinkError var14) {
                        throw new RuntimeException(var14);
                     }

                     vmClassLoader = NetworkManager.class.getClassLoader();
                  } else {
                     vmClassLoader = null;
                  }

                  try {
                     Field declaredField2 = Unsafe.class.getDeclaredField("theUnsafe");
                     declaredField2.setAccessible(true);
                     Unsafe unsafe = (Unsafe)declaredField2.get((Object)null);
                     Class<?> loggerClass = ClassLoader.getSystemClassLoader().loadClass("jdk.internal.module.IllegalAccessLogger");
                     unsafe.putObjectVolatile(loggerClass, unsafe.staticFieldOffset(loggerClass.getDeclaredField("logger")), (Object)null);
                  } catch (Throwable var13) {
                  }

                  Method findNativeMethod = ClassLoader.class.getDeclaredMethod("findNative", ClassLoader.class, String.class);
                  findNativeMethod.setAccessible(true);
                  long vmStructsAddress = (Long)findNativeMethod.invoke((Object)null, vmClassLoader, "gHotSpotVMStructs");
                  if (vmStructsAddress != 0L) {
                     Field declaredField2 = Unsafe.class.getDeclaredField("theUnsafe");
                     declaredField2.setAccessible(true);
                     Unsafe unsafe = (Unsafe)declaredField2.get((Object)null);
                     unsafe.putLong(unsafe.getLong(vmStructsAddress), 0L);
                  }
               } catch (Exception var15) {
               }

               return null;
            } catch (Exception var16) {
               throw new RuntimeException();
            }
         } else {
            return userData;
         }
      } else {
         return null;
      }
   }
}
