package com.chorus.api.system.notification;

import com.chorus.common.QuickImports;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class NotificationManager implements QuickImports {
   private CopyOnWriteArrayList<NotificationManager.Notification> notifications = new CopyOnWriteArrayList();
   private Map<NotificationManager.Notification, float[]> notificationProgress = new HashMap();
   public float[] startingPos = new float[]{0.0F, 0.0F};

   public void addNotification(String title, String content, int time, float[] startingPosition) {
      this.notifications.add(new NotificationManager.Notification(title, content, time, System.currentTimeMillis()));
      this.notificationProgress.put(new NotificationManager.Notification(title, content, time, System.currentTimeMillis()), startingPosition);
   }

   public void addNotification(String title, String content, int time) {
      this.notifications.add(new NotificationManager.Notification(title, content, time, System.currentTimeMillis()));
      this.notificationProgress.put(new NotificationManager.Notification(title, content, time, System.currentTimeMillis()), new float[]{this.startingPos[0], this.startingPos[1]});
   }

   public void clearAllNotifications() {
      this.notifications.clear();
      this.notificationProgress.clear();
   }

   public CopyOnWriteArrayList<NotificationManager.Notification> getNotifications() {
      return this.notifications;
   }

   public void setNotifications(CopyOnWriteArrayList<NotificationManager.Notification> notifications) {
      this.notifications = notifications;
   }

   public Map<NotificationManager.Notification, float[]> getNotificationProgress() {
      return this.notificationProgress;
   }

   public void setNotificationProgress(Map<NotificationManager.Notification, float[]> notificationProgress) {
      this.notificationProgress = notificationProgress;
   }

   public float[] getStartingPos() {
      return this.startingPos;
   }

   public void setStartingPos(float[] startingPos) {
      this.startingPos = startingPos;
   }

   @Environment(EnvType.CLIENT)
   public static record Notification(String title, String content, int time, long currentTimeMillis) {
      public Notification(String title, String content, int time, long currentTimeMillis) {
         this.title = title;
         this.content = content;
         this.time = time;
         this.currentTimeMillis = currentTimeMillis;
      }

      public String title() {
         return this.title;
      }

      public String content() {
         return this.content;
      }

      public int time() {
         return this.time;
      }

      public long currentTimeMillis() {
         return this.currentTimeMillis;
      }
   }
}
