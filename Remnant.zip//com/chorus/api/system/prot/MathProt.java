package com.chorus.api.system.prot;

import cc.polymorphism.annot.IncludeReference;
import com.chorus.api.system.networking.NetworkManager;
import com.chorus.api.system.networking.packet.factory.PacketFactory;
import com.chorus.api.system.networking.response.factory.ResponseHandlerFactory;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@IncludeReference
@Environment(EnvType.CLIENT)
public class MathProt {
   private static final Map<String, Double> consts = new ConcurrentHashMap();
   private static volatile boolean initialized = false;
   private static final Object INIT_LOCK = new Object();

   public static void initializeConstants() {
      if (!initialized) {
         synchronized(INIT_LOCK) {
            if (!initialized) {
               fetchAllConstants();
               initialized = true;
            }
         }
      }

   }

   public static void fetchAllConstants() {
      String[] constantNames = new String[]{"pi", "e", "phi", "sqrt2", "sqrt3", "ln2", "ln10", "size"};
      CompletableFuture<?>[] futures = new CompletableFuture[constantNames.length];

      for(int i = 0; i < constantNames.length; ++i) {
         String constantName = constantNames[i];
         futures[i] = CompletableFuture.runAsync(() -> {
            double value = fetchConst(constantName);
            consts.put(constantName, value);
         });
      }

      try {
         CompletableFuture.allOf(futures).get(5L, TimeUnit.SECONDS);
      } catch (ExecutionException | TimeoutException | InterruptedException var4) {
         var4.printStackTrace();
      }

   }

   private static double fetchConst(String name) {
      NetworkManager net = NetworkManager.getInstance();
      if (!net.isConnected()) {
         return 0.0D;
      } else {
         try {
            net.sendPacket(PacketFactory.createConstantPacket(name));
            String response = net.readResponse();
            return (Double)ResponseHandlerFactory.getConstantResponseHandler().handle(response);
         } catch (Exception var3) {
            var3.printStackTrace();
            return 0.0D;
         }
      }
   }

   public static double getConst(String name) {
      if (!initialized) {
         initializeConstants();
      }

      return (Double)consts.getOrDefault(name, 0.0D);
   }

   public static double PI() {
      return getConst("pi");
   }

   public static double E() {
      return getConst("e");
   }

   public static double PHI() {
      return getConst("phi");
   }

   public static double SQRT2() {
      return getConst("sqrt2");
   }

   public static double SQRT3() {
      return getConst("sqrt3");
   }

   public static double LN2() {
      return getConst("ln2");
   }

   public static double LN10() {
      return getConst("ln10");
   }

   public static double SIZE() {
      return getConst("size");
   }
}
