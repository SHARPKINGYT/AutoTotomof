package com.chorus.api.system.render;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import com.chorus.common.QuickImports;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1041;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_6367;
import net.minecraft.class_293.class_5596;
import org.lwjgl.opengl.GL30;

@ExcludeFlow
@ExcludeConstant
@Environment(EnvType.CLIENT)
public class BlurProgram implements QuickImports {
   private class_276 input;
   private class_276 tempBuffer;
   private float blurX;
   private float blurY;
   private float blurWidth;
   private float blurHeight;
   private float blurRadius;
   private float blurStrength;
   private float blurOpacity;
   private int lastWidth = -1;
   private int lastHeight = -1;
   private float lastScaleFactor = -1.0F;

   public BlurProgram() {
      this.setup();
   }

   private void ensureBuffersExist() {
      int currentWidth = mc.method_22683().method_4489();
      int currentHeight = mc.method_22683().method_4506();
      float currentScaleFactor = (float)mc.method_22683().method_4495();
      boolean dimensionsChanged = currentWidth != this.lastWidth || currentHeight != this.lastHeight || currentScaleFactor != this.lastScaleFactor;
      if (dimensionsChanged || this.input == null || this.tempBuffer == null) {
         this.lastWidth = currentWidth;
         this.lastHeight = currentHeight;
         this.lastScaleFactor = currentScaleFactor;
         if (this.input == null) {
            this.input = new class_6367(currentWidth, currentHeight, false);
         } else if (this.input.field_1482 != currentWidth || this.input.field_1481 != currentHeight) {
            this.input.method_1234(currentWidth, currentHeight);
         }

         if (this.tempBuffer == null) {
            this.tempBuffer = new class_6367(currentWidth, currentHeight, false);
         } else if (this.tempBuffer.field_1482 != currentWidth || this.tempBuffer.field_1481 != currentHeight) {
            this.tempBuffer.method_1234(currentWidth, currentHeight);
         }
      }

   }

   public void beginBlur(float x, float y, float width, float height, float radius, float blurStrength, float blurOpacity) {
      this.blurX = x;
      this.blurY = y;
      this.blurWidth = width;
      this.blurHeight = height;
      this.blurRadius = radius;
      this.blurStrength = blurStrength;
      this.blurOpacity = blurOpacity;
      this.ensureBuffersExist();
      if (!(width <= 0.0F) && !(height <= 0.0F) && !(blurOpacity <= 0.0F) && !(radius <= 0.0F) && !(blurStrength <= 0.0F)) {
         class_276 mainBuffer = class_310.method_1551().method_1522();
         this.tempBuffer.method_1235(false);
         GL30.glBindFramebuffer(36008, mainBuffer.field_1476);
         GL30.glBlitFramebuffer(0, 0, mainBuffer.field_1482, mainBuffer.field_1481, 0, 0, this.tempBuffer.field_1482, this.tempBuffer.field_1481, 16384, 9729);
         mainBuffer.method_1235(false);
      }
   }

   public void beginBlur(float radius, float blurStrength) {
      class_1041 window = mc.method_22683();
      float width = (float)window.method_4486();
      float height = (float)window.method_4502();
      this.beginBlur(0.0F, 0.0F, width, height, radius, blurStrength, 1.0F);
   }

   public void endBlur() {
      this.ensureBuffersExist();
      if (!(this.blurOpacity <= 0.0F) && !(this.blurStrength <= 0.0F)) {
         class_276 mainBuffer = class_310.method_1551().method_1522();
         this.input.method_1235(false);
         GL30.glBindFramebuffer(36008, mainBuffer.field_1476);
         GL30.glBlitFramebuffer(0, 0, mainBuffer.field_1482, mainBuffer.field_1481, 0, 0, this.input.field_1482, this.input.field_1481, 16384, 9729);
         mainBuffer.method_1235(false);
         GL30.glBindFramebuffer(36008, this.tempBuffer.field_1476);
         GL30.glBlitFramebuffer(0, 0, this.tempBuffer.field_1482, this.tempBuffer.field_1481, 0, 0, mainBuffer.field_1482, mainBuffer.field_1481, 16384, 9729);
         float scaleFactor = (float)mc.method_22683().method_4495();
         this.applyShaderParameters(scaleFactor, mainBuffer);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         this.drawFullscreenQuad(mainBuffer);
         RenderSystem.disableBlend();
         RenderSystem.defaultBlendFunc();
      }
   }

   private void applyShaderParameters(float scaleFactor, class_276 mainBuffer) {
      Shaders.blurRadius.method_1251(this.blurRadius * scaleFactor);
      Shaders.blurLocation.method_1255(this.blurX * scaleFactor, -this.blurY * scaleFactor + (float)mc.method_22683().method_4502() * scaleFactor - this.blurHeight * scaleFactor);
      Shaders.blurSize.method_1255(this.blurWidth * scaleFactor, this.blurHeight * scaleFactor);
      Shaders.blurBrightness.method_1251(this.blurOpacity);
      Shaders.blurQuality.method_1251(this.blurStrength);
      Shaders.blurInputResolution.method_1255((float)mainBuffer.field_1482, (float)mainBuffer.field_1481);
      Shaders.BLUR.method_62899("InputSampler", this.input.method_30277());
      RenderSystem.setShader(Shaders.BLUR);
   }

   private void drawFullscreenQuad(class_276 buffer) {
      class_289 tessellator = class_289.method_1348();
      class_287 builder = tessellator.method_60827(class_5596.field_27382, class_290.field_1592);
      class_4587 matrices = new class_4587();
      builder.method_22918(matrices.method_23760().method_23761(), 0.0F, 0.0F, 0.0F);
      builder.method_22918(matrices.method_23760().method_23761(), 0.0F, (float)buffer.field_1481, 0.0F);
      builder.method_22918(matrices.method_23760().method_23761(), (float)buffer.field_1482, (float)buffer.field_1481, 0.0F);
      builder.method_22918(matrices.method_23760().method_23761(), (float)buffer.field_1482, 0.0F, 0.0F);
      class_286.method_43433(builder.method_60800());
   }

   public void setParameters(float x, float y, float width, float height, float r, float blurStrength, float blurOpacity) {
      this.ensureBuffersExist();
      if (!(width <= 0.0F) && !(height <= 0.0F) && !(blurOpacity <= 0.0F) && !(r <= 0.0F) && !(blurStrength <= 0.0F)) {
         float scaleFactor = (float)mc.method_22683().method_4495();
         Shaders.blurRadius.method_1251(r * scaleFactor);
         Shaders.blurLocation.method_1255(x * scaleFactor, -y * scaleFactor + (float)mc.method_22683().method_4502() * scaleFactor - height * scaleFactor);
         Shaders.blurSize.method_1255(width * scaleFactor, height * scaleFactor);
         Shaders.blurBrightness.method_1251(blurOpacity);
         Shaders.blurQuality.method_1251(blurStrength);
         Shaders.BLUR.method_62899("InputSampler", this.input.method_30277());
      }
   }

   public void use() {
      this.ensureBuffersExist();
      class_276 buffer = class_310.method_1551().method_1522();
      this.input.method_1235(false);
      GL30.glBindFramebuffer(36008, buffer.field_1476);
      GL30.glBlitFramebuffer(0, 0, buffer.field_1482, buffer.field_1481, 0, 0, buffer.field_1482, buffer.field_1481, 16384, 9729);
      buffer.method_1235(false);
      Shaders.blurInputResolution.method_1255((float)buffer.field_1482, (float)buffer.field_1481);
      Shaders.BLUR.method_62899("InputSampler", this.input.method_30277());
      RenderSystem.setShader(Shaders.BLUR);
   }

   protected void setup() {
      if (mc.method_22683() != null) {
         this.lastWidth = mc.method_22683().method_4489();
         this.lastHeight = mc.method_22683().method_4506();
         this.lastScaleFactor = (float)mc.method_22683().method_4495();
         this.input = new class_6367(this.lastWidth, this.lastHeight, false);
         this.tempBuffer = new class_6367(this.lastWidth, this.lastHeight, false);
      }

   }

   public void resize(int width, int height) {
      if (width > 0 && height > 0) {
         this.lastWidth = width;
         this.lastHeight = height;
         if (this.input != null) {
            this.input.method_1234(width, height);
         }

         if (this.tempBuffer != null) {
            this.tempBuffer.method_1234(width, height);
         }

      }
   }
}
