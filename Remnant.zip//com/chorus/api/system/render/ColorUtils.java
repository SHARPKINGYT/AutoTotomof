package com.chorus.api.system.render;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import com.chorus.common.QuickImports;
import com.chorus.common.util.world.SocialManager;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_3532;

@ExcludeFlow
@ExcludeConstant
@Environment(EnvType.CLIENT)
public class ColorUtils implements QuickImports {
   private static int interpolate(int oldValue, int newValue, float factor) {
      return (int)((float)oldValue + (float)(newValue - oldValue) * factor);
   }

   public static Color interpolateColor(Color color1, Color color2, float amount) {
      amount = Math.min(1.0F, Math.max(0.0F, amount));
      return new Color(interpolate(color1.getRed(), color2.getRed(), amount), interpolate(color1.getGreen(), color2.getGreen(), amount), interpolate(color1.getBlue(), color2.getBlue(), amount), interpolate(color1.getAlpha(), color2.getAlpha(), amount));
   }

   public static Color getAssociatedColor(class_1657 player) {
      if (player == mc.field_1724) {
         return new Color(127, 255, 127);
      } else if (friendRepository.isFriend(player.method_5667())) {
         return new Color(127, 255, 127);
      } else if (npcRepository.isNPC(player.method_5820())) {
         return new Color(118, 118, 118);
      } else if (SocialManager.isTarget(player)) {
         return new Color(255, 127, 127);
      } else {
         return player.method_5781() != null && player.method_5781().method_1202().method_532() != null ? formattingToRGB(player.method_5781().method_1202().method_532()) : new Color(184, 112, 242);
      }
   }

   public static Color formattingToRGB(int color) {
      int red = color >> 16 & 255;
      int green = color >> 8 & 255;
      int blue = color & 255;
      return new Color(red, green, blue);
   }

   public static int getMiddleColor(int color1, int color2) {
      return interpolateColor(new Color(color1), new Color(color1), 0.5F).getRGB();
   }

   public static int[] generateGradient(int startColor, int endColor, int steps) {
      int[] gradient = new int[steps];

      for(int i = 0; i < steps; ++i) {
         float factor = (float)i / (float)(steps - 1);
         gradient[i] = interpolateColor(new Color(startColor), new Color(endColor), factor).getRGB();
      }

      return gradient;
   }

   public static int combineColors(int color1, int color2) {
      int a = (color1 >> 24 & 255) + (color2 >> 24 & 255) >> 1;
      int r = (color1 >> 16 & 255) + (color2 >> 16 & 255) >> 1;
      int g = (color1 >> 8 & 255) + (color2 >> 8 & 255) >> 1;
      int b = (color1 & 255) + (color2 & 255) >> 1;
      return a << 24 | r << 16 | g << 8 | b;
   }

   public static int hsvToRgb(float hue, float saturation, float value) {
      int h = (int)(hue / 60.0F);
      float f = hue / 60.0F - (float)h;
      float p = value * (1.0F - saturation);
      float q = value * (1.0F - f * saturation);
      float t = value * (1.0F - (1.0F - f) * saturation);
      float r;
      float g;
      float b;
      switch(h) {
      case 0:
         r = value;
         g = t;
         b = p;
         break;
      case 1:
         r = q;
         g = value;
         b = p;
         break;
      case 2:
         r = p;
         g = value;
         b = t;
         break;
      case 3:
         r = p;
         g = q;
         b = value;
         break;
      case 4:
         r = t;
         g = p;
         b = value;
         break;
      default:
         r = value;
         g = p;
         b = q;
      }

      int ri = class_3532.method_15340((int)(r * 255.0F), 0, 255);
      int gi = class_3532.method_15340((int)(g * 255.0F), 0, 255);
      int bi = class_3532.method_15340((int)(b * 255.0F), 0, 255);
      return -16777216 | ri << 16 | gi << 8 | bi;
   }

   public static Color intToColor(int argb) {
      int a = argb >> 24 & 255;
      int r = argb >> 16 & 255;
      int g = argb >> 8 & 255;
      int b = argb & 255;
      return new Color(r, g, b, a);
   }

   public static int colorToInt(Color color) {
      return color.getRGB();
   }

   public static Color interpolateColor(Color color1, Color color2, int speed, int index) {
      int angle = (int)((System.currentTimeMillis() / (long)speed + (long)index) % 360L);
      angle = (angle >= 180 ? 360 - angle : angle) * 2;
      return interpolateColor(color1, color2, (float)angle / 360.0F);
   }
}
