package com.chorus.api.system.render;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import com.chorus.common.QuickImports;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@ExcludeFlow
@ExcludeConstant
@Environment(EnvType.CLIENT)
public class Render2DEngine implements QuickImports {
   public static BlurProgram BLUR_PROGRAM = new BlurProgram();

   public static void drawLine(class_4587 matrices, float x, float y, float x1, float y1, float width, Color color) {
      float r = (float)color.getRed() / 255.0F;
      float g = (float)color.getGreen() / 255.0F;
      float b = (float)color.getBlue() / 255.0F;
      float a = (float)color.getAlpha() / 255.0F;
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x, y, 0.0F).method_22915(r, g, b, a);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x1, y1, 0.0F).method_22915(r, g, b, a);
      RenderSystem.lineWidth(width);
      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
      RenderSystem.enableCull();
      RenderSystem.depthFunc(515);
   }

   public static void drawVerticalGradient(class_4587 matrices, float x, float y, float width, float height, Color color, Color color1) {
      float r = (float)color.getRed() / 255.0F;
      float g = (float)color.getGreen() / 255.0F;
      float b = (float)color.getBlue() / 255.0F;
      float a = (float)color.getAlpha() / 255.0F;
      float r1 = (float)color1.getRed() / 255.0F;
      float g1 = (float)color1.getGreen() / 255.0F;
      float b1 = (float)color1.getBlue() / 255.0F;
      float a1 = (float)color1.getAlpha() / 255.0F;
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x, y + height, 0.0F).method_22915(r1, g1, b1, a1);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x + width, y + height, 0.0F).method_22915(r1, g1, b1, a1);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x + width, y, 0.0F).method_22915(r, g, b, a);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x, y, 0.0F).method_22915(r, g, b, a);
      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
      RenderSystem.enableCull();
      RenderSystem.depthFunc(515);
   }

   public static void drawGradientRect(class_4587 matrices, float x, float y, float width, float height, Color color, Color color1) {
      float r = (float)color.getRed() / 255.0F;
      float g = (float)color.getGreen() / 255.0F;
      float b = (float)color.getBlue() / 255.0F;
      float a = (float)color.getAlpha() / 255.0F;
      float r1 = (float)color1.getRed() / 255.0F;
      float g1 = (float)color1.getGreen() / 255.0F;
      float b1 = (float)color1.getBlue() / 255.0F;
      float a1 = (float)color1.getAlpha() / 255.0F;
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x, y + height, 0.0F).method_22915(r, g, b, a);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x + width, y + height, 0.0F).method_22915(r1, g1, b1, a1);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x + width, y, 0.0F).method_22915(r1, g1, b1, a1);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x, y, 0.0F).method_22915(r, g, b, a);
      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
      RenderSystem.enableCull();
      RenderSystem.depthFunc(515);
   }

   public static void drawRect(class_4587 matrices, float x, float y, float width, float height, Color color) {
      float r = (float)color.getRed() / 255.0F;
      float g = (float)color.getGreen() / 255.0F;
      float b = (float)color.getBlue() / 255.0F;
      float a = (float)color.getAlpha() / 255.0F;
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x, y + height, 0.0F).method_22915(r, g, b, a);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x + width, y + height, 0.0F).method_22915(r, g, b, a);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x + width, y, 0.0F).method_22915(r, g, b, a);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), x, y, 0.0F).method_22915(r, g, b, a);
      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
      RenderSystem.enableCull();
      RenderSystem.depthFunc(515);
   }

   public static void drawRoundedRect(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, Color color) {
      drawRoundedRect(matrices, x1, y1, x2, y2, radius, color, color, color, color);
   }

   public static void drawRoundedRect(class_4587 matrices, float x1, float y1, float x2, float y2, float topLeft, float topRight, float bottomLeft, float bottomRight, Color color) {
      drawRoundedRect(matrices, x1, y1, x2, y2, topLeft, topRight, bottomLeft, bottomRight, color, color, color, color);
   }

   public static void drawTopRoundedRect(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, Color color) {
      drawRoundedRect(matrices, x1, y1, x2, y2, radius, radius, 0.0F, 0.0F, color, color, color, color);
   }

   public static void drawBottomRoundedRect(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, Color color) {
      drawRoundedRect(matrices, x1, y1, x2, y2, 0.0F, 0.0F, radius, radius, color, color, color, color);
   }

   public static void drawRoundedGradient(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, Color color1, Color color2) {
      drawRoundedRect(matrices, x1, y1, x2, y2, radius, color1, color1, color2, color2);
   }

   public static void drawRoundedVerticalGradient(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, Color color1, Color color2) {
      drawRoundedRect(matrices, x1, y1, x2, y2, radius, color2, color1, color2, color1);
   }

   public static void drawRoundedRect(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, Color color1, Color color2, Color color3, Color color4) {
      drawRoundedRect(matrices, x1, y1, x2, y2, radius, radius, radius, radius, color1, color2, color3, color4);
   }

   public static void drawRoundedRect(class_4587 matrices, float x1, float y1, float x2, float y2, float topLeft, float topRight, float bottomLeft, float bottomRight, Color color1, Color color2, Color color3, Color color4) {
      if (Shaders.ROUNDED_RECT == null) {
         Shaders.load();
      }

      x2 += x1;
      y2 += y1;
      float scaleFactor = (float)mc.method_22683().method_4495();
      int windowHeight = mc.method_22683().method_4507();
      class_5944 shaderProg = Shaders.ROUNDED_RECT;
      if (shaderProg == null) {
         throw new IllegalStateException("Shader program is not available.");
      } else {
         Vector3f start = transformPosition(matrices, x1, y1, 0.0F);
         Vector3f end = transformPosition(matrices, x2, y2, 0.0F);
         float[] actualCoords = getActualCoordinates(start, end, scaleFactor, windowHeight);
         class_289 tessellator = class_289.method_1348();
         class_287 buffer = tessellator.method_60827(class_5596.field_27382, class_290.field_1576);
         prepareBuffer(buffer, matrices.method_23760().method_23761(), x1, y1, x2, y2, 0.0F, color1);
         shaderProg.method_34582("RadiusTopLeft").method_1251(topLeft * scaleFactor);
         shaderProg.method_34582("RadiusTopRight").method_1251(topRight * scaleFactor);
         shaderProg.method_34582("RadiusBottomLeft").method_1251(bottomLeft * scaleFactor);
         shaderProg.method_34582("RadiusBottomRight").method_1251(bottomRight * scaleFactor);
         shaderProg.method_34582("Bounds").method_35657(actualCoords[0], actualCoords[3], actualCoords[2], actualCoords[1]);
         shaderProg.method_34582("Smoothness").method_1251(2.0F);
         shaderProg.method_34582("color1").method_35657((float)color1.getRed() / 255.0F, (float)color1.getGreen() / 255.0F, (float)color1.getBlue() / 255.0F, (float)color1.getAlpha() / 255.0F);
         shaderProg.method_34582("color2").method_35657((float)color2.getRed() / 255.0F, (float)color2.getGreen() / 255.0F, (float)color2.getBlue() / 255.0F, (float)color2.getAlpha() / 255.0F);
         shaderProg.method_34582("color3").method_35657((float)color3.getRed() / 255.0F, (float)color3.getGreen() / 255.0F, (float)color3.getBlue() / 255.0F, (float)color3.getAlpha() / 255.0F);
         shaderProg.method_34582("color4").method_35657((float)color4.getRed() / 255.0F, (float)color4.getGreen() / 255.0F, (float)color4.getBlue() / 255.0F, (float)color4.getAlpha() / 255.0F);
         renderShape(buffer, shaderProg);
      }
   }

   public static void drawRoundedOutline(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, float width, Color color) {
      drawRoundedOutline(matrices, x1, y1, x2, y2, radius, width, color, color, color, color);
   }

   public static void drawOutlinedGradient(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, float width, Color color1, Color color2) {
      drawRoundedOutline(matrices, x1, y1, x2, y2, radius, width, color1, color1, color2, color2);
   }

   public static void drawOutlinedVerticalGradient(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, float width, Color color1, Color color2) {
      drawRoundedOutline(matrices, x1, y1, x2, y2, radius, width, color2, color1, color2, color1);
   }

   public static void drawRoundedOutline(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, float width, Color color1, Color color2, Color color3, Color color4) {
      if (Shaders.ROUNDED_OUTLINE == null) {
         Shaders.load();
      }

      x2 += x1;
      y2 += y1;
      class_5944 shaderProg = Shaders.ROUNDED_OUTLINE;
      if (shaderProg == null) {
         throw new IllegalStateException("Shader program is not available.");
      } else {
         float scaleFactor = (float)mc.method_22683().method_4495();
         int windowHeight = mc.method_22683().method_4507();
         Vector3f start = transformPosition(matrices, x1, y1, 0.0F);
         Vector3f end = transformPosition(matrices, x2, y2, 0.0F);
         float[] actualCoords = getActualCoordinates(start, end, scaleFactor, windowHeight);
         class_289 tessellator = class_289.method_1348();
         class_287 buffer = tessellator.method_60827(class_5596.field_27382, class_290.field_1576);
         prepareBuffer(buffer, matrices.method_23760().method_23761(), x1, y1, x2, y2, 0.0F, color1);
         shaderProg.method_34582("Radius").method_1251(radius * scaleFactor);
         shaderProg.method_34582("Bounds").method_35657(actualCoords[0] + 1.0F, actualCoords[3] + 1.0F, actualCoords[2] - 1.0F, actualCoords[1] - 1.0F);
         shaderProg.method_34582("Smoothness").method_1251(2.0F);
         shaderProg.method_34582("StrokeWidth").method_1251(width);
         shaderProg.method_34582("color1").method_35657((float)color1.getRed() / 255.0F, (float)color1.getGreen() / 255.0F, (float)color1.getBlue() / 255.0F, (float)color1.getAlpha() / 255.0F);
         shaderProg.method_34582("color2").method_35657((float)color2.getRed() / 255.0F, (float)color2.getGreen() / 255.0F, (float)color2.getBlue() / 255.0F, (float)color2.getAlpha() / 255.0F);
         shaderProg.method_34582("color3").method_35657((float)color3.getRed() / 255.0F, (float)color3.getGreen() / 255.0F, (float)color3.getBlue() / 255.0F, (float)color3.getAlpha() / 255.0F);
         shaderProg.method_34582("color4").method_35657((float)color4.getRed() / 255.0F, (float)color4.getGreen() / 255.0F, (float)color4.getBlue() / 255.0F, (float)color4.getAlpha() / 255.0F);
         renderShape(buffer, Shaders.ROUNDED_OUTLINE);
      }
   }

   public static void drawCircle(class_4587 matrices, float ox, float oy, float radius, Color color) {
      drawCircle(matrices, ox, oy, radius, color, 0.0F, 360.0F);
   }

   public static void drawCircle(class_4587 matrices, float x, float y, float radius, Color color, float startAngle, float angleRange) {
      if (Shaders.CIRCLE == null) {
         Shaders.load();
      }

      float scaleFactor = (float)mc.method_22683().method_4495();
      float x1 = x - radius;
      float y1 = y - radius;
      float x2 = x + radius;
      float y2 = y + radius;
      int wh = mc.method_22683().method_4507();
      float actualX = x * scaleFactor;
      float actualY = (float)wh - y * scaleFactor;
      Matrix4f positionMatrix = matrices.method_23760().method_23761();
      class_289 tessellator = class_289.method_1348();
      class_287 buffer = tessellator.method_60827(class_5596.field_27382, class_290.field_1576);
      prepareBuffer(buffer, positionMatrix, x1, y1, x2, y2, 0.0F, color);
      class_5944 shaderProg = Shaders.CIRCLE;
      shaderProg.method_34582("Origin").method_1255(actualX, actualY);
      shaderProg.method_34582("Radius").method_1251(radius * scaleFactor);
      shaderProg.method_34582("StartAngle").method_1251(startAngle);
      shaderProg.method_34582("AngleRange").method_1251(angleRange);
      renderShape(buffer, Shaders.CIRCLE);
   }

   private static Vector3f transformPosition(class_4587 matrices, float x, float y, float z) {
      Matrix4f positionMatrix = matrices.method_23760().method_23761();
      return positionMatrix.transformPosition(x, y, z, new Vector3f());
   }

   private static float[] getActualCoordinates(Vector3f start, Vector3f end, float scaleFactor, int windowHeight) {
      float actualX1 = start.x * scaleFactor;
      float actualX2 = end.x * scaleFactor;
      float actualY1 = (float)windowHeight - start.y * scaleFactor;
      float actualY2 = (float)windowHeight - end.y * scaleFactor;
      return new float[]{actualX1, actualY1, actualX2, actualY2};
   }

   public static void prepareBuffer(class_287 buffer, Matrix4f positionMatrix, float x1, float y1, float x2, float y2, float z, Color color) {
      buffer.method_22918(positionMatrix, x1, y1, z).method_22915((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      buffer.method_22918(positionMatrix, x1, y2, z).method_22915((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      buffer.method_22918(positionMatrix, x2, y2, z).method_22915((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      buffer.method_22918(positionMatrix, x2, y1, z).method_22915((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
   }

   private static void renderShape(class_287 buffer, class_5944 shaderProgram) {
      RenderSystem.disableDepthTest();
      class_5944 last = RenderSystem.getShader();
      RenderSystem.setShader(shaderProgram);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      class_286.method_43433(buffer.method_60800());
      RenderSystem.disableBlend();
      RenderSystem.setShader(last);
      RenderSystem.enableDepthTest();
   }

   public static void drawOutline(class_4587 matrices, float x, float y, float width, float height, Color color) {
      drawLine(matrices, x, y, x + width, y, 1.0F, color);
      drawLine(matrices, x + width, y, x + width, y + height, 1.0F, color);
      drawLine(matrices, x - 0.5F, y + height, x + width, y + height, 1.0F, color);
      drawLine(matrices, x, y, x, y + height + 0.5F, 1.0F, color);
   }

   public static void drawQuads(class_287 bufferBuilder, Matrix4f matrix, float x, float y, float x1, float y1, Color color) {
      bufferBuilder.method_22918(matrix, x, y1, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
      bufferBuilder.method_22918(matrix, x1, y1, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
      bufferBuilder.method_22918(matrix, x1, y, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
      bufferBuilder.method_22918(matrix, x, y, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
   }

   public static void drawColorPicker(class_4587 matrices, float x, float y, float width, float height, float hue, float alpha) {
      if (Shaders.COLOR_PICKER == null) {
         Shaders.load();
      }

      float scaleFactor = (float)mc.method_22683().method_4495();
      int windowHeight = mc.method_22683().method_4507();
      class_5944 shaderProg = Shaders.COLOR_PICKER;
      if (shaderProg == null) {
         throw new IllegalStateException("Shader program is not available.");
      } else {
         Vector3f start = transformPosition(matrices, x, y, 0.0F);
         Vector3f end = transformPosition(matrices, x + width, y + height, 0.0F);
         float[] actualCoords = getActualCoordinates(start, end, scaleFactor, windowHeight);
         class_289 tessellator = class_289.method_1348();
         class_287 buffer = tessellator.method_60827(class_5596.field_27382, class_290.field_1576);
         prepareBuffer(buffer, matrices.method_23760().method_23761(), x, y, x + width, y + height, 0.0F, Color.WHITE);
         Shaders.colorPickerResolution.method_1255(width * scaleFactor, height * scaleFactor);
         Shaders.colorPickerPosition.method_1255(actualCoords[0], actualCoords[3]);
         Shaders.colorPickerHue.method_1251(hue);
         Shaders.colorPickerAlpha.method_1251(alpha);
         RenderSystem.disableDepthTest();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShader(shaderProg);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         class_286.method_43433(buffer.method_60800());
         RenderSystem.disableBlend();
         RenderSystem.enableDepthTest();
      }
   }

   public static void drawAlphaSlider(class_4587 matrices, float x, float y, float width, float height, Color baseColor) {
      float scaleFactor = (float)mc.method_22683().method_4495();
      int windowHeight = mc.method_22683().method_4507();
      class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
      Matrix4f matrix = matrices.method_23760().method_23761();

      for(int i = 0; i <= 10; ++i) {
         float alpha = (float)i / 10.0F;
         float xPos = x + width * (float)i / 10.0F;
         buffer.method_22918(matrix, xPos, y, 0.0F).method_22915((float)baseColor.getRed() / 255.0F, (float)baseColor.getGreen() / 255.0F, (float)baseColor.getBlue() / 255.0F, alpha);
         buffer.method_22918(matrix, xPos, y + height, 0.0F).method_22915((float)baseColor.getRed() / 255.0F, (float)baseColor.getGreen() / 255.0F, (float)baseColor.getBlue() / 255.0F, alpha);
      }

      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(class_10142.field_53876);
      class_286.method_43433(buffer.method_60800());
      RenderSystem.disableBlend();
      RenderSystem.enableCull();
   }

   public static void drawRoundedBlur(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, float blurRadius, Color color) {
      if (Shaders.BLUR == null) {
         Shaders.load();
      }

      x2 += x1;
      y2 += y1;
      class_289 tessellator = class_289.method_1348();
      class_287 buffer = tessellator.method_60827(class_5596.field_27382, class_290.field_1592);
      buffer.method_22918(matrices.method_23760().method_23761(), x1, y1, 0.0F);
      buffer.method_22918(matrices.method_23760().method_23761(), x1, y2, 0.0F);
      buffer.method_22918(matrices.method_23760().method_23761(), x2, y2, 0.0F);
      buffer.method_22918(matrices.method_23760().method_23761(), x2, y1, 0.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      BLUR_PROGRAM.setParameters(x1, y1, x2 - x1, y2 - y1, radius, blurRadius, 1.0F);
      BLUR_PROGRAM.use();
      class_286.method_43433(buffer.method_60800());
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static void drawRoundedBlur(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, float blurRadius) {
      if (Shaders.BLUR == null) {
         Shaders.load();
      }

      x2 += x1;
      y2 += y1;
      class_289 tessellator = class_289.method_1348();
      class_287 buffer = tessellator.method_60827(class_5596.field_27382, class_290.field_1592);
      buffer.method_22918(matrices.method_23760().method_23761(), x1, y1, 0.0F);
      buffer.method_22918(matrices.method_23760().method_23761(), x1, y2, 0.0F);
      buffer.method_22918(matrices.method_23760().method_23761(), x2, y2, 0.0F);
      buffer.method_22918(matrices.method_23760().method_23761(), x2, y1, 0.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      BLUR_PROGRAM.setParameters(x1, y1, x2 - x1, y2 - y1, radius, blurRadius, 1.0F);
      BLUR_PROGRAM.use();
      class_286.method_43433(buffer.method_60800());
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static void drawBlurredRoundedRect(class_4587 matrices, float x1, float y1, float x2, float y2, float radius, float blurRadius, Color color) {
      if (Shaders.BLUR == null) {
         Shaders.load();
      }

      BLUR_PROGRAM.beginBlur(x1, y1, x2, y2, radius, blurRadius, 1.0F);
      drawRoundedRect(matrices, x1, y1, x2, y2, radius, color);
      BLUR_PROGRAM.endBlur();
   }

   public static void drawBlurredRect(class_4587 matrices, float x, float y, float width, float height, float blurRadius, Color color) {
      if (Shaders.BLUR == null) {
         Shaders.load();
      }

      BLUR_PROGRAM.beginBlur(x, y, width, height, 0.0F, blurRadius, 1.0F);
      drawRect(matrices, x, y, width, height, color);
      BLUR_PROGRAM.endBlur();
   }
}
