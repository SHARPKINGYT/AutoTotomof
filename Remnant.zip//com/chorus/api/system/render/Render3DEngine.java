package com.chorus.api.system.render;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import com.chorus.common.QuickImports;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

@ExcludeFlow
@ExcludeConstant
@Environment(EnvType.CLIENT)
public class Render3DEngine implements QuickImports {
   public static void renderOutlinedBox(class_243 position, Color color, class_4587 stack, float width, float height) {
      int originalDepthFunc = GL11.glGetInteger(2932);
      boolean originalCull = GL11.glIsEnabled(2884);
      boolean originalBlend = GL11.glIsEnabled(3042);
      class_5944 originalShader = RenderSystem.getShader();

      try {
         float red = (float)color.getRed() / 255.0F;
         float green = (float)color.getGreen() / 255.0F;
         float blue = (float)color.getBlue() / 255.0F;
         float alpha = (float)color.getAlpha() / 255.0F;
         class_243 camPos = mc.field_1773.method_19418().method_19326();
         class_243 start = position.method_1020(camPos);
         float x = (float)start.field_1352;
         float y = (float)start.field_1351;
         float z = (float)start.field_1350;
         stack.method_22903();
         Matrix4f matrix = stack.method_23760().method_23761();
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         GL11.glDepthFunc(519);
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         class_286.method_43433(buffer.method_60800());
      } finally {
         GL11.glDepthFunc(originalDepthFunc);
         if (originalCull) {
            RenderSystem.enableCull();
         } else {
            RenderSystem.disableCull();
         }

         if (originalBlend) {
            RenderSystem.enableBlend();
         } else {
            RenderSystem.disableBlend();
         }

         RenderSystem.setShader(originalShader);
         stack.method_22909();
      }

   }

   public static void renderOutlinedBox(class_1657 player, Color color, class_4587 stack) {
      int originalDepthFunc = GL11.glGetInteger(2932);
      boolean originalCull = GL11.glIsEnabled(2884);
      boolean originalBlend = GL11.glIsEnabled(3042);
      class_5944 originalShader = RenderSystem.getShader();

      try {
         float red = (float)color.getRed() / 255.0F;
         float green = (float)color.getGreen() / 255.0F;
         float blue = (float)color.getBlue() / 255.0F;
         float alpha = (float)color.getAlpha() / 255.0F;
         class_243 camPos = mc.field_1773.method_19418().method_19326();
         class_243 start = player.method_30950(mc.method_61966().method_60637(false)).method_1020(camPos);
         float x = (float)start.field_1352;
         float y = (float)start.field_1351;
         float z = (float)start.field_1350;
         stack.method_22903();
         Matrix4f matrix = stack.method_23760().method_23761();
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         GL11.glDepthFunc(519);
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         float width = player.method_17681() / 2.0F;
         float height = player.method_17682();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         class_286.method_43433(buffer.method_60800());
      } finally {
         GL11.glDepthFunc(originalDepthFunc);
         if (originalCull) {
            RenderSystem.enableCull();
         } else {
            RenderSystem.disableCull();
         }

         if (originalBlend) {
            RenderSystem.enableBlend();
         } else {
            RenderSystem.disableBlend();
         }

         RenderSystem.setShader(originalShader);
         stack.method_22909();
      }

   }

   public static void renderOutlinedShadedBox(class_243 position, Color color, int shadedAlpha, class_4587 stack, float width, float height) {
      int originalDepthFunc = GL11.glGetInteger(2932);
      boolean originalCull = GL11.glIsEnabled(2884);
      boolean originalBlend = GL11.glIsEnabled(3042);
      class_5944 originalShader = RenderSystem.getShader();

      try {
         float red = (float)color.getRed() / 255.0F;
         float green = (float)color.getGreen() / 255.0F;
         float blue = (float)color.getBlue() / 255.0F;
         float alpha = (float)color.getAlpha() / 255.0F;
         float specialAlpha = (float)shadedAlpha / 255.0F;
         class_243 camPos = mc.field_1773.method_19418().method_19326();
         class_243 start = position.method_1020(camPos);
         float x = (float)start.field_1352;
         float y = (float)start.field_1351;
         float z = (float)start.field_1350;
         stack.method_22903();
         Matrix4f matrix = stack.method_23760().method_23761();
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         GL11.glDepthFunc(519);
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
      } finally {
         GL11.glDepthFunc(originalDepthFunc);
         if (originalCull) {
            RenderSystem.enableCull();
         } else {
            RenderSystem.disableCull();
         }

         if (originalBlend) {
            RenderSystem.enableBlend();
         } else {
            RenderSystem.disableBlend();
         }

         RenderSystem.setShader(originalShader);
         stack.method_22909();
      }

   }

   public static void renderOutlinedShadedBox(class_1657 player, Color color, int shadedAlpha, class_4587 stack) {
      int originalDepthFunc = GL11.glGetInteger(2932);
      boolean originalCull = GL11.glIsEnabled(2884);
      boolean originalBlend = GL11.glIsEnabled(3042);
      class_5944 originalShader = RenderSystem.getShader();

      try {
         float red = (float)color.getRed() / 255.0F;
         float green = (float)color.getGreen() / 255.0F;
         float blue = (float)color.getBlue() / 255.0F;
         float alpha = (float)color.getAlpha() / 255.0F;
         float specialAlpha = (float)shadedAlpha / 255.0F;
         class_243 camPos = mc.field_1773.method_19418().method_19326();
         class_243 start = player.method_30950(mc.method_61966().method_60637(false)).method_1020(camPos);
         float x = (float)start.field_1352;
         float y = (float)start.field_1351;
         float z = (float)start.field_1350;
         stack.method_22903();
         Matrix4f matrix = stack.method_23760().method_23761();
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         GL11.glDepthFunc(519);
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         float width = player.method_17681() / 2.0F;
         float height = player.method_17682();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, alpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
      } finally {
         GL11.glDepthFunc(originalDepthFunc);
         if (originalCull) {
            RenderSystem.enableCull();
         } else {
            RenderSystem.disableCull();
         }

         if (originalBlend) {
            RenderSystem.enableBlend();
         } else {
            RenderSystem.disableBlend();
         }

         RenderSystem.setShader(originalShader);
         stack.method_22909();
      }

   }

   public static void renderShadedBox(class_243 position, Color color, int shadedAlpha, class_4587 stack, float width, float height) {
      int originalDepthFunc = GL11.glGetInteger(2932);
      boolean originalCull = GL11.glIsEnabled(2884);
      boolean originalBlend = GL11.glIsEnabled(3042);
      class_5944 originalShader = RenderSystem.getShader();

      try {
         float red = (float)color.getRed() / 255.0F;
         float green = (float)color.getGreen() / 255.0F;
         float blue = (float)color.getBlue() / 255.0F;
         float specialAlpha = (float)shadedAlpha / 255.0F;
         class_243 camPos = mc.field_1773.method_19418().method_19326();
         class_243 start = position.method_1020(camPos);
         float x = (float)start.field_1352;
         float y = (float)start.field_1351;
         float z = (float)start.field_1350;
         stack.method_22903();
         Matrix4f matrix = stack.method_23760().method_23761();
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         GL11.glDepthFunc(519);
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
      } finally {
         GL11.glDepthFunc(originalDepthFunc);
         if (originalCull) {
            RenderSystem.enableCull();
         } else {
            RenderSystem.disableCull();
         }

         if (originalBlend) {
            RenderSystem.enableBlend();
         } else {
            RenderSystem.disableBlend();
         }

         RenderSystem.setShader(originalShader);
         stack.method_22909();
      }

   }

   public static void renderShadedBox(class_1657 player, Color color, int shadedAlpha, class_4587 stack) {
      int originalDepthFunc = GL11.glGetInteger(2932);
      boolean originalCull = GL11.glIsEnabled(2884);
      boolean originalBlend = GL11.glIsEnabled(3042);
      class_5944 originalShader = RenderSystem.getShader();

      try {
         float red = (float)color.getRed() / 255.0F;
         float green = (float)color.getGreen() / 255.0F;
         float blue = (float)color.getBlue() / 255.0F;
         float specialAlpha = (float)shadedAlpha / 255.0F;
         stack.method_22903();
         Matrix4f matrix = stack.method_23760().method_23761();
         class_243 start = player.method_30950(mc.method_61966().method_60637(true)).method_1020(mc.method_1561().field_4686.method_19326());
         float x = (float)start.field_1352;
         float y = (float)start.field_1351;
         float z = (float)start.field_1350;
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         GL11.glDepthFunc(519);
         float width = player.method_17681() / 2.0F;
         float height = player.method_17682();
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z + width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z + width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         buffer.method_22918(matrix, x - width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x - width, y, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y + height, z - width).method_22915(red, green, blue, specialAlpha);
         buffer.method_22918(matrix, x + width, y, z - width).method_22915(red, green, blue, specialAlpha);
         class_286.method_43433(buffer.method_60800());
      } finally {
         GL11.glDepthFunc(originalDepthFunc);
         if (originalCull) {
            RenderSystem.enableCull();
         } else {
            RenderSystem.disableCull();
         }

         if (originalBlend) {
            RenderSystem.enableBlend();
         } else {
            RenderSystem.disableBlend();
         }

         RenderSystem.setShader(originalShader);
         stack.method_22909();
      }

   }

   public static class_3545<class_243, Boolean> project(Matrix4f modelView, Matrix4f projection, class_243 vector) {
      class_243 camPos = vector.method_1020(mc.field_1773.method_19418().method_19326());
      Vector4f vec = new Vector4f((float)camPos.field_1352, (float)camPos.field_1351, (float)camPos.field_1350, 1.0F);
      vec.mul(modelView);
      vec.mul(projection);
      boolean isVisible = (double)vec.w() > 0.0D;
      if (vec.w() != 0.0F) {
         vec.x /= vec.w();
         vec.y /= vec.w();
         vec.z /= vec.w();
      }

      double screenX = ((double)vec.x() * 0.5D + 0.5D) * (double)mc.method_22683().method_4486();
      double screenY = (0.5D - (double)vec.y() * 0.5D) * (double)mc.method_22683().method_4502();
      class_243 position = new class_243(screenX, screenY, (double)vec.z());
      return new class_3545(position, isVisible);
   }

   public static class_243 getEntityPositionInterpolated(class_1297 entity, float delta) {
      return new class_243(class_3532.method_16436((double)delta, entity.field_6014, entity.method_23317()), class_3532.method_16436((double)delta, entity.field_6036, entity.method_23318()), class_3532.method_16436((double)delta, entity.field_5969, entity.method_23321()));
   }

   public static class_243 getEntityPositionOffsetInterpolated(class_1297 entity, float delta) {
      class_243 interpolated = getEntityPositionInterpolated(entity, delta);
      return entity.method_19538().method_1020(interpolated);
   }
}
