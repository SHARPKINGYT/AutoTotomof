package com.chorus.api.system.render;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import com.chorus.common.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_10149;
import net.minecraft.class_10156;
import net.minecraft.class_278;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_5944;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ExcludeFlow
@ExcludeConstant
@Environment(EnvType.CLIENT)
public class Shaders implements QuickImports, SimpleSynchronousResourceReloadListener {
   private static final Logger log = LoggerFactory.getLogger(Shaders.class);
   public static class_5944 ROUNDED_RECT;
   public static class_5944 ROUNDED_OUTLINE;
   public static class_5944 CIRCLE;
   public static class_5944 MSDF;
   public static class_5944 BLUR;
   public static class_5944 COLOR_PICKER;
   public static class_278 msdfPxrange;
   public static class_278 colorPickerResolution;
   public static class_278 colorPickerPosition;
   public static class_278 colorPickerHue;
   public static class_278 colorPickerAlpha;
   public static class_278 blurInputResolution;
   public static class_278 blurSize;
   public static class_278 blurLocation;
   public static class_278 blurRadius;
   public static class_278 blurBrightness;
   public static class_278 blurQuality;
   public static class_278 blurSampler;
   private static boolean initialized = false;

   public class_2960 getFabricId() {
      return class_2960.method_60655("chorus", "reload_shaders");
   }

   public void method_14491(class_3300 manager) {
      log.info("Reloading shaders...");
      load();
      log.info("Shaders reloaded successfully");
   }

   public static void load() {
      try {
         ROUNDED_RECT = class_310.method_1551().method_62887().method_62947(new class_10156(class_2960.method_60655("chorus", "core/rounded_rect"), class_290.field_1576, class_10149.field_53930));
         ROUNDED_OUTLINE = class_310.method_1551().method_62887().method_62947(new class_10156(class_2960.method_60655("chorus", "core/rounded_outline"), class_290.field_1576, class_10149.field_53930));
         CIRCLE = class_310.method_1551().method_62887().method_62947(new class_10156(class_2960.method_60655("chorus", "core/circle"), class_290.field_1576, class_10149.field_53930));
         MSDF = class_310.method_1551().method_62887().method_62947(new class_10156(class_2960.method_60655("chorus", "core/msdf"), class_290.field_1575, class_10149.field_53930));
         COLOR_PICKER = class_310.method_1551().method_62887().method_62947(new class_10156(class_2960.method_60655("chorus", "core/color_picker"), class_290.field_1576, class_10149.field_53930));
         BLUR = class_310.method_1551().method_62887().method_62947(new class_10156(class_2960.method_60655("chorus", "core/blur"), class_290.field_1592, class_10149.field_53930));
         msdfPxrange = MSDF.method_34582("pxRange");
         blurInputResolution = BLUR.method_34582("InputResolution");
         blurBrightness = BLUR.method_34582("Brightness");
         blurQuality = BLUR.method_34582("Quality");
         blurSize = BLUR.method_34582("uSize");
         blurLocation = BLUR.method_34582("uLocation");
         blurRadius = BLUR.method_34582("radius");
         colorPickerResolution = COLOR_PICKER.method_34582("Resolution");
         colorPickerPosition = COLOR_PICKER.method_34582("Position");
         colorPickerHue = COLOR_PICKER.method_34582("Hue");
         colorPickerAlpha = COLOR_PICKER.method_34582("Alpha");
         initialized = true;
      } catch (Exception var1) {
         log.error("Failed to load shaders: {}", var1.getMessage());
      }

   }

   public static boolean isInitialized() {
      return initialized;
   }

   static {
      ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new Shaders());
   }
}
