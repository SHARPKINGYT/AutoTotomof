package com.chorus.api.system.render;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.opengl.GL11;

@ExcludeFlow
@ExcludeConstant
@Environment(EnvType.CLIENT)
public class StencilUtil {
   public static void initStencil() {
      GL11.glEnable(2960);
      GL11.glEnable(3008);
      RenderSystem.colorMask(false, false, false, false);
      RenderSystem.depthMask(false);
      RenderSystem.stencilOp(7680, 7680, 7681);
      RenderSystem.stencilFunc(519, 255, 255);
      RenderSystem.stencilMask(255);
      RenderSystem.clear(1024);
   }

   public static void eraseStencil() {
      RenderSystem.colorMask(true, true, true, true);
      RenderSystem.depthMask(true);
      GL11.glDisable(3008);
      RenderSystem.stencilMask(0);
      RenderSystem.stencilOp(7680, 7680, 7680);
      RenderSystem.stencilFunc(514, 255, 255);
   }

   public static void disposeStencil() {
      GL11.glDisable(2960);
   }

   public static void renderStencil(Runnable init, Runnable end) {
      initStencil();
      init.run();
      eraseStencil();
      end.run();
      disposeStencil();
   }
}
