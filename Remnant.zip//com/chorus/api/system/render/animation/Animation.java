package com.chorus.api.system.render.animation;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ExcludeConstant
@ExcludeFlow
@Environment(EnvType.CLIENT)
public class Animation {
   private final AnimationTimer stopwatch = new AnimationTimer();
   private EasingType easing;
   private long duration;
   private double startPoint;
   private double endPoint;
   private double value;
   private boolean finished;

   public Animation(EasingType easing, long duration) {
      this.easing = easing;
      this.duration = duration;
   }

   public void run(double endPoint) {
      if (this.endPoint != endPoint) {
         this.endPoint = endPoint;
         this.reset();
      } else {
         this.finished = this.stopwatch.finished(this.duration);
         if (this.finished) {
            this.value = endPoint;
            return;
         }
      }

      double newValue = (Double)this.easing.getFunction().apply(this.getProgress());
      if (this.value > endPoint) {
         this.value = this.startPoint - (this.startPoint - endPoint) * newValue;
      } else {
         this.value = this.startPoint + (endPoint - this.startPoint) * newValue;
      }

   }

   public double getProgress() {
      return (double)(System.currentTimeMillis() - this.stopwatch.getLastMS()) / (double)this.duration;
   }

   public void reset() {
      this.stopwatch.reset();
      this.startPoint = this.value;
      this.startPoint = 0.0D;
      this.finished = false;
   }

   public void restart() {
      this.stopwatch.reset();
      this.startPoint = 0.0D;
      this.finished = false;
   }

   public AnimationTimer getStopwatch() {
      return this.stopwatch;
   }

   public EasingType getEasing() {
      return this.easing;
   }

   public long getDuration() {
      return this.duration;
   }

   public double getStartPoint() {
      return this.startPoint;
   }

   public double getEndPoint() {
      return this.endPoint;
   }

   public double getValue() {
      return this.value;
   }

   public boolean isFinished() {
      return this.finished;
   }

   public void setEasing(EasingType easing) {
      this.easing = easing;
   }

   public void setDuration(long duration) {
      this.duration = duration;
   }

   public void setStartPoint(double startPoint) {
      this.startPoint = startPoint;
   }

   public void setEndPoint(double endPoint) {
      this.endPoint = endPoint;
   }

   public void setValue(double value) {
      this.value = value;
   }

   public void setFinished(boolean finished) {
      this.finished = finished;
   }
}
