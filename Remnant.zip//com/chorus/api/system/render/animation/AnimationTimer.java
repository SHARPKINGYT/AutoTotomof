package com.chorus.api.system.render.animation;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ExcludeConstant
@ExcludeFlow
@Environment(EnvType.CLIENT)
public class AnimationTimer {
   private long lastMS;

   public AnimationTimer() {
      this.reset();
   }

   public boolean finished(long delay) {
      return System.currentTimeMillis() - delay >= this.lastMS;
   }

   public long getTime() {
      return System.currentTimeMillis() - this.lastMS;
   }

   public void reset() {
      this.lastMS = System.currentTimeMillis();
   }

   public long getLastMS() {
      return this.lastMS;
   }

   public void setLastMS(long lastMS) {
      this.lastMS = lastMS;
   }
}
