package com.chorus.api.system.render.animation;

import cc.polymorphism.annot.ExcludeConstant;
import cc.polymorphism.annot.ExcludeFlow;
import java.util.function.Function;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ExcludeConstant
@ExcludeFlow
@Environment(EnvType.CLIENT)
public enum EasingType {
   LINEAR((x) -> {
      return x;
   });

   private final Function<Double, Double> function;

   public Function<Double, Double> getFunction() {
      return this.function;
   }

   private EasingType(final Function<Double, Double> function) {
      this.function = function;
   }

   // $FF: synthetic method
   private static EasingType[] $values() {
      return new EasingType[]{LINEAR};
   }
}
