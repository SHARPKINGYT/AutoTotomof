package com.chorus.api.system.render.font;

import cc.polymorphism.annot.ExcludeFlow;
import com.chorus.api.system.render.Shaders;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import net.minecraft.class_5944;
import net.minecraft.class_9848;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;

@ExcludeFlow
@Environment(EnvType.CLIENT)
public class FontAtlas {
   private static final String FORMATTING_PALETTE = "0123456789abcdefklmnor";
   private static final int[][] FORMATTING_COLOR_PALETTE = new int[32][3];
   private final int[] textColor;
   private volatile float textX;
   private final int distanceRange;
   private final int width;
   private final int height;
   private float size;
   private final Glyph[] glyphs;
   private final FontMetrics fontMetrics;
   private final class_1043 tex;

   public FontAtlas(class_3300 manager, String name) throws IOException {
      this((Reader)(new InputStreamReader(manager.open(class_2960.method_60655("chorus", "fonts/" + name + ".json")))), (InputStream)manager.open(class_2960.method_60655("chorus", "fonts/" + name + ".png")));
   }

   public FontAtlas(Reader meta, InputStream texture) throws IOException {
      this.textColor = new int[3];
      this.size = 9.0F;
      this.glyphs = new Glyph[4194304];
      this.tex = new class_1043(class_1011.method_4309(texture));
      JsonObject atlasJson = JsonParser.parseReader(meta).getAsJsonObject();
      if ("msdf".equals(atlasJson.getAsJsonObject("atlas").get("width").getAsString())) {
         throw new RuntimeException("Unsupported atlas-type");
      } else {
         this.width = atlasJson.getAsJsonObject("atlas").get("width").getAsInt();
         this.height = atlasJson.getAsJsonObject("atlas").get("height").getAsInt();
         this.distanceRange = atlasJson.getAsJsonObject("atlas").get("distanceRange").getAsInt();
         this.fontMetrics = FontMetrics.parse(atlasJson.getAsJsonObject("metrics"));

         Glyph glyph;
         for(Iterator var4 = atlasJson.getAsJsonArray("glyphs").iterator(); var4.hasNext(); this.glyphs[glyph.getUnicode()] = glyph) {
            JsonElement glyphElement = (JsonElement)var4.next();
            JsonObject glyphObject = glyphElement.getAsJsonObject();
            glyph = Glyph.parse(glyphObject);
         }

      }
   }

   public String truncate(String text, float width, float size) {
      if (this.getWidth(text, size) <= width) {
         return text;
      } else {
         StringBuilder truncated = new StringBuilder();

         for(int i = 0; i < text.length(); ++i) {
            if (!(this.getWidth(truncated.toString(), size) < width)) {
               truncated.append("...");
               break;
            }

            truncated.append(text.charAt(i));
         }

         return truncated.toString();
      }
   }

   public void render(class_4587 matrixStack, String text, float x, float y, int color) {
      this.render(matrixStack, text, x, y, this.size, color);
   }

   public void renderRightString(class_4587 matrixStack, String text, float x, float y, float size, int color) {
      this.render(matrixStack, text, x - this.getWidth(text), y, size, color);
   }

   public void renderRightString(class_4587 matrixStack, String text, float x, float y, int color) {
      this.render(matrixStack, text, x - this.getWidth(text), y, this.size, color);
   }

   public void renderCenteredString(class_4587 matrixStack, String text, float x, float y, int color) {
      this.render(matrixStack, text, x - this.getWidth(text) / 2.0F, y, this.size, color);
   }

   public void renderCenteredString(class_4587 matrixStack, String text, float x, float y, float size, int color) {
      this.render(matrixStack, text, x - this.getWidth(text) / 2.0F, y, size, color);
   }

   public void renderHorizontalGradient(class_4587 matrices, String text, float x, float y, float size, Color primaryColor, Color secondaryColor, int speed) {
      if (Shaders.MSDF == null) {
         Shaders.load();
      }

      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_5944 lastShader = RenderSystem.getShader();
      RenderSystem.setShaderTexture(0, this.tex.method_4624());
      RenderSystem.setShader(Shaders.MSDF);
      Matrix4f model = matrices.method_23760().method_23761();
      int alpha = primaryColor.getAlpha();
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
      boolean hasContent = false;
      float currentX = x;

      for(int i = 0; i < text.length(); ++i) {
         int unicode = text.codePointAt(i);
         if (unicode == 167 && i + 1 < text.length()) {
            ++i;
         } else {
            Glyph glyph = this.glyphs[unicode];
            if (glyph != null) {
               if (glyph.getPlaneRight() - glyph.getPlaneLeft() != 0.0F) {
                  int index = (int)(currentX - x);
                  Color charColor = interpolateColor(primaryColor, secondaryColor, speed, index);
                  float x0 = currentX + glyph.getPlaneLeft() * size;
                  float x1 = currentX + glyph.getPlaneRight() * size;
                  float y0 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneTop() * size;
                  float y1 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneBottom() * size;
                  float u0 = glyph.getAtlasLeft() / (float)this.width;
                  float u1 = glyph.getAtlasRight() / (float)this.width;
                  float v0 = glyph.getAtlasTop() / (float)this.height;
                  float v1 = glyph.getAtlasBottom() / (float)this.height;
                  bufferBuilder.method_22918(model, x0, y0, 0.0F).method_22913(u0, 1.0F - v0).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  bufferBuilder.method_22918(model, x0, y1, 0.0F).method_22913(u0, 1.0F - v1).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  bufferBuilder.method_22918(model, x1, y1, 0.0F).method_22913(u1, 1.0F - v1).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  bufferBuilder.method_22918(model, x1, y0, 0.0F).method_22913(u1, 1.0F - v0).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  hasContent = true;
               }

               currentX += size * glyph.getAdvance();
            }
         }
      }

      if (hasContent) {
         class_286.method_43433(bufferBuilder.method_60800());
      }

      RenderSystem.setShader(lastShader);
      RenderSystem.disableBlend();
   }

   public void renderDiagonalGradient(class_4587 matrices, String text, float x, float y, float size, Color primaryColor, Color secondaryColor, int speed, float verticalStrength) {
      if (Shaders.MSDF == null) {
         Shaders.load();
      }

      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_5944 lastShader = RenderSystem.getShader();
      RenderSystem.setShaderTexture(0, this.tex.method_4624());
      RenderSystem.setShader(Shaders.MSDF);
      Matrix4f model = matrices.method_23760().method_23761();
      int alpha = primaryColor.getAlpha();
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
      boolean hasContent = false;
      float currentX = x;
      int yOffset = (int)(y * verticalStrength * 5.0F);

      for(int i = 0; i < text.length(); ++i) {
         int unicode = text.codePointAt(i);
         if (unicode == 167 && i + 1 < text.length()) {
            ++i;
         } else {
            Glyph glyph = this.glyphs[unicode];
            if (glyph != null) {
               if (glyph.getPlaneRight() - glyph.getPlaneLeft() != 0.0F) {
                  int xIndex = (int)(currentX - x);
                  int combinedIndex = xIndex + yOffset;
                  Color charColor = interpolateColor(primaryColor, secondaryColor, speed, -combinedIndex);
                  float x0 = currentX + glyph.getPlaneLeft() * size;
                  float x1 = currentX + glyph.getPlaneRight() * size;
                  float y0 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneTop() * size;
                  float y1 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneBottom() * size;
                  float u0 = glyph.getAtlasLeft() / (float)this.width;
                  float u1 = glyph.getAtlasRight() / (float)this.width;
                  float v0 = glyph.getAtlasTop() / (float)this.height;
                  float v1 = glyph.getAtlasBottom() / (float)this.height;
                  bufferBuilder.method_22918(model, x0, y0, 0.0F).method_22913(u0, 1.0F - v0).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  bufferBuilder.method_22918(model, x0, y1, 0.0F).method_22913(u0, 1.0F - v1).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  bufferBuilder.method_22918(model, x1, y1, 0.0F).method_22913(u1, 1.0F - v1).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  bufferBuilder.method_22918(model, x1, y0, 0.0F).method_22913(u1, 1.0F - v0).method_1336(charColor.getRed(), charColor.getGreen(), charColor.getBlue(), alpha);
                  hasContent = true;
               }

               currentX += size * glyph.getAdvance();
            }
         }
      }

      if (hasContent) {
         class_286.method_43433(bufferBuilder.method_60800());
      }

      RenderSystem.setShader(lastShader);
      RenderSystem.disableBlend();
   }

   public static Color interpolateColor(Color color1, Color color2, int speed, int index) {
      int angle = (int)((System.currentTimeMillis() / (long)speed + (long)index) % 360L);
      angle = (angle >= 180 ? 360 - angle : angle) * 2;
      return interpolateColorSimple(color1, color2, (float)angle / 360.0F);
   }

   public static Color interpolateColorSimple(Color color1, Color color2, float ratio) {
      int red = (int)((float)color1.getRed() + (float)(color2.getRed() - color1.getRed()) * ratio);
      int green = (int)((float)color1.getGreen() + (float)(color2.getGreen() - color1.getGreen()) * ratio);
      int blue = (int)((float)color1.getBlue() + (float)(color2.getBlue() - color1.getBlue()) * ratio);
      return new Color(red, green, blue);
   }

   public void render(class_4587 matrices, class_5481 text, float x, float y, float size, int color) {
      if (Shaders.MSDF == null) {
         Shaders.load();
      }

      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_5944 lastShader = RenderSystem.getShader();
      RenderSystem.setShaderTexture(0, this.tex.method_4624());
      RenderSystem.setShader(Shaders.MSDF);
      this.textX = x;
      Matrix4f model = matrices.method_23760().method_23761();
      int alpha = class_9848.method_61320(color);
      int red = class_9848.method_61327(color);
      int green = class_9848.method_61329(color);
      int blue = class_9848.method_61331(color);
      this.textColor[0] = red;
      this.textColor[1] = green;
      this.textColor[2] = blue;
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
      text.accept((index, style, codePoint) -> {
         Glyph glyph = this.glyphs[codePoint];
         if (glyph == null) {
            return true;
         } else {
            if (style.method_10973() == null) {
               this.textColor[0] = red;
               this.textColor[1] = green;
               this.textColor[2] = blue;
            } else {
               int rgb = style.method_10973().method_27716();
               this.textColor[0] = class_9848.method_61327(rgb);
               this.textColor[1] = class_9848.method_61329(rgb);
               this.textColor[2] = class_9848.method_61331(rgb);
            }

            this.textX += this.visit(model, bufferBuilder, glyph, this.textX, y, size, alpha);
            return true;
         }
      });
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.setShader(lastShader);
      RenderSystem.disableBlend();
   }

   public void render(class_4587 matrices, String text, float x, float y, float size, int color) {
      if (Shaders.MSDF == null) {
         Shaders.load();
      }

      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_5944 lastShader = RenderSystem.getShader();
      RenderSystem.setShaderTexture(0, this.tex.method_4624());
      RenderSystem.setShader(Shaders.MSDF);
      Matrix4f model = matrices.method_23760().method_23761();
      int alpha = class_9848.method_61320(color);
      int red = class_9848.method_61327(color);
      int green = class_9848.method_61329(color);
      int blue = class_9848.method_61331(color);
      this.textColor[0] = red;
      this.textColor[1] = green;
      this.textColor[2] = blue;
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
      boolean hasContent = false;

      for(int i = 0; i < text.length(); ++i) {
         int unicode = text.codePointAt(i);
         if (unicode == 167 && i + 1 < text.length()) {
            int colorIndex = "0123456789abcdefklmnor".indexOf(Character.toLowerCase(text.charAt(i + 1)));
            if (colorIndex >= 0 && colorIndex < 16) {
               System.arraycopy(FORMATTING_COLOR_PALETTE[colorIndex], 0, this.textColor, 0, 3);
            } else if (colorIndex == 21) {
               this.textColor[0] = red;
               this.textColor[1] = green;
               this.textColor[2] = blue;
            }

            ++i;
         } else {
            Glyph glyph = this.glyphs[unicode];
            if (glyph != null) {
               if (glyph.getPlaneRight() - glyph.getPlaneLeft() != 0.0F) {
                  float x0 = x + glyph.getPlaneLeft() * size;
                  float x1 = x + glyph.getPlaneRight() * size;
                  float y0 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneTop() * size;
                  float y1 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneBottom() * size;
                  float u0 = glyph.getAtlasLeft() / (float)this.width;
                  float u1 = glyph.getAtlasRight() / (float)this.width;
                  float v0 = glyph.getAtlasTop() / (float)this.height;
                  float v1 = glyph.getAtlasBottom() / (float)this.height;
                  bufferBuilder.method_22918(model, x0, y0, 0.0F).method_22913(u0, 1.0F - v0).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
                  bufferBuilder.method_22918(model, x0, y1, 0.0F).method_22913(u0, 1.0F - v1).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
                  bufferBuilder.method_22918(model, x1, y1, 0.0F).method_22913(u1, 1.0F - v1).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
                  bufferBuilder.method_22918(model, x1, y0, 0.0F).method_22913(u1, 1.0F - v0).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
                  hasContent = true;
               }

               x += size * glyph.getAdvance();
            }
         }
      }

      if (hasContent) {
         class_286.method_43433(bufferBuilder.method_60800());
      }

      RenderSystem.setShader(lastShader);
      RenderSystem.disableBlend();
   }

   public void renderWithShadow(class_4587 matrices, String text, float x, float y, float size, int color) {
      RenderSystem.setShaderColor(0.25F, 0.25F, 0.25F, 1.0F);
      this.render(matrices, text, x + 0.75F, y + 0.75F, size, color);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      this.render(matrices, text, x, y, size, color);
   }

   private float visit(Matrix4f model, class_287 bufferBuilder, Glyph glyph, float x, float y, float size, int alpha) {
      if (glyph.getPlaneRight() - glyph.getPlaneLeft() != 0.0F) {
         float x0 = x + glyph.getPlaneLeft() * size;
         float x1 = x + glyph.getPlaneRight() * size;
         float y0 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneTop() * size;
         float y1 = y + this.fontMetrics.getAscender() * size - glyph.getPlaneBottom() * size;
         float u0 = glyph.getAtlasLeft() / (float)this.width;
         float u1 = glyph.getAtlasRight() / (float)this.width;
         float v0 = glyph.getAtlasTop() / (float)this.height;
         float v1 = glyph.getAtlasBottom() / (float)this.height;
         bufferBuilder.method_22918(model, x0, y0, 0.0F).method_22913(u0, 1.0F - v0).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
         bufferBuilder.method_22918(model, x0, y1, 0.0F).method_22913(u0, 1.0F - v1).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
         bufferBuilder.method_22918(model, x1, y1, 0.0F).method_22913(u1, 1.0F - v1).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
         bufferBuilder.method_22918(model, x1, y0, 0.0F).method_22913(u1, 1.0F - v0).method_1336(this.textColor[0], this.textColor[1], this.textColor[2], alpha);
      }

      return size * glyph.getAdvance();
   }

   public void setSize(float size) {
      this.size = size;
   }

   public final float getSize() {
      return this.size;
   }

   public final float getWidth(class_2561 text) {
      return this.getWidth(text, this.size);
   }

   public final float getWidth(class_2561 text, float size) {
      return this.getWidth(text.method_30937(), size);
   }

   public final float getWidth(class_5481 text) {
      return this.getWidth(text, this.size);
   }

   public final float getWidth(class_5481 text, float size) {
      float[] sum = new float[1];
      text.accept((index, style, codePoint) -> {
         Glyph glyph = this.glyphs[codePoint];
         if (glyph == null) {
            return true;
         } else {
            if (glyph.getPlaneRight() - glyph.getPlaneLeft() != 0.0F) {
               sum[0] += size * glyph.getAdvance();
            }

            return true;
         }
      });
      return sum[0];
   }

   public final float getWidth(String text) {
      return this.getWidth(text, this.size);
   }

   public float getWidth(String text, float size) {
      float sum = 0.0F;

      for(int i = 0; i < text.length(); ++i) {
         int unicode = text.codePointAt(i);
         if (unicode == 167 && i + 1 < text.length()) {
            ++i;
         } else {
            Glyph glyph = this.glyphs[unicode];
            if (glyph != null) {
               sum += size * glyph.getAdvance();
            }
         }
      }

      return sum;
   }

   public final float getLineHeight() {
      return this.getLineHeight(this.size);
   }

   public final float getLineHeight(float size) {
      return this.fontMetrics.getLineHeight() * size;
   }

   static {
      for(int i = 0; i < 32; ++i) {
         int j = (i >> 3 & 1) * 85;
         int k = (i >> 2 & 1) * 170 + j;
         int l = (i >> 1 & 1) * 170 + j;
         int i1 = (i & 1) * 170 + j;
         if (i == 6) {
            k += 85;
         }

         if (i >= 16) {
            k /= 4;
            l /= 4;
            i1 /= 4;
         }

         FORMATTING_COLOR_PALETTE[i][0] = k;
         FORMATTING_COLOR_PALETTE[i][1] = l;
         FORMATTING_COLOR_PALETTE[i][2] = i1;
      }

   }
}
