package com.chorus.api.system.render.font;

import cc.polymorphism.annot.ExcludeFlow;
import com.google.gson.JsonObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ExcludeFlow
@Environment(EnvType.CLIENT)
public class FontMetrics {
   private int emSize;
   private float lineHeight;
   private float ascender;
   private float descender;
   private float underlineY;
   private float underlineThickness;

   public FontMetrics() {
   }

   public FontMetrics(int emSize, float lineHeight, float ascender, float descender, float underlineY, float underlineThickness) {
      this.emSize = emSize;
      this.lineHeight = lineHeight;
      this.ascender = ascender;
      this.descender = descender;
      this.underlineY = underlineY;
      this.underlineThickness = underlineThickness;
   }

   public static FontMetrics parse(JsonObject object) {
      FontMetrics metrics = new FontMetrics();
      metrics.emSize = object.get("emSize").getAsInt();
      metrics.lineHeight = object.get("lineHeight").getAsFloat();
      metrics.ascender = object.get("ascender").getAsFloat();
      metrics.descender = object.get("descender").getAsFloat();
      metrics.underlineY = object.get("underlineY").getAsFloat();
      metrics.underlineThickness = object.get("underlineThickness").getAsFloat();
      return metrics;
   }

   public int getEmSize() {
      return this.emSize;
   }

   public float getLineHeight() {
      return this.lineHeight;
   }

   public float getAscender() {
      return this.ascender;
   }

   public float getDescender() {
      return this.descender;
   }

   public float getUnderlineY() {
      return this.underlineY;
   }

   public float getUnderlineThickness() {
      return this.underlineThickness;
   }
}
