package com.chorus.api.system.render.font;

import cc.polymorphism.annot.ExcludeFlow;
import java.io.IOException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;

@ExcludeFlow
@Environment(EnvType.CLIENT)
public class Fonts implements SimpleSynchronousResourceReloadListener {
   private FontAtlas interBold;
   private FontAtlas interSemiBold;
   private FontAtlas interMedium;
   private FontAtlas proggyClean;
   private FontAtlas poppins;
   private FontAtlas icons;
   private FontAtlas lucide;

   public Fonts() {
      ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(this);
   }

   public class_2960 getFabricId() {
      return class_2960.method_60655("chorus", "reload_fonts");
   }

   public void method_14491(class_3300 manager) {
      try {
         this.interBold = new FontAtlas(manager, "inter-bold");
         this.interMedium = new FontAtlas(manager, "inter-medium");
         this.interSemiBold = new FontAtlas(manager, "inter-semibold");
         this.proggyClean = new FontAtlas(manager, "proggy-clean");
         this.poppins = new FontAtlas(manager, "poppins");
         this.icons = new FontAtlas(manager, "icons");
         this.lucide = new FontAtlas(manager, "lucide");
      } catch (IOException var3) {
         throw new RuntimeException("Couldn't load fonts", var3);
      }
   }

   public FontAtlas getInterBold() {
      return this.interBold;
   }

   public FontAtlas getInterSemiBold() {
      return this.interSemiBold;
   }

   public FontAtlas getInterMedium() {
      return this.interMedium;
   }

   public FontAtlas getProggyClean() {
      return this.proggyClean;
   }

   public FontAtlas getPoppins() {
      return this.poppins;
   }

   public FontAtlas getIcons() {
      return this.icons;
   }

   public FontAtlas getLucide() {
      return this.lucide;
   }
}
