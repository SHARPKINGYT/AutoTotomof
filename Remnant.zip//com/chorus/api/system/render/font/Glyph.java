package com.chorus.api.system.render.font;

import cc.polymorphism.annot.ExcludeFlow;
import com.google.gson.JsonObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ExcludeFlow
@Environment(EnvType.CLIENT)
public class Glyph {
   private int unicode;
   private float advance;
   private float planeLeft;
   private float planeBottom;
   private float planeRight;
   private float planeTop;
   private float atlasLeft;
   private float atlasBottom;
   private float atlasRight;
   private float atlasTop;

   public static Glyph parse(JsonObject object) {
      Glyph glyph = new Glyph();
      glyph.unicode = object.get("unicode").getAsInt();
      glyph.advance = object.get("advance").getAsFloat();
      if (object.has("planeBounds")) {
         glyph.planeLeft = object.get("planeBounds").getAsJsonObject().get("left").getAsFloat();
         glyph.planeBottom = object.get("planeBounds").getAsJsonObject().get("bottom").getAsFloat();
         glyph.planeRight = object.get("planeBounds").getAsJsonObject().get("right").getAsFloat();
         glyph.planeTop = object.get("planeBounds").getAsJsonObject().get("top").getAsFloat();
      }

      if (object.has("atlasBounds")) {
         glyph.atlasLeft = object.get("atlasBounds").getAsJsonObject().get("left").getAsFloat();
         glyph.atlasBottom = object.get("atlasBounds").getAsJsonObject().get("bottom").getAsFloat();
         glyph.atlasRight = object.get("atlasBounds").getAsJsonObject().get("right").getAsFloat();
         glyph.atlasTop = object.get("atlasBounds").getAsJsonObject().get("top").getAsFloat();
      }

      return glyph;
   }

   public int getUnicode() {
      return this.unicode;
   }

   public float getAdvance() {
      return this.advance;
   }

   public float getPlaneLeft() {
      return this.planeLeft;
   }

   public float getPlaneBottom() {
      return this.planeBottom;
   }

   public float getPlaneRight() {
      return this.planeRight;
   }

   public float getPlaneTop() {
      return this.planeTop;
   }

   public float getAtlasLeft() {
      return this.atlasLeft;
   }

   public float getAtlasBottom() {
      return this.atlasBottom;
   }

   public float getAtlasRight() {
      return this.atlasRight;
   }

   public float getAtlasTop() {
      return this.atlasTop;
   }
}
