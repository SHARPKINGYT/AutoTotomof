package com.chorus.api.system.rotation;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.math.rotation.RotationUtils;
import com.chorus.core.listener.Listener;
import com.chorus.impl.events.player.SilentRotationEvent;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.events.render.Render2DEvent;
import java.util.Optional;
import java.util.PriorityQueue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

@Environment(EnvType.CLIENT)
public class RotationComponent implements QuickImports, Listener {
   private float multiPoint = 1.0F;
   private float horizontalSpeed = 100.0F;
   private float verticalSpeed = 100.0F;
   private boolean silentRotation = true;
   private final PriorityQueue<RotationRequest> rotationQueue = new PriorityQueue();
   private float[] lastRotations = new float[]{0.0F, 0.0F};

   public RotationComponent() {
      Chorus.getInstance().getEventManager().register(this);
   }

   public void queueRotation(class_243 position, class_2350 direction, RotationComponent.RotationPriority priority, RotationComponent.AimType aimType) {
      float[] targetRotations = RotationUtils.getRotationToBlock(class_2338.method_49638(position), direction);
      this.addRotationRequest(new RotationRequest(targetRotations, priority, aimType));
   }

   public void queueRotation(class_243 position, RotationComponent.RotationPriority priority, RotationComponent.AimType aimType) {
      float[] targetRotations = RotationUtils.calculate(position);
      this.addRotationRequest(new RotationRequest(targetRotations, priority, aimType));
   }

   public void queueRotation(class_1309 entity, RotationComponent.RotationPriority priority, RotationComponent.AimType aimType, RotationComponent.EntityPoints entityPoints) {
      Optional<class_243> position = RotationUtils.getPossiblePoints(entity, this.multiPoint, entityPoints);
      if (!position.isEmpty()) {
         float[] targetRotations = RotationUtils.calculate(mc.field_1724.method_5836(mc.method_61966().method_60637(false)), (class_243)position.get());
         this.addRotationRequest(new RotationRequest(targetRotations, priority, aimType));
      }
   }

   public void queueRotation(float[] rotation, RotationComponent.RotationPriority priority, RotationComponent.AimType aimType) {
      this.addRotationRequest(new RotationRequest(RotationUtils.getFixedRotations(this.lastRotations, rotation), priority, aimType));
   }

   public void addRotationRequest(RotationRequest newRequest) {
      this.rotationQueue.removeIf((request) -> {
         return request.getPriority().getValue() < newRequest.getPriority().getValue();
      });
      this.rotationQueue.offer(newRequest);
   }

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (!event.getMode().equals(TickEvent.Mode.POST)) {
            RotationRequest highestPriorityRequest = (RotationRequest)this.rotationQueue.poll();
            if (highestPriorityRequest != null) {
               this.rotationQueue.remove(highestPriorityRequest);
            }
         }
      }
   }

   @RegisterEvent
   private void Render2DEventListener(Render2DEvent event) {
      RotationRequest highestPriorityRequest = (RotationRequest)this.rotationQueue.poll();
      if (highestPriorityRequest == null) {
         this.addRotationRequest(new RotationRequest(new float[]{mc.field_1724.method_36454(), mc.field_1724.method_36455()}, RotationComponent.RotationPriority.LOWEST, RotationComponent.AimType.BLATANT));
      } else {
         this.lastRotations = RotationUtils.getFixedRotations(this.lastRotations, this.getTargetRotations(this.lastRotations, highestPriorityRequest.getRotation(), this.horizontalSpeed, this.verticalSpeed, highestPriorityRequest.getAimType()));
         if (!this.silentRotation) {
            mc.field_1724.method_36456(this.lastRotations[0]);
            mc.field_1724.method_36457(this.lastRotations[1]);
         }

      }
   }

   @RegisterEvent
   private void silentRotationEvent(SilentRotationEvent event) {
      event.setYaw(this.lastRotations[0]);
      event.setPitch(this.lastRotations[1]);
   }

   public void clearQueue() {
      this.rotationQueue.clear();
   }

   public float[] getTargetRotations(float[] lastRotations, float[] targetRotations, float yawSpeed, float pitchSpeed, RotationComponent.AimType aimType) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         float yaw = this.silentRotation ? lastRotations[0] : mc.field_1724.method_36454();
         float pitch = this.silentRotation ? lastRotations[1] : mc.field_1724.method_36455();
         float delta = 1.0F / (float)mc.method_47599();
         switch(aimType.ordinal()) {
         case 0:
            return new float[]{MathUtils.lerpAngle(yaw, targetRotations[0], delta, yawSpeed * 0.5F), MathUtils.lerpAngle(pitch, targetRotations[1], delta, pitchSpeed * 0.5F)};
         case 1:
            return new float[]{MathUtils.smoothLerpAngle(yaw, targetRotations[0], delta, yawSpeed * 0.5F), MathUtils.smoothLerpAngle(pitch, targetRotations[1], delta, pitchSpeed * 0.5F)};
         case 2:
            float deltaYaw = Math.abs(yaw - targetRotations[0]);
            float deltaPitch = Math.abs(pitch - targetRotations[1]);
            return new float[]{MathUtils.smoothLerpAngle(yaw, targetRotations[0], delta, MathUtils.clamp((double)deltaYaw, 5.0D, 100.0D) * yawSpeed * 0.0075F), MathUtils.smoothLerpAngle(pitch, targetRotations[1], delta, MathUtils.clamp((double)deltaPitch, 5.0D, 100.0D) * pitchSpeed * 0.025F)};
         case 3:
            return new float[]{targetRotations[0], targetRotations[1]};
         default:
            return lastRotations;
         }
      } else {
         return lastRotations;
      }
   }

   public void setMultiPoint(float multiPoint) {
      this.multiPoint = multiPoint;
   }

   public void setHorizontalSpeed(float horizontalSpeed) {
      this.horizontalSpeed = horizontalSpeed;
   }

   public void setVerticalSpeed(float verticalSpeed) {
      this.verticalSpeed = verticalSpeed;
   }

   public void setSilentRotation(boolean silentRotation) {
      this.silentRotation = silentRotation;
   }

   public float[] getLastRotations() {
      return this.lastRotations;
   }

   public void setLastRotations(float[] lastRotations) {
      this.lastRotations = lastRotations;
   }

   @Environment(EnvType.CLIENT)
   public static enum RotationPriority {
      CRITICAL(5),
      HIGHEST(4),
      HIGH(3),
      MEDIUM(2),
      LOW(1),
      LOWEST(0);

      private final int value;

      private RotationPriority(int value) {
         this.value = value;
      }

      public int getValue() {
         return this.value;
      }

      // $FF: synthetic method
      private static RotationComponent.RotationPriority[] $values() {
         return new RotationComponent.RotationPriority[]{CRITICAL, HIGHEST, HIGH, MEDIUM, LOW, LOWEST};
      }
   }

   @Environment(EnvType.CLIENT)
   public static enum AimType {
      REGULAR,
      LINEAR,
      ADAPTIVE,
      BLATANT;

      // $FF: synthetic method
      private static RotationComponent.AimType[] $values() {
         return new RotationComponent.AimType[]{REGULAR, LINEAR, ADAPTIVE, BLATANT};
      }
   }

   @Environment(EnvType.CLIENT)
   public static enum EntityPoints {
      CLOSEST,
      STRAIGHT,
      RANDOM;

      // $FF: synthetic method
      private static RotationComponent.EntityPoints[] $values() {
         return new RotationComponent.EntityPoints[]{CLOSEST, STRAIGHT, RANDOM};
      }
   }
}
