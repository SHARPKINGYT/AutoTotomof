package com.chorus.api.system.rotation;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class RotationRequest implements Comparable<RotationRequest> {
   private final float[] rotation;
   private final RotationComponent.RotationPriority priority;
   private final RotationComponent.AimType aimType;

   public RotationRequest(float[] rotation, RotationComponent.RotationPriority priority, RotationComponent.AimType aimType) {
      this.rotation = rotation;
      this.priority = priority;
      this.aimType = aimType;
   }

   public int compareTo(RotationRequest other) {
      return other.priority.getValue() - this.priority.getValue();
   }

   public float[] getRotation() {
      return this.rotation;
   }

   public RotationComponent.RotationPriority getPriority() {
      return this.priority;
   }

   public RotationComponent.AimType getAimType() {
      return this.aimType;
   }
}
