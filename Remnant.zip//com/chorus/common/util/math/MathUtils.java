package com.chorus.common.util.math;

import com.chorus.api.system.prot.MathProt;
import java.util.Objects;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class MathUtils {
   private static final Random random = new Random();

   public static double angleBetween(class_243 v1, class_243 v2) {
      double dotProduct = v1.method_1026(v2);
      double magnitudeProduct = v1.method_1033() * v2.method_1033();
      return Math.acos(dotProduct / magnitudeProduct);
   }

   public static float applyGCD(float value, float gcd) {
      return value - value % gcd;
   }

   public static float calculateGCD(float sensitivity) {
      float f = sensitivity * 0.6F + 0.2F;
      return f * f * f * 1.2F;
   }

   public static float clamp(double val, double min, double max) {
      return (float)Math.max(min, Math.min(max, val));
   }

   public static double distance(class_243 vec1, class_243 vec2) {
      return distance(vec1.field_1352, vec1.field_1351, vec1.field_1350, vec2.field_1352, vec2.field_1351, vec2.field_1350);
   }

   public static double distance(double x1, double z1, double x2, double z2) {
      return Math.sqrt(Math.pow(x2 - x1, 2.0D) + Math.pow(z2 - z1, 2.0D));
   }

   public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
      return Math.sqrt(Math.pow(x2 - x1, 2.0D) + Math.pow(y2 - y1, 2.0D) + Math.pow(z2 - z1, 2.0D));
   }

   public static long factorial(int n) {
      if (n == 0) {
         return 1L;
      } else {
         long result = 1L;

         for(int i = 1; i <= n; ++i) {
            result *= (long)i;
         }

         return result;
      }
   }

   public static float lerp(float a, float b, float t) {
      return a + t * (b - a);
   }

   public static float smoothLerpAngle(float start, float end, float delta, float speed) {
      float diff = class_3532.method_15393(end - start);
      float alpha = 1.0F - (float)Math.exp((double)(-speed * delta));
      return Math.abs(diff) < speed * alpha ? end : start + class_3532.method_15363(diff, -speed * alpha, speed * alpha);
   }

   public static float lerpAngle(float start, float target, float deltaTime, float lerpSpeed) {
      float delta = class_3532.method_15393(target - start);
      float alpha = 1.0F - (float)Math.exp((double)(-lerpSpeed * deltaTime));
      return start + delta * alpha;
   }

   public static double randomDouble(double min, double max) {
      return min == 0.0D && max == 0.0D ? 0.0D : min + (max - min) * random.nextDouble();
   }

   public static int randomInt(int min, int max) {
      return min == 0 && max == 0 ? 0 : random.nextInt(max - min + 1) + min;
   }

   public static float randomFloat(float min, float max) {
      return min == 0.0F && max == 0.0F ? 0.0F : min + random.nextFloat() * (max - min);
   }

   public static <T extends Number> T randomNumber(T min, T max) {
      if (min.doubleValue() == 0.0D && max.doubleValue() == 0.0D) {
         return min;
      } else {
         double result = min.doubleValue() + random.nextDouble() * (max.doubleValue() - min.doubleValue());
         Objects.requireNonNull(min);
         byte var5 = 0;
         Number var10000;
         switch(min.typeSwitch<invokedynamic>(min, var5)) {
         case 0:
            Integer i = (Integer)min;
            var10000 = (Number)(int)result;
            break;
         case 1:
            Long l = (Long)min;
            var10000 = (Number)(long)result;
            break;
         case 2:
            Float v = (Float)min;
            var10000 = (Number)(float)result;
            break;
         case 3:
            Double v = (Double)min;
            var10000 = (Number)result;
            break;
         default:
            throw new IllegalArgumentException("Unsupported number type: " + String.valueOf(min.getClass()));
         }

         return var10000;
      }
   }

   public static double round(double value, int places) {
      if (places < 0) {
         throw new IllegalArgumentException();
      } else {
         long factor = (long)Math.pow(10.0D, (double)places);
         value *= (double)factor;
         long tmp = Math.round(value);
         return (double)tmp / (double)factor;
      }
   }

   public static double smoothStepLerp(double delta, double start, double end) {
      delta = Math.max(0.0D, Math.min(1.0D, delta));
      double t = delta * delta * (3.0D - 2.0D * delta);
      double value = start + class_3532.method_15338(end - start) * t;
      return value;
   }

   public static double toDegrees(double radians) {
      return radians * 180.0D / MathProt.PI();
   }

   public static double toRadians(double degrees) {
      return degrees * MathProt.PI() / 180.0D;
   }

   public static boolean isInRange(double value, double min, double max) {
      return value >= min && value <= max;
   }

   public static double getPercentage(double value, double min, double max) {
      return (value - min) / (max - min) * 100.0D;
   }

   public static boolean isPrime(int n) {
      if (n <= 1) {
         return false;
      } else {
         for(int i = 2; (double)i <= Math.sqrt((double)n); ++i) {
            if (n % i == 0) {
               return false;
            }
         }

         return true;
      }
   }
}
