package com.chorus.common.util.math;

import com.chorus.common.QuickImports;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1676;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1823;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3730;

@Environment(EnvType.CLIENT)
public class ProjectileUtils implements QuickImports {
   private static final List<class_243> landingPositions = new ArrayList();
   private static final class_1937 world;

   public static void trackProjectile(class_1799 itemStack, class_1309 shooter) {
      class_1299<? extends class_1676> entityType = getEntityTypeFromItem(itemStack.method_7909());
      if (entityType != null && world != null) {
         class_1676 projectile = (class_1676)entityType.method_5883(world, class_3730.field_16462);
         if (projectile != null) {
            projectile.method_5814(shooter.method_23317(), shooter.method_23320(), shooter.method_23321());
            setProjectileVelocity(projectile, shooter);
            simulateProjectilePath(projectile);
         }
      }
   }

   private static class_1299<? extends class_1676> getEntityTypeFromItem(class_1792 item) {
      if (!(item instanceof class_1753) && !(item instanceof class_1764)) {
         if (item instanceof class_1823) {
            return class_1299.field_6068;
         } else if (item instanceof class_1771) {
            return class_1299.field_6144;
         } else if (item instanceof class_1776) {
            return class_1299.field_6082;
         } else if (item instanceof class_1779) {
            return class_1299.field_6064;
         } else if (item instanceof class_1812) {
            return class_1299.field_6045;
         } else {
            return item instanceof class_1835 ? class_1299.field_6127 : null;
         }
      } else {
         return class_1299.field_6122;
      }
   }

   private static void setProjectileVelocity(class_1676 projectile, class_1309 shooter) {
      float pitch = shooter.method_36455();
      float yaw = shooter.method_36454();
      float velocity = 3.0F;
      float x = -class_3532.method_15374(yaw * 3.1415927F / 180.0F) * class_3532.method_15362(pitch * 3.1415927F / 180.0F);
      float y = -class_3532.method_15374(pitch * 3.1415927F / 180.0F);
      float z = class_3532.method_15362(yaw * 3.1415927F / 180.0F) * class_3532.method_15362(pitch * 3.1415927F / 180.0F);
      projectile.method_18799(new class_243((double)(x * velocity), (double)(y * velocity), (double)(z * velocity)));
   }

   private static void simulateProjectilePath(class_1676 projectile) {
      class_243 position = projectile.method_19538();
      class_243 velocity = projectile.method_18798();
      double gravity = 0.006D;

      while(position.field_1351 > 0.0D) {
         velocity = velocity.method_1021(0.99D);
         velocity = velocity.method_1031(0.0D, -gravity, 0.0D);
         position = position.method_1019(velocity);
         class_2338 blockPos = convertToBlockPos(position);
         if (!world.method_22347(blockPos)) {
            break;
         }

         if (world.method_8316(blockPos).method_15771()) {
            velocity = velocity.method_1021(0.8D);
         }
      }

      landingPositions.add(position);
   }

   public static class_2338 convertToBlockPos(class_243 vec3d) {
      return new class_2338((int)vec3d.field_1352, (int)vec3d.field_1351, (int)vec3d.field_1350);
   }

   public static List<class_243> getLandingPositions() {
      return new ArrayList(landingPositions);
   }

   static {
      world = mc.field_1687;
   }
}
