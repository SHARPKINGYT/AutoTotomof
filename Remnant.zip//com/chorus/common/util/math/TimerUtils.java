package com.chorus.common.util.math;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class TimerUtils {
   private long lastMS;
   private long lastUpdateTick;

   private long currentTick() {
      class_746 player = class_310.method_1551().field_1724;
      return player != null ? (long)player.field_6012 : 0L;
   }

   public long currentTimeMillis() {
      return System.nanoTime() / 1000000L;
   }

   public boolean delay(float milliSec) {
      return (float)(this.currentTimeMillis() - this.lastMS) >= milliSec;
   }

   public void reset() {
      this.lastMS = this.currentTimeMillis();
      this.lastUpdateTick = this.currentTick();
   }

   public boolean hasElapsed(int ticks) {
      if (ticks == 0) {
         return true;
      } else {
         long currentTick = this.currentTick();
         if (currentTick < this.lastUpdateTick) {
            this.lastUpdateTick = currentTick;
            return false;
         } else {
            return currentTick - this.lastUpdateTick >= (long)ticks;
         }
      }
   }

   public long getElapsedTicks() {
      return this.currentTick() - this.lastUpdateTick;
   }

   public boolean hasReached(double milliseconds) {
      if (milliseconds == 0.0D) {
         return true;
      } else {
         return (double)(this.currentTimeMillis() - this.lastMS) >= milliseconds;
      }
   }

   public long getLastMS() {
      return this.lastMS;
   }
}
