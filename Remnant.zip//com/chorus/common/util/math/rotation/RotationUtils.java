package com.chorus.common.util.math.rotation;

import chorus0.Chorus;
import com.chorus.api.system.rotation.RotationComponent;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.impl.modules.combat.Piercing;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public class RotationUtils implements QuickImports {
   public static float[] calculate(class_243 from, class_243 to) {
      class_243 diff = to.method_1020(from);
      double distance = Math.hypot(diff.method_10216(), diff.method_10215());
      float yaw = class_3532.method_15393((float)Math.toDegrees(Math.atan2(diff.method_10215(), diff.method_10216())) - 90.0F);
      float pitch = class_3532.method_15393((float)(-Math.toDegrees(Math.atan2(diff.method_10214(), distance))));
      return new float[]{yaw, pitch};
   }

   public static float[] calculate(class_243 to) {
      return calculate(mc.field_1724.method_19538().method_1031(0.0D, (double)mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D), to);
   }

   public static float[] getTargetRotations(float[] lastRotations, float[] targetRotations, float yawSpeed, float pitchSpeed, boolean silent, RotationComponent.AimType aimType) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         float yaw = silent ? lastRotations[0] : mc.field_1724.method_36454();
         float pitch = silent ? lastRotations[1] : mc.field_1724.method_36455();
         float delta = 1.0F / (float)mc.method_47599();
         switch(aimType) {
         case REGULAR:
            return new float[]{MathUtils.lerpAngle(yaw, targetRotations[0], delta, yawSpeed * 0.5F), MathUtils.lerpAngle(pitch, targetRotations[1], delta, pitchSpeed * 0.5F)};
         case LINEAR:
            return new float[]{MathUtils.smoothLerpAngle(yaw, targetRotations[0], delta, yawSpeed * 0.5F), MathUtils.smoothLerpAngle(pitch, targetRotations[1], delta, pitchSpeed * 0.5F)};
         case ADAPTIVE:
            float deltaYaw = Math.abs(yaw - targetRotations[0]);
            float deltaPitch = Math.abs(pitch - targetRotations[1]);
            return new float[]{MathUtils.smoothLerpAngle(yaw, targetRotations[0], delta, MathUtils.clamp((double)deltaYaw, 5.0D, 100.0D) * yawSpeed * 0.0075F), MathUtils.smoothLerpAngle(pitch, targetRotations[1], delta, MathUtils.clamp((double)deltaPitch, 5.0D, 100.0D) * pitchSpeed * 0.025F)};
         case BLATANT:
            return new float[]{targetRotations[0], targetRotations[1]};
         default:
            return lastRotations;
         }
      } else {
         return lastRotations;
      }
   }

   public static float[] calculate(class_243 position, class_2350 direction) {
      double x = position.method_10216() + 0.5D;
      double y = position.method_10214() + 0.5D;
      double z = position.method_10215() + 0.5D;
      x += (double)direction.method_62675().method_10263() * 0.5D;
      y += (double)direction.method_62675().method_10264() * 0.5D;
      z += (double)direction.method_62675().method_10260() * 0.5D;
      return calculate(new class_243(x, y, z));
   }

   public static float[] getRotationToBlock(class_2338 blockPos, class_2350 direction) {
      class_1657 player = mc.field_1724;
      class_243 playerPos = player.method_33571();
      class_243 pos = null;
      double distance = Double.MAX_VALUE;

      for(float xOffset = 0.5F; (double)xOffset >= -0.5D; xOffset -= 0.01F) {
         for(float yOffset = 0.5F; yOffset >= 0.0F; yOffset -= 0.1F) {
            for(float zOffset = 0.5F; (double)zOffset >= -0.5D; zOffset -= 0.01F) {
               class_243 target = blockPos.method_46558().method_1031(mc.field_1724.method_23317() - blockPos.method_46558().method_10216() + (double)xOffset, (double)yOffset, mc.field_1724.method_23321() - blockPos.method_46558().method_10215() + (double)zOffset);
               if (!mc.field_1687.method_8320(class_2338.method_49638(target)).method_26215() && playerPos.method_1022(target) < distance) {
                  distance = playerPos.method_1022(target);
                  pos = target;
               }
            }
         }
      }

      if (pos == null) {
         return new float[]{mc.field_1724.method_36454(), mc.field_1724.method_36455()};
      } else {
         class_243 delta = pos.method_1020(playerPos);
         double distanceXZ = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);
         float yaw = (float)class_3532.method_15338(Math.toDegrees(Math.atan2(delta.field_1350, delta.field_1352)) - 90.0D);
         float pitch = (float)class_3532.method_15338(-Math.toDegrees(Math.atan2(delta.field_1351, distanceXZ)));
         return new float[]{yaw, pitch};
      }
   }

   public static float[] applyGCD(float[] rotations, float[] lastRotations) {
      float f = (float)((Double)mc.field_1690.method_42495().method_41753() * 0.6000000238418579D + 0.20000000298023224D);
      float gcd = f * f * f * 1.2F;
      float deltaYaw = rotations[0] - lastRotations[0];
      float deltaPitch = rotations[1] - lastRotations[1];
      return new float[]{lastRotations[0] + (deltaYaw - deltaYaw % gcd), lastRotations[1] + (deltaPitch - deltaPitch % gcd)};
   }

   public static class_2350 getClosestSide(class_2338 blockPos, class_243 targetVec) {
      class_243 blockCenterPos = blockPos.method_46558();
      double deltaX = targetVec.field_1352 - blockCenterPos.field_1352;
      double deltaY = targetVec.field_1351 - blockCenterPos.field_1351;
      double deltaZ = targetVec.field_1350 - blockCenterPos.field_1350;
      double absDeltaX = Math.abs(deltaX);
      double absDeltaY = Math.abs(deltaY);
      double absDeltaZ = Math.abs(deltaZ);
      if (absDeltaX > absDeltaY && absDeltaX > absDeltaZ) {
         return deltaX > 0.0D ? class_2350.field_11034 : class_2350.field_11039;
      } else if (absDeltaY > absDeltaX && absDeltaY > absDeltaZ) {
         return deltaY > 0.0D ? class_2350.field_11036 : class_2350.field_11033;
      } else {
         return deltaZ > 0.0D ? class_2350.field_11035 : class_2350.field_11043;
      }
   }

   public static float[] getFixedRotations(float[] prev, float[] current) {
      return applyGCD(getCappedRotations(prev, current), prev);
   }

   public static class_243 getRotationVec(float yaw, float pitch) {
      float f = pitch * 0.017453292F;
      float g = -yaw * 0.017453292F;
      float h = class_3532.method_15362(g);
      float i = class_3532.method_15374(g);
      float j = class_3532.method_15362(f);
      float k = class_3532.method_15374(f);
      return new class_243((double)(i * j), (double)(-k), (double)(h * j));
   }

   public static class_3965 rayTrace(float yaw, float pitch, float reach) {
      class_243 start = mc.field_1719.method_5836(mc.method_61966().method_60637(false));
      class_243 rotationVec = getRotationVec(yaw, pitch);
      class_243 end = start.method_1019(rotationVec.method_1021((double)reach));
      return mc.field_1687.method_17742(new class_3959(start, end, class_3960.field_17558, class_242.field_1345, mc.field_1719));
   }

   public static class_3965 rayTrace(float yaw, float pitch, float reach, float tickDelta) {
      class_243 start = mc.field_1719.method_5836(tickDelta);
      class_243 rotationVec = getRotationVec(yaw, pitch);
      class_243 end = start.method_1019(rotationVec.method_1021((double)reach));
      return mc.field_1687.method_17742(new class_3959(start, end, ((Piercing)Chorus.getInstance().getModuleManager().getModule(Piercing.class)).isEnabled() ? class_3960.field_17558 : class_3960.field_17559, class_242.field_1348, mc.field_1719));
   }

   public static class_3965 rayTrace(class_243 end) {
      class_243 start = mc.field_1719.method_5836(mc.method_61966().method_60637(false));
      return mc.field_1687.method_17742(new class_3959(start, end, class_3960.field_17559, class_242.field_1348, mc.field_1719));
   }

   public static class_239 rayTraceWithCobwebs(class_243 endPos) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 startPos = mc.field_1724.method_5836(1.0F);
         return mc.field_1687.method_17742(new class_3959(startPos, endPos, class_3960.field_17559, class_242.field_1348, mc.field_1724));
      } else {
         return null;
      }
   }

   public static Optional<class_243> getPossiblePoints(class_1309 entity, float shrink) {
      if (entity != null && mc.field_1724 != null && mc.field_1687 != null) {
         Set<class_243> possiblePoints = new HashSet();
         class_238 bBox = entity.method_5829();
         class_243 playerPosition = mc.field_1724.method_19538().method_1031(0.0D, (double)mc.field_1724.method_5751(), 0.0D);
         float offset = (float)(bBox.method_17941() / 2.0D * (double)shrink);

         for(float x = -offset; x <= offset; x += (float)(bBox.method_17939() / 25.0D)) {
            for(float y = 0.0F; (double)y <= bBox.method_17940(); y += (float)bBox.method_17940() / 25.0F) {
               for(float z = -offset; z <= offset; z += (float)bBox.method_17941() / 25.0F) {
                  class_243 point = new class_243(bBox.method_1005().field_1352 - (double)x, bBox.field_1325 - (double)y - 0.10000000149011612D, bBox.method_1005().field_1350 - (double)z);
                  if (rayTrace(point).method_17784() == point) {
                     possiblePoints.add(point);
                  }
               }
            }
         }

         return possiblePoints.stream().min(Comparator.comparingDouble((pointx) -> {
            return pointx.method_1025(playerPosition);
         }));
      } else {
         return Optional.empty();
      }
   }

   public static Optional<class_243> getPossiblePoints(class_1309 entity, float shrink, RotationComponent.EntityPoints entityPoints) {
      if (entity != null && mc.field_1724 != null && mc.field_1687 != null) {
         Set<class_243> possiblePoints = new HashSet();
         class_238 bBox = entity.method_5829();
         class_243 playerPosition = mc.field_1724.method_19538().method_1031(0.0D, (double)mc.field_1724.method_5751(), 0.0D);
         float offset = (float)(bBox.method_17941() / 2.0D * (double)shrink);
         float xOffset = 0.0F;
         float yHeight = 0.0F;
         float zOffset = 0.0F;
         switch(entityPoints) {
         case STRAIGHT:
            xOffset = 0.0F;
            yHeight = (float)bBox.method_17940();
            zOffset = 0.0F;
            break;
         case CLOSEST:
            xOffset = offset;
            yHeight = (float)bBox.method_17940();
            zOffset = offset;
            break;
         case RANDOM:
            xOffset = (float)(bBox.method_17941() / 2.0D * (double)MathUtils.randomFloat(0.01F, 1.0F));
            yHeight = (float)(bBox.method_17940() * (double)MathUtils.randomFloat(0.01F, 1.0F));
            zOffset = (float)(bBox.method_17941() / 2.0D * (double)MathUtils.randomFloat(0.01F, 1.0F));
         }

         for(float x = -xOffset; x <= xOffset; x += (float)(bBox.method_17939() / 25.0D)) {
            for(float y = 0.0F; y <= yHeight; y += (float)bBox.method_17940() / 25.0F) {
               for(float z = -zOffset; z <= zOffset; z += (float)bBox.method_17941() / 25.0F) {
                  class_243 point = new class_243(bBox.method_1005().field_1352 - (double)x, bBox.field_1325 - (double)y - 0.10000000149011612D, bBox.method_1005().field_1350 - (double)z);
                  if (rayTrace(point).method_17784() == point) {
                     possiblePoints.add(point);
                  }
               }
            }
         }

         return possiblePoints.stream().min(Comparator.comparingDouble((pointx) -> {
            return pointx.method_1025(playerPosition);
         }));
      } else {
         return Optional.empty();
      }
   }

   public static float[] getCappedRotations(float[] prev, float[] current) {
      float yawDiff = getDelta(current[0], prev[0]);
      float cappedPYaw = prev[0] + yawDiff;
      float pitchDiff = getDelta(current[1], prev[1]);
      float cappedPitch = prev[1] + pitchDiff;
      return new float[]{cappedPYaw, cappedPitch};
   }

   public static float getDelta(float first, float second) {
      return class_3532.method_15393(first - second);
   }
}
