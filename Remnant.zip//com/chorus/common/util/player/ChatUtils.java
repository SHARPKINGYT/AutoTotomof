package com.chorus.common.util.player;

import com.chorus.api.system.render.ColorUtils;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import org.apache.commons.codec.binary.Base32;

@Environment(EnvType.CLIENT)
public class ChatUtils {
   protected static final class_310 mc = class_310.method_1551();

   public static void addChatMessage(String message) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         mc.field_1705.method_1743().method_1812(class_2561.method_43470(message));
      }
   }

   public static void printCrashReason(String message) {
      String saltedData = message + "remnantpathosionrealmoofdyrk";
      Base32 base32 = new Base32();
      String encoded = base32.encodeToString(saltedData.getBytes());
      System.out.println("Remnant Security » " + encoded);
   }

   public static void sendFormattedMessage(String message) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_5250 arrow = class_2561.method_43473();
         String prefix = "Remnant » ";
         Color primaryColor = new Color(184, 112, 242);
         Color secondaryColor = Color.white;

         for(int i = 0; i < prefix.length(); ++i) {
            int interpolatedColor = ColorUtils.interpolateColor(primaryColor, secondaryColor, 5, i * prefix.length() * 3).getRGB();
            class_5251 textColor = class_5251.method_27717(interpolatedColor);
            arrow.method_10852(class_2561.method_43470(String.valueOf(prefix.charAt(i))).method_10862(class_2583.field_24360.method_27703(textColor).method_10982(true)));
         }

         class_5250 fullMessage = arrow.method_10852(class_2561.method_43470(message).method_10862(class_2583.field_24360.method_10977(class_124.field_1068)));
         mc.field_1705.method_1743().method_1812(fullMessage);
      }
   }
}
