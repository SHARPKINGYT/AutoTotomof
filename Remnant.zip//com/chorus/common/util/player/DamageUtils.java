package com.chorus.common.util.player;

import com.chorus.common.QuickImports;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiFunction;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1280;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_1927;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3483;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_8103;
import net.minecraft.class_9285;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2902.class_2903;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class DamageUtils implements QuickImports {
   private static final float CRYSTAL_POWER = 12.0F;
   private static final float BED_POWER = 10.0F;
   private static final float ANCHOR_POWER = 10.0F;
   private static final float BLAST_RANGE_FACTOR = 2.0F;
   private static final float EXPLOSION_BASE_POWER = 7.0F;
   private static final float EXPLOSION_MODIFIER = 12.0F;
   public static final DamageUtils.ExplosionRaycast DEFAULT_RAYCAST = (context, pos) -> {
      class_2680 state = mc.field_1687.method_8320(pos);
      return state.method_26204().method_9520() >= 600.0F ? state.method_26220(mc.field_1687, pos).method_1092(context.start(), context.end(), pos) : null;
   };

   public static float calculateExplosionDamage(class_1309 entity, class_243 explosionPos, float power) {
      return !isValidTarget(entity) ? 0.0F : computeExplosionDamage(entity, entity.method_19538(), entity.method_5829(), explosionPos, power, DEFAULT_RAYCAST);
   }

   public static float calculateCrystalDamage(class_1309 entity, class_243 crystal) {
      return calculateExplosionDamage(entity, crystal, 12.0F);
   }

   public static float calculateBedDamage(class_1309 entity, class_243 bed) {
      return calculateExplosionDamage(entity, bed, 10.0F);
   }

   public static float calculateAnchorDamage(class_1309 entity, class_243 anchor) {
      return calculateExplosionWithOverride(entity, anchor, 10.0F, class_2338.method_49638(anchor), class_2246.field_10124.method_9564());
   }

   public static float calculateCombatDamage(class_1309 attacker, class_1309 target) {
      float baseDamage = (float)attacker.method_45325(class_5134.field_23721);
      class_1282 source = getDamageSource(attacker);
      return applyDamageModifiers(attacker, target, attacker.method_59958(), source, baseDamage);
   }

   public static float calculateWeaponDamage(class_1309 attacker, class_1309 target, class_1799 weapon) {
      class_1324 damageAttribute = createDamageAttribute(attacker, weapon);
      float baseDamage = (float)damageAttribute.method_6194();
      class_1282 source = getDamageSource(attacker);
      return applyDamageModifiers(attacker, target, weapon, source, baseDamage);
   }

   public static float calculateFallDamage(class_1309 entity) {
      if (shouldIgnoreFallDamage(entity)) {
         return 0.0F;
      } else {
         int surfaceY = getSurfaceHeight(entity);
         if (entity.method_31478() >= surfaceY) {
            return calculateFallReduction(entity, surfaceY);
         } else {
            class_3965 result = raycastToGround(entity);
            return result.method_17783() == class_240.field_1333 ? 0.0F : calculateFallReduction(entity, result.method_17777().method_10264());
         }
      }
   }

   private static float computeExplosionDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, float power, DamageUtils.ExplosionRaycast raycast) {
      double distance = targetPos.method_1022(explosionPos);
      if (distance > (double)power) {
         return 0.0F;
      } else {
         double exposure = (double)getExposure(explosionPos, targetBox, raycast);
         double impact = (1.0D - distance / (double)power) * exposure;
         float damage = (float)((impact * impact + impact) / 2.0D * 7.0D * 12.0D + 1.0D);
         return applyDamageReductions(damage, target, mc.field_1687.method_48963().method_48807((class_1927)null));
      }
   }

   private static float getExposure(class_243 source, class_238 box, DamageUtils.ExplosionRaycast raycast) {
      double d = 1.0D / ((box.field_1320 - box.field_1323) * 2.0D + 1.0D);
      double e = 1.0D / ((box.field_1325 - box.field_1322) * 2.0D + 1.0D);
      double f = 1.0D / ((box.field_1324 - box.field_1321) * 2.0D + 1.0D);
      double g = (1.0D - Math.floor(1.0D / d) * d) / 2.0D;
      double h = (1.0D - Math.floor(1.0D / f) * f) / 2.0D;
      if (!(d < 0.0D) && !(e < 0.0D) && !(f < 0.0D)) {
         int miss = 0;
         int hit = 0;

         for(double k = 0.0D; k <= 1.0D; k += d) {
            for(double l = 0.0D; l <= 1.0D; l += e) {
               for(double m = 0.0D; m <= 1.0D; m += f) {
                  double n = class_3532.method_16436(k, box.field_1323, box.field_1320);
                  double o = class_3532.method_16436(l, box.field_1322, box.field_1325);
                  double p = class_3532.method_16436(m, box.field_1321, box.field_1324);
                  class_243 vec3d = new class_243(n + g, o, p + h);
                  if (mc.field_1687.method_17742(new class_3959(vec3d, source, class_3960.field_17558, class_242.field_1348, mc.field_1724)).method_17783() == class_240.field_1333) {
                     ++miss;
                  }

                  ++hit;
               }
            }
         }

         return (float)miss / (float)hit;
      } else {
         return 0.0F;
      }
   }

   private static boolean isLineOfSight(class_243 start, class_243 end) {
      return mc.field_1687.method_17742(new class_3959(start, end, class_3960.field_17558, class_242.field_1348, mc.field_1724)).method_17783() == class_240.field_1333;
   }

   private static float applyDamageReductions(float damage, class_1309 entity, class_1282 source) {
      damage = applyDifficultyModifier(damage, source);
      damage = applyArmorReduction(damage, entity, source);
      damage = applyResistanceEffect(damage, entity);
      damage = applyProtectionEnchantments(damage, entity, source);
      return Math.max(damage, 0.0F);
   }

   private static float applyDifficultyModifier(float damage, class_1282 source) {
      if (!source.method_5514()) {
         return damage;
      } else {
         float var10000;
         switch(mc.field_1687.method_8407()) {
         case field_5805:
            var10000 = Math.min(damage / 2.0F + 1.0F, damage);
            break;
         case field_5807:
            var10000 = damage * 1.5F;
            break;
         default:
            var10000 = damage;
         }

         return var10000;
      }
   }

   private static float applyArmorReduction(float damage, class_1309 entity, class_1282 source) {
      return class_1280.method_5496(entity, damage, source, (float)Math.floor(entity.method_45325(class_5134.field_23724)), (float)entity.method_45325(class_5134.field_23725));
   }

   private static float applyResistanceEffect(float damage, class_1309 entity) {
      class_1293 resistance = entity.method_6112(class_1294.field_5907);
      if (resistance != null) {
         int level = resistance.method_5578() + 1;
         damage *= 1.0F - (float)level * 0.2F;
      }

      return Math.max(damage, 0.0F);
   }

   private static float applyProtectionEnchantments(float damage, class_1309 entity, class_1282 source) {
      if (source.method_48789(class_8103.field_42242)) {
         return damage;
      } else {
         int totalProtection = 0;

         Object2IntOpenHashMap enchants;
         for(Iterator var4 = entity.method_56674().iterator(); var4.hasNext(); totalProtection += calculateProtectionValue(enchants, source)) {
            class_1799 armor = (class_1799)var4.next();
            enchants = new Object2IntOpenHashMap();
            getItemEnchantments(armor, enchants);
         }

         return class_1280.method_5497(damage, (float)totalProtection);
      }
   }

   private static void getItemEnchantments(class_1799 item, Object2IntMap<class_6880<class_1887>> enchants) {
      enchants.clear();
      if (!item.method_7960()) {
         Set<Entry<class_6880<class_1887>>> entries = item.method_7909() == class_1802.field_8598 ? ((class_9304)item.method_57824(class_9334.field_49643)).method_57539() : item.method_58657().method_57539();
         entries.forEach((entry) -> {
            enchants.put((class_6880)entry.getKey(), entry.getIntValue());
         });
      }
   }

   private static int calculateProtectionValue(Object2IntMap<class_6880<class_1887>> enchants, class_1282 source) {
      int protection = 0;
      ObjectIterator var3 = Object2IntMaps.fastIterable(enchants).iterator();

      while(var3.hasNext()) {
         Entry<class_6880<class_1887>> entry = (Entry)var3.next();
         if (((class_6880)entry.getKey()).method_40225(class_1893.field_9111)) {
            protection += entry.getIntValue();
         }

         if (source.method_48789(class_8103.field_42246) && ((class_6880)entry.getKey()).method_40225(class_1893.field_9095)) {
            protection += 2 * entry.getIntValue();
         }

         if (source.method_48789(class_8103.field_42249) && ((class_6880)entry.getKey()).method_40225(class_1893.field_9107)) {
            protection += 2 * entry.getIntValue();
         }

         if (source.method_48789(class_8103.field_42247) && ((class_6880)entry.getKey()).method_40225(class_1893.field_9096)) {
            protection += 2 * entry.getIntValue();
         }

         if (source.method_48789(class_8103.field_42250) && ((class_6880)entry.getKey()).method_40225(class_1893.field_9129)) {
            protection += 3 * entry.getIntValue();
         }
      }

      return protection;
   }

   private static boolean isValidTarget(class_1309 entity) {
      if (entity == null) {
         return false;
      } else if (!(entity instanceof class_1657)) {
         return true;
      } else {
         class_1657 player = (class_1657)entity;
         return !player.method_7337() && !player.method_7325();
      }
   }

   private static float calculateFallReduction(class_1309 entity, int surfaceY) {
      int fallHeight = (int)(entity.method_23318() - (double)surfaceY + (double)entity.field_6017 - 3.0D);
      class_1293 jumpBoost = entity.method_6112(class_1294.field_5913);
      if (jumpBoost != null) {
         fallHeight -= jumpBoost.method_5578() + 1;
      }

      return applyDamageReductions((float)fallHeight, entity, mc.field_1687.method_48963().method_48827());
   }

   private static boolean shouldIgnoreFallDamage(class_1309 entity) {
      boolean var10000;
      label17: {
         if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (player.method_31549().field_7479) {
               break label17;
            }
         }

         if (!entity.method_6059(class_1294.field_5906) && !entity.method_6059(class_1294.field_5902)) {
            var10000 = false;
            return var10000;
         }
      }

      var10000 = true;
      return var10000;
   }

   private static int getSurfaceHeight(class_1309 entity) {
      return mc.field_1687.method_8500(entity.method_24515()).method_12032(class_2903.field_13197).method_12603(entity.method_31477() & 15, entity.method_31479() & 15);
   }

   private static class_3965 raycastToGround(class_1309 entity) {
      return mc.field_1687.method_17742(new class_3959(entity.method_19538(), new class_243(entity.method_23317(), (double)mc.field_1687.method_31607(), entity.method_23321()), class_3960.field_17558, class_242.field_36338, entity));
   }

   private static class_1282 getDamageSource(class_1309 attacker) {
      class_1282 var10000;
      if (attacker instanceof class_1657) {
         class_1657 player = (class_1657)attacker;
         var10000 = mc.field_1687.method_48963().method_48802(player);
      } else {
         var10000 = mc.field_1687.method_48963().method_48812(attacker);
      }

      return var10000;
   }

   private static class_1324 createDamageAttribute(class_1309 attacker, class_1799 weapon) {
      class_1324 original = attacker.method_5996(class_5134.field_23721);
      class_1324 copy = new class_1324(class_5134.field_23721, (o) -> {
      });
      copy.method_6192(original.method_6201());
      Set var10000 = original.method_6195();
      Objects.requireNonNull(copy);
      var10000.forEach(copy::method_26835);
      copy.method_6200(class_1792.field_8006);
      class_9285 modifiers = (class_9285)weapon.method_57824(class_9334.field_49636);
      if (modifiers != null) {
         modifiers.method_57482(class_1304.field_6173, (entry, modifier) -> {
            if (entry == class_5134.field_23721) {
               copy.method_55696(modifier);
            }

         });
      }

      return copy;
   }

   private static float calculateExplosionWithOverride(class_1309 entity, class_243 pos, float power, class_2338 override, class_2680 state) {
      DamageUtils.ExplosionRaycast var10000 = (context, blockPos) -> {
         class_2680 blockState = blockPos.equals(override) ? state : mc.field_1687.method_8320(blockPos);
         return blockState.method_26204().method_9520() >= 600.0F ? blockState.method_26220(mc.field_1687, blockPos).method_1092(context.start(), context.end(), blockPos) : null;
      };
      return calculateExplosionDamage(entity, pos, power);
   }

   private static float applyDamageModifiers(class_1309 attacker, class_1309 target, class_1799 weapon, class_1282 source, float baseDamage) {
      float damage = baseDamage;
      Object2IntMap<class_6880<class_1887>> enchantments = new Object2IntOpenHashMap();
      getItemEnchantments(weapon, enchantments);
      float enchantDamage = 0.0F;
      int sharpness = getEnchantmentLevel((Object2IntMap)enchantments, class_1893.field_9118);
      if (sharpness > 0) {
         enchantDamage += 1.0F + 0.5F * (float)(sharpness - 1);
      }

      int baneOfArthropods = getEnchantmentLevel((Object2IntMap)enchantments, class_1893.field_9112);
      if (baneOfArthropods > 0 && target.method_5864().method_20210(class_3483.field_48285)) {
         enchantDamage += 2.5F * (float)baneOfArthropods;
      }

      int impaling = getEnchantmentLevel((Object2IntMap)enchantments, class_1893.field_9106);
      if (impaling > 0 && target.method_5864().method_20210(class_3483.field_48284)) {
         enchantDamage += 2.5F * (float)impaling;
      }

      int smite = getEnchantmentLevel((Object2IntMap)enchantments, class_1893.field_9123);
      if (smite > 0 && target.method_5864().method_20210(class_3483.field_49931)) {
         enchantDamage += 2.5F * (float)smite;
      }

      if (attacker instanceof class_1657) {
         class_1657 player = (class_1657)attacker;
         float cooldown = player.method_7261(0.5F);
         damage = baseDamage * (0.2F + cooldown * cooldown * 0.8F);
         enchantDamage *= cooldown;
         class_1792 var15 = weapon.method_7909();
         if (var15 instanceof class_9362) {
            class_9362 mace = (class_9362)var15;
            float bonusDamage = mace.method_58403(target, damage, source);
            if (bonusDamage > 0.0F) {
               int density = getEnchantmentLevel(weapon, class_1893.field_50157);
               if (density > 0) {
                  bonusDamage += 0.5F * attacker.field_6017;
               }

               damage += bonusDamage;
            }
         }

         if (cooldown > 0.9F && attacker.field_6017 > 0.0F && !attacker.method_24828() && !attacker.method_6101() && !attacker.method_5799() && !attacker.method_6059(class_1294.field_5919) && !attacker.method_5765()) {
            damage *= 1.5F;
         }
      }

      return applyDamageReductions(damage + enchantDamage, target, source);
   }

   public static int getEnchantmentLevel(class_1799 stack, class_5321<class_1887> enchantment) {
      if (stack.method_7960()) {
         return 0;
      } else {
         Object2IntMap<class_6880<class_1887>> enchantments = new Object2IntArrayMap();
         getItemEnchantments(stack, enchantments);
         return getEnchantmentLevel((Object2IntMap)enchantments, enchantment);
      }
   }

   public static int getEnchantmentLevel(Object2IntMap<class_6880<class_1887>> enchantments, class_5321<class_1887> enchantment) {
      ObjectIterator var2 = Object2IntMaps.fastIterable(enchantments).iterator();

      Entry entry;
      do {
         if (!var2.hasNext()) {
            return 0;
         }

         entry = (Entry)var2.next();
      } while(!((class_6880)entry.getKey()).method_40225(enchantment));

      return entry.getIntValue();
   }

   @Environment(EnvType.CLIENT)
   public interface ExplosionRaycast extends BiFunction<DamageUtils.ExplosionContext, class_2338, class_3965> {
   }

   @Environment(EnvType.CLIENT)
   public static record ExplosionContext(class_243 start, class_243 end) {
      public ExplosionContext(class_243 start, class_243 end) {
         this.start = start;
         this.end = end;
      }

      public class_243 start() {
         return this.start;
      }

      public class_243 end() {
         return this.end;
      }
   }
}
