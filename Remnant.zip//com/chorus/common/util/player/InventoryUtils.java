package com.chorus.common.util.player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public class InventoryUtils {
   protected static final class_310 mc = class_310.method_1551();

   public static int findItemInInventory(class_1792 item) {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 0; i < inventory.method_5439(); ++i) {
         if (inventory.method_5438(i).method_7909() == item) {
            return i;
         }
      }

      return -1;
   }

   public static int findItemInStrictlyInventory(class_1792 item) {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 9; i < inventory.method_5439(); ++i) {
         if (inventory.method_5438(i).method_7909() == item && i != 40) {
            return i;
         }
      }

      return -1;
   }

   public static int findItemInHotBar(class_1792 item) {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 0; i <= 8; ++i) {
         if (inventory.method_5438(i).method_7909() == item) {
            return i;
         }
      }

      return -1;
   }

   public static int FindItemInInventoryWindow(class_1792 item, int min, int max, class_1703 handler) {
      for(int i = min; i <= max; ++i) {
         if (handler.method_7611(i).method_7677().method_7909() == item) {
            return i;
         }
      }

      return -1;
   }

   public static int findItemByName(String itemName) {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 0; i <= 8; ++i) {
         if (inventory.method_5438(i).method_7964().method_44745(class_2561.method_30163(itemName))) {
            return i;
         }
      }

      return -1;
   }

   public static int countItem(class_1792 item) {
      class_1661 inventory = mc.field_1724.method_31548();
      int count = 0;

      for(int i = 0; i < inventory.method_5439(); ++i) {
         class_1799 stack = inventory.method_5438(i);
         if (stack.method_7909() == item) {
            count += stack.method_7947();
         }
      }

      return count;
   }

   public static void swapWithMainHand(int slot) {
      mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7791, mc.field_1724);
   }

   public static void dropItem(int slot) {
      mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 1, class_1713.field_7795, mc.field_1724);
   }

   public static boolean isInventoryFull() {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 0; i < inventory.field_7547.size(); ++i) {
         if (((class_1799)inventory.field_7547.get(i)).method_7960()) {
            return false;
         }
      }

      return true;
   }

   public static int findEmptySlot() {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 0; i < inventory.field_7547.size(); ++i) {
         if (((class_1799)inventory.field_7547.get(i)).method_7960()) {
            return i;
         }
      }

      return -1;
   }

   public static void moveItem(int fromSlot, int toSlot) {
      mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, fromSlot, 0, class_1713.field_7793, mc.field_1724);
      mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, toSlot, 0, class_1713.field_7790, mc.field_1724);
   }

   public static void moveAllItems(int fromSlot, int toSlot) {
      mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, fromSlot, 0, class_1713.field_7793, mc.field_1724);
      mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, toSlot, 0, class_1713.field_7793, mc.field_1724);
   }

   public static boolean hasItem(class_1792 item) {
      return findItemInInventory(item) != -1;
   }

   public static boolean hasItemInInventory(class_1792 item) {
      return findItemInStrictlyInventory(item) != -1;
   }

   public static int findItemWithPredicate(Predicate<class_1799> predicate) {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 0; i < inventory.method_5439(); ++i) {
         if (predicate.test(inventory.method_5438(i))) {
            return i;
         }
      }

      return -1;
   }

   public static List<Integer> findItemWithPredicateInventory(Predicate<class_1799> predicate) {
      class_1661 inventory = mc.field_1724.method_31548();
      List<Integer> slots = new ArrayList();

      for(int i = 9; i < 45; ++i) {
         if (predicate.test(inventory.method_5438(i))) {
            slots.add(i);
         }
      }

      return slots;
   }

   public static int findItemWithPredicateInHotbar(Predicate<class_1799> predicate) {
      class_1661 inventory = mc.field_1724.method_31548();

      for(int i = 0; i <= 8; ++i) {
         if (predicate.test(inventory.method_5438(i))) {
            return i;
         }
      }

      return -1;
   }

   public static class_1799 getMainHandItem() {
      return mc.field_1724.method_6047();
   }

   public static class_1799 getOffHandItem() {
      return mc.field_1724.method_6079();
   }

   public static boolean isMainHandEmpty() {
      return mc.field_1724.method_6047().method_7960();
   }

   public static void swapToMainHand(int slot) {
      class_1661 inventory = mc.field_1724.method_31548();
      inventory.field_7545 = slot;
   }

   public static void swapItemToOffhand(int fromSlot) {
      int convertedSlot = fromSlot < 9 ? fromSlot + 36 : fromSlot;
      mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, convertedSlot, 40, class_1713.field_7791, mc.field_1724);
   }

   public static boolean swap(class_1792 item) {
      class_1661 inv = mc.field_1724.method_31548();

      for(int i = 0; i <= 8; ++i) {
         if (inv.method_5438(i).method_31574(item)) {
            inv.field_7545 = i;
            return true;
         }
      }

      return false;
   }
}
