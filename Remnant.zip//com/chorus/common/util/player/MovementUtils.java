package com.chorus.common.util.player;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class MovementUtils {
   protected static final class_310 mc = class_310.method_1551();

   public static double getSpeed() {
      return mc.field_1724 == null ? 0.0D : Math.hypot(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1350);
   }

   public static double getSpeed(class_1309 entity) {
      return mc.field_1724 == null ? 0.0D : Math.hypot(entity.method_18798().field_1352, entity.method_18798().field_1350);
   }

   public static int[] convertToMoveDirection(float deltaYaw, float forwardMultiplier, float sidewaysMultiplier) {
      float forwardMovement = forwardMultiplier * class_3532.method_15362(deltaYaw * 0.017453292F) - forwardMultiplier * class_3532.method_15374(deltaYaw * 0.017453292F);
      float sidewaysMovement = sidewaysMultiplier * class_3532.method_15362(deltaYaw * 0.017453292F) + sidewaysMultiplier * class_3532.method_15374(deltaYaw * 0.017453292F);
      int movementForward = Math.round(forwardMovement);
      int movementSideways = Math.round(sidewaysMovement);
      return new int[]{movementForward, movementSideways};
   }

   public static void setSpeedWithStrafe(double speed) {
      if (mc.field_1724 != null) {
         mc.field_1724.method_18800(-Math.sin(getDirection()) * speed, mc.field_1724.method_18798().method_10214(), Math.cos(getDirection()) * speed);
      }
   }

   public static void setSpeedWithStrafe(double speed, float yaw) {
      if (mc.field_1724 != null) {
         mc.field_1724.method_18800(-Math.sin(getDirection()) * speed, mc.field_1724.method_18798().method_10214(), Math.cos(getDirection()) * speed);
      }
   }

   public static boolean hasMovementInput() {
      if (mc.field_1724 == null) {
         return false;
      } else {
         return mc.field_1690.field_1894.method_1434() || mc.field_1690.field_1881.method_1434() || mc.field_1690.field_1913.method_1434() || mc.field_1690.field_1849.method_1434() || mc.field_1690.field_1903.method_1434();
      }
   }

   public static double getDirection() {
      if (mc.field_1724 == null) {
         return 0.0D;
      } else {
         float moveForward = mc.field_1724.field_3913.field_3905;
         float moveStrafing = mc.field_1724.field_3913.field_3907;
         float rotationYaw = mc.field_1724.method_36454();
         if (moveForward < 0.0F) {
            rotationYaw += 180.0F;
         }

         float forward = Math.abs(moveForward) > 0.1F ? (moveForward > 0.0F ? 0.5F : -0.5F) : 0.0F;
         if (moveStrafing > 0.0F) {
            rotationYaw -= 90.0F * forward;
         } else if (moveStrafing < 0.0F) {
            rotationYaw += 90.0F * forward;
         }

         return Math.toRadians((double)rotationYaw);
      }
   }

   public static double getDirection(float rotationYaw, double moveForward, double moveStrafing) {
      if (mc.field_1724 == null) {
         return 0.0D;
      } else {
         float rotationYawCalced = rotationYaw;
         if (moveForward < 0.0D) {
            rotationYawCalced = rotationYaw + 180.0F;
         }

         float forward = Math.abs(moveForward) > 0.10000000149011612D ? (moveForward > 0.0D ? 0.5F : -0.5F) : 0.0F;
         if (moveStrafing > 0.0D) {
            rotationYawCalced -= 90.0F * forward;
         } else if (moveStrafing < 0.0D) {
            rotationYawCalced += 90.0F * forward;
         }

         return Math.toRadians((double)rotationYawCalced);
      }
   }
}
