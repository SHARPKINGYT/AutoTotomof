package com.chorus.common.util.player;

import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.SocialManager;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Objects;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public class PlayerUtils {
   protected static final class_310 mc = class_310.method_1551();

   public static boolean canCriticalHit() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         boolean canCrit = mc.field_1724.field_6017 > 0.0F && !mc.field_1724.method_5799() && !mc.field_1724.method_5771() && !mc.field_1724.method_6101() && !mc.field_1724.method_5765() && !mc.field_1724.method_6059(class_1294.field_5919);
         return canCrit;
      } else {
         return false;
      }
   }

   public static class_1297 raytraceEntity(double range) {
      class_243 cameraPos = mc.field_1773.method_19418().method_19326();
      class_243 viewVector = mc.field_1724.method_5663();
      class_243 extendedPoint = cameraPos.method_1031(viewVector.field_1352 * range, viewVector.field_1351 * range, viewVector.field_1350 * range);
      Iterator var5 = mc.field_1687.method_18112().iterator();

      class_1297 entity;
      do {
         if (!var5.hasNext()) {
            return null;
         }

         entity = (class_1297)var5.next();
      } while(!(entity instanceof class_1309) || entity == mc.field_1724 || !entity.method_5829().method_993(cameraPos, extendedPoint));

      return entity;
   }

   public static boolean isShieldFacingAway(class_1309 player) {
      if (!player.method_31747()) {
         return true;
      } else if (mc.field_1724 == null) {
         return false;
      } else {
         class_243 directionToPlayer = mc.field_1724.method_19538().method_1020(player.method_19538()).method_1029();
         class_243 facingDirection = (new class_243(-Math.sin(Math.toRadians((double)player.method_36454())) * Math.cos(Math.toRadians((double)player.method_36455())), -Math.sin(Math.toRadians((double)player.method_36455())), Math.cos(Math.toRadians((double)player.method_36454())) * Math.cos(Math.toRadians((double)player.method_36455())))).method_1029();
         double dotProduct = facingDirection.method_1026(directionToPlayer);
         return dotProduct < -0.06D;
      }
   }

   public static void attackEnemy(boolean packetAttack, class_1309 entity) {
      if (packetAttack) {
         mc.field_1761.method_2918(mc.field_1724, entity);
         mc.field_1724.method_6104(class_1268.field_5808);
      } else {
         InputUtils.simulateClick(0, 50);
      }

   }

   public static class_1297 getClosestEnemy(float range) {
      Stream var10000 = mc.field_1687.method_18456().stream().filter((player) -> {
         return player != mc.field_1724 && mc.field_1724.method_5739(player) <= range && SocialManager.isEnemy(player);
      });
      class_746 var10001 = mc.field_1724;
      Objects.requireNonNull(var10001);
      return (class_1297)var10000.min(Comparator.comparingDouble(var10001::method_5739)).orElse((Object)null);
   }
}
