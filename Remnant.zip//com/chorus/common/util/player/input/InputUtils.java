package com.chorus.common.util.player.input;

import chorus0.asm.accessors.MinecraftClientAccessor;
import chorus0.asm.accessors.MouseHandlerAccessor;
import com.chorus.common.QuickImports;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class InputUtils implements QuickImports {
   private static final HashMap<Integer, Boolean> mouseButtons = new HashMap();
   private static final ExecutorService clickExecutor = Executors.newFixedThreadPool(100);
   private static final ExecutorService keyExecutor = Executors.newFixedThreadPool(100);

   public static MouseHandlerAccessor getMouseHandler() {
      return (MouseHandlerAccessor)((MinecraftClientAccessor)class_310.method_1551()).getMouse();
   }

   public static void simulateClick(int keyCode) {
      simulateClick(keyCode, 35);
   }

   public static void simulateClick(int keyCode, int millis) {
      clickExecutor.submit(() -> {
         try {
            simulatePress(keyCode);
            Thread.sleep((long)millis);
            simulateRelease(keyCode);
         } catch (InterruptedException var3) {
            var3.printStackTrace();
         }

      });
   }

   public static void simulateKeyPress(class_304 key, int millis) {
      keyExecutor.submit(() -> {
         try {
            key.method_23481(true);
            Thread.sleep((long)millis);
            key.method_23481(false);
         } catch (InterruptedException var3) {
            var3.printStackTrace();
         }

      });
   }

   public static void simulatePress(int keyCode) {
      simulateMouseEvent(keyCode, 1);
   }

   public static void simulateRelease(int keyCode) {
      simulateMouseEvent(keyCode, 0);
   }

   private static void simulateMouseEvent(int keyCode, int action) {
      MouseHandlerAccessor mouseHandler = getMouseHandler();
      if (mouseHandler != null) {
         mouseHandler.press(class_310.method_1551().method_22683().method_4490(), keyCode, action, 0);
         if (action == 1) {
            mouseButtons.put(keyCode, true);
         } else if (action == 0) {
            mouseButtons.put(keyCode, false);
         }
      }

   }

   public static boolean isMouseButtonPressed(int keyCode) {
      return (Boolean)mouseButtons.getOrDefault(keyCode, false);
   }

   public static boolean mouseDown(int button) {
      return GLFW.glfwGetMouseButton(class_310.method_1551().method_22683().method_4490(), button) == 1;
   }

   public static boolean keyDown(int key) {
      return GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), key) == 1;
   }

   public static String getKeyName(int keyCode) {
      String var10000;
      switch(keyCode) {
      case -1:
         var10000 = "None";
         break;
      case 1:
         var10000 = "RMB";
         break;
      case 2:
         var10000 = "MMB";
         break;
      case 32:
         var10000 = "Space";
         break;
      case 39:
         var10000 = "Apostrophe";
         break;
      case 96:
         var10000 = "Grave Accent";
         break;
      case 161:
         var10000 = "World 1";
         break;
      case 162:
         var10000 = "World 2";
         break;
      case 256:
         var10000 = "Esc";
         break;
      case 257:
         var10000 = "Enter";
         break;
      case 258:
         var10000 = "Tab";
         break;
      case 259:
         var10000 = "Backspace";
         break;
      case 260:
         var10000 = "Insert";
         break;
      case 261:
         var10000 = "Delete";
         break;
      case 262:
         var10000 = "Arrow Right";
         break;
      case 263:
         var10000 = "Arrow Left";
         break;
      case 264:
         var10000 = "Arrow Down";
         break;
      case 265:
         var10000 = "Arrow Up";
         break;
      case 266:
         var10000 = "Page Up";
         break;
      case 267:
         var10000 = "Page Down";
         break;
      case 268:
         var10000 = "Home";
         break;
      case 269:
         var10000 = "End";
         break;
      case 280:
         var10000 = "Caps Lock";
         break;
      case 282:
         var10000 = "Num Lock";
         break;
      case 283:
         var10000 = "Print Screen";
         break;
      case 284:
         var10000 = "Pause";
         break;
      case 290:
      case 291:
      case 292:
      case 293:
      case 294:
      case 295:
      case 296:
      case 297:
      case 298:
      case 299:
      case 300:
      case 301:
      case 302:
      case 303:
      case 304:
      case 305:
      case 306:
      case 307:
      case 308:
      case 309:
      case 310:
      case 311:
      case 312:
      case 313:
      case 314:
         var10000 = "F" + (keyCode - 290 + 1);
         break;
      case 335:
         var10000 = "Numpad Enter";
         break;
      case 340:
         var10000 = "Left Shift";
         break;
      case 341:
         var10000 = "Left Control";
         break;
      case 342:
         var10000 = "Left Alt";
         break;
      case 343:
         var10000 = "Left Super";
         break;
      case 344:
         var10000 = "Right Shift";
         break;
      case 345:
         var10000 = "Right Control";
         break;
      case 346:
         var10000 = "Right Alt";
         break;
      case 347:
         var10000 = "Right Super";
         break;
      case 348:
         var10000 = "Menu";
         break;
      default:
         String keyName = GLFW.glfwGetKeyName(keyCode, 0);
         var10000 = keyName == null ? "None" : Character.toUpperCase(keyName.charAt(0)) + keyName.substring(1).toLowerCase();
      }

      return var10000;
   }
}
