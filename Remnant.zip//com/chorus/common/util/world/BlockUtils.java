package com.chorus.common.util.world;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2266;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2413;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4770;
import net.minecraft.class_4969;

@Environment(EnvType.CLIENT)
public class BlockUtils {
   protected static final class_310 mc = class_310.method_1551();

   public static boolean isBlockType(class_2338 pos, class_2248 block) {
      return mc.field_1687.method_8320(pos).method_26204() == block;
   }

   public static boolean canExplodeAnchor(class_2338 pos) {
      return isBlockType(pos, class_2246.field_23152) && (Integer)mc.field_1687.method_8320(pos).method_11654(class_4969.field_23153) != 0;
   }

   public static boolean isAir(class_2338 pos) {
      return mc.field_1687.method_8320(pos).method_26215();
   }

   public static boolean isReplaceable(class_2338 pos) {
      return mc.field_1687.method_8320(pos).method_45474();
   }

   public static boolean isLiquid(class_2338 pos) {
      return mc.field_1687.method_8320(pos).method_26227().method_15771();
   }

   public static float getHardness(class_2338 pos) {
      return mc.field_1687.method_8320(pos).method_26214(mc.field_1687, pos);
   }

   public static boolean isBreakable(class_2338 pos) {
      class_2248 block = mc.field_1687.method_8320(pos).method_26204();
      return block != class_2246.field_9987 && block != class_2246.field_10499;
   }

   public static List<class_2338> getAdjacentBlocks(class_2338 pos) {
      List<class_2338> adjacentBlocks = new ArrayList();
      class_2350[] var2 = class_2350.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         class_2350 direction = var2[var4];
         adjacentBlocks.add(pos.method_10093(direction));
      }

      return adjacentBlocks;
   }

   public static boolean canPlaceBlock(class_2338 pos) {
      return isAir(pos) || isReplaceable(pos);
   }

   public static int getLightLevel(class_2338 pos) {
      return mc.field_1687.method_22339(pos);
   }

   public static boolean isExposedToSky(class_2338 pos) {
      return mc.field_1687.method_8311(pos);
   }

   public static boolean isSafeBlock(class_2338 pos) {
      class_2680 state = mc.field_1687.method_8320(pos);
      return state.method_51367() && !(state.method_26204() instanceof class_2413) && !(state.method_26204() instanceof class_2266) && !(state.method_26204() instanceof class_4770);
   }

   public static float getBlastResistance(class_2338 pos) {
      return mc.field_1687.method_8320(pos).method_26204().method_9520();
   }

   public static boolean isNaturalBlock(class_2338 pos) {
      class_2248 block = mc.field_1687.method_8320(pos).method_26204();
      return block == class_2246.field_10219 || block == class_2246.field_10566 || block == class_2246.field_10340 || block == class_2246.field_10102 || block == class_2246.field_10255;
   }

   public static class_2338 findNearestBlock(class_2338 center, class_2248 block, int radius) {
      for(int x = -radius; x <= radius; ++x) {
         for(int y = -radius; y <= radius; ++y) {
            for(int z = -radius; z <= radius; ++z) {
               class_2338 pos = center.method_10069(x, y, z);
               if (isBlockType(pos, block)) {
                  return pos;
               }
            }
         }
      }

      return null;
   }
}
