package com.chorus.common.util.world;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class SimulatedPlayer {
   private class_243 position;
   private class_243 velocity;
   private float fallDistance;
   private float yaw;
   private float pitch;
   private boolean onGround;
   private boolean sprinting;
   private boolean horizontalCollision;
   private boolean verticalCollision;
   private SimulatedPlayer.PlayerInput input;
   private class_238 boundingBox;
   private final class_1937 world;
   private final class_1657 entity;
   private static final double GRAVITY = 0.08D;
   private static final float JUMP_VELOCITY = 0.42F;
   private static final float BASE_MOVEMENT_SPEED = 0.1F;

   public SimulatedPlayer(class_1657 entity) {
      this.world = entity.method_37908();
      this.entity = entity;
      this.position = entity.method_19538();
      this.velocity = new class_243(0.0D, 0.0D, 0.0D);
      this.yaw = entity.method_36454();
      this.pitch = entity.method_36455();
      this.onGround = entity.method_24828();
      this.sprinting = entity.method_5624();
      this.fallDistance = entity.field_6017;
      this.horizontalCollision = entity.field_5976;
      this.verticalCollision = entity.field_5992;
      this.input = new SimulatedPlayer.PlayerInput(this);
      this.boundingBox = (new class_238(-0.3D, 0.0D, -0.3D, 0.3D, 1.8D, 0.3D)).method_997(this.position);
   }

   public void tick() {
      this.input.update();
      if (!this.onGround) {
         this.velocity = this.velocity.method_1031(0.0D, -0.08D, 0.0D).method_18805(1.0D, 0.9800000190734863D, 1.0D);
      } else if (this.input.jumping) {
         this.velocity = new class_243(0.0D, 0.41999998688697815D, 0.0D);
         if (this.isSprinting()) {
            float rads = (float)Math.toRadians((double)this.yaw);
            this.velocity.method_1019(new class_243((double)(-class_3532.method_15374(rads) * 0.2F), 0.0D, (double)(class_3532.method_15362(rads) * 0.2F)));
         }
      }

      class_243 movementInput = new class_243((double)(this.input.movementSideways * this.getMovementSpeed()), 0.0D, (double)(this.input.movementForward * this.getMovementSpeed()));
      this.simulateMovement(movementInput);
      this.boundingBox = (new class_238(-0.3D, 0.0D, -0.3D, 0.3D, 1.8D, 0.3D)).method_997(this.position);
      if (this.onGround) {
         this.velocity = new class_243(this.velocity.field_1352 * 0.91D, this.velocity.field_1351, this.velocity.field_1350 * 0.91D);
      } else {
         this.velocity = new class_243(this.velocity.field_1352 * 0.98D, this.velocity.field_1351 * 0.98D, this.velocity.field_1350 * 0.98D);
      }

   }

   private void simulateMovement(class_243 movementInput) {
      class_243 transformedMovement = this.rotateMovement(movementInput);
      this.velocity = this.velocity.method_1019(transformedMovement);
      this.move(this.velocity);
   }

   private void move(class_243 velocity) {
      class_243 newVelocity = this.includeCollisionsInVelocity(velocity);
      if (this.onGround) {
         this.fallDistance = 0.0F;
      } else if (newVelocity.field_1351 < 0.0D) {
         this.fallDistance -= (float)newVelocity.field_1351;
      }

      this.position = this.position.method_1019(newVelocity);
      this.horizontalCollision = !this.threePointEstimator(velocity.field_1352, newVelocity.field_1352) || !this.threePointEstimator(velocity.field_1350, newVelocity.field_1350);
      this.verticalCollision = !this.threePointEstimator(velocity.field_1351, newVelocity.field_1351);
      this.onGround = this.verticalCollision && velocity.field_1351 < 0.0D;
      if (this.onGround) {
         this.velocity = new class_243(this.velocity.field_1352, 0.0D, this.velocity.field_1350);
      }

   }

   private class_243 includeCollisionsInVelocity(class_243 movement) {
      class_238 box = (new class_238(-0.3D, 0.0D, -0.3D, 0.3D, 1.8D, 0.3D)).method_997(this.position);
      class_243 adjustedMovement = movement.method_1027() == 0.0D ? movement : class_1297.method_20736(this.entity, movement, box, this.world, List.of());
      return adjustedMovement;
   }

   private boolean threePointEstimator(double a, double b) {
      return Math.abs(a - b) < 0.003D;
   }

   private class_243 rotateMovement(class_243 movement) {
      double sin = Math.sin(Math.toRadians((double)this.yaw));
      double cos = Math.cos(Math.toRadians((double)this.yaw));
      return new class_243(movement.field_1352 * cos - movement.field_1350 * sin, movement.field_1351, movement.field_1352 * sin + movement.field_1350 * cos);
   }

   private float getMovementSpeed() {
      float averageBlockSlipperiness = 0.6F;
      if (this.onGround) {
         return 0.1F * (0.21600002F / (averageBlockSlipperiness * averageBlockSlipperiness * averageBlockSlipperiness));
      } else {
         float speed = 0.02F;
         if (this.isSprinting()) {
            speed += 0.006F;
         }

         return speed;
      }
   }

   public void setInput(boolean forward, boolean backward, boolean left, boolean right, boolean jump, boolean sprint) {
      this.input.forward = forward;
      this.input.backward = backward;
      this.input.left = left;
      this.input.right = right;
      this.input.jumping = jump;
      this.sprinting = sprint;
   }

   public class_243 getPosition() {
      return this.position;
   }

   public class_243 getVelocity() {
      return this.velocity;
   }

   public float getFallDistance() {
      return this.fallDistance;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public boolean isOnGround() {
      return this.onGround;
   }

   public boolean isSprinting() {
      return this.sprinting;
   }

   public boolean isHorizontalCollision() {
      return this.horizontalCollision;
   }

   public boolean isVerticalCollision() {
      return this.verticalCollision;
   }

   public SimulatedPlayer.PlayerInput getInput() {
      return this.input;
   }

   public class_238 getBoundingBox() {
      return this.boundingBox;
   }

   public class_1937 getWorld() {
      return this.world;
   }

   public class_1657 getEntity() {
      return this.entity;
   }

   @Environment(EnvType.CLIENT)
   public class PlayerInput {
      public boolean forward;
      public boolean backward;
      public boolean left;
      public boolean right;
      public boolean jumping;
      public float movementForward;
      public float movementSideways;

      public PlayerInput(final SimulatedPlayer this$0) {
      }

      public void update() {
         if (this.forward != this.backward) {
            this.movementForward = this.forward ? 1.0F : -1.0F;
         } else {
            this.movementForward = 0.0F;
         }

         if (this.left != this.right) {
            this.movementSideways = this.left ? 1.0F : -1.0F;
         } else {
            this.movementSideways = 0.0F;
         }

      }
   }
}
