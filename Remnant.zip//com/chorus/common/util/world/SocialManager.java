package com.chorus.common.util.world;

import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.impl.modules.other.Target;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;

@Environment(EnvType.CLIENT)
public final class SocialManager implements QuickImports {
   public static boolean isEnemy(class_1657 player) {
      if (((Target)Chorus.getInstance().getModuleManager().getModule(Target.class)).enemy == player) {
         return true;
      } else if (teamRepository.isMemberOfCurrentTeam(player.method_5820())) {
         return false;
      } else if (friendRepository.isFriend(player.method_5820())) {
         return false;
      } else {
         return !npcRepository.isNPC(player.method_5820());
      }
   }

   public static class_1657 isTargetedPlayer(class_1657 player) {
      class_1657 enemy = ((Target)Chorus.getInstance().getModuleManager().getModule(Target.class)).enemy;
      return enemy != null ? enemy : player;
   }

   public static Boolean isTarget(class_1657 player) {
      class_1657 enemy = ((Target)Chorus.getInstance().getModuleManager().getModule(Target.class)).enemy;
      return enemy == null ? false : enemy == player;
   }

   public static class_1657 getTarget() {
      class_1657 enemy = ((Target)Chorus.getInstance().getModuleManager().getModule(Target.class)).enemy;
      return enemy;
   }
}
