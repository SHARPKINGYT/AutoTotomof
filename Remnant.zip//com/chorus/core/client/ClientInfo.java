package com.chorus.core.client;

import java.nio.file.Path;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public record ClientInfo(String name, String version, String branch, Path clientDir, Path filesDir, Path configsDir) implements ClientInfoProvider {
   public ClientInfo(String name, String version, String branch, Path clientDir, Path filesDir, Path configsDir) {
      this.name = name;
      this.version = version;
      this.branch = branch;
      this.clientDir = clientDir;
      this.filesDir = filesDir;
      this.configsDir = configsDir;
   }

   public String getFullInfo() {
      return String.format("Welcome! Client: %s Version: %s Branch: %s", this.name, this.version, this.branch);
   }

   public String name() {
      return this.name;
   }

   public String version() {
      return this.version;
   }

   public String branch() {
      return this.branch;
   }

   public Path clientDir() {
      return this.clientDir;
   }

   public Path filesDir() {
      return this.filesDir;
   }

   public Path configsDir() {
      return this.configsDir;
   }
}
