package com.chorus.core.client;

import java.nio.file.Path;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ConcreteClientInfoProvider implements ClientInfoProvider {
   public String branch() {
      return "main";
   }

   public Path clientDir() {
      return Path.of(System.getProperty("user.home"), new String[]{".chorus"});
   }

   public Path configsDir() {
      return Path.of(System.getProperty("user.home"), new String[]{".chorus", "configs"});
   }

   public Path filesDir() {
      return Path.of(System.getProperty("user.home"), new String[]{".chorus", "files"});
   }

   public String name() {
      return "Chorus";
   }

   public ClientInfo provideClientInfo() {
      return new ClientInfo(this.name(), this.version(), this.branch(), this.clientDir(), this.filesDir(), this.configsDir());
   }

   public String version() {
      return "1.0.0";
   }

   public String getFullInfo() {
      return String.format("Welcome! Client: %s Version: %s Branch: %s", this.name(), this.version(), this.branch());
   }
}
