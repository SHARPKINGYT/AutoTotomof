package com.chorus.core.client.config;

import chorus0.Chorus;
import com.chorus.api.module.ModuleManager;
import com.chorus.api.module.setting.Setting;
import com.chorus.api.module.setting.implement.ColorSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.core.client.ClientInfo;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Type;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.apache.commons.io.FileUtils;

@Environment(EnvType.CLIENT)
public class ConfigManager {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor();
   private final Path configRoot;
   private final Map<String, ConfigManager.Profile> profiles = new ConcurrentHashMap();
   private String activeProfile = "default";

   public ConfigManager(ClientInfo clientInfo) {
      this.configRoot = clientInfo.configsDir().resolve("profiles");
      this.initializeFileSystem();
      this.loadProfiles();
      SCHEDULER.scheduleAtFixedRate(this::autoSave, 5L, 5L, TimeUnit.SECONDS);
   }

   private void initializeFileSystem() {
      try {
         Files.createDirectories(this.configRoot);
         if (!Files.exists(this.configRoot.resolve(this.activeProfile), new LinkOption[0])) {
            this.createProfile(this.activeProfile);
         }

      } catch (IOException var2) {
         throw new ConfigManager.ConfigException("Failed to initialize config directory", var2);
      }
   }

   public void createProfile(String name) {
      Path profilePath = this.configRoot.resolve(name);

      try {
         Files.createDirectory(profilePath);
         this.profiles.put(name, new ConfigManager.Profile(profilePath));
         this.saveProfile(name);
      } catch (IOException var4) {
         throw new ConfigManager.ConfigException("Failed to create profile: " + name, var4);
      }
   }

   public void deleteProfile(String name) {
      if (!name.equals(this.activeProfile)) {
         try {
            FileUtils.deleteDirectory(this.configRoot.resolve(name).toFile());
            this.profiles.remove(name);
         } catch (IOException var3) {
            throw new ConfigManager.ConfigException("Failed to delete profile: " + name, var3);
         }
      }
   }

   public void loadProfile(String name) {
      ConfigManager.Profile profile = (ConfigManager.Profile)this.profiles.get(name);
      if (profile != null) {
         profile.load(Chorus.getInstance().getModuleManager());
         this.activeProfile = name;
      }

   }

   public void saveProfile(String name) {
      ConfigManager.Profile profile = (ConfigManager.Profile)this.profiles.get(name);
      if (profile != null) {
         profile.save(Chorus.getInstance().getModuleManager());
      }

   }

   public void reloadActiveProfile() {
      this.loadProfile(this.activeProfile);
   }

   private void loadProfiles() {
      try {
         DirectoryStream stream = Files.newDirectoryStream(this.configRoot);

         try {
            Iterator var2 = stream.iterator();

            while(var2.hasNext()) {
               Path profileDir = (Path)var2.next();
               if (Files.isDirectory(profileDir, new LinkOption[0])) {
                  String profileName = profileDir.getFileName().toString();
                  this.profiles.put(profileName, new ConfigManager.Profile(profileDir));
               }
            }
         } catch (Throwable var6) {
            if (stream != null) {
               try {
                  stream.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (stream != null) {
            stream.close();
         }

      } catch (IOException var7) {
         throw new ConfigManager.ConfigException("Failed to load profiles", var7);
      }
   }

   private void autoSave() {
      this.saveProfile(this.activeProfile);
   }

   public void shutdown() {
      SCHEDULER.shutdown();
      this.saveProfile(this.activeProfile);
   }

   public List<String> getProfileNames() {
      return new ArrayList(this.profiles.keySet());
   }

   public boolean profileExists(String name) {
      return this.profiles.containsKey(name);
   }

   public void saveCurrentProfile() {
      this.saveProfile(this.activeProfile);
   }

   public Path getConfigRoot() {
      return this.configRoot;
   }

   public String getActiveProfile() {
      return this.activeProfile;
   }

   @Environment(EnvType.CLIENT)
   public static class ConfigException extends RuntimeException {
      public ConfigException(String message, Throwable cause) {
         super(message, cause);
      }
   }

   @Environment(EnvType.CLIENT)
   private static class Profile {
      private final Path profilePath;
      private final Map<String, ConfigManager.ModuleConfig> config = new ConcurrentHashMap();

      Profile(Path profilePath) {
         this.profilePath = profilePath;
      }

      void load(ModuleManager moduleManager) {
         Path configFile = this.profilePath.resolve("modules.json");
         if (Files.exists(configFile, new LinkOption[0])) {
            try {
               BufferedReader reader = Files.newBufferedReader(configFile);

               try {
                  Type type = (new TypeToken<Map<String, ConfigManager.ModuleConfig>>(this) {
                  }).getType();
                  this.config.clear();
                  this.config.putAll((Map)ConfigManager.GSON.fromJson(reader, type));
                  this.applyConfig(moduleManager);
               } catch (Throwable var7) {
                  if (reader != null) {
                     try {
                        reader.close();
                     } catch (Throwable var6) {
                        var7.addSuppressed(var6);
                     }
                  }

                  throw var7;
               }

               if (reader != null) {
                  reader.close();
               }
            } catch (Exception var8) {
               throw new ConfigManager.ConfigException("Failed to load profile config", var8);
            }
         }

      }

      void save(ModuleManager moduleManager) {
         Path configFile = this.profilePath.resolve("modules.json");
         this.updateConfig(moduleManager);

         try {
            BufferedWriter writer = Files.newBufferedWriter(configFile);

            try {
               ConfigManager.GSON.toJson(this.config, writer);
            } catch (Throwable var7) {
               if (writer != null) {
                  try {
                     writer.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (writer != null) {
               writer.close();
            }

         } catch (IOException var8) {
            throw new ConfigManager.ConfigException("Failed to save profile config", var8);
         }
      }

      private void updateConfig(ModuleManager moduleManager) {
         moduleManager.getModules().forEach((module) -> {
            ConfigManager.ModuleConfig moduleConfig = (ConfigManager.ModuleConfig)this.config.computeIfAbsent(module.getName(), (k) -> {
               return new ConfigManager.ModuleConfig();
            });
            moduleConfig.enabled = module.isEnabled();
            moduleConfig.keyBind = module.getKey();
            moduleConfig.settings = new HashMap();
            module.getSettingRepository().getSettings().forEach((name, setting) -> {
               if (setting instanceof ColorSetting) {
                  moduleConfig.settings.put(name, ((ColorSetting)setting).getValue().getRGB());
               } else {
                  moduleConfig.settings.put(name, setting.getValue());
               }

            });
         });
      }

      private void applyConfig(ModuleManager moduleManager) {
         moduleManager.getModules().forEach((module) -> {
            ConfigManager.ModuleConfig moduleConfig = (ConfigManager.ModuleConfig)this.config.get(module.getName());
            if (moduleConfig != null) {
               if (moduleConfig.enabled) {
                  module.onEnable();
               } else {
                  module.onDisable();
               }

               module.setKey(moduleConfig.keyBind);
               moduleConfig.settings.forEach((name, value) -> {
                  Setting<?> setting = module.getSettingRepository().getSetting(name);
                  if (setting != null) {
                     try {
                        this.setSettingValue(setting, value);
                     } catch (ClassCastException var6) {
                        System.err.println("Type mismatch for setting " + name + ": " + var6.getMessage());
                     }
                  }

               });
            }

         });
      }

      private <T> void setSettingValue(Setting<T> setting, Object value) {
         try {
            if (setting instanceof NumberSetting) {
               NumberSetting<? extends Number> numberSetting = (NumberSetting)setting;
               Number converted = this.convertNumericType(value, numberSetting.getValue());
               setting.setValue(converted);
            } else if (setting instanceof RangeSetting) {
               this.handleRangeSetting((RangeSetting)setting, value);
            } else if (setting instanceof MultiSetting) {
               if (value instanceof List) {
                  List<?> list = (List)value;
                  Set<String> converted = new LinkedHashSet();
                  Iterator var5 = list.iterator();

                  while(var5.hasNext()) {
                     Object item = var5.next();
                     converted.add(item.toString());
                  }

                  setting.setValue(converted);
               }
            } else if (setting instanceof ColorSetting) {
               if (value instanceof Number) {
                  int intValue = ((Number)value).intValue();
                  Color color = new Color(intValue, true);
                  ((ColorSetting)setting).setValue(color);
               }
            } else {
               setting.setValue(value);
            }
         } catch (NumberFormatException | ClassCastException var7) {
            PrintStream var10000 = System.err;
            String var10001 = setting.getName();
            var10000.println("Type mismatch for " + var10001 + ": " + var7.getMessage());
         }

      }

      private <T extends Number & Comparable<T>> void handleRangeSetting(RangeSetting<T> setting, Object value) {
         if (value instanceof List) {
            List<?> list = (List)value;
            if (list.size() == 2) {
               T[] converted = new Number[2];
               Class<T> type = this.getSettingType(setting);
               converted[0] = this.convertToExactType(list.get(0), type);
               converted[1] = this.convertToExactType(list.get(1), type);
               setting.setValue(converted);
            }
         }

      }

      private <T extends Number & Comparable<T>> Class<T> getSettingType(RangeSetting<T> setting) {
         return setting.getValue()[0].getClass();
      }

      private <T extends Number> T convertToExactType(Object value, Class<T> targetType) {
         if (targetType == Double.class) {
            return (Number)targetType.cast(((Number)value).doubleValue());
         } else if (targetType == Integer.class) {
            return (Number)targetType.cast(((Number)value).intValue());
         } else if (targetType == Float.class) {
            return (Number)targetType.cast(((Number)value).floatValue());
         } else {
            throw new IllegalArgumentException("Unsupported number type: " + String.valueOf(targetType));
         }
      }

      private Number convertNumericType(Object value, Number exampleValue) {
         if (exampleValue == null) {
            return ((Number)value).doubleValue();
         } else if (exampleValue instanceof Double) {
            return ((Number)value).doubleValue();
         } else if (exampleValue instanceof Integer) {
            return ((Number)value).intValue();
         } else if (exampleValue instanceof Float) {
            return ((Number)value).floatValue();
         } else {
            return (Number)(exampleValue instanceof Long ? ((Number)value).longValue() : ((Number)value).doubleValue());
         }
      }
   }

   @Environment(EnvType.CLIENT)
   private static class ModuleConfig {
      boolean enabled;
      int keyBind;
      Map<String, Object> settings;
   }
}
