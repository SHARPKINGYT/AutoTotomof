package com.chorus.core.listener;

import chorus0.Chorus;
import com.chorus.core.listener.impl.KeyPressEventListener;
import com.chorus.core.listener.impl.TickEventListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ListenerRepository {
   private final List<Listener> listeners = new ArrayList();

   public void setup() {
      this.registerListeners(new TickEventListener(), new KeyPressEventListener());
   }

   public void registerListeners(Listener... listeners) {
      this.listeners.addAll(List.of(listeners));
      Arrays.stream(listeners).forEach((listener) -> {
         Chorus.getInstance().getEventManager().register(listener);
      });
   }

   public List<Listener> getListeners() {
      return this.listeners;
   }
}
