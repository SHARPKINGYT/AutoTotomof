package com.chorus.core.listener.impl;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.Module;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.ChatUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.core.listener.Listener;
import com.chorus.impl.events.input.KeyPressEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class KeyPressEventListener implements Listener, QuickImports {
   private static Module moduleToBindTo;

   @RegisterEvent
   private void keyPressEventListener(KeyPressEvent event) {
      if (moduleToBindTo != null && event.getAction() == 1) {
         moduleToBindTo.setKey(event.getKey());
         String var10000 = moduleToBindTo.getName();
         ChatUtils.sendFormattedMessage("Bound " + var10000 + " to key: " + InputUtils.getKeyName(event.getKey()));
         moduleToBindTo = null;
      }

   }

   public static void setModuleToBindTo(Module moduleToBindTo) {
      KeyPressEventListener.moduleToBindTo = moduleToBindTo;
   }
}
