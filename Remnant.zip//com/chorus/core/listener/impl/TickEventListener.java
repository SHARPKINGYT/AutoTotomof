package com.chorus.core.listener.impl;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.common.QuickImports;
import com.chorus.core.listener.Listener;
import com.chorus.impl.events.player.MoveFixEvent;
import com.chorus.impl.events.player.SilentRotationEvent;
import com.chorus.impl.events.player.TickAIEvent;
import com.chorus.impl.modules.combat.AimAssist;
import com.chorus.impl.modules.movement.MoveFix;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TickEventListener implements Listener, QuickImports {
   private float yaw;
   private float prevYaw;
   private float pitch;
   private float prevPitch = 0.0F;
   public boolean rotating;

   @RegisterEvent
   private void tickAIEventEventListener(TickAIEvent event) {
      if (mc.field_1724 != null) {
         SilentRotationEvent rotation = new SilentRotationEvent(mc.field_1724.method_36454(), mc.field_1724.method_36455());
         Chorus.getInstance().getEventManager().post(rotation);
         this.prevYaw = this.yaw;
         this.prevPitch = this.pitch;
         if (rotation.hasBeenModified()) {
            this.yaw = rotation.getYaw();
            this.pitch = rotation.getPitch();
            this.rotating = true;
         } else {
            this.yaw = mc.field_1724.method_36454();
            this.pitch = mc.field_1724.method_36455();
            this.rotating = false;
         }

      }
   }

   @RegisterEvent
   private void handleEvent(MoveFixEvent event) {
      if (this.rotating && Chorus.getInstance().getModuleManager().isModuleEnabled(MoveFix.class) && !((AimAssist)Chorus.getInstance().getModuleManager().getModule(AimAssist.class)).getSettingRepository().getSetting("Silent Rotations").getValue().equals(false)) {
         event.setYaw(this.yaw);
      }
   }

   public float[] getCurrentRotation() {
      return new float[]{this.yaw, this.pitch};
   }

   public float[] getPreviousRotation() {
      return new float[]{this.prevYaw, this.prevPitch};
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPrevYaw() {
      return this.prevYaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public float getPrevPitch() {
      return this.prevPitch;
   }

   public boolean isRotating() {
      return this.rotating;
   }

   public void setYaw(float yaw) {
      this.yaw = yaw;
   }

   public void setPrevYaw(float prevYaw) {
      this.prevYaw = prevYaw;
   }

   public void setPitch(float pitch) {
      this.pitch = pitch;
   }

   public void setPrevPitch(float prevPitch) {
      this.prevPitch = prevPitch;
   }

   public void setRotating(boolean rotating) {
      this.rotating = rotating;
   }
}
