package com.chorus.impl.commands;

import chorus0.Chorus;
import com.chorus.api.command.BaseCommand;
import com.chorus.api.command.CommandInfo;
import com.chorus.api.module.Module;
import com.chorus.common.util.player.ChatUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.core.listener.impl.KeyPressEventListener;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;

@CommandInfo(
   name = "bind",
   description = "Bind modules to keys",
   aliases = {"keybind", "key"}
)
@Environment(EnvType.CLIENT)
public class BindCommand extends BaseCommand {
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)((LiteralArgumentBuilder)builder.then(literal("set").then(argument("module", StringArgumentType.word()).suggests((context, suggestionsBuilder) -> {
         List<String> moduleNames = (List)Chorus.getInstance().getModuleManager().getModules().stream().map((module) -> {
            return module.getName().replace(" ", "");
         }).collect(Collectors.toList());
         return class_2172.method_9265(moduleNames, suggestionsBuilder);
      }).executes((context) -> {
         String moduleName = (String)context.getArgument("module", String.class);
         Module module = Chorus.getInstance().getModuleManager().getModuleByName(moduleName);
         if (module != null) {
            KeyPressEventListener.setModuleToBindTo(module);
            ChatUtils.sendFormattedMessage("Listening for key press for module: " + module.getName());
            notificationManager.addNotification("Listening...", "Listening for key press for module: " + module.getName(), 10000);
         } else {
            ChatUtils.sendFormattedMessage("Module not found: " + moduleName);
         }

         return 1;
      })))).then(((LiteralArgumentBuilder)literal("clear").executes((context) -> {
         ChatUtils.sendFormattedMessage("Usage: .bind clear <module>");
         return 1;
      })).then(argument("module", StringArgumentType.word()).suggests((context, suggestionsBuilder) -> {
         List<String> moduleNames = (List)Chorus.getInstance().getModuleManager().getModules().stream().map((module) -> {
            return module.getName().replace(" ", "");
         }).collect(Collectors.toList());
         return class_2172.method_9265(moduleNames, suggestionsBuilder);
      }).executes((context) -> {
         String moduleName = (String)context.getArgument("module", String.class);
         Module module = Chorus.getInstance().getModuleManager().getModuleByName(moduleName);
         if (module != null) {
            module.setKey(-1);
            ChatUtils.sendFormattedMessage("Cleared keybind for " + module.getName());
         } else {
            ChatUtils.sendFormattedMessage("Module not found: " + moduleName);
         }

         return 1;
      })))).then(literal("list").executes((context) -> {
         List<Module> modules = Chorus.getInstance().getModuleManager().getModules();
         ChatUtils.sendFormattedMessage("Module bindings:");
         Iterator var2 = modules.iterator();

         while(var2.hasNext()) {
            Module module = (Module)var2.next();
            int key = module.getKey();
            if (key != -1) {
               String var10000 = module.getName();
               ChatUtils.sendFormattedMessage(var10000 + ": " + InputUtils.getKeyName(key));
            }
         }

         return 1;
      }));
   }
}
