package com.chorus.impl.commands;

import chorus0.Chorus;
import com.chorus.api.command.BaseCommand;
import com.chorus.api.command.CommandInfo;
import com.chorus.common.util.player.ChatUtils;
import com.chorus.core.client.config.ConfigManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;

@CommandInfo(
   name = "config",
   description = "Manage configuration profiles",
   aliases = {"cfg", "profile"}
)
@Environment(EnvType.CLIENT)
public class ConfigCommand extends BaseCommand {
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ConfigManager cfg = Chorus.getInstance().getConfigManager();
      ((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)builder.then(literal("load").then(argument("profile", StringArgumentType.string()).suggests((context, suggestionsBuilder) -> {
         return class_2172.method_9265(cfg.getProfileNames(), suggestionsBuilder);
      }).executes((context) -> {
         String profile = (String)context.getArgument("profile", String.class);
         if (cfg.profileExists(profile)) {
            cfg.loadProfile(profile);
            ChatUtils.addChatMessage("Loaded profile: " + profile);
         } else {
            ChatUtils.addChatMessage("§cProfile not found: " + profile);
         }

         return 1;
      })))).then(((LiteralArgumentBuilder)literal("save").executes((context) -> {
         cfg.saveCurrentProfile();
         ChatUtils.addChatMessage("Saved current profile");
         return 1;
      })).then(argument("profile", StringArgumentType.string()).executes((context) -> {
         String profile = (String)context.getArgument("profile", String.class);
         cfg.saveProfile(profile);
         ChatUtils.addChatMessage("Saved to profile: " + profile);
         return 1;
      })))).then(literal("create").then(argument("name", StringArgumentType.string()).executes((context) -> {
         String name = (String)context.getArgument("name", String.class);
         cfg.createProfile(name);
         ChatUtils.addChatMessage("Created profile: " + name);
         return 1;
      })))).then(literal("delete").then(argument("profile", StringArgumentType.string()).suggests((context, suggestionsBuilder) -> {
         return class_2172.method_9265(cfg.getProfileNames(), suggestionsBuilder);
      }).executes((context) -> {
         String profile = (String)context.getArgument("profile", String.class);
         if (cfg.profileExists(profile)) {
            cfg.deleteProfile(profile);
            ChatUtils.addChatMessage("Deleted profile: " + profile);
         } else {
            ChatUtils.addChatMessage("§cProfile not found: " + profile);
         }

         return 1;
      })))).then(literal("list").executes((context) -> {
         List<String> profiles = cfg.getProfileNames();
         ChatUtils.addChatMessage("Available profiles:");
         profiles.forEach((p) -> {
            String var10000 = p.equals(cfg.getActiveProfile()) ? "§a> " : "§7- ";
            ChatUtils.addChatMessage(var10000 + p);
         });
         return 1;
      }))).then(literal("reload").executes((context) -> {
         cfg.reloadActiveProfile();
         ChatUtils.addChatMessage("Reloaded current profile");
         return 1;
      }));
   }
}
