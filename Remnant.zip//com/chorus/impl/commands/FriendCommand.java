package com.chorus.impl.commands;

import com.chorus.api.command.BaseCommand;
import com.chorus.api.command.CommandInfo;
import com.chorus.api.repository.friend.Friend;
import com.chorus.common.util.player.ChatUtils;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_746;

@CommandInfo(
   name = "friend",
   description = "Adds friends.",
   aliases = {"f"}
)
@Environment(EnvType.CLIENT)
public class FriendCommand extends BaseCommand {
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("player", class_2186.method_9305()).executes((context) -> {
         class_746 player = mc.field_1724;
         if (friendRepository.isFriend(player.method_5667())) {
            friendRepository.removeFriend(player.method_5667());
            ChatUtils.addChatMessage("Removed " + player.method_7334().getName() + " from friends");
         } else {
            friendRepository.addFriend(new Friend(player.method_5667(), player.method_7334().getName()));
            ChatUtils.addChatMessage("Added " + player.method_7334().getName() + " to friends");
         }

         return 1;
      }));
   }
}
