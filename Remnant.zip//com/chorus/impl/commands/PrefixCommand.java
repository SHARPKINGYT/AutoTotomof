package com.chorus.impl.commands;

import chorus0.Chorus;
import com.chorus.api.command.BaseCommand;
import com.chorus.api.command.CommandInfo;
import com.chorus.common.util.player.ChatUtils;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;

@CommandInfo(
   name = "prefix",
   description = "Sets the command prefix.",
   aliases = {"p"}
)
@Environment(EnvType.CLIENT)
public class PrefixCommand extends BaseCommand {
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("prefix", StringArgumentType.word()).executes((context) -> {
         String prefix = (String)context.getArgument("prefix", String.class);
         Chorus.getInstance().getCommandManager().setPrefix(prefix);
         ChatUtils.addChatMessage("Changed prefix to " + prefix + ".");
         return 1;
      }));
   }
}
