package com.chorus.impl.commands;

import chorus0.Chorus;
import com.chorus.api.command.BaseCommand;
import com.chorus.api.command.CommandInfo;
import com.chorus.api.module.Module;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2172;

@CommandInfo(
   name = "toggle",
   description = "Toggle Modules",
   aliases = {"t"}
)
@Environment(EnvType.CLIENT)
public class ToggleCommand extends BaseCommand {
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("module", StringArgumentType.word()).suggests((context, suggestionsBuilder) -> {
         List<String> moduleNames = (List)Chorus.getInstance().getModuleManager().getModules().stream().map((module) -> {
            return module.getName().replace(" ", "");
         }).collect(Collectors.toList());
         return class_2172.method_9265(moduleNames, suggestionsBuilder);
      }).executes((context) -> {
         String moduleName = (String)context.getArgument("module", String.class);
         Module module = Chorus.getInstance().getModuleManager().getModuleByName(moduleName);
         if (module != null) {
            Chorus.getInstance().getModuleManager().toggleModule(module.getClass());
            notificationManager.addNotification("Toggled", module.getName().makeConcatWithConstants<invokedynamic>(module.getName()), 10000);
         }

         return 1;
      }));
   }
}
