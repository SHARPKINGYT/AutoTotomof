package com.chorus.impl.events.input;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class KeyPressEvent extends Event {
   private final int key;
   private final int scancode;
   private final int action;
   private final int modifiers;

   public int getKey() {
      return this.key;
   }

   public int getScancode() {
      return this.scancode;
   }

   public int getAction() {
      return this.action;
   }

   public int getModifiers() {
      return this.modifiers;
   }

   public KeyPressEvent(int key, int scancode, int action, int modifiers) {
      this.key = key;
      this.scancode = scancode;
      this.action = action;
      this.modifiers = modifiers;
   }
}
