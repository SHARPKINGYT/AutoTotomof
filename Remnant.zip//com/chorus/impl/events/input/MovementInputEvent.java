package com.chorus.impl.events.input;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MovementInputEvent extends Event {
   boolean pressingForward;
   boolean pressingBack;
   boolean pressingLeft;
   boolean pressingRight;
   boolean jumping;
   boolean sneaking;
   boolean sprinting;
   float movementForward;
   float movementSideways;

   public MovementInputEvent(boolean pressingForward, boolean pressingBack, boolean pressingLeft, boolean pressingRight, boolean jumping, boolean sneaking, boolean sprinting, float movementForward, float movementSideways) {
      this.pressingForward = pressingForward;
      this.pressingBack = pressingBack;
      this.pressingLeft = pressingLeft;
      this.pressingRight = pressingRight;
      this.jumping = jumping;
      this.sneaking = sneaking;
      this.sprinting = sprinting;
      this.movementForward = movementForward;
      this.movementSideways = movementSideways;
   }

   public boolean isPressingForward() {
      return this.pressingForward;
   }

   public boolean isPressingBack() {
      return this.pressingBack;
   }

   public boolean isPressingLeft() {
      return this.pressingLeft;
   }

   public boolean isPressingRight() {
      return this.pressingRight;
   }

   public boolean isJumping() {
      return this.jumping;
   }

   public boolean isSneaking() {
      return this.sneaking;
   }

   public boolean isSprinting() {
      return this.sprinting;
   }

   public float getMovementForward() {
      return this.movementForward;
   }

   public float getMovementSideways() {
      return this.movementSideways;
   }

   public void setPressingForward(boolean pressingForward) {
      this.pressingForward = pressingForward;
   }

   public void setPressingBack(boolean pressingBack) {
      this.pressingBack = pressingBack;
   }

   public void setPressingLeft(boolean pressingLeft) {
      this.pressingLeft = pressingLeft;
   }

   public void setPressingRight(boolean pressingRight) {
      this.pressingRight = pressingRight;
   }

   public void setJumping(boolean jumping) {
      this.jumping = jumping;
   }

   public void setSneaking(boolean sneaking) {
      this.sneaking = sneaking;
   }

   public void setSprinting(boolean sprinting) {
      this.sprinting = sprinting;
   }

   public void setMovementForward(float movementForward) {
      this.movementForward = movementForward;
   }

   public void setMovementSideways(float movementSideways) {
      this.movementSideways = movementSideways;
   }
}
