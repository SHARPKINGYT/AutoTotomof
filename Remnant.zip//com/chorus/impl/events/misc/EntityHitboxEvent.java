package com.chorus.impl.events.misc;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_238;

@Environment(EnvType.CLIENT)
public class EntityHitboxEvent extends Event {
   private final class_1297 entity;
   private class_238 box;

   public EntityHitboxEvent(class_1297 entity, class_238 box) {
      this.entity = entity;
      this.box = box;
   }

   public class_1297 getEntity() {
      return this.entity;
   }

   public class_238 getBox() {
      return this.box;
   }

   public void setBox(class_238 box) {
      this.box = box;
   }
}
