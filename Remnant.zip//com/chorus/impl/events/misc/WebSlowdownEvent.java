package com.chorus.impl.events.misc;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class WebSlowdownEvent extends Event {
   private final WebSlowdownEvent.Mode mode;

   public WebSlowdownEvent(WebSlowdownEvent.Mode mode) {
      this.mode = mode;
   }

   public WebSlowdownEvent.Mode getMode() {
      return this.mode;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static WebSlowdownEvent.Mode[] $values() {
         return new WebSlowdownEvent.Mode[]{PRE, POST};
      }
   }
}
