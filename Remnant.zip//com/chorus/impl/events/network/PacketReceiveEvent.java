package com.chorus.impl.events.network;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;

@Environment(EnvType.CLIENT)
public class PacketReceiveEvent extends Event {
   private final class_2596<?> packet;
   private final PacketReceiveEvent.Mode mode;

   public PacketReceiveEvent(class_2596<?> packet, PacketReceiveEvent.Mode mode) {
      this.packet = packet;
      this.mode = mode;
   }

   public class_2596<?> getPacket() {
      return this.packet;
   }

   public PacketReceiveEvent.Mode getMode() {
      return this.mode;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static PacketReceiveEvent.Mode[] $values() {
         return new PacketReceiveEvent.Mode[]{PRE, POST};
      }
   }
}
