package com.chorus.impl.events.network;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;

@Environment(EnvType.CLIENT)
public class PacketSendEvent extends Event {
   private final class_2596 packet;
   private final PacketSendEvent.Mode mode;

   public PacketSendEvent(PacketSendEvent.Mode mode, class_2596 packet) {
      this.mode = mode;
      this.packet = packet;
   }

   public class_2596 getPacket() {
      return this.packet;
   }

   public PacketSendEvent.Mode getMode() {
      return this.mode;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static PacketSendEvent.Mode[] $values() {
         return new PacketSendEvent.Mode[]{PRE, POST};
      }
   }
}
