package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;

@Environment(EnvType.CLIENT)
public class AttackEvent extends Event {
   private final AttackEvent.Mode mode;
   class_1297 target;

   public AttackEvent(AttackEvent.Mode mode, class_1297 target) {
      this.mode = mode;
      this.target = target;
   }

   public AttackEvent.Mode getMode() {
      return this.mode;
   }

   public class_1297 getTarget() {
      return this.target;
   }

   public void setTarget(class_1297 target) {
      this.target = target;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static AttackEvent.Mode[] $values() {
         return new AttackEvent.Mode[]{PRE, POST};
      }
   }
}
