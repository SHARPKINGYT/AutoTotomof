package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class BlockBreakingEvent extends Event {
   private final BlockBreakingEvent.Mode mode;

   public BlockBreakingEvent(BlockBreakingEvent.Mode mode) {
      this.mode = mode;
   }

   public BlockBreakingEvent.Mode getMode() {
      return this.mode;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static BlockBreakingEvent.Mode[] $values() {
         return new BlockBreakingEvent.Mode[]{PRE, POST};
      }
   }
}
