package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CurrentItemAttackStrengthDelayEvent extends Event {
   private double value = 1.0D;

   public double getValue() {
      return this.value;
   }

   public void setValue(double value) {
      this.value = value;
   }
}
