package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ItemUseCooldownEvent extends Event {
   int speed;

   public ItemUseCooldownEvent(int speed) {
      this.speed = speed;
   }

   public int getSpeed() {
      return this.speed;
   }

   public void setSpeed(int speed) {
      this.speed = speed;
   }
}
