package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ItemUseEvent extends Event {
   private final ItemUseEvent.Mode mode;

   public ItemUseEvent(ItemUseEvent.Mode mode) {
      this.mode = mode;
   }

   public ItemUseEvent.Mode getMode() {
      return this.mode;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static ItemUseEvent.Mode[] $values() {
         return new ItemUseEvent.Mode[]{PRE, POST};
      }
   }
}
