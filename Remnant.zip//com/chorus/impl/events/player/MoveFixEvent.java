package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MoveFixEvent extends Event {
   float yaw;

   public MoveFixEvent(float yaw) {
      this.yaw = yaw;
   }

   public MoveFixEvent() {
      this.yaw = 0.0F;
   }

   public float getYaw() {
      return this.yaw;
   }

   public void setYaw(float yaw) {
      this.yaw = yaw;
   }
}
