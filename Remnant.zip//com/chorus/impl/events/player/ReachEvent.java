package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ReachEvent extends Event {
   private final ReachEvent.Type type;
   private double distance;

   public ReachEvent(ReachEvent.Type type, double originalDistance) {
      this.type = type;
      this.distance = originalDistance;
   }

   public ReachEvent.Type getType() {
      return this.type;
   }

   public double getDistance() {
      return this.distance;
   }

   public void setDistance(double distance) {
      this.distance = distance;
   }

   @Environment(EnvType.CLIENT)
   public static enum Type {
      BLOCK,
      ENTITY;

      // $FF: synthetic method
      private static ReachEvent.Type[] $values() {
         return new ReachEvent.Type[]{BLOCK, ENTITY};
      }
   }
}
