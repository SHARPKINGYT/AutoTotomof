package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SilentRotationEvent extends Event {
   private final float initYaw;
   private final float initPitch;
   private float yaw;
   private float pitch;

   public SilentRotationEvent(float yaw, float pitch) {
      this.initYaw = yaw;
      this.initPitch = pitch;
      this.yaw = yaw;
      this.pitch = pitch;
   }

   public boolean hasBeenModified() {
      return this.initYaw != this.yaw || this.initPitch != this.pitch;
   }

   public float getInitYaw() {
      return this.initYaw;
   }

   public float getInitPitch() {
      return this.initPitch;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void setYaw(float yaw) {
      this.yaw = yaw;
   }

   public void setPitch(float pitch) {
      this.pitch = pitch;
   }
}
