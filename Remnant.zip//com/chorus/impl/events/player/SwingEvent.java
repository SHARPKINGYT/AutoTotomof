package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;

@Environment(EnvType.CLIENT)
public class SwingEvent extends Event {
   private final SwingEvent.Mode mode;
   class_1297 target;

   public SwingEvent(SwingEvent.Mode mode) {
      this.mode = mode;
   }

   public SwingEvent.Mode getMode() {
      return this.mode;
   }

   public class_1297 getTarget() {
      return this.target;
   }

   public void setTarget(class_1297 target) {
      this.target = target;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static SwingEvent.Mode[] $values() {
         return new SwingEvent.Mode[]{PRE, POST};
      }
   }
}
