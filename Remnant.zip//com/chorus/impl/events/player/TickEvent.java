package com.chorus.impl.events.player;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TickEvent extends Event {
   private final TickEvent.Mode mode;

   public TickEvent(TickEvent.Mode mode) {
      this.mode = mode;
   }

   public TickEvent.Mode getMode() {
      return this.mode;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static TickEvent.Mode[] $values() {
         return new TickEvent.Mode[]{PRE, POST};
      }
   }
}
