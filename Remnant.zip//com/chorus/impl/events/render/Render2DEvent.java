package com.chorus.impl.events.render;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class Render2DEvent extends Event {
   private final Render2DEvent.Mode mode;
   private final class_332 context;

   public Render2DEvent(class_332 context, Render2DEvent.Mode mode) {
      this.mode = mode;
      this.context = context;
   }

   public Render2DEvent.Mode getMode() {
      return this.mode;
   }

   public class_332 getContext() {
      return this.context;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static Render2DEvent.Mode[] $values() {
         return new Render2DEvent.Mode[]{PRE, POST};
      }
   }
}
