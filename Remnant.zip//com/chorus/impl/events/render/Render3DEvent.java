package com.chorus.impl.events.render;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class Render3DEvent extends Event {
   private final Render3DEvent.Mode mode;
   private final class_4587 matrices;
   private final float tickDelta;
   private final class_4184 camera;
   private final class_757 gameRenderer;
   private final Matrix4f projectionMatrix;
   private final class_761 worldRenderer;

   public Render3DEvent(Render3DEvent.Mode mode, class_4587 matrices, float tickDelta, class_4184 camera, class_757 gameRenderer, Matrix4f projectionMatrix, class_761 worldRenderer) {
      this.mode = mode;
      this.matrices = matrices;
      this.tickDelta = tickDelta;
      this.camera = camera;
      this.gameRenderer = gameRenderer;
      this.projectionMatrix = projectionMatrix;
      this.worldRenderer = worldRenderer;
   }

   public Render3DEvent.Mode getMode() {
      return this.mode;
   }

   public class_4587 getMatrices() {
      return this.matrices;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public class_4184 getCamera() {
      return this.camera;
   }

   public class_757 getGameRenderer() {
      return this.gameRenderer;
   }

   public Matrix4f getProjectionMatrix() {
      return this.projectionMatrix;
   }

   public class_761 getWorldRenderer() {
      return this.worldRenderer;
   }

   @Environment(EnvType.CLIENT)
   public static enum Mode {
      PRE,
      POST;

      // $FF: synthetic method
      private static Render3DEvent.Mode[] $values() {
         return new Render3DEvent.Mode[]{PRE, POST};
      }
   }
}
