package com.chorus.impl.events.world;

import cc.polymorphism.eventbus.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_638;

@Environment(EnvType.CLIENT)
public class WorldChangeEvent extends Event {
   class_638 world;

   public WorldChangeEvent(class_638 world) {
      this.world = world;
   }

   public class_638 getWorld() {
      return this.world;
   }
}
