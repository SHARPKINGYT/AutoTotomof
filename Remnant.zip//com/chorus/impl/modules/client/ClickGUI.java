package com.chorus.impl.modules.client;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.common.QuickImports;
import com.chorus.impl.screen.auth.LoginScreen;
import com.chorus.impl.screen.primordial.PrimordialScreen;
import com.chorus.impl.screen.remnant.RemnantScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_437;

@ModuleInfo(
   name = "ClickGUI",
   description = "Opens an interface for module management",
   category = ModuleCategory.CLIENT,
   key = 260
)
@Environment(EnvType.CLIENT)
public class ClickGUI extends BaseModule implements QuickImports {
   private final ModeSetting mode = new ModeSetting("Mode", "Choose Clickgui to use", "Remnant", new String[]{"Remnant", "Primordial"});

   protected void onModuleEnabled() {
      if (!(mc.field_1755 instanceof LoginScreen)) {
         if (this.mode.getValue().equals("Remnant")) {
            mc.method_1507(RemnantScreen.getINSTANCE());
         } else {
            mc.method_1507(PrimordialScreen.getINSTANCE());
         }

      }
   }

   public ClickGUI() {
      this.getSettingRepository().registerSettings(this.mode);
   }

   public void onDisable() {
      if (this.mode.getValue().equals("Remnant") && mc.field_1755 instanceof RemnantScreen) {
         mc.method_1507((class_437)null);
      } else if (this.mode.getValue().equals("Primordial") && mc.field_1755 instanceof PrimordialScreen) {
         mc.method_1507((class_437)null);
      }

      super.onDisable();
   }
}
