package com.chorus.impl.modules.client;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.repository.friend.Friend;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3966;

@ModuleInfo(
   name = "Friends",
   description = "Prevents Targeting Friends",
   category = ModuleCategory.CLIENT
)
@Environment(EnvType.CLIENT)
public class Friends extends BaseModule implements QuickImports {
   boolean pressed = false;

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1687 == null | mc.field_1724 == null) {
            return;
         }

         if (!InputUtils.mouseDown(2)) {
            this.pressed = false;
            return;
         }

         class_239 hitResult = mc.field_1765;
         if (this.pressed) {
            return;
         }

         if (hitResult instanceof class_3966) {
            class_3966 entityHitResult = (class_3966)hitResult;
            class_1297 var5 = entityHitResult.method_17782();
            if (var5 instanceof class_1657) {
               class_1657 player = (class_1657)var5;
               this.pressed = true;
               if (friendRepository.isFriend(player.method_5667())) {
                  friendRepository.removeFriend(player.method_5667());
                  Chorus.getInstance().getNotificationManager().addNotification("Removed", player.method_5820(), 5000);
               } else {
                  friendRepository.addFriend(new Friend(player.method_5667(), player.method_5820()));
                  Chorus.getInstance().getNotificationManager().addNotification("Added", player.method_5820(), 5000);
               }
            }
         }
      }

   }
}
