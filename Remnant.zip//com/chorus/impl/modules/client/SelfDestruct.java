package com.chorus.impl.modules.client;

import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.common.QuickImports;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_437;

@ModuleInfo(
   name = "SelfDestruct",
   description = "Cleans up client traces",
   category = ModuleCategory.CLIENT
)
@Environment(EnvType.CLIENT)
public class SelfDestruct extends BaseModule implements QuickImports {
   private final BooleanSetting clearLatestLog = new BooleanSetting("Clear Logs", "Removes client traces from logs", true);

   public SelfDestruct() {
      this.getSettingRepository().registerSettings(this.clearLatestLog);
   }

   protected void onModuleEnabled() {
      Chorus.getInstance().getConfigManager().saveCurrentProfile();
      Chorus.getInstance().getConfigManager().shutdown();
      Chorus.getInstance().getModuleManager().getModules().forEach((module) -> {
         if (module != this) {
            module.onDisable();
            module.setKey(-1);
         }

      });
      if (this.clearLatestLog.getValue()) {
         try {
            Path logPath = mc.field_1697.toPath().resolve("logs/latest.log");
            if (Files.exists(logPath, new LinkOption[0])) {
               List<String> lines = Files.readAllLines(logPath);
               List<String> cleanedLines = new ArrayList();
               Iterator var4 = lines.iterator();

               while(var4.hasNext()) {
                  String line = (String)var4.next();
                  String lowerCase = line.toLowerCase();
                  if (!lowerCase.contains("chorus") && !lowerCase.contains("modulemanager") && !lowerCase.contains("commandrepository")) {
                     cleanedLines.add(line);
                  }
               }

               Files.write(logPath, cleanedLines);
            }
         } catch (IOException var7) {
            var7.printStackTrace();
         }
      }

      mc.method_1507((class_437)null);
      System.gc();
   }
}
