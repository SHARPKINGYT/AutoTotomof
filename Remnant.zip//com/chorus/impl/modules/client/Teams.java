package com.chorus.impl.modules.client;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.repository.team.TeamRepository;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.TickEvent;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

@ModuleInfo(
   name = "Teams",
   description = "Prevents Targeting Teammates",
   category = ModuleCategory.CLIENT
)
@Environment(EnvType.CLIENT)
public class Teams extends BaseModule implements QuickImports {
   public TeamRepository repo;
   private final Queue<class_1657> playerList = new ConcurrentLinkedQueue();
   private final Queue<class_1657> hasSameArmor = new ConcurrentLinkedQueue();

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1687 == null | mc.field_1724 == null) {
            return;
         }

         if (mc.field_1724.field_6012 < 5) {
            teamRepository.clear();
            return;
         }

         if (teamRepository.getCurrentTeam() == null) {
            teamRepository.setTeam("gangstas");
            return;
         }

         mc.field_1687.method_18456().forEach((player) -> {
            if (this.checkNameColor(player)) {
               if (!this.checkArmorColor(player)) {
               }

               if (this.checkScoreboardTeam(player)) {
                  teamRepository.addMemberToCurrentTeam(player.method_5820());
               }
            }
         });
      }

   }

   private boolean checkNameColor(class_1657 player) {
      class_2561 playerDisplayName = player.method_5476();
      class_2561 mcPlayerDisplayName = mc.field_1724.method_5476();
      boolean isTeam = playerDisplayName != null && mcPlayerDisplayName != null && playerDisplayName.method_10866() != null && mcPlayerDisplayName.method_10866() != null && Objects.equals(playerDisplayName.method_10866().method_10973(), mcPlayerDisplayName.method_10866().method_10973());
      if (!isTeam) {
         teamRepository.removeMemberFromCurrentTeam(player.method_5820());
         return false;
      } else {
         return true;
      }
   }

   private boolean checkArmorColor(class_1657 player) {
      int armorAmount = 0;

      for(int i = 3; i >= 0; --i) {
         class_1799 armor = player.method_31548().method_7372(i);
         class_1799 playerArmor = mc.field_1724.method_31548().method_7372(i);
         class_1792 var8 = armor.method_7909();
         if (var8 instanceof class_1769) {
            class_1769 dyeableArmorItem = (class_1769)var8;
            var8 = playerArmor.method_7909();
            if (var8 instanceof class_1769) {
               class_1769 dyeableArmorItem2 = (class_1769)var8;
               if (dyeableArmorItem.method_7802() == dyeableArmorItem2.method_7802()) {
                  ++armorAmount;
               }
            }
         }
      }

      if (armorAmount > 0) {
         return true;
      } else {
         teamRepository.removeMemberFromCurrentTeam(player.method_5820());
         return false;
      }
   }

   private boolean checkScoreboardTeam(class_1657 player) {
      return player.method_5781() != null && mc.field_1724.method_5781() != null && Objects.equals(player.method_5781(), mc.field_1724.method_5781());
   }
}
