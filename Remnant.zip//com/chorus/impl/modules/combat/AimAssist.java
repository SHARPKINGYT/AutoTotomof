package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.rotation.RotationComponent;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.math.rotation.RotationUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.util.Comparator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1829;
import net.minecraft.class_3532;

@ModuleInfo(
   name = "AimAssist",
   description = "Assists, Or Aims For You.",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class AimAssist extends BaseModule implements QuickImports {
   private final SettingCategory aimingCategory = new SettingCategory("Aiming");
   private final SettingCategory targetingCategory = new SettingCategory("Targeting");
   private final SettingCategory behaviorCategory = new SettingCategory("Behavior");
   private final ModeSetting aimMode;
   private final ModeSetting aimMath;
   private final ModeSetting aimVector;
   private final BooleanSetting silent;
   private final RangeSetting<Double> horizontalSpeed;
   private final RangeSetting<Double> verticalSpeed;
   private final NumberSetting<Double> range;
   private final NumberSetting<Double> fov;
   private final NumberSetting<Double> multipoint;
   private final MultiSetting conditions;
   private final ModeSetting targetSorting;
   private final TimerUtils rotationTime;

   @RegisterEvent
   private void render3DEventEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null && mc.field_1755 == null) {
         if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
            class_1657 target = (class_1657)mc.field_1687.method_18456().stream().filter((player) -> {
               return player != mc.field_1724 && (double)mc.field_1724.method_5739(player) <= (Double)this.range.getValue() && SocialManager.isEnemy(player) && SocialManager.isTargetedPlayer(player) == player && Math.toDegrees(MathUtils.angleBetween(mc.field_1724.method_5720(), player.method_19538().method_1031(0.0D, (double)player.method_18381(player.method_18376()), 0.0D).method_1020(mc.field_1724.method_33571()))) <= (Double)this.fov.getValue() / 2.0D;
            }).min(Comparator.comparingDouble((player) -> {
               String var2 = this.targetSorting.getValue();
               byte var3 = -1;
               switch(var2.hashCode()) {
               case -2137395588:
                  if (var2.equals("Health")) {
                     var3 = 2;
                  }
                  break;
               case 24343454:
                  if (var2.equals("Rotation")) {
                     var3 = 3;
                  }
                  break;
               case 353103893:
                  if (var2.equals("Distance")) {
                     var3 = 1;
                  }
                  break;
               case 765499292:
                  if (var2.equals("HurtTime")) {
                     var3 = 0;
                  }
               }

               double var10000;
               switch(var3) {
               case 0:
                  var10000 = (double)player.field_6235;
                  break;
               case 1:
                  var10000 = (double)mc.field_1724.method_5739(player);
                  break;
               case 2:
                  var10000 = (double)player.method_6032();
                  break;
               case 3:
                  var10000 = (double)Math.abs(class_3532.method_15393((float)MathUtils.toDegrees(Math.atan2(player.method_33571().method_1020(mc.field_1724.method_33571()).field_1350, player.method_33571().method_1020(mc.field_1724.method_33571()).field_1352)) - 90.0F) - mc.field_1724.method_36454());
                  break;
               default:
                  throw new IllegalStateException("Unexpected value: " + this.targetSorting.getValue());
               }

               return var10000;
            })).orElse((Object)null);
            rotationComponent.setMultiPoint(((Double)this.multipoint.getValue()).floatValue() * 0.01F);
            rotationComponent.setSilentRotation(this.silent.getValue());
            rotationComponent.setHorizontalSpeed(this.horizontalSpeed.getRandomValue().floatValue());
            rotationComponent.setVerticalSpeed(this.verticalSpeed.getRandomValue().floatValue());
            if (target != null && !this.checkConditions() && (!this.rotationTime.hasReached(100.0D) || this.aimMode.getValue().equals("Normal"))) {
               rotationComponent.queueRotation((class_1309)target, (RotationComponent.RotationPriority)RotationComponent.RotationPriority.MEDIUM, (RotationComponent.AimType)this.getAimMath(), (RotationComponent.EntityPoints)this.getAimVecMode());
            }
         }

         this.setSuffix(this.aimMath.getValue());
      }
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null && mc.field_1755 == null) {
         if (event.getMode().equals(TickEvent.Mode.PRE)) {
            class_1657 target = (class_1657)mc.field_1687.method_18456().stream().filter((player) -> {
               return player != mc.field_1724 && (double)mc.field_1724.method_5739(player) <= (Double)this.range.getValue() && SocialManager.isEnemy(player) && SocialManager.isTargetedPlayer(player) == player && Math.toDegrees(MathUtils.angleBetween(mc.field_1724.method_5720(), player.method_19538().method_1031(0.0D, (double)player.method_18381(player.method_18376()), 0.0D).method_1020(mc.field_1724.method_33571()))) <= (Double)this.fov.getValue() / 2.0D;
            }).min(Comparator.comparingDouble((player) -> {
               String var2 = this.targetSorting.getValue();
               byte var3 = -1;
               switch(var2.hashCode()) {
               case -2137395588:
                  if (var2.equals("Health")) {
                     var3 = 2;
                  }
                  break;
               case 24343454:
                  if (var2.equals("Rotation")) {
                     var3 = 3;
                  }
                  break;
               case 353103893:
                  if (var2.equals("Distance")) {
                     var3 = 1;
                  }
                  break;
               case 765499292:
                  if (var2.equals("HurtTime")) {
                     var3 = 0;
                  }
               }

               double var10000;
               switch(var3) {
               case 0:
                  var10000 = (double)player.field_6235;
                  break;
               case 1:
                  var10000 = (double)mc.field_1724.method_5739(player);
                  break;
               case 2:
                  var10000 = (double)player.method_6032();
                  break;
               case 3:
                  var10000 = (double)Math.abs(class_3532.method_15393((float)MathUtils.toDegrees(Math.atan2(player.method_33571().method_1020(mc.field_1724.method_33571()).field_1350, player.method_33571().method_1020(mc.field_1724.method_33571()).field_1352)) - 90.0F) - mc.field_1724.method_36454());
                  break;
               default:
                  throw new IllegalStateException("Unexpected value: " + this.targetSorting.getValue());
               }

               return var10000;
            })).orElse((Object)null);
            if (target != null) {
               float targetYaw = class_3532.method_15393(RotationUtils.calculate(target.method_33571())[0]);
               float prevYawDiff = targetYaw - class_3532.method_15393(mc.field_1724.field_5982);
               float currentYawDiff = targetYaw - class_3532.method_15393(mc.field_1724.method_36454());
               float threshold = 0.5F * (Math.abs(currentYawDiff) / 180.0F);
               if (Math.abs(currentYawDiff) > Math.abs(prevYawDiff) + threshold) {
                  this.rotationTime.reset();
               }
            }
         }

      }
   }

   private RotationComponent.AimType getAimMath() {
      String var1 = this.aimMath.getValue();
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -2018804923:
         if (var1.equals("Linear")) {
            var2 = 2;
         }
         break;
      case -1543850116:
         if (var1.equals("Regular")) {
            var2 = 0;
         }
         break;
      case -1241367914:
         if (var1.equals("Adaptive")) {
            var2 = 1;
         }
         break;
      case 1630783146:
         if (var1.equals("Blatant")) {
            var2 = 3;
         }
      }

      RotationComponent.AimType var10000;
      switch(var2) {
      case 0:
         var10000 = RotationComponent.AimType.REGULAR;
         break;
      case 1:
         var10000 = RotationComponent.AimType.ADAPTIVE;
         break;
      case 2:
         var10000 = RotationComponent.AimType.LINEAR;
         break;
      case 3:
         var10000 = RotationComponent.AimType.BLATANT;
         break;
      default:
         var10000 = RotationComponent.AimType.REGULAR;
      }

      return var10000;
   }

   private RotationComponent.EntityPoints getAimVecMode() {
      String var1 = this.aimVector.getValue();
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -1854418717:
         if (var1.equals("Random")) {
            var2 = 2;
         }
         break;
      case -1763776967:
         if (var1.equals("Closest")) {
            var2 = 1;
         }
         break;
      case 1852116762:
         if (var1.equals("Straight")) {
            var2 = 0;
         }
      }

      RotationComponent.EntityPoints var10000;
      switch(var2) {
      case 0:
         var10000 = RotationComponent.EntityPoints.STRAIGHT;
         break;
      case 1:
         var10000 = RotationComponent.EntityPoints.CLOSEST;
         break;
      case 2:
         var10000 = RotationComponent.EntityPoints.RANDOM;
         break;
      default:
         var10000 = RotationComponent.EntityPoints.STRAIGHT;
      }

      return var10000;
   }

   private boolean checkConditions() {
      String[] var1 = new String[]{"Holding Weapon", "Clicking", "Break Blocks"};
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String check = var1[var3];
         byte var7 = -1;
         switch(check.hashCode()) {
         case 971106682:
            if (check.equals("Clicking")) {
               var7 = 1;
            }
            break;
         case 1133664857:
            if (check.equals("Holding Weapon")) {
               var7 = 0;
            }
            break;
         case 1463209991:
            if (check.equals("Break Blocks")) {
               var7 = 2;
            }
         }

         boolean var10000;
         switch(var7) {
         case 0:
            if (this.conditions.getSpecificValue(check) && !(mc.field_1724.method_31548().method_7391().method_7909() instanceof class_1829)) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         case 1:
            if (this.conditions.getSpecificValue(check) && !InputUtils.mouseDown(0)) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         case 2:
            if (this.conditions.getSpecificValue(check) && mc.field_1761.method_2923()) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         default:
            var10000 = false;
         }

         boolean isTrue = var10000;
         if (isTrue) {
            return true;
         }
      }

      return false;
   }

   public AimAssist() {
      this.aimMode = new ModeSetting(this.aimingCategory, "Aim Mode", "Select the aiming mode", "Normal", new String[]{"Normal", "Assist"});
      this.aimMath = new ModeSetting(this.aimingCategory, "Aim Math", "Select the aiming math", "Regular", new String[]{"Regular", "Adaptive", "Linear", "Blatant"});
      this.aimVector = new ModeSetting(this.aimingCategory, "Aim Vector", "Select the aiming location behavior", "Straight", new String[]{"Straight", "Closest", "Random"});
      this.silent = new BooleanSetting(this.aimingCategory, "Silent Rotations", "Rotates Silently", false);
      this.horizontalSpeed = new RangeSetting(this.aimingCategory, "Horizontal Aim Speed", "Adjust the speed", 0.0D, 100.0D, 30.0D, 50.0D);
      this.verticalSpeed = new RangeSetting(this.aimingCategory, "Vertical Aim Speed", "Adjust the speed", 0.0D, 100.0D, 30.0D, 50.0D);
      this.range = new NumberSetting(this.behaviorCategory, "Range", "Set the maximum distance", 6.0D, 1.0D, 50.0D);
      this.fov = new NumberSetting(this.behaviorCategory, "FOV", "Define the field of view for target detection", 90.0D, 0.0D, 360.0D);
      this.multipoint = new NumberSetting(this.behaviorCategory, "Multipoint", "Control aiming point between center and edges", 50.0D, 0.0D, 100.0D);
      this.conditions = new MultiSetting(this.targetingCategory, "Conditions", "Set activation conditions", new String[]{"Clicking", "Holding Weapon", "Break Blocks"});
      this.targetSorting = new ModeSetting(this.targetingCategory, "Target Sorting", "Choose how targets are prioritized", "Distance", new String[]{"Distance", "HurtTime", "Health", "Rotation"});
      this.rotationTime = new TimerUtils();
      this.getSettingRepository().registerSettings(this.aimingCategory, this.targetingCategory, this.behaviorCategory, this.aimMode, this.aimMath, this.aimVector, this.silent, this.horizontalSpeed, this.verticalSpeed, this.range, this.fov, this.conditions, this.targetSorting, this.multipoint);
   }
}
