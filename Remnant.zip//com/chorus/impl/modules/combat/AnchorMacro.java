package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.DamageUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.ItemUseCooldownEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

@ModuleInfo(
   name = "Anchor Macro",
   description = "Automatically Fills And Explodes Anchors",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class AnchorMacro extends BaseModule implements QuickImports {
   private final SettingCategory generalSettings = new SettingCategory("General Settings");
   private final SettingCategory chargeSettings = new SettingCategory("Anchor Charge Settings");
   private final SettingCategory explosionSettings = new SettingCategory("Anchor Explosion Settings");
   private final SettingCategory swapSettings = new SettingCategory("Hotbar Swap Settings");
   private final MultiSetting condition;
   private final RangeSetting<Float> range;
   private final BooleanSetting charge;
   private final NumberSetting<Integer> chargeAmount;
   private final RangeSetting<Integer> chargeDelay;
   private final BooleanSetting explode;
   private final NumberSetting<Float> explodeDamage;
   private final RangeSetting<Integer> explodeDelay;
   private final ModeSetting swap;
   private final NumberSetting<Integer> swapDelay;
   private final TimerUtils chargeTimer;
   private final TimerUtils explodeTimer;
   private final TimerUtils swapTimer;

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         if (event.getMode() == TickEvent.Mode.PRE) {
            class_239 crosshairTarget = mc.field_1765;
            if (crosshairTarget instanceof class_3965) {
               class_3965 blockHit = (class_3965)crosshairTarget;
               class_1792 mainHand = InventoryUtils.getMainHandItem().method_7909();
               if (!this.condition.getSpecificValue("Clicking") || InputUtils.mouseDown(1)) {
                  if (!this.condition.getSpecificValue("Holding Anchor Related Item") || mainHand == class_1802.field_23141 || mainHand == class_1802.field_8801) {
                     if (mc.field_1687.method_8320(blockHit.method_17777()).method_26204() == class_2246.field_23152) {
                        mc.field_1690.field_1904.method_23481(false);
                        int charges = (Integer)mc.field_1687.method_8320(blockHit.method_17777()).method_11654(class_4969.field_23153);
                        if (charges < (Integer)this.chargeAmount.getValue()) {
                           this.explodeTimer.reset();
                           this.chargeTimer.reset();
                           if (!this.charge.getValue()) {
                              return;
                           }

                           if (mainHand != class_1802.field_8801) {
                              if (InventoryUtils.findItemInHotBar(class_1802.field_8801) != -1 && this.swapTimer.hasReached((double)(Integer)this.swapDelay.getValue())) {
                                 InventoryUtils.swapToMainHand(InventoryUtils.findItemInHotBar(class_1802.field_8801));
                                 this.swapTimer.reset();
                              }
                           } else if (this.chargeTimer.hasReached((double)this.chargeDelay.getRandomValue().intValue())) {
                              mc.field_1690.field_1904.method_23481(false);
                              InputUtils.simulateClick(1, 50);
                           }
                        } else {
                           if (!this.explode.getValue()) {
                              return;
                           }

                           if (mainHand == class_1802.field_8801) {
                              this.explodeTimer.reset();
                              if (this.swapTimer.hasReached((double)(Integer)this.swapDelay.getValue())) {
                                 InventoryUtils.swapToMainHand(InventoryUtils.findItemInHotBar(class_1802.field_23141));
                                 this.swapTimer.reset();
                              }
                           } else if (this.explodeTimer.hasReached((double)this.explodeDelay.getRandomValue().intValue())) {
                              if (DamageUtils.calculateAnchorDamage(mc.field_1724, blockHit.method_17777().method_46558()) > (Float)this.explodeDamage.getValue()) {
                                 return;
                              }

                              InputUtils.simulateClick(1, 50);
                           }
                        }
                     } else {
                        this.swapTimer.reset();
                     }

                  }
               }
            }
         }
      }
   }

   @RegisterEvent
   private void itemUseCooldownEventEventListener(ItemUseCooldownEvent event) {
      event.setSpeed(this.meetsConditions() ? 0 : 4);
   }

   public boolean meetsConditions() {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         if (this.condition.getSpecificValue("Clicking") && !InputUtils.mouseDown(1)) {
            return false;
         } else {
            class_1792 mainHand = InventoryUtils.getMainHandItem().method_7909();
            return !this.condition.getSpecificValue("Holding Anchor Related Item") || mainHand == class_1802.field_23141 || mainHand == class_1802.field_8801;
         }
      } else {
         return false;
      }
   }

   public AnchorMacro() {
      this.condition = new MultiSetting(this.generalSettings, "Conditions", "Only Anchor When", new String[]{"Clicking", "Holding Anchor Related Item"});
      this.range = new RangeSetting(this.generalSettings, "Range", "", 0.0F, 6.0F, 3.0F, 3.0F);
      this.charge = new BooleanSetting(this.chargeSettings, "Charge Anchors", "Decide To Automatically Charge Anchors", true);
      this.chargeAmount = new NumberSetting(this.chargeSettings, "Charge Amount", "", 1, 1, 4);
      this.chargeDelay = new RangeSetting(this.chargeSettings, "Charge Delay", "", 0, 250, 100, 100);
      this.explode = new BooleanSetting(this.explosionSettings, "Explode Anchors", "Decide To Automatically Explode Anchors", true);
      this.explodeDamage = new NumberSetting(this.explosionSettings, "Explode Max Self Damage", "Max Damage An Anchor Can Do", 1.0F, 1.0F, 20.0F);
      this.explodeDelay = new RangeSetting(this.explosionSettings, "Explode Delay", "", 0, 250, 100, 100);
      this.swap = new ModeSetting(this.swapSettings, "Swap To", "Swap To An Item After Exploding An Anchor", "Anchor", new String[]{"Anchor", "Totem", "Shield", "Obsidian"});
      this.swapDelay = new NumberSetting(this.swapSettings, "Swap Delay", "", 50, 0, 250);
      this.chargeTimer = new TimerUtils();
      this.explodeTimer = new TimerUtils();
      this.swapTimer = new TimerUtils();
      this.getSettingRepository().registerSettings(this.generalSettings, this.chargeSettings, this.explosionSettings, this.swapSettings, this.condition, this.range, this.charge, this.chargeAmount, this.chargeDelay, this.explode, this.explodeDamage, this.explodeDelay, this.swap, this.swapDelay);
      this.chargeAmount.setRenderCondition(() -> {
         return this.charge.getValue();
      });
      this.chargeAmount.setRenderCondition(() -> {
         return this.charge.getValue();
      });
      this.explodeDamage.setRenderCondition(() -> {
         return this.explode.getValue();
      });
      this.swapDelay.setRenderCondition(() -> {
         return !this.swap.getValue().equals("Anchor");
      });
   }
}
