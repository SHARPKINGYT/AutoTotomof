package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.DamageUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(
   name = "AutoCrystal",
   description = "Uses and Explodes Crystals",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class AutoCrystal extends BaseModule implements QuickImports {
   private final SettingCategory conditionSetting = new SettingCategory("Condition Settings");
   private final SettingCategory placeSetting = new SettingCategory("Placing Settings");
   private final SettingCategory breakSetting = new SettingCategory("Breaking Settings");
   private final SettingCategory otherSetting = new SettingCategory("Other Settings");
   private final MultiSetting actions;
   private final BooleanSetting onRightClick;
   private final BooleanSetting pauseOnKill;
   private final BooleanSetting damageTick;
   private final ModeSetting placeMode;
   private final RangeSetting<Integer> placeDelay;
   private final ModeSetting breakMode;
   private final RangeSetting<Integer> breakDelay;
   private final NumberSetting<Integer> failChance;
   private final ModeSetting scanType;
   private final NumberSetting<Double> expansion;
   private final NumberSetting<Double> maxDamage;
   private final BooleanSetting preventPlace;
   private final TimerUtils placeTimer;
   private final TimerUtils breakTimer;
   int lastAttackTime;

   public AutoCrystal() {
      this.actions = new MultiSetting(this.conditionSetting, "Actions", "Decide what autocrystal does", new String[]{"Place", "Break"});
      this.onRightClick = new BooleanSetting(this.conditionSetting, "On Right Click", "Activate Crystal Only Right Click", true);
      this.pauseOnKill = new BooleanSetting(this.conditionSetting, "Pause On Kill", "Pause On Enemy Death", true);
      this.damageTick = new BooleanSetting(this.conditionSetting, "Damage Tick", "Time Crystal Explosions To Hurt-Time", true);
      this.placeMode = new ModeSetting(this.placeSetting, "Place Input", "Select Place Input", "Click", new String[]{"Click", "Packet"});
      this.placeDelay = new RangeSetting(this.placeSetting, "Place Delay", "Delay it uses to Place crystals", 0, 250, 50, 50);
      this.breakMode = new ModeSetting(this.breakSetting, "Break Input", "Select Break Input", "Click", new String[]{"Click", "Packet"});
      this.breakDelay = new RangeSetting(this.breakSetting, "Break Delay", "Delay it uses to break crystals", 0, 250, 50, 50);
      this.failChance = new NumberSetting(this.breakSetting, "Fail Chance", "Chance To Fail Breaking Crystal", 10, 0, 100);
      this.scanType = new ModeSetting(this.breakSetting, "Scan Type", "Select Method To Scan For Crystals", "Raytrace", new String[]{"Raytrace", "Expanded Raytrace"});
      this.expansion = new NumberSetting(this.breakSetting, "Expansion", "Expansion For Expanded Raytrace Scan Type", 0.0D, 0.0D, 1.0D);
      this.maxDamage = new NumberSetting(this.breakSetting, "Max Self Damage", "Max Self Damage", 10.0D, 0.0D, 20.0D);
      this.preventPlace = new BooleanSetting(this.otherSetting, "Prevent Minecraft Place", "Allows only the client to place crystals", true);
      this.placeTimer = new TimerUtils();
      this.breakTimer = new TimerUtils();
      this.lastAttackTime = 0;
      this.getSettingRepository().registerSettings(this.conditionSetting, this.placeSetting, this.breakSetting, this.otherSetting, this.actions, this.onRightClick, this.pauseOnKill, this.damageTick, this.placeMode, this.placeDelay, this.breakMode, this.breakDelay, this.failChance, this.scanType, this.expansion, this.maxDamage, this.preventPlace);
      this.placeSetting.setRenderCondition(() -> {
         return this.actions.getSpecificValue("Place");
      });
      this.breakSetting.setRenderCondition(() -> {
         return this.actions.getSpecificValue("Break");
      });
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null || !mc.method_1569()) {
            return;
         }

         if (this.pauseOnKill.getValue() && mc.field_1687.method_18456().stream().anyMatch((player) -> {
            return player != mc.field_1724 && !player.method_5805() && player.method_5858(mc.field_1724) < 36.0D;
         })) {
            return;
         }

         if (this.onRightClick.getValue() && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), 1) != 1) {
            return;
         }

         if (mc.field_1724.method_6047().method_7909() != class_1802.field_8301) {
            return;
         }

         class_239 hitResult = mc.field_1765;
         if (this.lastAttackTime < 0) {
            this.lastAttackTime = mc.field_1724.field_6012;
         }

         if (this.actions.getSpecificValue("Place") && hitResult instanceof class_3965) {
            class_3965 blockHitResult = (class_3965)hitResult;
            class_2338 blockPos = blockHitResult.method_17777();
            class_2248 block = mc.field_1687.method_8320(blockPos).method_26204();
            if (block == class_2246.field_10540 || block == class_2246.field_9987) {
               this.handlePlace(blockHitResult);
            }
         }

         if (this.actions.getSpecificValue("Break") && (!this.damageTick.getValue() || mc.field_1724.method_6052() instanceof class_1657 || mc.field_1687.method_18456().stream().anyMatch((player) -> {
            return player != mc.field_1724 && player.field_6235 == 0;
         }) || mc.field_1724.field_6012 - this.lastAttackTime > 12)) {
            if (mc.field_1724.method_6052() instanceof class_1657) {
               this.lastAttackTime = mc.field_1724.field_6012;
            }

            if (this.scanType.getValue().equals("Raytrace")) {
               if (hitResult instanceof class_3966) {
                  class_3966 entityHitResult = (class_3966)hitResult;
                  class_1297 entity = entityHitResult.method_17782();
                  if (entity instanceof class_1511 && entity.method_5805()) {
                     this.handleBreak(entity);
                  }
               }
            } else {
               class_1297 hitboxEntity = this.raycastCrystal(4.0D);
               if (hitboxEntity != null) {
                  this.handleBreak(hitboxEntity);
               }
            }
         }
      }

   }

   public void handlePlace(class_3965 blockHitResult) {
      if (this.placeTimer.hasReached((double)this.placeDelay.getRandomValue().floatValue())) {
         if (blockHitResult.method_17777().method_19769(mc.field_1724.method_19538(), 4.0D)) {
            boolean random = MathUtils.randomInt(1, 100) >= (Integer)this.failChance.getValue();
            if (random) {
               String var3 = this.placeMode.getValue();
               byte var4 = -1;
               switch(var3.hashCode()) {
               case -1911998296:
                  if (var3.equals("Packet")) {
                     var4 = 1;
                  }
                  break;
               case 65197416:
                  if (var3.equals("Click")) {
                     var4 = 0;
                  }
               }

               switch(var4) {
               case 0:
                  InputUtils.simulateClick(1);
                  mc.field_1690.field_1904.method_23481(true);
                  InputUtils.simulateRelease(1);
                  break;
               case 1:
                  mc.method_1562().method_52787(new class_2885(class_1268.field_5808, blockHitResult, 0));
                  mc.field_1724.method_6104(mc.field_1724.method_6058());
               }
            } else {
               InputUtils.simulateClick(0);
               mc.field_1690.field_1886.method_23481(true);
               mc.field_1690.field_1886.method_23481(false);
               InputUtils.simulateRelease(0);
            }

            this.placeTimer.reset();
            if (this.preventPlace.getValue()) {
               mc.field_1690.field_1904.method_23481(false);
            }

         }
      }
   }

   public void handleBreak(class_1297 entity) {
      if (this.breakTimer.hasReached((double)this.breakDelay.getRandomValue().floatValue())) {
         if (!((double)DamageUtils.calculateCrystalDamage(mc.field_1724, entity.method_19538()) > (Double)this.maxDamage.getValue())) {
            String var2 = this.breakMode.getValue();
            byte var3 = -1;
            switch(var2.hashCode()) {
            case -1911998296:
               if (var2.equals("Packet")) {
                  var3 = 1;
               }
               break;
            case 65197416:
               if (var2.equals("Click")) {
                  var3 = 0;
               }
            }

            switch(var3) {
            case 0:
               InputUtils.simulateClick(0);
               mc.field_1690.field_1886.method_23481(true);
               mc.field_1690.field_1886.method_23481(false);
               InputUtils.simulateRelease(0);
               break;
            case 1:
               mc.field_1761.method_2918(mc.field_1724, entity);
               mc.field_1724.method_6104(class_1268.field_5808);
            }

         }
      }
   }

   private class_1297 raycastCrystal(double range) {
      class_243 cameraPos = mc.field_1773.method_19418().method_19326();
      class_243 viewVector = mc.field_1724.method_5663();
      class_243 extendedPoint = cameraPos.method_1031(viewVector.field_1352 * range, viewVector.field_1351 * range, viewVector.field_1350 * range);
      Iterator var6 = mc.field_1687.method_18112().iterator();

      class_1297 entity;
      do {
         if (!var6.hasNext()) {
            return null;
         }

         entity = (class_1297)var6.next();
      } while(!(entity instanceof class_1511) || !entity.method_5829().method_1014((Double)this.expansion.getValue()).method_993(cameraPos, extendedPoint));

      return entity;
   }
}
