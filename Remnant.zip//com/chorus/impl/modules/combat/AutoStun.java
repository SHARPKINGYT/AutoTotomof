package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.PlayerUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.modules.other.MultiTask;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_239;
import net.minecraft.class_3966;

@ModuleInfo(
   name = "AutoStun",
   description = "Stuns Enemies Shields",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class AutoStun extends BaseModule implements QuickImports {
   private final SettingCategory conditional = new SettingCategory("Conditional Settings");
   private final SettingCategory delay = new SettingCategory("Delay Settings");
   private final SettingCategory shield = new SettingCategory("Shield Settings");
   private final RangeSetting<Integer> reactionDelay;
   private final RangeSetting<Integer> initialDelay;
   private final RangeSetting<Integer> attackDelay;
   private final RangeSetting<Integer> swapBackDelay;
   private final ModeSetting swap;
   private final ModeSetting handleShield;
   private int oldSlot;
   private boolean unblocked;
   private final TimerUtils reactionTimer;
   private final TimerUtils initialSwapTimer;
   private final TimerUtils actionTimer;
   private final TimerUtils swapBackTimer;

   protected void onModuleDisabled() {
      this.oldSlot = -1;
   }

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         class_239 var4 = mc.field_1765;
         if (var4 instanceof class_3966) {
            class_3966 entityHit = (class_3966)var4;
            class_1297 var8 = entityHit.method_17782();
            if (var8 instanceof class_1657) {
               class_1657 target = (class_1657)var8;
               boolean isBlocking = target.method_6115() && target.method_6030().method_7909() instanceof class_1819;
               boolean canBreakShield = !PlayerUtils.isShieldFacingAway(target);
               class_1799 mainHand = InventoryUtils.getMainHandItem();
               if (mc.field_1724.method_6030().method_7909() instanceof class_1819 && mc.field_1724.method_6058() == class_1268.field_5810) {
                  if (this.handleShield.getValue().equals("Multi-Task") && !Chorus.getInstance().getModuleManager().isModuleEnabled(MultiTask.class)) {
                     return;
                  }

                  if (this.handleShield.getValue().equals("Unblock Shield")) {
                     mc.field_1690.field_1904.method_23481(false);
                     this.unblocked = true;
                  }
               }

               if (isBlocking && canBreakShield) {
                  if (mainHand.method_7909() instanceof class_1743) {
                     if (this.actionTimer.hasReached((double)this.attackDelay.getRandomValue().intValue())) {
                        InputUtils.simulateClick(0, 35);
                        this.actionTimer.reset();
                        this.swapBackTimer.reset();
                        return;
                     }
                  } else {
                     if (this.swap.getValue().equals("None")) {
                        return;
                     }

                     if (!this.reactionTimer.hasReached((double)this.reactionDelay.getRandomValue().intValue())) {
                        return;
                     }

                     int itemSlot = InventoryUtils.findItemWithPredicateInHotbar((itemStack) -> {
                        return itemStack.method_7909() instanceof class_1743;
                     });
                     if (itemSlot != -1 && this.oldSlot == -1 && this.initialSwapTimer.hasReached((double)this.initialDelay.getRandomValue().intValue())) {
                        this.oldSlot = mc.field_1724.method_31548().field_7545;
                        InventoryUtils.swapToMainHand(itemSlot);
                        this.actionTimer.reset();
                        return;
                     }
                  }

                  return;
               } else {
                  this.reactionTimer.reset();
                  if (this.oldSlot != -1 && this.swapBackTimer.hasReached((double)this.initialDelay.getRandomValue().intValue())) {
                     InventoryUtils.swapToMainHand(this.oldSlot);
                     this.oldSlot = -1;
                     if (this.unblocked) {
                        this.reblockShield();
                     }

                     return;
                  }

                  return;
               }
            }
         }

         this.initialSwapTimer.reset();
      }
   }

   public void reblockShield() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (InputUtils.mouseDown(1) && mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
            mc.field_1690.field_1904.method_23481(true);
            this.unblocked = false;
         }

      }
   }

   public AutoStun() {
      this.reactionDelay = new RangeSetting(this.delay, "Reaction Time", "Adjust Reaction Time", 0, 250, 10, 25);
      this.initialDelay = new RangeSetting(this.delay, "Swap Delay", "Adjust Swap Delay", 0, 500, 10, 25);
      this.attackDelay = new RangeSetting(this.delay, "Attack Delay", "Adjust Attack Delay", 0, 500, 10, 25);
      this.swapBackDelay = new RangeSetting(this.delay, "Swap Back Delay", "Adjust Swapping Back Delay", 0, 500, 10, 25);
      this.swap = new ModeSetting(this.conditional, "Swap", "Swap Setting", "Swap", new String[]{"Swap", "None"});
      this.handleShield = new ModeSetting(this.shield, "Handle Shield", "Handles Player Shield", "None", new String[]{"Multi-Task", "Unblock Shield", "None"});
      this.oldSlot = -1;
      this.unblocked = false;
      this.reactionTimer = new TimerUtils();
      this.initialSwapTimer = new TimerUtils();
      this.actionTimer = new TimerUtils();
      this.swapBackTimer = new TimerUtils();
      this.getSettingRepository().registerSettings(this.conditional, this.delay, this.swap, this.reactionDelay, this.initialDelay, this.attackDelay, this.swapBackDelay, this.handleShield, this.shield);
   }
}
