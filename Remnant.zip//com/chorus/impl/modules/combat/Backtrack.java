package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.impl.events.network.PacketReceiveEvent;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10264;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2661;
import net.minecraft.class_2664;
import net.minecraft.class_2684;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2749;
import net.minecraft.class_2767;
import net.minecraft.class_2777;
import net.minecraft.class_2797;
import net.minecraft.class_3532;
import net.minecraft.class_7422;
import net.minecraft.class_7439;
import net.minecraft.class_7472;

@ModuleInfo(
   name = "Backtrack",
   description = "Fakes High Ping To Gain An Advantage",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class Backtrack extends BaseModule implements QuickImports {
   private final SettingCategory backtrack = new SettingCategory("Backtrack");
   private final SettingCategory behavior = new SettingCategory("Behavior");
   private final ModeSetting delayType;
   private final RangeSetting<Float> range;
   private final RangeSetting<Integer> latency;
   private final BooleanSetting flushOnVelocity;
   private final NumberSetting<Integer> flushDelay;
   private final ConcurrentLinkedQueue<Backtrack.PacketData> packetQueue;
   private class_7422 position;
   private final TimerUtils waitTimer;
   private class_243 currentPosition;
   private class_243 oldPlayerPosition;
   private class_1297 target;
   private float currentDelay;

   public Backtrack() {
      this.delayType = new ModeSetting(this.backtrack, "Backtrack Type", "", "Dynamic", new String[]{"Dynamic"});
      this.range = new RangeSetting(this.backtrack, "Range", "Sets Serverside Range Limits", 0.0F, 10.0F, 1.5F, 6.0F);
      this.latency = new RangeSetting(this.backtrack, "Latency", "Latency: Sets Latency Amounts, Dynamic: Sets Latency Limits", 0, 2500, 100, 150);
      this.flushOnVelocity = new BooleanSetting(this.behavior, "Flush On Velocity", "", true);
      this.flushDelay = new NumberSetting(this.behavior, "Delay On Velocity", "Delay To Backtrack After Taking Velocity", 50, 0, 500);
      this.packetQueue = new ConcurrentLinkedQueue();
      this.waitTimer = new TimerUtils();
      this.currentPosition = new class_243(0.0D, 0.0D, 0.0D);
      this.oldPlayerPosition = new class_243(0.0D, 0.0D, 0.0D);
      this.getSettingRepository().registerSettings(this.backtrack, this.behavior, this.delayType, this.range, this.latency, this.flushOnVelocity, this.flushDelay);
   }

   @RegisterEvent
   private void packetReceiveListener(PacketReceiveEvent event) {
      if (event.getMode() == PacketReceiveEvent.Mode.PRE && mc.field_1687 != null && mc.field_1724 != null) {
         if (!this.waitTimer.hasReached((double)(Integer)this.flushDelay.getValue())) {
         }

         String var10001 = String.valueOf(this.latency.getValueMin());
         this.setSuffix(var10001 + "-" + String.valueOf(this.latency.getValueMax()) + "ms");
         if (mc.field_1724.field_6012 < 10) {
            this.resetModule(true);
         } else {
            class_2596<?> packet = event.getPacket();
            if (!(packet instanceof class_2708) && !(packet instanceof class_2661)) {
               if (this.flushOnVelocity.getValue()) {
                  label131: {
                     label128: {
                        if (packet instanceof class_2743) {
                           class_2743 velocityUpdate = (class_2743)packet;
                           if (velocityUpdate.method_11818() == mc.field_1724.method_5628()) {
                              break label128;
                           }
                        }

                        if (!(packet instanceof class_2664)) {
                           break label131;
                        }

                        class_2664 explosionPacket = (class_2664)packet;
                        if (((class_243)explosionPacket.comp_2884().get()).field_1352 == 0.0D || ((class_243)explosionPacket.comp_2884().get()).field_1351 == 0.0D || ((class_243)explosionPacket.comp_2884().get()).field_1350 == 0.0D) {
                           break label131;
                        }
                     }

                     this.resetModule(true);
                     this.waitTimer.reset();
                     return;
                  }
               }

               if (!(packet instanceof class_2797) && !(packet instanceof class_7439) && !(packet instanceof class_7472) && !(packet instanceof class_2767) && !(packet instanceof class_2749)) {
                  if (this.target != null && this.target.method_5805()) {
                     boolean isEntityPosition = packet instanceof class_2777 && ((class_2777)packet).comp_3237() == this.target.method_5628();
                     boolean isEntityPositionSync = packet instanceof class_10264 && ((class_10264)packet).comp_3223() == this.target.method_5628();
                     boolean isEntityS2C = packet instanceof class_2684 && ((class_2684)packet).method_11645(mc.field_1687) == this.target;
                     boolean isRelevant = isEntityS2C || isEntityPosition || isEntityPositionSync;
                     if (isRelevant) {
                        class_243 newPos = new class_243(0.0D, 0.0D, 0.0D);
                        if (packet instanceof class_2684) {
                           newPos = this.position.method_43489((long)((class_2684)packet).method_36150(), (long)((class_2684)packet).method_36151(), (long)((class_2684)packet).method_36152());
                        } else if (packet instanceof class_2777) {
                           class_243 pos = ((class_2777)packet).comp_3238().comp_3148();
                           newPos = new class_243(pos.method_10216(), pos.method_10214(), pos.method_10215());
                        } else if (packet instanceof class_10264) {
                           class_10264 syncS2CPacket = (class_10264)packet;
                           newPos = syncS2CPacket.comp_3224().comp_3148();
                        }

                        if (Objects.equals(newPos, new class_243(0.0D, 0.0D, 0.0D))) {
                           return;
                        }

                        this.position.method_43494(newPos);
                        this.currentPosition = newPos;
                        if ((double)mc.field_1724.method_5739(this.target) > newPos.method_1022(mc.field_1724.method_19538())) {
                           this.processPacketQueue(true);
                           return;
                        }
                     }
                  }

                  event.cancel();
                  this.packetQueue.add(new Backtrack.PacketData(packet, System.currentTimeMillis()));
               }
            } else {
               this.resetModule(true);
               this.waitTimer.reset();
            }
         }
      }
   }

   @RegisterEvent
   private void tickListener(TickEvent event) {
      if (event.getMode() == TickEvent.Mode.PRE) {
         if (mc.field_1687 != null && mc.field_1724 != null) {
            if (this.target != null && this.target.method_5805() && this.target != null && this.isEntityInRange(this.target)) {
               this.processPacketQueue(false);
            } else {
               this.resetModule(true);
            }

         } else {
            this.resetModule(false);
         }
      }
   }

   @RegisterEvent
   private void attackListener(AttackEvent event) {
      if (event.getMode() == AttackEvent.Mode.PRE) {
         class_1297 enemy = event.getTarget();
         if (enemy instanceof class_1657 && this.isEntityInRange(enemy)) {
            if (enemy != this.target) {
               this.oldPlayerPosition = new class_243(0.0D, 0.0D, 0.0D);
               this.currentPosition = new class_243(0.0D, 0.0D, 0.0D);
               this.resetModule(true);
               this.position = new class_7422();
               this.position.method_43494(enemy.method_43389().method_60933());
            }

            this.target = enemy;
         }
      }
   }

   @RegisterEvent
   private void Render3DEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && this.currentPosition.field_1351 != 0.0D) {
         double lerpSpeed = Math.min(this.oldPlayerPosition.method_1022(this.currentPosition) * 0.1D, (double)event.getTickDelta());
         lerpSpeed = Math.min(lerpSpeed, this.oldPlayerPosition.method_1022(this.currentPosition) * 0.01D);
         this.oldPlayerPosition = this.oldPlayerPosition.method_35590(this.currentPosition, lerpSpeed);
         if (this.target != null) {
            Render3DEngine.renderOutlinedShadedBox(this.oldPlayerPosition, new Color(255, 255, 255), 50, event.getMatrices(), this.target.method_17681() / 2.0F, this.target.method_17682());
         }
      }
   }

   protected void onModuleEnabled() {
      this.resetModule(false);
      this.currentDelay = 100.0F;
   }

   protected void onModuleDisabled() {
      this.resetModule(true);
      this.oldPlayerPosition = new class_243(0.0D, 0.0D, 0.0D);
      this.currentPosition = new class_243(0.0D, 0.0D, 0.0D);
   }

   private void processPacketQueue(boolean force) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.method_1562() != null) {
         this.packetQueue.removeIf((data) -> {
            String var3 = this.delayType.getValue();
            byte var4 = -1;
            switch(var3.hashCode()) {
            case -1808614770:
               if (var3.equals("Static")) {
                  var4 = 0;
               }
               break;
            case -505546721:
               if (var3.equals("Dynamic")) {
                  var4 = 1;
               }
            }

            switch(var4) {
            case 0:
               this.currentDelay = this.latency.getRandomValue().floatValue();
               break;
            case 1:
               if (this.target != null) {
                  this.currentDelay = class_3532.method_15363(mc.field_1724.method_5739(this.target) * 200.0F, (float)(Integer)this.latency.getValueMin(), (float)(Integer)this.latency.getValueMax());
               }
            }

            if (!force && !((float)(System.currentTimeMillis() - data.timestamp) >= this.currentDelay)) {
               return false;
            } else {
               mc.execute(() -> {
                  try {
                     if (mc.method_1562() != null) {
                        data.packet.method_65081(mc.method_1562());
                     }
                  } catch (Exception var2) {
                     var2.printStackTrace();
                  }

               });
               return true;
            }
         });
      }
   }

   private void resetModule(boolean handlePackets) {
      if (handlePackets) {
         this.processPacketQueue(true);
      } else {
         this.packetQueue.clear();
      }

      this.target = null;
      this.position = null;
   }

   private boolean isEntityInRange(class_1297 entity) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         double distance = (double)mc.field_1724.method_5739(entity);
         return distance >= (double)(Float)this.range.getValueMin() && distance <= (double)(Float)this.range.getValueMax();
      } else {
         return false;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class PacketData {
      final class_2596<?> packet;
      final long timestamp;

      PacketData(class_2596<?> packet, long timestamp) {
         this.packet = packet;
         this.timestamp = timestamp;
      }
   }
}
