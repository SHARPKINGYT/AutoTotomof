package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.SimulatedPlayer;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.network.PacketSendEvent;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2848;
import net.minecraft.class_5134;
import net.minecraft.class_2828.class_2829;
import net.minecraft.class_2848.class_2849;

@ModuleInfo(
   name = "Criticals",
   description = "Always Deal Critical Hits",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class Criticals extends BaseModule implements QuickImports {
   private final ModeSetting mode = new ModeSetting("Mode", "Choose Mode", "Legit", new String[]{"Legit", "Packet", "Blatant"});
   private class_2824 packet = null;
   private class_1657 lastEnemy = null;

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      this.setSuffix(this.mode.getValue());
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (!event.getMode().equals(TickEvent.Mode.POST)) {
            boolean hasAttackingEnemy = mc.field_1724.method_6052() != null && mc.field_1724.method_6052() instanceof class_1657;
            if (hasAttackingEnemy) {
               this.lastEnemy = (class_1657)mc.field_1724.method_6052();
            }

            if (this.lastEnemy != null && (!this.lastEnemy.method_36608() || this.lastEnemy.method_29504() || this.lastEnemy.method_7325() || this.lastEnemy.method_5739(mc.field_1724) > 6.5F || mc.field_1724.field_6012 - mc.field_1724.method_6083() > 25)) {
               this.lastEnemy = null;
            }

            if (SocialManager.getTarget() != null) {
               this.lastEnemy = SocialManager.getTarget();
            }

            String var3 = this.mode.getValue();
            byte var4 = -1;
            switch(var3.hashCode()) {
            case 73298841:
               if (var3.equals("Legit")) {
                  var4 = 0;
               }
            }

            switch(var4) {
            case 0:
               if (this.lastEnemy != null) {
                  SimulatedPlayer simulator = new SimulatedPlayer(mc.field_1724);
                  simulator.setInput(mc.field_1690.field_1894.method_1434(), mc.field_1690.field_1881.method_1434(), mc.field_1690.field_1913.method_1434(), mc.field_1690.field_1849.method_1434(), true, false);

                  for(int i = 0; i <= 11 - Math.round(mc.field_1724.method_7261((float)mc.field_1724.method_45325(class_5134.field_23723)) * 10.0F); ++i) {
                     simulator.tick();
                  }

                  if (simulator.getFallDistance() != 0.0F && (double)simulator.getFallDistance() < 0.75D && mc.field_1724.method_24828()) {
                     InputUtils.simulateKeyPress(mc.field_1690.field_1903, 35);
                  }
               }
            default:
            }
         }
      }
   }

   @RegisterEvent
   private void AttackEventListener(AttackEvent event) {
      if (!event.getMode().equals(AttackEvent.Mode.POST)) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            class_1297 entity = event.getTarget();
            if (!this.canDealCriticals()) {
               if (entity != null) {
                  String var3 = this.mode.getValue();
                  byte var4 = -1;
                  switch(var3.hashCode()) {
                  case -1911998296:
                     if (var3.equals("Packet")) {
                        var4 = 0;
                     }
                     break;
                  case 1630783146:
                     if (var3.equals("Blatant")) {
                        var4 = 1;
                     }
                  }

                  switch(var4) {
                  case 0:
                  case 1:
                     if (entity instanceof class_1309) {
                        mc.field_1724.field_3944.method_52787(new class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.0625D, mc.field_1724.method_23321(), false, false));
                        mc.field_1724.field_3944.method_52787(new class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), false, false));
                     }
                  default:
                  }
               }
            }
         }
      }
   }

   @RegisterEvent
   private void packetSendEventListener(PacketSendEvent event) {
      if (event.getMode() != PacketSendEvent.Mode.POST) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            if (!this.canDealCriticals()) {
               if (this.mode.getValue().equals("Blatant")) {
                  class_2596 var3 = event.getPacket();
                  if (var3 instanceof class_2848) {
                     class_2848 packet = (class_2848)var3;
                     if (packet.method_12365() == class_2849.field_12981) {
                        event.setCancelled(true);
                     }
                  }
               }

            }
         }
      }
   }

   public boolean canDealCriticals() {
      return mc.field_1724 != null && !mc.field_1724.method_24828() && !mc.field_1724.method_5869() && !mc.field_1724.method_5771() && !mc.field_1724.method_6101();
   }

   public double predictedMotion(double motion, int ticks) {
      if (ticks == 0) {
         return motion;
      } else {
         double predicted = motion;

         for(int i = 0; i < ticks; ++i) {
            predicted = (predicted - 0.08D) * 0.9800000190734863D;
         }

         return predicted;
      }
   }

   public Criticals() {
      this.getSettingRepository().registerSettings(this.mode);
   }
}
