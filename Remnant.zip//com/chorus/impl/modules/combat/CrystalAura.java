package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.math.rotation.RotationUtils;
import com.chorus.common.util.player.DamageUtils;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "CrystalAura",
   description = "CrystalAura",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class CrystalAura extends BaseModule implements QuickImports {
   private final SettingCategory conditionSetting = new SettingCategory("Condition Settings");
   private final SettingCategory placeSetting = new SettingCategory("Placing Settings");
   private final SettingCategory breakSetting = new SettingCategory("Breaking Settings");
   private final SettingCategory otherSetting = new SettingCategory("Other Settings");
   private final MultiSetting actions;
   private final BooleanSetting onRightClick;
   private final BooleanSetting pauseOnKill;
   private final BooleanSetting damageTick;
   private final ModeSetting placeMode;
   private final RangeSetting<Integer> placeDelay;
   private final ModeSetting breakMode;
   private final RangeSetting<Integer> breakDelay;
   private final NumberSetting<Integer> failChance;
   private final ModeSetting scanType;
   private final NumberSetting<Double> expansion;
   private final NumberSetting<Double> maxDamage;
   private final BooleanSetting preventPlace;
   private final TimerUtils placeTimer;
   private final TimerUtils breakTimer;
   int lastAttackTime;

   public CrystalAura() {
      this.actions = new MultiSetting(this.conditionSetting, "Actions", "Decide what autocrystal does", new String[]{"Place", "Break"});
      this.onRightClick = new BooleanSetting(this.conditionSetting, "On Right Click", "Activate Crystal Only Right Click", true);
      this.pauseOnKill = new BooleanSetting(this.conditionSetting, "Pause On Kill", "Pause On Enemy Death", true);
      this.damageTick = new BooleanSetting(this.conditionSetting, "Damage Tick", "Time Crystal Explosions To Hurt-Time", true);
      this.placeMode = new ModeSetting(this.placeSetting, "Place Input", "Select Place Input", "Click", new String[]{"Click", "Packet"});
      this.placeDelay = new RangeSetting(this.placeSetting, "Place Delay", "Delay it uses to Place crystals", 0, 250, 50, 50);
      this.breakMode = new ModeSetting(this.breakSetting, "Break Input", "Select Break Input", "Click", new String[]{"Click", "Packet"});
      this.breakDelay = new RangeSetting(this.breakSetting, "Break Delay", "Delay it uses to break crystals", 0, 250, 50, 50);
      this.failChance = new NumberSetting(this.breakSetting, "Fail Chance", "Chance To Fail Breaking Crystal", 10, 0, 100);
      this.scanType = new ModeSetting(this.breakSetting, "Scan Type", "Select Method To Scan For Crystals", "Raytrace", new String[]{"Raytrace", "Expanded Raytrace"});
      this.expansion = new NumberSetting(this.breakSetting, "Expansion", "Expansion For Expanded Raytrace Scan Type", 0.0D, 0.0D, 1.0D);
      this.maxDamage = new NumberSetting(this.breakSetting, "Max Self Damage", "Max Self Damage", 10.0D, 0.0D, 20.0D);
      this.preventPlace = new BooleanSetting(this.otherSetting, "Prevent Minecraft Place", "Allows only the client to place crystals", true);
      this.placeTimer = new TimerUtils();
      this.breakTimer = new TimerUtils();
      this.lastAttackTime = 0;
      this.getSettingRepository().registerSettings(this.conditionSetting, this.placeSetting, this.breakSetting, this.otherSetting, this.actions, this.onRightClick, this.pauseOnKill, this.damageTick, this.placeMode, this.placeDelay, this.breakMode, this.breakDelay, this.failChance, this.scanType, this.expansion, this.maxDamage, this.preventPlace);
      this.placeSetting.setRenderCondition(() -> {
         return this.actions.getSpecificValue("Place");
      });
      this.breakSetting.setRenderCondition(() -> {
         return this.actions.getSpecificValue("Break");
      });
   }

   @RegisterEvent
   private void Render3DEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null && mc.method_1569()) {
         if (!this.pauseOnKill.getValue() || !mc.field_1687.method_18456().stream().anyMatch((player) -> {
            return player != mc.field_1724 && !player.method_5805() && player.method_5858(mc.field_1724) < 36.0D;
         })) {
            if (mc.field_1724.method_6047().method_7909() == class_1802.field_8301) {
               if (this.lastAttackTime < 0) {
                  this.lastAttackTime = mc.field_1724.field_6012;
               }

               if (this.breakTimer.hasReached(50.0D)) {
                  if (SocialManager.getTarget() != null) {
                     class_243 bestPoint = this.findPlacePoints(3, event.getMatrices(), SocialManager.getTarget());
                     if (bestPoint != null) {
                        Render3DEngine.renderShadedBox(bestPoint, Color.GREEN, 50, event.getMatrices(), 0.5F, 1.0F);
                        float[] rots = RotationUtils.calculate(bestPoint.method_1031(0.0D, 1.0D, 0.0D), bestPoint);
                        class_3965 hitResult = RotationUtils.rayTrace(rots[0], rots[1], 6.0F);
                        if (this.placeTimer.hasReached(50.0D) && hitResult != null) {
                           this.placeTimer.reset();
                           mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(bestPoint, class_2350.field_11036, class_2338.method_49638(bestPoint), true));
                        }

                        if (this.findCrystal(3.0D, SocialManager.getTarget()) != null) {
                           mc.field_1761.method_2918(mc.field_1724, this.findCrystal(3.0D, SocialManager.getTarget()));
                           mc.field_1724.method_6104(class_1268.field_5808);
                           this.breakTimer.reset();
                        }

                     }
                  }
               }
            }
         }
      }
   }

   public class_243 findPlacePoints(int offset, class_4587 matrices, class_1657 player) {
      class_243 bestPoint = null;
      float currentDamage = -1.0F;

      for(float x = (float)(-offset); x <= (float)offset; ++x) {
         for(float y = (float)(-offset); y <= (float)offset; ++y) {
            for(float z = (float)(-offset); z <= (float)offset; ++z) {
               class_243 point = new class_243((double)((float)player.method_24515().method_10263() + x) + 0.5D, (double)((float)player.method_24515().method_10264() + y), (double)((float)player.method_24515().method_10260() + z) + 0.5D);
               class_2680 blockState = mc.field_1687.method_8320(class_2338.method_49638(point));
               class_2680 aboveBlock = mc.field_1687.method_8320(class_2338.method_49638(point).method_10084());
               if (blockState.method_26204().equals(class_2246.field_10540) || blockState.method_26204().equals(class_2246.field_9987)) {
                  class_243 up = point.method_1031(0.0D, 1.0D, 0.0D);
                  if (!player.method_5829().method_1003(up.field_1352 - 0.5D, up.field_1351 - 0.5D, up.field_1350 - 0.5D, up.field_1352 + 0.5D, up.field_1351 + 0.5D, up.field_1350 + 0.5D) && aboveBlock.method_26215()) {
                     Render3DEngine.renderShadedBox(point, Color.WHITE, 50, matrices, 0.5F, 1.0F);
                     if (DamageUtils.calculateCrystalDamage(player, class_2338.method_49638(point).method_10084().method_46558()) > currentDamage) {
                        currentDamage = DamageUtils.calculateCrystalDamage(player, class_2338.method_49638(point).method_10084().method_46558());
                        bestPoint = point;
                     }
                  }
               }
            }
         }
      }

      return bestPoint;
   }

   public void handlePlace(class_3965 blockHitResult) {
      if (this.placeTimer.hasReached((double)this.placeDelay.getRandomValue().floatValue())) {
         if (blockHitResult.method_17777().method_19769(mc.field_1724.method_19538(), 4.0D)) {
            mc.method_1562().method_52787(new class_2885(class_1268.field_5808, blockHitResult, 0));
            mc.field_1724.method_6104(mc.field_1724.method_6058());
            this.placeTimer.reset();
            if (this.preventPlace.getValue()) {
               mc.field_1690.field_1904.method_23481(false);
            }

         }
      }
   }

   public void handleBreak(class_1297 entity) {
      if (this.breakTimer.hasReached((double)this.breakDelay.getRandomValue().floatValue())) {
         if (!((double)DamageUtils.calculateCrystalDamage(mc.field_1724, entity.method_19538()) > (Double)this.maxDamage.getValue())) {
            mc.field_1761.method_2918(mc.field_1724, entity);
            mc.field_1724.method_6104(class_1268.field_5808);
         }
      }
   }

   private class_1297 findCrystal(double range, class_1657 player) {
      class_243 cameraPos = mc.field_1773.method_19418().method_19326();
      class_243 viewVector = mc.field_1724.method_5663();
      cameraPos.method_1031(viewVector.field_1352 * range, viewVector.field_1351 * range, viewVector.field_1350 * range);
      Iterator var7 = mc.field_1687.method_18112().iterator();

      class_1297 entity;
      do {
         if (!var7.hasNext()) {
            return null;
         }

         entity = (class_1297)var7.next();
      } while(!(entity instanceof class_1511) || !((double)player.method_5739(entity) <= range));

      return entity;
   }
}
