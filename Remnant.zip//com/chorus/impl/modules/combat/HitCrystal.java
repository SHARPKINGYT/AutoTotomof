package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

@ModuleInfo(
   name = "Hit Crystal",
   description = "Automatically Hit Crystals For You",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class HitCrystal extends BaseModule implements QuickImports {
   private final SettingCategory delays = new SettingCategory("Delays");
   private final SettingCategory behavior = new SettingCategory("Behavior");
   private final NumberSetting<Integer> obsidianSwitchDelay;
   private final NumberSetting<Integer> obsidianPlaceDelay;
   private final NumberSetting<Integer> crystalSwitchDelay;
   private final NumberSetting<Integer> crystalPlaceDelay;
   private final MultiSetting whileHolding;
   private final TimerUtils obsidianPlace;
   private final TimerUtils obsidianSwitch;
   private final TimerUtils crystalPlace;
   private final TimerUtils crystalSwitch;
   private int stage;

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (!InputUtils.mouseDown(1)) {
            this.resetStages();
         } else {
            class_239 hitResult = mc.field_1765;
            if (hitResult instanceof class_3965) {
               class_3965 blockHitResult = (class_3965)hitResult;
               if (mc.field_1687.method_8320(blockHitResult.method_17777()).method_26215()) {
                  return;
               }

               if (this.whileHolding.getSpecificValue("Sword") && InventoryUtils.getMainHandItem().method_7909() instanceof class_1829) {
                  this.stage = 1;
               }

               if (this.whileHolding.getSpecificValue("Totem") && InventoryUtils.getMainHandItem().method_7909() == class_1802.field_8288) {
                  this.stage = 1;
               }

               if (this.isLookingAtCrystal()) {
                  return;
               }

               if (mc.field_1687.method_8320(blockHitResult.method_17777()).method_26204() == class_2246.field_10540) {
                  this.handleExistingObsidian(blockHitResult);
               } else {
                  this.handleNewPlacement(blockHitResult);
               }
            } else {
               this.resetStages();
            }

         }
      }
   }

   private boolean isLookingAtCrystal() {
      class_239 var2 = mc.field_1765;
      if (var2 instanceof class_3966) {
         class_3966 entityHitResult = (class_3966)var2;
         class_1297 targetEntity = entityHitResult.method_17782();
         return targetEntity instanceof class_1511;
      } else {
         return false;
      }
   }

   private void handleExistingObsidian(class_3965 blockHitResult) {
      if (this.stage < 3 && this.stage != 0) {
         this.stage = 3;
      }

      if (this.crystalSwitch.hasReached((double)(Integer)this.crystalSwitchDelay.getValue()) && this.stage == 3) {
         this.crystalSwitch.reset();
         this.crystalPlace.reset();
         InventoryUtils.swap(class_1802.field_8301);
         this.stage = 4;
      }

      if (this.crystalPlace.hasReached((double)(Integer)this.crystalPlaceDelay.getValue()) && this.stage == 4) {
         this.crystalPlace.reset();
         InputUtils.simulateClick(1);
         InputUtils.simulateRelease(1);
         this.stage = 0;
      }

   }

   private void handleNewPlacement(class_3965 blockHitResult) {
      if (this.obsidianSwitch.hasReached((double)(Integer)this.obsidianSwitchDelay.getValue()) && this.stage == 1) {
         this.obsidianSwitch.reset();
         this.obsidianPlace.reset();
         InventoryUtils.swap(class_1802.field_8281);
         this.stage = 2;
      }

      if (this.obsidianPlace.hasReached((double)(Integer)this.obsidianPlaceDelay.getValue()) && this.stage == 2) {
         this.obsidianPlace.reset();
         this.crystalPlace.reset();
         InputUtils.simulateClick(1);
         InputUtils.simulateRelease(1);
         this.stage = 3;
      }

   }

   private void resetStages() {
      this.stage = 0;
      this.obsidianSwitch.reset();
      this.obsidianPlace.reset();
      this.crystalSwitch.reset();
      this.crystalPlace.reset();
   }

   public HitCrystal() {
      this.obsidianSwitchDelay = new NumberSetting(this.delays, "Obsidian Swap Delay (ms)", "w", 5, 0, 250);
      this.obsidianPlaceDelay = new NumberSetting(this.delays, "Obsidian Place Delay (ms)", "w", 25, 0, 250);
      this.crystalSwitchDelay = new NumberSetting(this.delays, "Crystal Swap Delay (ms)", " w", 5, 0, 250);
      this.crystalPlaceDelay = new NumberSetting(this.delays, "Crystal Place Delay (ms)", " w", 5, 0, 250);
      this.whileHolding = new MultiSetting(this.behavior, "While Holding", "Activate When Holding... Item", new String[]{"Sword", "Totem"});
      this.obsidianPlace = new TimerUtils();
      this.obsidianSwitch = new TimerUtils();
      this.crystalPlace = new TimerUtils();
      this.crystalSwitch = new TimerUtils();
      this.stage = 0;
      this.getSettingRepository().registerSettings(this.delays, this.behavior, this.obsidianSwitchDelay, this.obsidianPlaceDelay, this.crystalSwitchDelay, this.crystalPlaceDelay, this.whileHolding);
   }
}
