package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.network.PacketReceiveEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_2596;
import net.minecraft.class_2708;

@ModuleInfo(
   name = "HitSelection",
   description = "Selects Hits",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class HitSelection extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("Distances");
   private final SettingCategory conditions = new SettingCategory("Conditions");
   private final BooleanSetting criticalSpam;
   private final RangeSetting<Double> selectRange;
   private final NumberSetting<Double> hitRange;
   boolean spaced;
   class_1657 player;

   public HitSelection() {
      this.criticalSpam = new BooleanSetting(this.conditions, "Stop On Jump", "Prevents While Jumping to allow Crit-Spamming", true);
      this.selectRange = new RangeSetting(this.general, "Select Distance", "Range To Start Selecting", 0.0D, 6.0D, 2.0D, 3.5D);
      this.hitRange = new NumberSetting(this.general, "Hit Distance", "Distance To Move To", 2.85D, 0.0D, 6.0D);
      this.spaced = false;
      this.player = null;
      this.getSettingRepository().registerSettings(this.general, this.conditions, this.selectRange, this.hitRange, this.criticalSpam);
   }

   @RegisterEvent
   private void PacketReceiveEventListener(PacketReceiveEvent event) {
      if (event.getMode().equals(PacketReceiveEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_2708) {
            class_2708 packet = (class_2708)var3;
            this.player = null;
         }
      }

   }

   @RegisterEvent
   private void tickEventEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if (mc.field_1724.method_6052() instanceof class_1657 && mc.field_1724.method_6052() != null && mc.field_1724.field_6279 == 1) {
            if (mc.field_1724.field_6012 - mc.field_1724.method_6083() > 5) {
               return;
            }

            if (mc.field_1724.method_18798().field_1351 > 0.0D) {
               return;
            }

            this.player = (class_1657)mc.field_1724.method_6052();
            this.spaced = true;
            if (this.player == null) {
               return;
            }

            if (!SocialManager.isEnemy(this.player)) {
               return;
            }

            if (this.player.method_29504() || this.player.method_56992() || this.player.method_7325() || this.player.method_5655()) {
               this.player = null;
               return;
            }

            if ((double)this.player.method_5739(mc.field_1724) >= (Double)this.selectRange.getValueMin() && (double)this.player.method_5739(mc.field_1724) <= (Double)this.selectRange.getValueMax() && (!this.criticalSpam.getValue() || !mc.field_1690.field_1903.method_1434())) {
               this.spaced = true;
               mc.field_1690.field_1894.method_23481(false);
               mc.field_1690.field_1881.method_23481(true);
            }
         }

         if (this.spaced) {
            if (this.player != null) {
               if (this.player.method_5739(mc.field_1724) > 12.0F) {
                  this.player = null;
                  return;
               }

               if ((double)this.player.method_5739(mc.field_1724) >= (Double)this.hitRange.getValue()) {
                  this.spaced = false;
                  mc.field_1690.field_1894.method_23481(InputUtils.keyDown(mc.field_1690.field_1894.method_1429().method_1444()));
                  mc.field_1690.field_1881.method_23481(false);
               }
            } else {
               this.spaced = false;
               mc.field_1690.field_1894.method_23481(InputUtils.keyDown(mc.field_1690.field_1894.method_1429().method_1444()));
               mc.field_1690.field_1881.method_23481(!mc.field_1690.field_1881.method_1434());
            }
         }
      }

   }
}
