package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.rotation.RotationComponent;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.misc.EntityHitboxEvent;
import com.chorus.impl.events.player.SwingEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

@ModuleInfo(
   name = "Hitboxes",
   description = "Expands Enemies Hit-boxes",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class Hitboxes extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final ModeSetting mode;
   private final NumberSetting<Double> expandAmount;
   int go;

   @RegisterEvent
   private void eventEntityHitboxEventListener(EntityHitboxEvent event) {
      if (event.getEntity() != null && mc.field_1724 != null && event.getEntity().method_5628() != mc.field_1724.method_5628()) {
         class_238 expandedBox = event.getBox().method_1009((Double)this.expandAmount.getValue(), 0.0D, (Double)this.expandAmount.getValue());
         if (this.mode.getValue().equals("Blatant")) {
            event.setBox(expandedBox);
         }

      }
   }

   @RegisterEvent
   private void SwingEventListener(SwingEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null && mc.field_1755 == null) {
         if (event.getMode().equals(SwingEvent.Mode.PRE) && this.raytrace() != null && mc.field_1765 instanceof class_3965) {
            this.go = 0;
            event.setCancelled(true);
         }

      }
   }

   @RegisterEvent
   private void Render3DEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null && mc.field_1755 == null) {
         if (event.getMode().equals(Render3DEvent.Mode.PRE) && this.raytrace() != null && this.go < 50) {
            class_239 var3 = mc.field_1765;
            if (var3 instanceof class_3966) {
               class_3966 entityHitResult = (class_3966)var3;
               class_1297 var4 = entityHitResult.method_17782();
               if (var4 instanceof class_1309) {
                  class_1309 livingEntity = (class_1309)var4;
                  if (livingEntity == this.raytrace()) {
                     this.go = 150;
                     InputUtils.simulateClick(0, 35);
                  }
               }
            }

            rotationComponent.setMultiPoint(1.0F);
            rotationComponent.setSilentRotation(true);
            rotationComponent.setHorizontalSpeed(100.0F);
            rotationComponent.setVerticalSpeed(100.0F);
            ++this.go;
            rotationComponent.queueRotation(this.raytrace(), RotationComponent.RotationPriority.HIGH, RotationComponent.AimType.BLATANT, RotationComponent.EntityPoints.STRAIGHT);
         }

      }
   }

   private class_1309 raytrace() {
      class_243 cameraPos = mc.field_1773.method_19418().method_19326();
      class_243 viewVector = mc.field_1724.method_5663();
      class_243 extendedPoint = cameraPos.method_1031(viewVector.field_1352 * 3.0D, viewVector.field_1351 * 3.0D, viewVector.field_1350 * 3.0D);
      class_1297 closestEntity = null;
      double closestDistance = Double.MAX_VALUE;
      Iterator var7 = mc.field_1687.method_18112().iterator();

      while(var7.hasNext()) {
         class_1297 entity = (class_1297)var7.next();
         if (entity instanceof class_1657 && entity != mc.field_1724 && entity.method_5829().method_1014((Double)this.expandAmount.getValue()).method_993(cameraPos, extendedPoint)) {
            double distance = cameraPos.method_1022(entity.method_19538());
            if (distance < closestDistance) {
               closestDistance = distance;
               closestEntity = entity;
            }
         }
      }

      return (class_1309)closestEntity;
   }

   public Hitboxes() {
      this.mode = new ModeSetting(this.general, "Expand Mode", "Select the expand mode", "Blatant", new String[]{"Blatant", "Legit"});
      this.expandAmount = new NumberSetting(this.general, "Expand Amount", "how big", 0.1D, 0.0D, 1.0D);
      this.go = 150;
      this.getSettingRepository().registerSettings(this.general, this.mode, this.expandAmount);
   }
}
