package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.rotation.RotationComponent;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.player.ReachEvent;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1829;
import net.minecraft.class_239;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_5134;

@ModuleInfo(
   name = "KillAura",
   description = "Attacks Enemies Within Range",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class KillAura extends BaseModule implements QuickImports {
   private final SettingCategory aimingCategory = new SettingCategory("Aiming");
   private final SettingCategory targetingCategory = new SettingCategory("Targeting");
   private final SettingCategory behaviorCategory = new SettingCategory("Behavior");
   private final ModeSetting aimMath;
   private final ModeSetting aimVector;
   private final RangeSetting<Double> horizontalSpeed;
   private final RangeSetting<Double> verticalSpeed;
   private final NumberSetting<Double> range;
   private final MultiSetting conditions;
   private final ModeSetting targetSorting;

   @RegisterEvent
   private void render3DEventEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
            class_1309 target = (class_1309)toList(mc.field_1687.method_18112()).stream().filter((entity) -> {
               if (entity == mc.field_1724) {
                  return false;
               } else if ((double)mc.field_1724.method_5739(entity) >= (Double)this.range.getValue()) {
                  return false;
               } else if (!(entity instanceof class_1309)) {
                  return false;
               } else if (entity.method_31747() && SocialManager.isTargetedPlayer((class_1657)entity) != entity) {
                  return false;
               } else {
                  return !(entity instanceof class_1531);
               }
            }).min(Comparator.comparingDouble((entity) -> {
               String var2 = this.targetSorting.getValue();
               byte var3 = -1;
               switch(var2.hashCode()) {
               case -2137395588:
                  if (var2.equals("Health")) {
                     var3 = 2;
                  }
                  break;
               case 24343454:
                  if (var2.equals("Rotation")) {
                     var3 = 3;
                  }
                  break;
               case 353103893:
                  if (var2.equals("Distance")) {
                     var3 = 1;
                  }
                  break;
               case 765499292:
                  if (var2.equals("HurtTime")) {
                     var3 = 0;
                  }
               }

               double var10000;
               switch(var3) {
               case 0:
                  var10000 = (double)((class_1309)entity).field_6235;
                  break;
               case 1:
                  var10000 = (double)mc.field_1724.method_5739(entity);
                  break;
               case 2:
                  var10000 = (double)((class_1309)entity).method_6032();
                  break;
               case 3:
                  var10000 = (double)Math.abs(class_3532.method_15393((float)MathUtils.toDegrees(Math.atan2(entity.method_33571().method_1020(mc.field_1724.method_33571()).field_1350, entity.method_33571().method_1020(mc.field_1724.method_33571()).field_1352)) - 90.0F) - mc.field_1724.method_36454());
                  break;
               default:
                  throw new IllegalStateException("Unexpected value: " + this.targetSorting.getValue());
               }

               return var10000;
            })).orElse((Object)null);
            rotationComponent.setMultiPoint(0.5F);
            rotationComponent.setSilentRotation(true);
            rotationComponent.setHorizontalSpeed(this.horizontalSpeed.getRandomValue().floatValue());
            rotationComponent.setVerticalSpeed(this.verticalSpeed.getRandomValue().floatValue());
            if (target != null && !this.checkConditions()) {
               rotationComponent.queueRotation(target, RotationComponent.RotationPriority.HIGH, this.getAimMath(), this.getAimVecMode());
            }
         }

         this.setSuffix(this.aimMath.getValue());
      }
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         if (event.getMode().equals(TickEvent.Mode.PRE)) {
            class_1309 target = (class_1309)toList(mc.field_1687.method_18112()).stream().filter((entity) -> {
               if (entity == mc.field_1724) {
                  return false;
               } else if ((double)mc.field_1724.method_5739(entity) >= (Double)this.range.getValue()) {
                  return false;
               } else if (!(entity instanceof class_1309)) {
                  return false;
               } else if (entity.method_31747() && SocialManager.isTargetedPlayer((class_1657)entity) != entity) {
                  return false;
               } else {
                  return !(entity instanceof class_1531);
               }
            }).min(Comparator.comparingDouble((entity) -> {
               String var2 = this.targetSorting.getValue();
               byte var3 = -1;
               switch(var2.hashCode()) {
               case -2137395588:
                  if (var2.equals("Health")) {
                     var3 = 2;
                  }
                  break;
               case 24343454:
                  if (var2.equals("Rotation")) {
                     var3 = 3;
                  }
                  break;
               case 353103893:
                  if (var2.equals("Distance")) {
                     var3 = 1;
                  }
                  break;
               case 765499292:
                  if (var2.equals("HurtTime")) {
                     var3 = 0;
                  }
               }

               double var10000;
               switch(var3) {
               case 0:
                  var10000 = (double)((class_1309)entity).field_6235;
                  break;
               case 1:
                  var10000 = (double)mc.field_1724.method_5739(entity);
                  break;
               case 2:
                  var10000 = (double)((class_1309)entity).method_6032();
                  break;
               case 3:
                  var10000 = (double)Math.abs(class_3532.method_15393((float)MathUtils.toDegrees(Math.atan2(entity.method_33571().method_1020(mc.field_1724.method_33571()).field_1350, entity.method_33571().method_1020(mc.field_1724.method_33571()).field_1352)) - 90.0F) - mc.field_1724.method_36454());
                  break;
               default:
                  throw new IllegalStateException("Unexpected value: " + this.targetSorting.getValue());
               }

               return var10000;
            })).orElse((Object)null);
            if (target != null && !this.checkConditions()) {
               if ((double)mc.field_1724.method_7261((float)mc.field_1724.method_45325(class_5134.field_23723)) < 0.93D) {
                  return;
               }

               class_239 var4 = mc.field_1765;
               if (var4 instanceof class_3966) {
                  class_3966 result = (class_3966)var4;
                  if (result.method_17782() == target) {
                     InputUtils.simulateClick(0, 35);
                  }
               }
            }
         }

      }
   }

   @RegisterEvent
   private void ReachEventListener(ReachEvent event) {
      event.setDistance((Double)this.range.getValue());
   }

   public static <T> List<T> toList(Iterable<T> it) {
      return (List)(it == null ? List.of() : new ArrayList<T>() {
         {
            it.forEach(this::add);
         }
      });
   }

   private RotationComponent.AimType getAimMath() {
      String var1 = this.aimMath.getValue();
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -2018804923:
         if (var1.equals("Linear")) {
            var2 = 2;
         }
         break;
      case -1543850116:
         if (var1.equals("Regular")) {
            var2 = 0;
         }
         break;
      case -1241367914:
         if (var1.equals("Adaptive")) {
            var2 = 1;
         }
         break;
      case 1630783146:
         if (var1.equals("Blatant")) {
            var2 = 3;
         }
      }

      RotationComponent.AimType var10000;
      switch(var2) {
      case 0:
         var10000 = RotationComponent.AimType.REGULAR;
         break;
      case 1:
         var10000 = RotationComponent.AimType.ADAPTIVE;
         break;
      case 2:
         var10000 = RotationComponent.AimType.LINEAR;
         break;
      case 3:
         var10000 = RotationComponent.AimType.BLATANT;
         break;
      default:
         var10000 = RotationComponent.AimType.REGULAR;
      }

      return var10000;
   }

   private RotationComponent.EntityPoints getAimVecMode() {
      String var1 = this.aimVector.getValue();
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -1854418717:
         if (var1.equals("Random")) {
            var2 = 2;
         }
         break;
      case -1763776967:
         if (var1.equals("Closest")) {
            var2 = 1;
         }
         break;
      case 1852116762:
         if (var1.equals("Straight")) {
            var2 = 0;
         }
      }

      RotationComponent.EntityPoints var10000;
      switch(var2) {
      case 0:
         var10000 = RotationComponent.EntityPoints.STRAIGHT;
         break;
      case 1:
         var10000 = RotationComponent.EntityPoints.CLOSEST;
         break;
      case 2:
         var10000 = RotationComponent.EntityPoints.RANDOM;
         break;
      default:
         var10000 = RotationComponent.EntityPoints.STRAIGHT;
      }

      return var10000;
   }

   private boolean checkConditions() {
      String[] var1 = new String[]{"Holding Weapon", "Clicking", "Break Blocks"};
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String check = var1[var3];
         byte var7 = -1;
         switch(check.hashCode()) {
         case 971106682:
            if (check.equals("Clicking")) {
               var7 = 1;
            }
            break;
         case 1133664857:
            if (check.equals("Holding Weapon")) {
               var7 = 0;
            }
            break;
         case 1463209991:
            if (check.equals("Break Blocks")) {
               var7 = 2;
            }
         }

         boolean var10000;
         switch(var7) {
         case 0:
            if (this.conditions.getSpecificValue(check) && !(mc.field_1724.method_31548().method_7391().method_7909() instanceof class_1829)) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         case 1:
            if (this.conditions.getSpecificValue(check) && !InputUtils.mouseDown(0)) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         case 2:
            if (this.conditions.getSpecificValue(check) && mc.field_1761.method_2923()) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         default:
            var10000 = false;
         }

         boolean isTrue = var10000;
         if (isTrue) {
            return true;
         }
      }

      return false;
   }

   public KillAura() {
      this.aimMath = new ModeSetting(this.aimingCategory, "Aim Math", "Select the aiming math", "Regular", new String[]{"Regular", "Adaptive", "Linear", "Blatant"});
      this.aimVector = new ModeSetting(this.aimingCategory, "Aim Vector", "Select the aiming location behavior", "Straight", new String[]{"Straight", "Closest", "Random"});
      this.horizontalSpeed = new RangeSetting(this.aimingCategory, "Horizontal Aim Speed", "Adjust the speed", 0.0D, 100.0D, 30.0D, 50.0D);
      this.verticalSpeed = new RangeSetting(this.aimingCategory, "Vertical Aim Speed", "Adjust the speed", 0.0D, 100.0D, 30.0D, 50.0D);
      this.range = new NumberSetting(this.behaviorCategory, "Reach", "Set the maximum distance", 3.0D, 0.1D, 6.0D);
      this.conditions = new MultiSetting(this.targetingCategory, "Conditions", "Set activation conditions", new String[]{"Clicking", "Holding Weapon", "Break Blocks"});
      this.targetSorting = new ModeSetting(this.targetingCategory, "Target Sorting", "Choose how targets are prioritized", "Distance", new String[]{"Distance", "HurtTime", "Health", "Rotation"});
      this.getSettingRepository().registerSettings(this.aimingCategory, this.targetingCategory, this.behaviorCategory, this.aimMath, this.aimVector, this.horizontalSpeed, this.verticalSpeed, this.range, this.conditions, this.targetSorting);
   }
}
