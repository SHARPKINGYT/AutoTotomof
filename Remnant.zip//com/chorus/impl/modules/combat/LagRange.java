package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.network.PacketReceiveEvent;
import com.chorus.impl.events.network.PacketSendEvent;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2749;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_746;
import net.minecraft.class_7648;

@ModuleInfo(
   name = "LagRange",
   description = "Uses Lag To Stay A Set Distance Away From Enemies",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class LagRange extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General Settings");
   private final SettingCategory visual = new SettingCategory("Visual Settings");
   private final SettingCategory debug = new SettingCategory("Debug Settings");
   private final NumberSetting<Integer> fov;
   private final NumberSetting<Integer> delay;
   private final NumberSetting<Double> distance;
   private final NumberSetting<Double> leniency;
   private final BooleanSetting realPos;
   private final BooleanSetting whileLagging;
   public final ConcurrentLinkedQueue<LagRange.DelayedPacket> packetQueue;
   private final TimerUtils waitTimer;
   private class_243 currentPosition;
   private class_243 oldPlayerPosition;

   protected void onModuleDisabled() {
      this.handlePackets(false, false);
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         this.setSuffix(String.valueOf(this.delay.getValue()) + "ms");
         if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) {
            return;
         }

         class_1657 target = (class_1657)this.getClosestPlayerEntityWithinRange(((Double)this.distance.getValue()).floatValue() + 2.0F);
         if (target == null) {
            this.handlePackets(false, false);
            this.waitTimer.reset();
            return;
         }

         if (!this.waitTimer.hasReached(250.0D)) {
            this.handlePackets(false, false);
            return;
         }

         if ((double)mc.field_1724.method_5739(target) > (Double)this.distance.getValue()) {
            this.handlePackets(false, true);
         } else {
            this.handlePackets(true, false);
         }

         if (this.currentPosition.method_1022(target.method_19538()) + (Double)this.leniency.getValue() < (double)mc.field_1724.method_5739(target)) {
            this.handlePackets(false, false);
         }
      }

   }

   @RegisterEvent
   private void Render3DEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && this.currentPosition.method_10214() != 0.0D) {
         if (this.realPos.getValue()) {
            Color color = this.packetQueue.isEmpty() ? new Color(255, 0, 0) : new Color(255, 255, 255);
            this.oldPlayerPosition = this.oldPlayerPosition.method_35590(this.currentPosition, 0.1D);
            if (!this.whileLagging.getValue() || !color.equals(new Color(255, 0, 0))) {
               class_1657 target = (class_1657)this.getClosestPlayerEntityWithinRange(((Double)this.distance.getValue()).floatValue() + 2.0F);
               if (target != null) {
                  Render3DEngine.renderOutlinedShadedBox(this.oldPlayerPosition, color, 50, event.getMatrices(), mc.field_1724.method_17681() / 2.0F, mc.field_1724.method_17682());
               }
            }
         }
      }
   }

   @RegisterEvent
   private void packetReceiveEventEventListener(PacketReceiveEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2596<?> packet = event.getPacket();
         if (!(packet instanceof class_2708)) {
            label40: {
               if (packet instanceof class_2749) {
                  class_2749 healthPacket = (class_2749)packet;
                  if (healthPacket.method_11833() != mc.field_1724.method_6032()) {
                     break label40;
                  }
               }

               if (packet instanceof class_2743) {
                  class_2743 velocityPacket = (class_2743)packet;
                  if (velocityPacket.method_11818() == mc.field_1724.method_5628()) {
                     break label40;
                  }
               }

               if (!(packet instanceof class_2664)) {
                  return;
               }

               class_2664 explosionPacket = (class_2664)packet;
               if (((class_243)explosionPacket.comp_2884().get()).field_1352 == 0.0D || ((class_243)explosionPacket.comp_2884().get()).field_1351 == 0.0D || ((class_243)explosionPacket.comp_2884().get()).field_1350 == 0.0D) {
                  return;
               }
            }
         }

         this.handlePackets(false, false);
         this.waitTimer.reset();
      }
   }

   @RegisterEvent
   private void sendEventEventListener(PacketSendEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         if (mc.field_1724.field_6012 < 10) {
            this.handlePackets(false, false);
         } else {
            class_2596 packet = event.getPacket();
            class_1657 target = (class_1657)this.getClosestPlayerEntityWithinRange(((Double)this.distance.getValue()).floatValue() + 2.0F);
            if (target == null) {
               this.handlePackets(false, false);
               this.waitTimer.reset();
            } else if (!this.waitTimer.hasReached(250.0D)) {
               this.handlePackets(false, false);
            } else if (packet instanceof class_2824) {
               class_2824 playerInteractEntityC2SPacket = (class_2824)packet;
               this.handlePackets(false, false);
               this.waitTimer.reset();
            } else {
               this.packetQueue.offer(new LagRange.DelayedPacket(event.getPacket(), System.currentTimeMillis()));
               event.setCancelled(true);
            }
         }
      }
   }

   private void handlePackets(Boolean useDelay, Boolean findCloserPosition) {
      if (mc.field_1724 != null && mc.field_1687 != null && !this.packetQueue.isEmpty()) {
         class_1657 target = (class_1657)this.getClosestPlayerEntityWithinRange(((Double)this.distance.getValue()).floatValue() + 2.0F);
         List<LagRange.DelayedPacket> toRemove = new ArrayList();
         Iterator var5 = this.packetQueue.iterator();

         while(var5.hasNext()) {
            LagRange.DelayedPacket packet = (LagRange.DelayedPacket)var5.next();
            boolean sincePacket = System.currentTimeMillis() - packet.receiveTime >= (long)(useDelay ? (Integer)this.delay.getValue() : -1000);
            if (sincePacket) {
               mc.method_1562().method_48296().method_10752(packet.packet, (class_7648)null);
               toRemove.add(packet);
               class_2596 var9 = packet.packet;
               if (var9 instanceof class_2828) {
                  class_2828 packets = (class_2828)var9;
                  class_243 pos = mc.field_1724.method_19538();
                  if (useDelay) {
                     this.currentPosition = new class_243(((class_2828)packet.packet).method_12269(pos.field_1352), ((class_2828)packet.packet).method_12268(pos.field_1351), ((class_2828)packet.packet).method_12274(pos.field_1350));
                  } else {
                     this.currentPosition = mc.field_1724.method_30950(mc.method_61966().method_60637(false));
                  }

                  if (target != null && findCloserPosition && !useDelay && target.method_5649(packets.method_12269(pos.field_1352), packets.method_12268(pos.field_1351), packets.method_12274(pos.field_1350)) <= Math.pow((Double)this.distance.getValue(), 2.0D)) {
                     break;
                  }
               }
            }
         }

         this.packetQueue.removeAll(toRemove);
      }
   }

   public class_1297 getClosestPlayerEntityWithinRange(float range) {
      Stream var10000 = mc.field_1687.method_18456().stream().filter((player) -> {
         return player != mc.field_1724 && mc.field_1724.method_5739(player) <= range && SocialManager.isEnemy(player) && Math.toDegrees(MathUtils.angleBetween(mc.field_1724.method_5720(), player.method_19538().method_1031(0.0D, (double)player.method_18381(player.method_18376()), 0.0D).method_1020(mc.field_1724.method_33571()))) <= (double)((float)(Integer)this.fov.getValue() / 2.0F);
      });
      class_746 var10001 = mc.field_1724;
      Objects.requireNonNull(var10001);
      return (class_1297)var10000.min(Comparator.comparingDouble(var10001::method_5739)).orElse((Object)null);
   }

   public LagRange() {
      this.fov = new NumberSetting(this.debug, "Fov", "Fov", 140, 0, 360);
      this.delay = new NumberSetting(this.general, "Delay", "Delay", 250, 0, 2500);
      this.distance = new NumberSetting(this.general, "Distance", "Distance", 3.0D, 0.0D, 6.0D);
      this.leniency = new NumberSetting(this.general, "Extra Leniency", "Leniency", 0.1D, 0.0D, 1.0D);
      this.realPos = new BooleanSetting(this.visual, "Real Position", "Real Position", false);
      this.whileLagging = new BooleanSetting(this.visual, "Only While Lagging", "Only While Lagging", false);
      this.packetQueue = new ConcurrentLinkedQueue();
      this.waitTimer = new TimerUtils();
      this.currentPosition = new class_243(0.0D, 0.0D, 0.0D);
      this.oldPlayerPosition = new class_243(0.0D, 0.0D, 0.0D);
      this.getSettingRepository().registerSettings(this.general, this.visual, this.debug, this.fov, this.delay, this.distance, this.leniency, this.realPos, this.whileLagging);
   }

   @Environment(EnvType.CLIENT)
   private static class DelayedPacket {
      final class_2596<?> packet;
      final long receiveTime;

      DelayedPacket(class_2596<?> packet, long receiveTime) {
         this.packet = packet;
         this.receiveTime = receiveTime;
      }
   }
}
