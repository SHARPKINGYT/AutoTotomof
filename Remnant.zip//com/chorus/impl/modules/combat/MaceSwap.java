package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.impl.events.player.SwingEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1743;
import net.minecraft.class_2868;
import net.minecraft.class_3966;
import net.minecraft.class_9362;

@ModuleInfo(
   name = "MaceSwap",
   description = "swap",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class MaceSwap extends BaseModule implements QuickImports {
   private final BooleanSetting swapSilently = new BooleanSetting("Swap Silently", "Swaps to a mace silently", false);
   private int lastSlot = -1;

   @RegisterEvent
   private void onUpdate(TickEvent event) {
      if (mc.field_1724 != null && this.lastSlot != -1) {
         if (event.getMode() == TickEvent.Mode.PRE) {
            this.swap(this.lastSlot);
            this.lastSlot = -1;
         }
      }
   }

   @RegisterEvent
   private void SwingEvent(SwingEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         int slot = InventoryUtils.findItemWithPredicateInHotbar((itemStack) -> {
            return itemStack.method_7909() instanceof class_9362;
         });
         if (slot != mc.field_1724.method_31548().field_7545) {
            if (slot != -1 && this.lastSlot == -1) {
               if (!(InventoryUtils.getMainHandItem().method_7909() instanceof class_1743)) {
                  if (mc.field_1765 instanceof class_3966) {
                     this.lastSlot = mc.field_1724.method_31548().field_7545;
                     this.swap(slot);
                  }
               }
            }
         }
      }
   }

   public void swap(int slot) {
      if (this.swapSilently.getValue()) {
         mc.method_1562().method_52787(new class_2868(slot));
      } else {
         InventoryUtils.swapToMainHand(slot);
      }

   }

   public MaceSwap() {
      this.getSettingRepository().registerSettings(this.swapSilently);
   }
}
