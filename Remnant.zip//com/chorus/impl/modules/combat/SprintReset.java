package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.network.PacketSendEvent;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_3966;
import net.minecraft.class_2848.class_2849;

@ModuleInfo(
   name = "SprintReset",
   description = "Resets Sprint To Deal More Knock-back",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class SprintReset extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("Attack Settings");
   private final ModeSetting sprintMode;
   private final RangeSetting<Integer> delay;
   private final TimerUtils waitTimer;
   public boolean reset;
   public boolean isSprinting;

   @RegisterEvent
   private void AttackEventListener(AttackEvent event) {
      if (event.getMode().equals(AttackEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if (this.waitTimer.hasReached((double)(Integer)this.delay.getValueMax())) {
            class_239 var3 = mc.field_1765;
            if (var3 instanceof class_3966) {
               class_3966 hitResult = (class_3966)var3;
               class_1297 var4 = hitResult.method_17782();
               if (var4 instanceof class_1657) {
                  class_1657 player = (class_1657)var4;
                  if (player.field_6235 == 0) {
                     this.waitTimer.reset();
                  }
               }
            }
         }
      }

   }

   @RegisterEvent
   private void PacketSendListener(PacketSendEvent event) {
      if (event.getMode().equals(PacketSendEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_2848) {
            class_2848 clientCommandC2SPacket = (class_2848)var3;
            if (clientCommandC2SPacket.method_36173() == mc.field_1724.method_5628()) {
               this.isSprinting = clientCommandC2SPacket.method_12365() == class_2849.field_12981;
            }
         }
      }

   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         String var2;
         byte var3;
         if (this.waitTimer.hasReached((double)(Integer)this.delay.getValueMax())) {
            if (this.reset) {
               var2 = this.sprintMode.getValue();
               var3 = -1;
               switch(var2.hashCode()) {
               case 78076681:
                  if (var2.equals("S-Tap")) {
                     var3 = 1;
                  }
                  break;
               case 79854690:
                  if (var2.equals("Shift")) {
                     var3 = 2;
                  }
                  break;
               case 81770765:
                  if (var2.equals("W-Tap")) {
                     var3 = 0;
                  }
               }

               switch(var3) {
               case 0:
                  if (InputUtils.keyDown(87)) {
                     mc.field_1690.field_1894.method_23481(true);
                  }
                  break;
               case 1:
                  mc.field_1690.field_1881.method_23481(false);
                  break;
               case 2:
                  mc.field_1690.field_1832.method_23481(false);
               }

               this.reset = false;
            }
         } else {
            var2 = this.sprintMode.getValue();
            var3 = -1;
            switch(var2.hashCode()) {
            case -579180799:
               if (var2.equals("No Stop")) {
                  var3 = 3;
               }
               break;
            case 78076681:
               if (var2.equals("S-Tap")) {
                  var3 = 1;
               }
               break;
            case 79854690:
               if (var2.equals("Shift")) {
                  var3 = 2;
               }
               break;
            case 81770765:
               if (var2.equals("W-Tap")) {
                  var3 = 0;
               }
            }

            switch(var3) {
            case 0:
               mc.field_1690.field_1894.method_23481(false);
               break;
            case 1:
               mc.field_1690.field_1881.method_23481(true);
               break;
            case 2:
               mc.field_1690.field_1832.method_23481(true);
               break;
            case 3:
               if (mc.field_1690.field_1894.method_1434()) {
                  if (this.isSprinting) {
                     mc.method_1562().method_48296().method_10743(new class_2848(mc.field_1724, class_2849.field_12985));
                  }

                  mc.method_1562().method_48296().method_10743(new class_2848(mc.field_1724, class_2849.field_12981));
               }
            }

            this.reset = true;
         }
      }

   }

   public SprintReset() {
      this.sprintMode = new ModeSetting(this.general, "Reset Mode", "Select the reset type", "W-tap", new String[]{"W-Tap", "S-Tap", "No Stop", "Shift"});
      this.delay = new RangeSetting(this.general, "Delay", "Adjust reset delay", 0, 1000, 50, 50);
      this.waitTimer = new TimerUtils();
      this.reset = false;
      this.isSprinting = false;
      this.getSettingRepository().registerSettings(this.general, this.sprintMode, this.delay);
   }
}
