package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.world.SimulatedPlayer;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.network.PacketSendEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_9836;

@ModuleInfo(
   name = "TickBase",
   description = "Tick gangster",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class TickBase extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General Settings");
   private final NumberSetting<Integer> ticks;
   private final RangeSetting<Float> range;
   private final NumberSetting<Float> delay;
   public int laggedTicks;
   public TimerUtils timer;
   public boolean endedTick;

   @RegisterEvent
   private void PacketSendEvent(PacketSendEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (event.getPacket() instanceof class_9836) {
            this.endedTick = true;
         }

      }
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      this.setSuffix(String.valueOf(this.ticks.getValue()));
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (SocialManager.getTarget() == null) {
            this.laggedTicks = 0;
         } else if (this.timer.hasReached((double)((Float)this.delay.getValue() * 1000.0F))) {
            if (event.getMode().equals(TickEvent.Mode.PRE) && this.endedTick) {
               this.endedTick = false;
            }

            SimulatedPlayer player = new SimulatedPlayer(mc.field_1724);
            player.setInput(mc.field_1690.field_1894.method_1434(), mc.field_1690.field_1881.method_1434(), mc.field_1690.field_1913.method_1434(), mc.field_1690.field_1849.method_1434(), mc.field_1690.field_1903.method_1434(), mc.field_1724.method_5624());

            for(int i = 0; i <= (Integer)this.ticks.getValue(); ++i) {
               player.tick();
            }

            double simulatedDistance = player.getPosition().method_1022(SocialManager.getTarget().method_19538());
            double distance = (double)mc.field_1724.method_5739(SocialManager.getTarget());
            if (!(simulatedDistance > distance) && !(simulatedDistance < (double)(Float)this.range.getValueMin()) && !(simulatedDistance > (double)(Float)this.range.getValueMax())) {
               if (this.laggedTicks >= (Integer)this.ticks.getValue()) {
                  if (this.endedTick) {
                     return;
                  }

                  for(int i = 1; i <= this.laggedTicks; ++i) {
                     mc.field_1724.method_5773();
                     mc.method_1562().method_52787(new class_9836());
                  }

                  this.laggedTicks = 0;
                  this.timer.reset();
                  this.endedTick = false;
               } else {
                  event.setCancelled(true);
                  if (event.getMode().equals(TickEvent.Mode.PRE)) {
                     ++this.laggedTicks;
                  }
               }

            } else {
               this.laggedTicks = 0;
            }
         }
      } else {
         this.laggedTicks = 0;
      }
   }

   public TickBase() {
      this.ticks = new NumberSetting(this.general, "Ticks", "Ticks", 5, 0, 40);
      this.range = new RangeSetting(this.general, "Range", "Sets Serverside Range Limits", 0.0F, 10.0F, 1.5F, 4.5F);
      this.delay = new NumberSetting(this.general, "Delay", "Delay in seconds", 5.0F, 0.0F, 25.0F);
      this.laggedTicks = 0;
      this.timer = new TimerUtils();
      this.endedTick = false;
      this.getSettingRepository().registerSettings(this.general, this.ticks, this.range, this.delay);
   }
}
