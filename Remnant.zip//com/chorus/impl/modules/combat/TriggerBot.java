package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.PlayerUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.network.PacketSendEvent;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.modules.other.MultiTask;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_1839;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_9362;
import net.minecraft.class_2848.class_2849;

@ModuleInfo(
   name = "TriggerBot",
   description = "Attacks Enemies",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class TriggerBot extends BaseModule implements QuickImports {
   private final SettingCategory attack = new SettingCategory("Attack Settings");
   private final SettingCategory critical = new SettingCategory("Critical Hit Settings");
   private final SettingCategory targeting = new SettingCategory("Targeting Settings");
   private final SettingCategory additional = new SettingCategory("Additional Settings");
   private final ModeSetting attackMode;
   private final RangeSetting<Integer> reactionTime;
   private final RangeSetting<Integer> attackDelay;
   private final NumberSetting<Integer> cooldown;
   private final ModeSetting handleShield;
   private final ModeSetting criticalType;
   private final NumberSetting<Double> maceFallDistance;
   private final MultiSetting enemyConditions;
   private final MultiSetting conditions;
   private final ModeSetting targetSorting;
   private final NumberSetting<Integer> fakeChance;
   private final RangeSetting<Double> fakeRange;
   private final MultiSetting fakeItems;
   private final TimerUtils hitTimer;
   private final TimerUtils reactionTimer;
   private boolean unblocked;
   private boolean attacked;
   private boolean attackedThisTick;
   private boolean sprintDesynced;
   private boolean isSprinting;

   @RegisterEvent
   private void PacketSendEventListener(PacketSendEvent event) {
      if (event.getMode().equals(PacketSendEvent.Mode.PRE)) {
         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_2848) {
            class_2848 clientCommandC2SPacket = (class_2848)var3;
            if (clientCommandC2SPacket.method_36173() == mc.field_1724.method_5628()) {
               this.isSprinting = clientCommandC2SPacket.method_12365() == class_2849.field_12981;
               this.sprintDesynced = false;
            }
         }
      }

   }

   @RegisterEvent
   private void attackEventListener(AttackEvent event) {
      if (event.getMode().equals(AttackEvent.Mode.POST)) {
         this.sprintDesynced = true;
      }

   }

   @RegisterEvent
   private void Render3DEventListener(TickEvent event) {
      if (!event.getMode().equals(TickEvent.Mode.PRE)) {
         this.attackedThisTick = false;
      } else {
         if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) {
            return;
         }

         if (this.attacked) {
            if (this.unblocked && InputUtils.mouseDown(1) && mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
               mc.field_1690.field_1904.method_23481(true);
               this.unblocked = false;
            }

            this.attacked = false;
         }

         this.setSuffix(this.criticalType.getValue());
         if (!mc.field_1690.field_1894.method_1434()) {
            this.sprintDesynced = false;
         }

         if (this.conditions.getSpecificValue("Holding Weapon") && !(mc.field_1724.method_6047().method_7909() instanceof class_1829) && !(mc.field_1724.method_6047().method_7909() instanceof class_1743) && !(mc.field_1724.method_6047().method_7909() instanceof class_1835) && !(mc.field_1724.method_6047().method_7909() instanceof class_9362)) {
            return;
         }

         if (this.conditions.getSpecificValue("Clicking") && !InputUtils.mouseDown(0)) {
            return;
         }

         if (mc.field_1724.method_6047().method_7909() instanceof class_9362 && (double)mc.field_1724.field_6017 < (Double)this.maceFallDistance.getValue()) {
            return;
         }

         if ((double)mc.field_1724.method_7261((float)mc.field_1724.method_45325(class_5134.field_23723)) < (double)(Integer)this.cooldown.getValue() * 0.01D) {
            if (this.attackMode.getValue().equals("Cooldown")) {
               this.hitTimer.reset();
               return;
            }
         } else {
            class_1297 enemy = PlayerUtils.raytraceEntity(10.0D);
            if (enemy != null && (double)enemy.method_5739(mc.field_1724) > (Double)this.fakeRange.getValueMin() && (double)enemy.method_5739(mc.field_1724) < (Double)this.fakeRange.getValueMax() && MathUtils.randomInt(1, 100) <= (Integer)this.fakeChance.getValue() && mc.field_1724.field_6012 % 20 == 0) {
               InputUtils.simulateClick(0, 50);
            }
         }

         if (!this.hitTimer.hasReached((double)MathUtils.randomInt((Integer)this.attackDelay.getValueMin(), (Integer)this.attackDelay.getValueMax()))) {
            return;
         }

         class_239 crosshairTarget = mc.field_1765;
         if (crosshairTarget == null) {
            return;
         }

         if (!(crosshairTarget instanceof class_3966)) {
            this.reactionTimer.reset();
            return;
         }

         class_3966 entityHitResult = (class_3966)crosshairTarget;
         class_1297 var5 = entityHitResult.method_17782();
         if (var5 instanceof class_1309) {
            class_1309 entity = (class_1309)var5;
            if (!this.reactionTimer.hasReached((double)MathUtils.randomInt((Integer)this.reactionTime.getValueMin(), (Integer)this.reactionTime.getValueMax()))) {
               return;
            }

            String var9 = this.targetSorting.getValue();
            byte var6 = -1;
            switch(var9.hashCode()) {
            case -1901885695:
               if (var9.equals("Player")) {
                  var6 = 0;
               }
               break;
            case 2131396690:
               if (var9.equals("Visible")) {
                  var6 = 1;
               }
            }

            switch(var6) {
            case 0:
               if (!entity.method_31747()) {
                  return;
               }
               break;
            case 1:
               if (!entity.method_6057(entity)) {
                  return;
               }
            }

            if (entity.method_31747()) {
               if (SocialManager.isTargetedPlayer((class_1657)entity) != entity) {
                  return;
               }

               if (!SocialManager.isEnemy((class_1657)entity)) {
                  return;
               }
            }

            if (this.enemyConditions.getSpecificValue("Attackable") && entity.field_6235 != 0) {
               return;
            }

            if (this.enemyConditions.getSpecificValue("Ignore Shield") && entity.method_31747() && entity.method_6115() && entity.method_6030().method_7909() == class_1802.field_8255 && !PlayerUtils.isShieldFacingAway(entity)) {
               return;
            }

            boolean inCobweb = mc.field_1687.method_8320(mc.field_1724.method_24515()).method_26204() == class_2246.field_10343 || mc.field_1687.method_8320(mc.field_1724.method_24515().method_10084()).method_26204() == class_2246.field_10343 || mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_26204() == class_2246.field_10343;
            String var11 = this.criticalType.getValue();
            byte var7 = -1;
            switch(var11.hashCode()) {
            case 79996329:
               if (var11.equals("Smart")) {
                  var7 = 0;
               }
               break;
            case 2043603644:
               if (var11.equals("Desync")) {
                  var7 = 1;
               }
            }

            switch(var7) {
            case 0:
               if (!this.sprintDesynced && !mc.field_1724.method_6128() && !inCobweb) {
                  if (!mc.field_1690.field_1894.method_1434() && mc.field_1724.field_6235 != 0) {
                     if (mc.field_1724.field_6017 == 0.0F) {
                        return;
                     }
                  } else if (mc.field_1724.field_6017 == 0.0F && !mc.field_1724.method_24828()) {
                     return;
                  }
               }
               break;
            case 1:
               if (!this.sprintDesynced && !PlayerUtils.canCriticalHit() && !mc.field_1724.method_24828()) {
                  return;
               }
               break;
            default:
               return;
            }

            if (mc.field_1724.method_6058() == class_1268.field_5810 && !mc.field_1724.method_6030().method_7976().equals(class_1839.field_8952)) {
               if (this.handleShield.getValue().equals("Unblock Shield") && mc.field_1724.method_6030().method_7909() == class_1802.field_8255) {
                  mc.field_1690.field_1904.method_23481(false);
                  this.unblocked = true;
                  return;
               }

               if (this.handleShield.getValue().equals("Multi-Task") && Chorus.getInstance().getModuleManager().isModuleEnabled(MultiTask.class)) {
                  if (mc.field_1724 == null || mc.field_1687 == null || this.attackedThisTick) {
                     return;
                  }

                  this.attacked = true;
                  this.attackedThisTick = true;
                  PlayerUtils.attackEnemy(false, entity);
                  this.hitTimer.reset();
               }
            } else {
               if (mc.field_1724 == null || mc.field_1687 == null || this.attackedThisTick) {
                  return;
               }

               this.attacked = true;
               this.attackedThisTick = true;
               PlayerUtils.attackEnemy(false, entity);
               this.hitTimer.reset();
            }
         }
      }

   }

   public TriggerBot() {
      this.attackMode = new ModeSetting(this.attack, "Attack Timing", "Select the attack timing", "Cooldown", new String[]{"Cooldown", "Delay"});
      this.reactionTime = new RangeSetting(this.attack, "Reaction Time", "Adjust Reaction Time", 0, 250, 0, 0);
      this.attackDelay = new RangeSetting(this.attack, "Attack Delay", "Adjust Attack Delay", 0, 1000, 10, 25);
      this.cooldown = new NumberSetting(this.attack, "Cooldown", "Attack Cooldown (%)", 95, 0, 100);
      this.handleShield = new ModeSetting(this.attack, "Handle Shield", "Handles Player Shield", "Multi-Task", new String[]{"Unblock Shield"});
      this.criticalType = new ModeSetting(this.critical, "Criticals", "None", "Desync", new String[]{"Desync", "Smart"});
      this.maceFallDistance = new NumberSetting(this.critical, "Mace Fall Distance", "Set Minimum Fall Distance before attacking with a mace", 3.0D, 0.0D, 25.0D);
      this.enemyConditions = new MultiSetting(this.targeting, "Enemy Conditions", "Conditions", new String[]{"Attackable", "Ignore Shield"});
      this.conditions = new MultiSetting(this.targeting, "Conditions", "Set activation conditions", new String[]{"Clicking", "Holding Weapon"});
      this.targetSorting = new ModeSetting(this.targeting, "Target Sorting", "Choose targets", "Player", new String[]{"Visible", "Player"});
      this.fakeChance = new NumberSetting(this.additional, "Fail Swing Chance", "Chance to fail when optimal", 0, 0, 100);
      this.fakeRange = new RangeSetting(this.additional, "Fail Range", "Adjust Range To Fail Swings", 0.0D, 10.0D, 4.0D, 10.0D);
      this.fakeItems = new MultiSetting(this.additional, "Fail With", "not implemented", new String[]{"Sword", "Axe", "Fist", "Mace"});
      this.hitTimer = new TimerUtils();
      this.reactionTimer = new TimerUtils();
      this.getSettingRepository().registerSettings(this.attack, this.targeting, this.critical, this.additional, this.attackMode, this.reactionTime, this.attackDelay, this.conditions, this.targetSorting, this.criticalType, this.cooldown, this.handleShield, this.maceFallDistance, this.fakeChance, this.fakeRange, this.fakeItems, this.enemyConditions);
      this.fakeChance.setRenderCondition(() -> {
         return !this.fakeItems.getValue().isEmpty();
      });
      this.fakeRange.setRenderCondition(() -> {
         return !this.fakeItems.getValue().isEmpty();
      });
   }
}
