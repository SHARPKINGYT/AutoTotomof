package com.chorus.impl.modules.combat;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.network.PacketReceiveEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1743;
import net.minecraft.class_1829;
import net.minecraft.class_2596;
import net.minecraft.class_2743;
import net.minecraft.class_465;
import net.minecraft.class_239.class_240;

@ModuleInfo(
   name = "Velocity",
   description = "Reduces Taken Knock-Back",
   category = ModuleCategory.COMBAT
)
@Environment(EnvType.CLIENT)
public class Velocity extends BaseModule implements QuickImports {
   private final ModeSetting mode = new ModeSetting("Mode", "Velocity mode", "Jump Reset", new String[]{"Jump Reset", "Normal"});
   private final RangeSetting<Double> horizontal = new RangeSetting("Horizontal Motion", "The amount of velocity to reduce horizontally", 0.0D, 100.0D, 50.0D, 75.0D);
   private final RangeSetting<Double> vertical = new RangeSetting("Vertical Motion", "The amount of velocity to reduce horizontally", 0.0D, 100.0D, 50.0D, 75.0D);
   private final BooleanSetting fullZero = new BooleanSetting("Full Zero", "Makes it so Knockback does not touch your movement at all", false);
   private final NumberSetting<Double> chance = new NumberSetting("Chance", "Probability of performing action", 25.0D, 0.0D, 100.0D);
   private final NumberSetting<Float> range = new NumberSetting("Range", "Maximum distance to consider nearby players", 6.0F, 1.0F, 10.0F);
   private final MultiSetting conditions = new MultiSetting("Conditions", "Conditions before reducing knockback", new String[]{"Sprinting", "Holding Weapon", "Going Forward", "Looking At enemy", "Only In Air"});

   @RegisterEvent
   private void PacketReceiveEventListener(PacketReceiveEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_2743) {
            class_2743 velocityPacket = (class_2743)var3;
            if (velocityPacket.method_11818() == mc.field_1724.method_5628() && this.shouldModify() && this.mode.getValue().equals("Normal")) {
               event.cancel();
               double motionX = velocityPacket.method_11815() / 8000.0D;
               double motionY = velocityPacket.method_11816() / 8000.0D;
               double motionZ = velocityPacket.method_11819() / 8000.0D;
               double xzVelocityFactor = (double)this.horizontal.getRandomValue().floatValue() * 0.01D;
               double yVelocityFactor = (double)this.vertical.getRandomValue().floatValue() * 0.01D;
               if ((xzVelocityFactor != 0.0D || yVelocityFactor != 0.0D) && !this.fullZero.getValue()) {
                  mc.field_1724.method_18800(motionX * xzVelocityFactor, motionY * yVelocityFactor, motionZ * xzVelocityFactor);
               }
            }
         }

      }
   }

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 instanceof class_465) {
            return;
         }

         String var2 = this.mode.getValue();
         byte var3 = -1;
         switch(var2.hashCode()) {
         case -76957987:
            if (var2.equals("Jump Reset")) {
               var3 = 0;
            }
         }

         switch(var3) {
         case 0:
            if (!mc.field_1724.method_24828() || mc.field_1690.field_1903.method_1434() || mc.field_1724.method_5799() || !mc.field_1724.method_5624()) {
               return;
            }

            boolean playerNearby = mc.field_1687.method_18456().stream().filter((player) -> {
               return player != mc.field_1724;
            }).anyMatch((player) -> {
               return mc.field_1724.method_5739(player) <= (Float)this.range.getValue();
            });
            if (!playerNearby) {
               return;
            }

            if (mc.field_1724.field_6235 == 9 && (double)MathUtils.randomInt(0, 100) <= (Double)this.chance.getValue()) {
               InputUtils.simulateKeyPress(mc.field_1690.field_1903, 35);
            }
         }
      }

   }

   private boolean shouldModify() {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         if (this.conditions.getSpecificValue("Sprinting") && !mc.field_1724.method_5624()) {
            return false;
         } else if (this.conditions.getSpecificValue("Holding Weapon") && !(mc.field_1724.method_6047().method_7909() instanceof class_1829) && !(mc.field_1724.method_6047().method_7909() instanceof class_1743)) {
            return false;
         } else if (this.conditions.getSpecificValue("Going Forward") && !mc.field_1690.field_1894.method_1434()) {
            return false;
         } else if (this.conditions.getSpecificValue("Looking At Enemy") && mc.field_1765.method_17783() != class_240.field_1331) {
            return false;
         } else if (this.conditions.getSpecificValue("Only In Air") && mc.field_1724.method_24828()) {
            return false;
         } else {
            return (double)MathUtils.randomInt(0, 100) <= (Double)this.chance.getValue();
         }
      } else {
         return false;
      }
   }

   public Velocity() {
      this.horizontal.setRenderCondition(() -> {
         return this.mode.getValue().equals("Normal");
      });
      this.vertical.setRenderCondition(() -> {
         return this.mode.getValue().equals("Normal");
      });
      this.fullZero.setRenderCondition(() -> {
         return this.mode.getValue().equals("Normal");
      });
      this.getSettingRepository().registerSettings(this.mode, this.horizontal, this.vertical, this.fullZero, this.chance, this.range, this.conditions);
   }
}
