package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.player.TickEvent;
import java.util.Comparator;
import java.util.Objects;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_746;

@ModuleInfo(
   name = "AutoElytra",
   description = "Automatically Uses Fireworks",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class AutoElytra extends BaseModule implements QuickImports {
   private final SettingCategory behaviorCategory = new SettingCategory("Behavior");
   private final RangeSetting<Double> range;
   boolean swap;
   int slot;

   @RegisterEvent(3)
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_1297 enemy = this.getClosestPlayerEntityWithinRange(50.0F);
         if (enemy == null) {
            return;
         }

         if (!mc.field_1724.method_6128()) {
            if (mc.field_1724.method_24828()) {
               mc.field_1690.field_1903.method_23481(true);
            } else if (mc.field_1724.field_6017 > 0.0F) {
               mc.field_1690.field_1903.method_23481(true);
               mc.field_1724.field_6017 = 0.0F;
            } else {
               mc.field_1690.field_1903.method_23481(false);
            }

            return;
         }

         if (mc.field_1724.field_6012 % 5 == 0) {
            InputUtils.simulateClick(1, 35);
         }

         if ((double)mc.field_1724.method_5739(enemy) < (Double)this.range.getValueMax() && (double)mc.field_1724.method_5739(enemy) > (Double)this.range.getValueMin()) {
            if (!this.swap) {
               if (InventoryUtils.findItemInHotBar(class_1802.field_8639) == -1) {
                  return;
               }

               class_1799 firework = mc.field_1724.method_31548().method_5438(InventoryUtils.findItemInHotBar(class_1802.field_8639));
               if (firework == null) {
                  return;
               }

               this.slot = mc.field_1724.method_31548().field_7545;
               if (mc.field_1724.field_6012 % 3 != 0) {
                  return;
               }

               mc.method_1562().method_52787(new class_2868(InventoryUtils.findItemInHotBar(class_1802.field_8639)));
               mc.method_1562().method_52787(new class_2886(class_1268.field_5808, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
               mc.method_1562().method_52787(new class_2868(this.slot));
            }
         } else if (this.swap) {
            mc.method_1562().method_52787(new class_2868(this.slot));
            this.slot = -1;
            this.swap = false;
         }
      }

   }

   public class_1297 getClosestPlayerEntityWithinRange(float range) {
      Stream var10000 = mc.field_1687.method_18456().stream().filter((player) -> {
         return player != mc.field_1724 && mc.field_1724.method_5739(player) <= range && SocialManager.isTargetedPlayer(player) == player;
      });
      class_746 var10001 = mc.field_1724;
      Objects.requireNonNull(var10001);
      return (class_1297)var10000.min(Comparator.comparingDouble(var10001::method_5739)).orElse((Object)null);
   }

   protected void onModuleDisabled() {
      this.swap = false;
      this.slot = -1;
   }

   public AutoElytra() {
      this.range = new RangeSetting(this.behaviorCategory, "Range", "Range to firework", 0.0D, 50.0D, 8.0D, 20.0D);
      this.swap = false;
      this.slot = -1;
      this.getSettingRepository().registerSettings(this.behaviorCategory, this.range);
   }
}
