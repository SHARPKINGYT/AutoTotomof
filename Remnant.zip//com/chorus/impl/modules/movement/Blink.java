package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.network.PacketSendEvent;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_634;
import net.minecraft.class_7648;

@ModuleInfo(
   name = "Blink",
   description = "Distances SZ From Enemies",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class Blink extends BaseModule implements QuickImports {
   public final ConcurrentLinkedQueue<Blink.DelayedPacket> packetQueue = new ConcurrentLinkedQueue();

   @RegisterEvent
   private void PacketSendEventListener(PacketSendEvent event) {
      if (event.getMode() == PacketSendEvent.Mode.PRE) {
         event.setCancelled(true);
         event.cancel();
         this.packetQueue.add(new Blink.DelayedPacket(event.getPacket(), System.currentTimeMillis()));
         long delayMillis = 5000L;

         while(!this.packetQueue.isEmpty()) {
            Blink.DelayedPacket delayedPacket = (Blink.DelayedPacket)this.packetQueue.peek();
            if (delayedPacket == null || System.currentTimeMillis() - delayedPacket.receiveTime < delayMillis) {
               break;
            }

            this.packetQueue.poll();
            this.sendPacket(delayedPacket.packet);
         }
      }

   }

   protected void onModuleDisabled() {
      while(!this.packetQueue.isEmpty()) {
         Blink.DelayedPacket delayedPacket = (Blink.DelayedPacket)this.packetQueue.peek();
         this.packetQueue.poll();
         this.sendPacket(delayedPacket.packet);
      }

   }

   private void sendPacket(class_2596<?> packet) {
      ((class_634)Objects.requireNonNull(mc.method_1562())).method_48296().method_10752(packet, (class_7648)null);
   }

   @Environment(EnvType.CLIENT)
   private static class DelayedPacket {
      final class_2596<?> packet;
      final long receiveTime;

      DelayedPacket(class_2596<?> packet, long receiveTime) {
         this.packet = packet;
         this.receiveTime = receiveTime;
      }
   }
}
