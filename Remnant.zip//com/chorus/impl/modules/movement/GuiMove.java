package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_408;

@ModuleInfo(
   name = "GuiMove",
   description = "Allows you to move in GUIS",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class GuiMove extends BaseModule implements QuickImports {
   @RegisterEvent(3)
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if (mc.field_1755 == null) {
            return;
         }

         if (mc.field_1755 instanceof class_408) {
            return;
         }

         mc.field_1690.field_1894.method_23481(InputUtils.keyDown(mc.field_1690.field_1894.method_1429().method_1444()));
         mc.field_1690.field_1913.method_23481(InputUtils.keyDown(mc.field_1690.field_1913.method_1429().method_1444()));
         mc.field_1690.field_1849.method_23481(InputUtils.keyDown(mc.field_1690.field_1849.method_1429().method_1444()));
         mc.field_1690.field_1881.method_23481(InputUtils.keyDown(mc.field_1690.field_1881.method_1429().method_1444()));
         mc.field_1690.field_1903.method_23481(InputUtils.keyDown(mc.field_1690.field_1903.method_1429().method_1444()));
      }

   }
}
