package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.SwingEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2828.class_2830;

@ModuleInfo(
   name = "MaceKiller",
   description = "Modifies Positions With Maces to deal maximum damage",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class MaceKiller extends BaseModule implements QuickImports {
   @RegisterEvent(3)
   private void TickEventListener(SwingEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         mc.method_1562().method_52787(new class_2830(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 10.0D, mc.field_1724.method_23321(), mc.field_1724.method_36454(), mc.field_1724.method_36455(), false, mc.field_1724.field_5976));
         mc.method_1562().method_52787(new class_2830(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 1.0E-4D, mc.field_1724.method_23321(), mc.field_1724.method_36454(), mc.field_1724.method_36455(), false, mc.field_1724.field_5976));
      }
   }
}
