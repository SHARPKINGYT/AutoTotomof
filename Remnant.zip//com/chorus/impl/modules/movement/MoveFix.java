package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.input.MovementInputEvent;
import com.chorus.impl.events.player.MoveFixEvent;
import com.chorus.impl.events.player.SilentRotationEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;

@ModuleInfo(
   name = "MoveFix",
   description = "Corrects Movement Based Off Rotations",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class MoveFix extends BaseModule implements QuickImports {
   private final BooleanSetting keepMovementDirection = new BooleanSetting("Keep Movement Direction", "Keeps Your Direction Of Movement", false);
   float yaw;

   @RegisterEvent(0)
   private void silentRotationEventListener(SilentRotationEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.yaw = event.getYaw();
      }
   }

   @RegisterEvent(0)
   private void moveFixEventListener(MoveFixEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         event.setYaw(this.yaw);
      }
   }

   @RegisterEvent(0)
   private void movementInputEventEventListener(MovementInputEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (this.keepMovementDirection.getValue()) {
            fixMoveDirection(event, this.yaw);
         }

      }
   }

   public static void fixMoveDirection(MovementInputEvent event, float targetYaw) {
      float forwardInput = (event.isPressingForward() ? 1.0F : 0.0F) - (event.isPressingBack() ? 1.0F : 0.0F);
      float sidewaysInput = (event.isPressingLeft() ? 1.0F : 0.0F) - (event.isPressingRight() ? 1.0F : 0.0F);
      float deltaYaw = mc.field_1724.method_36454() - targetYaw;
      float rotatedSideways = sidewaysInput * class_3532.method_15362(deltaYaw * 0.017453292F) - forwardInput * class_3532.method_15374(deltaYaw * 0.017453292F);
      float rotatedForward = forwardInput * class_3532.method_15362(deltaYaw * 0.017453292F) + sidewaysInput * class_3532.method_15374(deltaYaw * 0.017453292F);
      event.setMovementForward((float)Math.round(rotatedForward));
      event.setMovementSideways((float)Math.round(rotatedSideways));
   }

   public MoveFix() {
      this.getSettingRepository().registerSetting(this.keepMovementDirection);
   }
}
