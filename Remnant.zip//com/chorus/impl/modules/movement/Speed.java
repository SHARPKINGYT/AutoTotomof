package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.MovementUtils;
import com.chorus.impl.events.player.TickEvent;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_238;

@ModuleInfo(
   name = "Speed",
   description = "hack",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class Speed extends BaseModule implements QuickImports {
   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (!this.isEnabled()) {
            return;
         }

         MovementUtils.setSpeedWithStrafe(1.0D);
         if (mc.field_1724.field_3913.field_3905 == 0.0F && mc.field_1724.field_3913.field_3907 == 0.0F) {
            return;
         }

         int collisions = 0;
         class_238 box = mc.field_1724.method_5829().method_1014(1.0D);
         Iterator var4 = mc.field_1687.method_18112().iterator();

         while(var4.hasNext()) {
            class_1297 entity = (class_1297)var4.next();
            class_238 entityBox = entity.method_5829();
            if (this.canCauseSpeed(entity) && box.method_994(entityBox)) {
               ++collisions;
            }
         }

         double yaw = Math.toRadians((double)mc.field_1724.method_36454());
         double boost = 0.08D * (double)collisions;
         mc.field_1724.method_5762(-Math.sin(yaw) * boost, 0.0D, Math.cos(yaw) * boost);
      }

   }

   private boolean canCauseSpeed(class_1297 entity) {
      return entity != mc.field_1724 && entity instanceof class_1309 && !(entity instanceof class_1531);
   }
}
