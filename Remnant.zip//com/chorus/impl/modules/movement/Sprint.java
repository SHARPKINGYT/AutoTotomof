package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "Sprint",
   description = "Automatically Sprints For You",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class Sprint extends BaseModule implements QuickImports {
   @RegisterEvent(3)
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         mc.field_1690.field_1867.method_23481(true);
      }

   }
}
