package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.rotation.RotationUtils;
import com.chorus.common.util.player.PlayerUtils;
import com.chorus.impl.events.player.MoveFixEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;

@ModuleInfo(
   name = "Target Strafe",
   description = "Strafes Around Your Opponent",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class TargetStrafe extends BaseModule implements QuickImports {
   @RegisterEvent
   private void moveFixEventEventListener(MoveFixEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_1309 entity = (class_1309)PlayerUtils.getClosestEnemy(6.0F);
         if (entity != null) {
            float[] targetRotations = RotationUtils.calculate(entity.method_19538());
            event.setYaw(targetRotations[0] + 45.0F);
         }
      }
   }
}
