package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;

@ModuleInfo(
   name = "WaterSpeed",
   description = "Increases your speed while swimming",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class WaterSpeed extends BaseModule implements QuickImports {
   private final ModeSetting mode = new ModeSetting("Mode", "WaterSpeed mode", "Safe", new String[]{"Safe", "Fast"});

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (!this.isEnabled() || mc.field_1724 == null) {
            return;
         }

         if (mc.field_1724.method_5805() && mc.field_1724.method_5681()) {
            double speed = 1.045D;
            if (this.mode.getValue().equals("Fast")) {
               speed = 1.054D;
            }

            double motionX = mc.field_1724.method_60478().field_1352 * speed;
            double motionY = mc.field_1724.method_60478().field_1351;
            double motionZ = mc.field_1724.method_60478().field_1350 * speed;
            mc.field_1724.method_18800(motionX, motionY, motionZ);
            mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12979));
            mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12984));
         }
      }

   }

   public WaterSpeed() {
      this.getSettingRepository().registerSettings(this.mode);
   }
}
