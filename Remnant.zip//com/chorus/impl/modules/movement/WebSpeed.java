package com.chorus.impl.modules.movement;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.MovementUtils;
import com.chorus.impl.events.misc.WebSlowdownEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "WebSpeed",
   description = "Boosts Speed While In Cobwbes",
   category = ModuleCategory.MOVEMENT
)
@Environment(EnvType.CLIENT)
public class WebSpeed extends BaseModule implements QuickImports {
   public ModeSetting mode = new ModeSetting("Boost Mode", "Choose which mode you want", "Legit", new String[]{"Legit", "Set Speed", "Universal", "Full"});
   private final NumberSetting<Double> speed = new NumberSetting("Speed", "How much to speed up", 0.2D, 0.0D, 1.0D);

   @RegisterEvent(3)
   private void WebSlowdownEventListener(WebSlowdownEvent event) {
      if (event.getMode().equals(WebSlowdownEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         String var2 = this.mode.getValue();
         byte var3 = -1;
         switch(var2.hashCode()) {
         case 2201263:
            if (var2.equals("Full")) {
               var3 = 3;
            }
            break;
         case 73298841:
            if (var2.equals("Legit")) {
               var3 = 0;
            }
            break;
         case 1102753481:
            if (var2.equals("Set Speed")) {
               var3 = 1;
            }
            break;
         case 1594433067:
            if (var2.equals("Universal")) {
               var3 = 2;
            }
         }

         switch(var3) {
         case 0:
            if (!MovementUtils.hasMovementInput()) {
               return;
            }

            if (mc.field_1724.method_24828()) {
               mc.field_1724.method_6043();
            }
            break;
         case 1:
            if (!MovementUtils.hasMovementInput()) {
               return;
            }

            if (mc.field_1690.field_1903.method_1434()) {
               mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, (Double)this.speed.getValue(), mc.field_1724.method_18798().field_1350);
            }

            if (mc.field_1690.field_1832.method_1434()) {
               mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, -(Double)this.speed.getValue(), mc.field_1724.method_18798().field_1350);
            }

            MovementUtils.setSpeedWithStrafe((Double)this.speed.getValue());
            break;
         case 2:
            if (!MovementUtils.hasMovementInput()) {
               return;
            }

            if (mc.field_1724.method_24828()) {
               mc.field_1724.method_6043();
               mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.0D, mc.field_1724.method_18798().field_1350);
            }
            break;
         case 3:
            event.setCancelled(true);
         }
      }

   }

   public WebSpeed() {
      this.speed.setRenderCondition(() -> {
         return this.mode.getValue().equals("Set Speed");
      });
      this.getSettingRepository().registerSettings(this.mode, this.speed);
   }
}
