package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.repository.bot.BotRepository;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.TickEvent;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "AntiBot",
   description = "Prevents Targeting Bots",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class AntiBot extends BaseModule implements QuickImports {
   private final SettingCategory checks = new SettingCategory("Checks");
   private final BooleanSetting moved;
   private final BooleanSetting touchedGround;
   private final BooleanSetting touchedAir;
   private final BooleanSetting swung;
   private final BooleanSetting damaged;
   private final BooleanSetting rotated;
   private final List<BotRepository.Flag> flags;

   public void onModuleDisabled() {
      npcRepository.clear(true, false);
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1687 == null | mc.field_1724 == null) {
            npcRepository.clear(true, true);
            return;
         }

         if (mc.field_1724.field_6012 <= 5) {
            npcRepository.clear(true, true);
         }

         mc.field_1687.method_18456().forEach((player) -> {
            if (player != null) {
               if (!npcRepository.isRegistered(player.method_5820())) {
                  npcRepository.registerPlayer(player.method_5820(), player.method_5667());
               } else {
                  if (player.field_6235 != 0) {
                     npcRepository.addFlags(player.method_5820(), BotRepository.Flag.DAMAGED);
                  }

                  if (player.method_24828()) {
                     npcRepository.addFlags(player.method_5820(), BotRepository.Flag.TOUCHED_GROUND);
                  } else {
                     npcRepository.addFlags(player.method_5820(), BotRepository.Flag.TOUCHED_AIR);
                  }

                  if (player.field_6279 != 0) {
                     npcRepository.addFlags(player.method_5820(), BotRepository.Flag.SWUNG);
                  }

                  if (player.method_23317() != player.field_6014 || player.method_23318() != player.field_6036 || player.method_23321() != player.field_5969) {
                     npcRepository.addFlags(player.method_5820(), BotRepository.Flag.MOVED);
                  }

                  if (player.method_36454() != player.field_5982 || player.method_36455() != player.field_6004) {
                     npcRepository.addFlags(player.method_5820(), BotRepository.Flag.ROTATED);
                  }

               }
            }
         });
         this.addFlag(this.moved.getValue(), BotRepository.Flag.MOVED);
         this.addFlag(this.touchedGround.getValue(), BotRepository.Flag.TOUCHED_GROUND);
         this.addFlag(this.touchedAir.getValue(), BotRepository.Flag.TOUCHED_AIR);
         this.addFlag(this.swung.getValue(), BotRepository.Flag.SWUNG);
         this.addFlag(this.damaged.getValue(), BotRepository.Flag.DAMAGED);
         this.addFlag(this.rotated.getValue(), BotRepository.Flag.ROTATED);
         if (!this.flags.isEmpty()) {
            npcRepository.meetsCriteria(this.flags);
         } else {
            npcRepository.clear(true, false);
         }
      }

   }

   private void addFlag(boolean condition, BotRepository.Flag flag) {
      if (condition) {
         if (!this.flags.contains(flag)) {
            this.flags.add(flag);
         }
      } else {
         this.flags.remove(flag);
      }

   }

   public AntiBot() {
      this.moved = new BooleanSetting(this.checks, "Moved", "Checks if a player has ever moved", false);
      this.touchedGround = new BooleanSetting(this.checks, "Ground", "Checks if a player has ever been on the ground.", false);
      this.touchedAir = new BooleanSetting(this.checks, "Air", "Checks if a player has ever been in the air", false);
      this.swung = new BooleanSetting(this.checks, "Swung", "Checks if a player has swung their hand", false);
      this.damaged = new BooleanSetting(this.checks, "Damaged", "Checks if a player has ever been damaged.", false);
      this.rotated = new BooleanSetting(this.checks, "Rotated", "Checks if a player has ever rotated before.", false);
      this.flags = new ArrayList();
      this.getSettingRepository().registerSettings(this.checks, this.moved, this.touchedGround, this.touchedAir, this.swung, this.damaged, this.rotated);
   }
}
