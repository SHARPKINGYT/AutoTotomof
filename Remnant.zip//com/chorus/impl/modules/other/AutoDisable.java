package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.network.PacketReceiveEvent;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_2856.class_2857;

@ModuleInfo(
   name = "AntiResourcePack",
   description = "Blocks Forced Resource Packs",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class AutoDisable extends BaseModule implements QuickImports {
   @RegisterEvent
   private void PacketReceiveEventListener(PacketReceiveEvent event) {
      if (event.getMode().equals(PacketReceiveEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_2720) {
            class_2720 resourcePackSendS2CPacket = (class_2720)var3;
            event.cancel();
            UUID uuid = mc.field_1724.method_5667();
            mc.method_1562().method_48296().method_10743(new class_2856(uuid, class_2857.field_47704));
            mc.method_1562().method_48296().method_10743(new class_2856(uuid, class_2857.field_13017));
         }
      }

   }
}
