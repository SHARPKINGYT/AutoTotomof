package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.asm.accessors.ChatMessageC2SPacketAccessor;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.network.PacketSendEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2797;

@ModuleInfo(
   name = "ChatBypass",
   description = "Attempts To Bypass Chat Filters",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class ChatBypass extends BaseModule implements QuickImports {
   @RegisterEvent
   private void PacketSendEventListener(PacketSendEvent event) {
      if (event.getMode().equals(PacketSendEvent.Mode.PRE)) {
         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_2797) {
            class_2797 chat = (class_2797)var3;
            String message = chat.comp_945();
            if (!message.startsWith("/") && !message.startsWith("!") && !message.startsWith(".")) {
               String bypassed = this.bypassString(message);
               ((ChatMessageC2SPacketAccessor)chat).setChatMessage(bypassed);
            }
         }
      }

   }

   public String bypassString(String text) {
      return text.replace("a", "á").replace("e", "é").replace("i", "¡").replace("o", "ó").replace("u", "ú").replace("y", "ÿ").replace("A", "Á").replace("E", "É").replace("I", "¡").replace("O", "Ó").replace("U", "Ú").replace("Y", "ÿ");
   }
}
