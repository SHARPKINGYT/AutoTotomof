package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.network.PacketReceiveEvent;
import java.text.DecimalFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2708;

@ModuleInfo(
   name = "FlagDetector",
   description = "detect setback >.<",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class FlagDetector extends BaseModule implements QuickImports {
   @RegisterEvent
   private void packetReceiveEventEventListener(PacketReceiveEvent event) {
      class_2596 var3 = event.getPacket();
      if (var3 instanceof class_2708) {
         class_2708 cPacket = (class_2708)var3;
         new DecimalFormat("#.##");
         notificationManager.addNotification("Set-back Detected", "Forcefully Teleported", 4000);
      }

   }
}
