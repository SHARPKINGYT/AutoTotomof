package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "HorseJump",
   description = "Always Jump perfectly with a horse",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class HorseJump extends BaseModule implements QuickImports {
   @RegisterEvent
   private void Render2DEvent(Render2DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (mc.field_1724.method_45773() != null && mc.field_1690.field_1903.method_1436()) {
            mc.field_1724.method_45773().method_6154(100);
         }

      }
   }
}
