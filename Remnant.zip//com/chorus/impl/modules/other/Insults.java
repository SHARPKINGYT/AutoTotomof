package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_634;

@ModuleInfo(
   name = "Insults",
   description = "Insults Dead Enemies",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class Insults extends BaseModule implements QuickImports {
   public String[] insults = new String[]{" me > u", " ez lol", " ez nn", " resolved hahaha", " gg ez", " quickdropped LOLOLOL", " avg prestige client user", " i mog you", " bagguette enjoyer", " stinky curry muncher", " lt6"};
   boolean dead = false;
   boolean targetdead = false;
   class_1657 player = null;

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if (this.player != mc.field_1724.method_6052() && mc.field_1724.method_6052() != null) {
            this.player = (class_1657)mc.field_1724.method_6052();
            this.dead = false;
         }

         if (this.player != null) {
            if (this.player.method_29504() || this.player.method_6032() == 0.0F) {
               this.dead = true;
               class_634 var10000 = mc.field_1724.field_3944;
               String var10001 = this.player.method_5820().replaceAll("[^a-zA-Z0-9_]", "");
               var10000.method_45729(var10001 + this.insults[MathUtils.randomInt(0, this.insults.length - 1)]);
            }

            if (!this.player.method_36608()) {
               this.dead = false;
               this.player = null;
            }
         }
      }

   }
}
