package com.chorus.impl.modules.other;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "MultiTask",
   description = "Lets you use items and attack at the same time",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class MultiTask extends BaseModule {
}
