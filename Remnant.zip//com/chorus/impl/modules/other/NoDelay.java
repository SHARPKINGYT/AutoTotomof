package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.events.player.BlockBreakingEvent;
import com.chorus.impl.events.player.SwingEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_239;
import net.minecraft.class_3218;
import net.minecraft.class_3966;
import net.minecraft.class_9362;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_239.class_240;

@ModuleInfo(
   name = "NoDelay",
   description = "Removes Delays",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class NoDelay extends BaseModule implements QuickImports {
   private final SettingCategory missDelays = new SettingCategory("Swing Miss Delays");
   private final SettingCategory movementDelays = new SettingCategory("Movement Delays");
   private final SettingCategory itemUseDelays = new SettingCategory("Use Item Delays");
   private final SettingCategory miscellaneousDelays = new SettingCategory("Miscellaneous Delays");
   public final BooleanSetting attackMissDelay;
   public final BooleanSetting miningMissDelay;
   public final BooleanSetting weaponOnly;
   public final BooleanSetting elytraDelay;
   public final BooleanSetting jumpDelay;
   public final NumberSetting<Integer> shieldDelay;
   public final BooleanSetting crystalDelay;
   public final NumberSetting<Integer> miningDelay;

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null) {
         if (event.getMode().equals(TickEvent.Mode.PRE)) {
            if (!this.elytraDelay.getValue()) {
               return;
            }

            boolean hasElytra = mc.field_1724.method_6118(class_1304.field_6174).method_7909().equals(class_1802.field_8833);
            if (!hasElytra) {
               mc.field_1724.method_23670();
            }
         }

      }
   }

   @RegisterEvent
   private void BlockBreakingEventListener(BlockBreakingEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null) {
         if (event.getMode().equals(BlockBreakingEvent.Mode.PRE)) {
            if (!this.miningMissDelay.getValue()) {
               return;
            }

            if (this.weaponOnly.getValue() && !(mc.field_1724.method_6047().method_7909() instanceof class_1829) && !(mc.field_1724.method_6047().method_7909() instanceof class_1835) && !(mc.field_1724.method_6047().method_7909() instanceof class_9362)) {
               return;
            }

            event.setCancelled(mc.field_1765.method_17783() == class_240.field_1332);
         }

      }
   }

   @RegisterEvent
   private void SwingEventListener(SwingEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null) {
         if (event.getMode().equals(SwingEvent.Mode.PRE)) {
            if (!this.attackMissDelay.getValue()) {
               return;
            }

            if (this.weaponOnly.getValue() && !(mc.field_1724.method_6047().method_7909() instanceof class_1829) && !(mc.field_1724.method_6047().method_7909() instanceof class_1835) && !(mc.field_1724.method_6047().method_7909() instanceof class_9362)) {
               return;
            }

            event.setCancelled(!(mc.field_1765 instanceof class_3966));
         }

      }
   }

   @RegisterEvent
   private void AttackEventListener(AttackEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null) {
         if (event.getMode().equals(AttackEvent.Mode.POST)) {
            if (!this.crystalDelay.getValue()) {
               return;
            }

            class_239 var3 = mc.field_1765;
            if (var3 instanceof class_3966) {
               class_3966 entityHitResult = (class_3966)var3;
               class_1297 entity = entityHitResult.method_17782();
               if (entity instanceof class_1511 && entity.method_5805()) {
                  entity.method_5768((class_3218)entity.method_37908());
                  entity.method_5650(class_5529.field_26998);
                  entity.method_36209();
               }
            }
         }

      }
   }

   public NoDelay() {
      this.attackMissDelay = new BooleanSetting(this.missDelays, "Attack Miss", "Removes Attack Miss Delay", false);
      this.miningMissDelay = new BooleanSetting(this.missDelays, "Mining Miss", "Removes Mining Miss Delay", false);
      this.weaponOnly = new BooleanSetting(this.missDelays, "Only Weapons", "Only Removes Delay With Weapons", false);
      this.elytraDelay = new BooleanSetting(this.movementDelays, "Elytra Delay", "Removes Elytra Flying Delay ", false);
      this.jumpDelay = new BooleanSetting(this.movementDelays, "Jump Delay", "Sets Jump Delay", false);
      this.shieldDelay = new NumberSetting(this.itemUseDelays, "Shield Delay", "Sets Shield Delay", 5, 0, 5);
      this.crystalDelay = new BooleanSetting(this.miscellaneousDelays, "Crystal Explode Delay", "Removes Crystal Explode Delay ", false);
      this.miningDelay = new NumberSetting(this.miscellaneousDelays, "Mining Delay", "Removes Mining Delay ", 5, 0, 5);
      this.getSettingRepository().registerSettings(this.missDelays, this.movementDelays, this.itemUseDelays, this.miscellaneousDelays, this.attackMissDelay, this.miningMissDelay, this.weaponOnly, this.elytraDelay, this.jumpDelay, this.shieldDelay, this.crystalDelay, this.miningDelay);
   }
}
