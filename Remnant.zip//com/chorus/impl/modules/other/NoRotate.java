package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.network.PacketReceiveEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2708;

@ModuleInfo(
   name = "NoRotate",
   description = "Blocks Forced Rotations",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class NoRotate extends BaseModule implements QuickImports {
   float yaw = 0.0F;
   float pitch = 0.0F;

   @RegisterEvent
   private void PacketReceiveEventListener(PacketReceiveEvent event) {
      if (event.getMode().equals(PacketReceiveEvent.Mode.PRE)) {
         if (mc.field_1724 == null) {
            return;
         }

         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_2708) {
            class_2708 packet = (class_2708)var3;
            this.yaw = mc.field_1724.method_36454();
            this.pitch = mc.field_1724.method_36455();
         }
      }

   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null) {
            return;
         }

         if (this.yaw != 0.0F || this.pitch != 0.0F) {
            mc.field_1724.method_36456(this.yaw);
            mc.field_1724.method_36457(this.pitch);
            this.yaw = 0.0F;
            this.pitch = 0.0F;
         }
      }

   }
}
