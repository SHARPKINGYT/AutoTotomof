package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.system.notification.NotificationManager;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.PlayerUtils;
import com.chorus.common.util.world.SimulatedPlayer;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.events.player.ItemUseEvent;
import com.chorus.impl.events.player.TickEvent;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1776;
import net.minecraft.class_1802;
import net.minecraft.class_2281;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2531;
import net.minecraft.class_2560;
import net.minecraft.class_3616;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

@ModuleInfo(
   name = "Prevent",
   description = "Prevents Bad Actions",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class Prevent extends BaseModule implements QuickImports {
   public final MultiSetting prevent = new MultiSetting("Prevent", "Set activation conditions", new String[]{"Shield Hit", "Missed Glowstone", "Useless Anchor Charges", "Chest Opening", "Pearl Onto Crystal Hitboxes", "Movement", "Off-Handing", "Dropping"});
   public final MultiSetting movementActions = new MultiSetting("Actions", "Choose what to prevent walking into", new String[]{"Void", "Lava", "Cobweb"});
   public final MultiSetting slots = new MultiSetting("Slot", "Choose Specific Slots", new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"});

   @RegisterEvent
   private void ItemUseEvent(ItemUseEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         class_239 hitResult = mc.field_1765;
         class_3965 blockHitResult = (class_3965)mc.field_1765;
         class_2338 blockPos = blockHitResult.method_17777();
         class_1297 crystal = this.raycastCrystal(6.0D);
         if (crystal != null && InventoryUtils.getMainHandItem().method_7909() instanceof class_1776 && !crystal.method_5829().method_994(mc.field_1724.method_5829()) && this.prevent.getSpecificValue("Pearl Onto Crystal Hitboxes")) {
            event.setCancelled(true);
         }

         if (blockPos != null) {
            if ((mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2336 || mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2281 || mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2531) && this.prevent.getSpecificValue("Chest Opening")) {
               event.setCancelled(true);
            }

            if (InventoryUtils.getMainHandItem().method_7909() == class_1802.field_8801) {
               if (mc.field_1687.method_8320(blockPos).method_26204() instanceof class_4969) {
                  int charges = (Integer)mc.field_1687.method_8320(blockPos).method_11654(class_4969.field_23153);
                  if (charges > 0 && this.prevent.getSpecificValue("Useless Anchor Charges")) {
                     event.setCancelled(true);
                  }
               } else {
                  if (mc.field_1687.method_8320(blockPos.method_10069(1, 1, 0)).method_26204() instanceof class_4969) {
                     return;
                  }

                  if (mc.field_1687.method_8320(blockPos.method_10069(0, 1, 1)).method_26204() instanceof class_4969) {
                     return;
                  }

                  if (mc.field_1687.method_8320(blockPos.method_10069(-1, 1, 0)).method_26204() instanceof class_4969) {
                     return;
                  }

                  if (mc.field_1687.method_8320(blockPos.method_10069(0, 1, -1)).method_26204() instanceof class_4969) {
                     return;
                  }

                  if (this.prevent.getSpecificValue("Missed Glowstone")) {
                     event.setCancelled(true);
                  }
               }
            }

         }
      }
   }

   @RegisterEvent
   private void attackEventListener(AttackEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         class_1297 var3 = event.getTarget();
         if (var3 instanceof class_1657) {
            class_1657 player = (class_1657)var3;
            if (player.method_6039() && !PlayerUtils.isShieldFacingAway(player) && this.prevent.getSpecificValue("Shield Hit")) {
               event.setCancelled(true);
            }
         }

      }
   }

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         for(int i = 0; i <= 8; ++i) {
            if (this.slots.getSpecificValue((i + 1).makeConcatWithConstants<invokedynamic>(i + 1)) && mc.field_1724.method_31548().field_7545 == i) {
               if (this.prevent.getSpecificValue("Dropping")) {
                  mc.field_1690.field_1869.method_23481(false);
               }

               if (this.prevent.getSpecificValue("Off-Handing")) {
                  mc.field_1690.field_1831.method_23481(false);
               }
            }
         }

         SimulatedPlayer simulator = new SimulatedPlayer(mc.field_1724);
         simulator.setInput(mc.field_1690.field_1894.method_1434(), mc.field_1690.field_1881.method_1434(), mc.field_1690.field_1913.method_1434(), mc.field_1690.field_1849.method_1434(), mc.field_1690.field_1903.method_1434(), mc.field_1724.method_5624());

         for(int i = 0; i <= 5; ++i) {
            simulator.tick();
         }

         if (this.prevent.getSpecificValue("Movement")) {
            if (this.movementActions.getSpecificValue("Void")) {
               for(float i = (float)simulator.getPosition().field_1351; i >= -64.0F; --i) {
                  if (!mc.field_1687.method_8320(class_2338.method_49638(new class_243(simulator.getPosition().field_1352, (double)i, simulator.getPosition().field_1350))).method_26215()) {
                     NotificationManager.notificationManager.addNotification("Warning", "You Are Close To Falling Into the void", 2500);
                     return;
                  }
               }
            }

            if (this.movementActions.getSpecificValue("Cobweb") && mc.field_1687.method_8320(class_2338.method_49638(simulator.getPosition())).method_26204() instanceof class_2560) {
               NotificationManager.notificationManager.addNotification("Warning", "u gonna be in the cobweb ho", 2500);
            }

            if (this.movementActions.getSpecificValue("Lava") && mc.field_1687.method_8316(class_2338.method_49638(simulator.getPosition())).method_15772() instanceof class_3616) {
               NotificationManager.notificationManager.addNotification("Warning", "u gonna be in the lava ho", 2500);
            }
         }

      }
   }

   public int convertToSlot(String number) {
      int num = Integer.parseInt(number);
      return num >= 1 && num <= 9 ? 35 + num : -1;
   }

   private class_1297 raycastCrystal(double range) {
      class_243 cameraPos = mc.field_1773.method_19418().method_19326();
      class_243 viewVector = mc.field_1724.method_5663();
      class_243 extendedPoint = cameraPos.method_1031(viewVector.field_1352 * range, viewVector.field_1351 * range, viewVector.field_1350 * range);
      Iterator var6 = mc.field_1687.method_18112().iterator();

      class_1297 entity;
      do {
         if (!var6.hasNext()) {
            return null;
         }

         entity = (class_1297)var6.next();
      } while(!(entity instanceof class_1511) || !entity.method_5829().method_1014(0.225D).method_993(cameraPos, extendedPoint));

      return entity;
   }

   public Prevent() {
      this.slots.setRenderCondition(() -> {
         return this.prevent.getSpecificValue("Off-Handing") || this.prevent.getSpecificValue("Dropping");
      });
      this.movementActions.setRenderCondition(() -> {
         return this.prevent.getSpecificValue("Movement");
      });
      this.getSettingRepository().registerSettings(this.prevent, this.movementActions, this.slots);
   }
}
