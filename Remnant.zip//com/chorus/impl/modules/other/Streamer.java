package com.chorus.impl.modules.other;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "Streamer",
   description = "Hides Your Username",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class Streamer extends BaseModule implements QuickImports {
}
