package com.chorus.impl.modules.other;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.AttackEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;

@ModuleInfo(
   name = "Target",
   description = "Sets Focus On One Enemy",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class Target extends BaseModule implements QuickImports {
   public final NumberSetting<Float> updateTime = new NumberSetting("Enemy Update Time", "Sets Time Before An Enemy is removed (Seconds)", 10.0F, 0.0F, 50.0F);
   public class_1657 enemy = null;
   private final TimerUtils timer = new TimerUtils();

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (this.timer.hasReached((double)(1000.0F * (Float)this.updateTime.getValue()))) {
            this.enemy = null;
         }

         if (this.enemy == null || mc.field_1724 == null) {
            return;
         }

         if (this.enemy.method_29504() || this.enemy.method_6032() == 0.0F || mc.field_1724.method_29504()) {
            this.enemy = null;
         }
      }

   }

   @RegisterEvent
   private void AttackEventListener(AttackEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null) {
         if (event.getMode().equals(AttackEvent.Mode.PRE) && event.getTarget().method_31747() && InputUtils.mouseDown(0)) {
            this.enemy = (class_1657)event.getTarget();
            this.timer.reset();
         }

      }
   }

   protected void onModuleDisabled() {
      this.enemy = null;
   }

   protected void onModuleEnabled() {
   }

   public Target() {
      this.getSettingRepository().registerSetting(this.updateTime);
   }
}
