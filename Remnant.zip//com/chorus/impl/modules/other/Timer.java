package com.chorus.impl.modules.other;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "Timer",
   description = "Speeds up your game",
   category = ModuleCategory.OTHER
)
@Environment(EnvType.CLIENT)
public class Timer extends BaseModule {
   private final SettingCategory general = new SettingCategory("General");
   private final NumberSetting<Double> speed;

   public Timer() {
      this.speed = new NumberSetting(this.general, "Speed", "how fast ya shi", 1.0D, 0.1D, 10.0D);
      this.getSettingRepository().registerSettings(this.general, this.speed);
   }
}
