package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.api.system.rotation.RotationComponent;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.math.rotation.RotationUtils;
import com.chorus.common.util.player.ChatUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.SilentRotationEvent;
import com.chorus.impl.events.player.TickEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2560;
import net.minecraft.class_3965;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "AntiWeb",
   description = "Places Water On Webs",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class AntiWeb extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("Aim");
   private final SettingCategory main = new SettingCategory("General");
   private final ModeSetting aimMode;
   private final BooleanSetting silent;
   private final RangeSetting<Double> horizontalSpeed;
   private final RangeSetting<Double> verticalSpeed;
   private final BooleanSetting includeHead;
   private final RangeSetting<Double> range;
   private final NumberSetting<Integer> webDelay;
   private final NumberSetting<Double> fov;
   private final MultiSetting conditions;
   private final TimerUtils waitTimer;
   private boolean grabWater;

   @RegisterEvent
   private void Render3DEventListener(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_1657 enemy = mc.field_1724;
         rotationComponent.setHorizontalSpeed(this.horizontalSpeed.getRandomValue().floatValue());
         rotationComponent.setVerticalSpeed(this.verticalSpeed.getRandomValue().floatValue());
         rotationComponent.setSilentRotation(this.silent.getValue());
         class_243 feetPos = this.getBestPlacementSpot(enemy);
         if (!this.waitTimer.hasReached((double)((Integer)this.webDelay.getValue() * 1000))) {
            return;
         }

         if (this.checkConditions()) {
            return;
         }

         if (feetPos != null) {
            Render3DEngine.renderOutlinedBox(feetPos.method_1023(0.0D, 0.5D, 0.0D), Color.RED, event.getMatrices(), 0.5F, 1.0F);
            float[] rotation = getRotationToBlock(feetPos.method_1023(0.0D, 0.5D, 0.0D), class_2350.field_11036, enemy, event.getMatrices());
            rotationComponent.queueRotation((float[])Objects.requireNonNullElseGet(rotation, () -> {
               return new float[]{mc.field_1724.method_36454(), mc.field_1724.method_36455()};
            }), RotationComponent.RotationPriority.HIGH, this.getAimMode());
         }
      }

   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (!event.getMode().equals(TickEvent.Mode.POST)) {
            class_239 hitResult = mc.field_1765;
            class_243 feetPos = this.getBestPlacementSpot(mc.field_1724);
            if (feetPos == null) {
               if (this.grabWater) {
                  ChatUtils.sendFormattedMessage("grabbed  2water item");
                  InputUtils.simulateClick(1, 50);
                  this.grabWater = false;
               }

            } else {
               if (hitResult instanceof class_3965) {
                  class_3965 blockHitResult = (class_3965)hitResult;
                  if (!this.grabWater && blockHitResult.method_17780() == class_2350.field_11036 && mc.field_1687.method_8320(blockHitResult.method_17777()).method_26204() instanceof class_2560) {
                     if (InventoryUtils.getMainHandItem().method_7909() != class_1802.field_8705) {
                        InventoryUtils.swap(class_1802.field_8705);
                        return;
                     }

                     ChatUtils.sendFormattedMessage("use item");
                     InputUtils.simulateClick(1, 1);
                     this.waitTimer.reset();
                     this.grabWater = true;
                  }
               }

            }
         }
      }
   }

   @RegisterEvent(1)
   private void silentRotationEventEventListener(SilentRotationEvent event) {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         ;
      }
   }

   private RotationComponent.AimType getAimMode() {
      String var1 = this.aimMode.getValue();
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -2018804923:
         if (var1.equals("Linear")) {
            var2 = 2;
         }
         break;
      case -1543850116:
         if (var1.equals("Regular")) {
            var2 = 0;
         }
         break;
      case -1241367914:
         if (var1.equals("Adaptive")) {
            var2 = 1;
         }
         break;
      case 1630783146:
         if (var1.equals("Blatant")) {
            var2 = 3;
         }
      }

      RotationComponent.AimType var10000;
      switch(var2) {
      case 0:
         var10000 = RotationComponent.AimType.REGULAR;
         break;
      case 1:
         var10000 = RotationComponent.AimType.ADAPTIVE;
         break;
      case 2:
         var10000 = RotationComponent.AimType.LINEAR;
         break;
      case 3:
         var10000 = RotationComponent.AimType.BLATANT;
         break;
      default:
         var10000 = RotationComponent.AimType.REGULAR;
      }

      return var10000;
   }

   private boolean checkConditions() {
      String[] var1 = new String[]{"Holding Weapon", "Clicking", "Break Blocks"};
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String check = var1[var3];
         byte var7 = -1;
         switch(check.hashCode()) {
         case 971106682:
            if (check.equals("Clicking")) {
               var7 = 1;
            }
            break;
         case 1463209991:
            if (check.equals("Break Blocks")) {
               var7 = 2;
            }
            break;
         case 1625121847:
            if (check.equals("Holding Web")) {
               var7 = 0;
            }
         }

         boolean var10000;
         switch(var7) {
         case 0:
            if (this.conditions.getSpecificValue(check) && mc.field_1724.method_31548().method_7391().method_7909().equals(class_1802.field_8705)) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         case 1:
            if (this.conditions.getSpecificValue(check) && InputUtils.mouseDown(1)) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         case 2:
            if (this.conditions.getSpecificValue(check) && mc.field_1761.method_2923()) {
               var10000 = true;
               break;
            }

            var10000 = false;
            break;
         default:
            var10000 = false;
         }

         boolean isTrue = var10000;
         if (isTrue) {
            return true;
         }
      }

      return false;
   }

   public class_243 getBestPlacementSpot(class_1657 player) {
      class_243 feetPosition = player.method_19538();
      LinkedHashSet<class_243> feetPositions = new LinkedHashSet();
      class_238 bBox = player.method_5829();

      class_243 position;
      for(float xOffset = -1.0F; xOffset <= 1.0F; ++xOffset) {
         for(float zOffset = -1.0F; zOffset <= 1.0F; ++zOffset) {
            float offset = (float)(bBox.method_995() / 2.0D);
            class_2338 feetPos = class_2338.method_49638(new class_243(feetPosition.field_1352 + (double)xOffset, feetPosition.field_1351, feetPosition.field_1350 + (double)zOffset));
            position = feetPos.method_46558();
            if (mc.field_1687.method_8320(feetPos).method_26204() instanceof class_2560 && bBox.method_1003(position.field_1352 - (double)offset, position.field_1351 - (double)offset, position.field_1350 - (double)offset, position.field_1352 + (double)offset, position.field_1351 + (double)offset, position.field_1350 + (double)offset)) {
               feetPositions.add(feetPos.method_46558());
            }
         }
      }

      class_243 bestPosition = null;
      if (!feetPositions.isEmpty()) {
         double distance = Double.MAX_VALUE;
         Iterator var14 = feetPositions.iterator();

         while(var14.hasNext()) {
            position = (class_243)var14.next();
            double distanceToEnemy = position.method_1022(player.method_19538());
            if (distanceToEnemy < distance) {
               bestPosition = position;
               distance = distanceToEnemy;
            }
         }
      }

      return bestPosition;
   }

   public static float[] getRotationToBlock(class_243 blockPos, class_2350 direction, class_1657 entity, class_4587 matrixStack) {
      class_243 playerPos = mc.field_1724.method_19538().method_1031(0.0D, (double)mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D);
      class_243 pos = null;
      class_238 bBox = entity.method_5829();
      double distance = Double.MAX_VALUE;

      for(float xOffset = -0.45F; xOffset <= 0.45F; xOffset += 0.05F) {
         for(float zOffset = -0.45F; zOffset <= 0.45F; zOffset += 0.05F) {
            class_243 target = blockPos.method_1031((double)((float)direction.method_10148() - xOffset), (double)((float)direction.method_10164() + 0.05F), (double)((float)direction.method_10165() - zOffset));
            class_239 var13 = RotationUtils.rayTraceWithCobwebs(target);
            if (var13 instanceof class_3965) {
               class_3965 blockHitResult = (class_3965)var13;
               if (blockHitResult.method_17777().equals(class_2338.method_49638(target)) && !bBox.method_1003(target.field_1352, target.field_1351, target.field_1350, target.field_1352, target.field_1351 + 1.0D, target.field_1350) && playerPos.method_1022(target) < distance) {
                  distance = playerPos.method_1022(target);
                  pos = target;
               }
            }
         }
      }

      if (pos == null) {
         return null;
      } else {
         Render3DEngine.renderShadedBox(blockPos, Color.white, 50, matrixStack, 0.5F, 1.0F);
         Render3DEngine.renderShadedBox(pos, Color.red, 50, matrixStack, 0.05F, 0.1F);
         class_243 delta = pos.method_1020(playerPos);
         double distanceXZ = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);
         float yaw = (float)Math.toDegrees(Math.atan2(delta.field_1350, delta.field_1352)) - 90.0F;
         float pitch = (float)(-Math.toDegrees(Math.atan2(delta.field_1351, distanceXZ)));
         return new float[]{yaw, pitch};
      }
   }

   public AntiWeb() {
      this.aimMode = new ModeSetting(this.general, "Aim Mode", "Select the aiming behavior", "Regular", new String[]{"Regular", "Adaptive", "Linear", "Blatant"});
      this.silent = new BooleanSetting(this.general, "Silent Rotations", "Rotates Silently", true);
      this.horizontalSpeed = new RangeSetting(this.general, "Horizontal Aim Speed", "Adjust the speed", 0.0D, 100.0D, 30.0D, 50.0D);
      this.verticalSpeed = new RangeSetting(this.general, "Vertical Aim Speed", "Adjust the speed", 0.0D, 100.0D, 30.0D, 50.0D);
      this.includeHead = new BooleanSetting("Include Head", "Blocks the enemies head too", false);
      this.range = new RangeSetting(this.main, "Range", "Set the maximum distance", 0.0D, 12.0D, 1.0D, 3.5D);
      this.webDelay = new NumberSetting(this.main, "Web Delay", "Adjust the of the autoweb (in seconds)", 10, 0, 100);
      this.fov = new NumberSetting(this.main, "FOV", "Define the field of view for target detection", 90.0D, 0.0D, 360.0D);
      this.conditions = new MultiSetting(this.main, "Conditions", "Set activation conditions", new String[]{"Clicking", "Holding Web", "Break Blocks", "Not When Affects Player"});
      this.waitTimer = new TimerUtils();
      this.grabWater = false;
      this.getSettingRepository().registerSettings(this.general, this.main, this.aimMode, this.silent, this.horizontalSpeed, this.verticalSpeed, this.includeHead, this.webDelay, this.range, this.fov, this.conditions);
   }
}
