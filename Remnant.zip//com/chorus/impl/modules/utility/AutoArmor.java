package com.chorus.impl.modules.utility;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "AutoArmor",
   description = "Automatically Equips The Best Armor",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class AutoArmor extends BaseModule implements QuickImports {
}
