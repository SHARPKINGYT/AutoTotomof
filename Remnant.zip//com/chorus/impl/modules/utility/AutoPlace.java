package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1747;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

@ModuleInfo(
   name = "AutoPlace",
   description = "Places blocks automatically",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class AutoPlace extends BaseModule implements QuickImports {
   private final NumberSetting<Integer> delay = new NumberSetting((SettingCategory)null, "Delay", "Delay between placements in milliseconds", 50, 0, 1000);
   private final BooleanSetting holdRight = new BooleanSetting((SettingCategory)null, "Hold Right", "Continuously place while holding right click", true);
   private long lastPlaceTime = 0L;
   private class_2338 lastPlacedPos = null;

   public AutoPlace() {
      this.getSettingRepository().registerSettings(this.delay, this.holdRight);
   }

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (event.getMode() == TickEvent.Mode.PRE) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if (this.holdRight.getValue() && !InputUtils.mouseDown(1)) {
            return;
         }

         if (!(mc.field_1724.method_6047().method_7909() instanceof class_1747)) {
            return;
         }

         long currentTime = System.currentTimeMillis();
         if (currentTime - this.lastPlaceTime < (long)(Integer)this.delay.getValue()) {
            return;
         }

         class_239 var5 = mc.field_1765;
         if (var5 instanceof class_3965) {
            class_3965 hitResult = (class_3965)var5;
            class_2350 side = hitResult.method_17780();
            if (side != class_2350.field_11036 && side != class_2350.field_11033) {
               class_2338 pos = hitResult.method_17777();
               class_2680 state = mc.field_1687.method_8320(pos);
               if (state.method_26204() != class_2246.field_10124 && !state.method_26227().method_15769()) {
                  return;
               }

               if (this.lastPlacedPos != null && this.lastPlacedPos.equals(pos)) {
                  return;
               }

               InputUtils.simulatePress(1);
               mc.field_1752 = 0;
               mc.field_1761.method_2896(mc.field_1724, mc.field_1724.method_6058(), hitResult);
               mc.field_1724.method_6104(mc.field_1724.method_6058());
               InputUtils.simulateRelease(1);
               this.lastPlacedPos = pos;
               this.lastPlaceTime = currentTime;
            }
         }
      }

   }
}
