package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.common.util.world.BlockUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1743;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1820;
import net.minecraft.class_1821;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;

@ModuleInfo(
   name = "AutoTool",
   description = "Switches To Best Mining Tool",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class AutoTool extends BaseModule implements QuickImports {
   private final SettingCategory behaviorSettings = new SettingCategory("Behavior");
   private final SettingCategory conditionsSettings = new SettingCategory("Conditions");
   private final BooleanSetting switchBack;
   private final NumberSetting<Integer> activationTime;
   private final NumberSetting<Integer> switchBackTime;
   private final MultiSetting conditions;
   private int originalSlot;
   private boolean isMining;
   private TimerUtils switchBackTimer;
   private TimerUtils miningTimer;

   @RegisterEvent
   private void tickEventEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null && mc.field_1755 == null) {
         if (InputUtils.mouseDown(0)) {
            if (this.miningTimer.hasReached((double)(Integer)this.activationTime.getValue()) && mc.field_1761.method_2923()) {
               if (this.originalSlot == -1) {
                  this.originalSlot = mc.field_1724.method_31548().field_7545;
               }

               this.isMining = true;
            }

            this.switchBackTimer.reset();
         } else {
            this.miningTimer.reset();
            if (this.isMining && this.switchBackTimer.hasReached((double)(Integer)this.switchBackTime.getValue())) {
               this.isMining = false;
               if (this.switchBack.getValue() && this.originalSlot != -1 && this.switchBackTimer.hasReached((double)(Integer)this.switchBackTime.getValue())) {
                  InventoryUtils.swapToMainHand(this.originalSlot);
                  this.originalSlot = -1;
               }
            }
         }

         if (!this.conditions.getSpecificValue("Only While Sneaking") || mc.field_1724.method_5715()) {
            if (!this.conditions.getSpecificValue("Not In Water") || !BlockUtils.isLiquid(mc.field_1724.method_24515())) {
               if (!this.conditions.getSpecificValue("Not In Lava") || !mc.field_1724.method_5771()) {
                  class_3965 hitResult = mc.field_1765 instanceof class_3965 ? (class_3965)mc.field_1765 : null;
                  if (mc.field_1765.method_17783() == class_240.field_1332) {
                     class_2338 pos = hitResult.method_17777();
                     class_2680 state = mc.field_1687.method_8320(pos);
                     if (BlockUtils.isBreakable(pos)) {
                        if (this.isMining) {
                           int bestSlot = -1;
                           float bestSpeed = 0.0F;

                           for(int i = 0; i < 9; ++i) {
                              class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                              if (!stack.method_7960()) {
                                 float speed = stack.method_7924(state);
                                 if ((stack.method_7909() instanceof class_1820 || stack.method_7909() instanceof class_1743 || stack.method_7909() instanceof class_1821 || stack.method_7909() instanceof class_1810 || stack.method_7909() instanceof class_1794) && speed > bestSpeed) {
                                    bestSpeed = speed;
                                    bestSlot = i;
                                 }
                              }
                           }

                           if (bestSlot != -1 && bestSlot != mc.field_1724.method_31548().field_7545) {
                              InventoryUtils.swapToMainHand(bestSlot);
                           }
                        }

                     }
                  }
               }
            }
         }
      }
   }

   public AutoTool() {
      this.switchBack = new BooleanSetting(this.behaviorSettings, "Switch Back", "", true);
      this.activationTime = new NumberSetting(this.behaviorSettings, "Activation Time", "", 50, 0, 1000);
      this.switchBackTime = new NumberSetting(this.behaviorSettings, "Switch Back Time", "", 250, 0, 1000);
      this.conditions = new MultiSetting(this.conditionsSettings, "Conditionals", "Set Conditions To Switch", new String[]{"Only While Sneaking", "Not In Lava", "Not In Water"});
      this.originalSlot = -1;
      this.isMining = false;
      this.switchBackTimer = new TimerUtils();
      this.miningTimer = new TimerUtils();
      this.getSettingRepository().registerSettings(this.behaviorSettings, this.conditionsSettings, this.switchBack, this.activationTime, this.switchBackTime, this.conditions);
   }
}
