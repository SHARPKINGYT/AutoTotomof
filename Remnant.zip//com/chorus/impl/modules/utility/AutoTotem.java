package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.asm.accessors.HandledScreenAccessor;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_490;

@ModuleInfo(
   name = "AutoTotem",
   description = "Automatically Places Totems In Offhand",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class AutoTotem extends BaseModule implements QuickImports {
   private final TimerUtils openTimer = new TimerUtils();
   private final TimerUtils totemTimer = new TimerUtils();
   private final ModeSetting swapMode = new ModeSetting("Swap Mode", "Select the totem swap type", "Hover", new String[]{"Hover", "Find"});

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1687 == null | mc.field_1724 == null) {
            return;
         }

         if (InventoryUtils.findItemInStrictlyInventory(class_1802.field_8288) == -1) {
            return;
         }

         if (!(mc.field_1755 instanceof class_465)) {
            this.openTimer.reset();
            return;
         }

         this.swap(true);
      }

   }

   public void swap(boolean offhand) {
      if (!(mc.field_1687 == null | mc.field_1724 == null)) {
         if (this.openTimer.hasReached(100.0D)) {
            if (this.totemTimer.hasReached(100.0D)) {
               int slot = InventoryUtils.findItemInStrictlyInventory(class_1802.field_8288);
               int mainSlot = 0;
               class_437 var5 = mc.field_1755;
               if (var5 instanceof class_490) {
                  class_490 inv = (class_490)var5;
                  String var8 = this.swapMode.getValue();
                  byte var6 = -1;
                  switch(var8.hashCode()) {
                  case 2189785:
                     if (var8.equals("Find")) {
                        var6 = 1;
                     }
                     break;
                  case 69916956:
                     if (var8.equals("Hover")) {
                        var6 = 0;
                     }
                  }

                  switch(var6) {
                  case 0:
                     class_1735 focusedSlot = ((HandledScreenAccessor)inv).getFocusedSlot();
                     if (focusedSlot != null && focusedSlot.method_7681() && focusedSlot.method_7677().method_7909() == class_1802.field_8288 && focusedSlot.field_7874 != 40) {
                        if (offhand) {
                           InventoryUtils.swapItemToOffhand(focusedSlot.field_7874);
                           this.totemTimer.reset();
                        } else if (mc.field_1724.method_31548().method_5438(mainSlot).method_7909() != class_1802.field_8288 && mc.field_1724.method_31548().method_5438(mainSlot).method_7960()) {
                           mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, focusedSlot.field_7874, mainSlot, class_1713.field_7791, mc.field_1724);
                           this.totemTimer.reset();
                        }
                     }
                     break;
                  case 1:
                     if (offhand) {
                        InventoryUtils.swapItemToOffhand(slot);
                        this.totemTimer.reset();
                     } else if (mc.field_1724.method_31548().method_5438(mainSlot).method_7909() != class_1802.field_8288 && mc.field_1724.method_31548().method_5438(mainSlot).method_7960()) {
                        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, mainSlot, class_1713.field_7791, mc.field_1724);
                        this.totemTimer.reset();
                     }
                  }
               }

            }
         }
      }
   }

   public AutoTotem() {
      this.getSettingRepository().registerSettings(this.swapMode);
   }
}
