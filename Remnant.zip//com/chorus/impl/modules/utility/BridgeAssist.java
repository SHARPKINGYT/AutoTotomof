package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1747;
import net.minecraft.class_243;

@ModuleInfo(
   name = "BridgeAssist",
   description = "Helps you bridge",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class BridgeAssist extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final SettingCategory conditions = new SettingCategory("Conditionals");
   private final RangeSetting<Double> edgeOffset;
   private final RangeSetting<Double> unsneakDelay;
   private final MultiSetting settings;
   private final TimerUtils unsneakTimer;
   boolean sneaked;

   public BridgeAssist() {
      this.edgeOffset = new RangeSetting(this.general, "Edge Offset", "Adjust Edge Offset", 0.01D, 0.3D, 0.2D, 0.25D);
      this.unsneakDelay = new RangeSetting(this.general, "Un-Sneak Delay", "Set Un-Sneaking Delay", 0.0D, 500.0D, 250.0D, 300.0D);
      this.settings = new MultiSetting(this.conditions, "Activation", "Set activation conditions", new String[]{"Looking Down", "Already Sneaking", "Not While Moving Forward", "Holding Blocks", "Above Air"});
      this.unsneakTimer = new TimerUtils();
      this.sneaked = false;
      this.getSettingRepository().registerSettings(this.general, this.conditions, this.edgeOffset, this.unsneakDelay, this.settings);
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1765 == null) {
            return;
         }

         if (!this.canAssist()) {
            if (this.sneaked) {
               mc.field_1690.field_1832.method_23481(false);
               this.sneaked = false;
            }

            return;
         }

         class_243 pos = mc.field_1724.method_19538();
         double xOffset = 0.5D - ((double)Math.round(pos.field_1352) + 0.5D - pos.field_1352);
         double zOffset = 0.5D - ((double)Math.round(pos.field_1350) + 0.5D - pos.field_1350);
         double offset;
         if (mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_45474()) {
            offset = MathUtils.randomDouble((Double)this.edgeOffset.getValueMin(), (Double)this.edgeOffset.getValueMax());
            if (!(xOffset <= offset) && !(zOffset <= offset)) {
               mc.field_1690.field_1832.method_23481(false);
            } else {
               mc.field_1690.field_1832.method_23481(true);
               if (!this.sneaked) {
                  this.unsneakTimer.reset();
               }

               this.sneaked = true;
            }
         } else {
            offset = MathUtils.randomDouble((Double)this.unsneakDelay.getValueMin(), (Double)this.unsneakDelay.getValueMax());
            if (this.unsneakTimer.hasReached(offset) && this.sneaked) {
               mc.field_1690.field_1832.method_23481(false);
               this.sneaked = false;
            }
         }
      }

   }

   public boolean canAssist() {
      if (this.settings.getSpecificValue("Looking Down") && !(mc.field_1724.method_36455() > 70.0F)) {
         return false;
      } else if (!mc.field_1724.method_24828()) {
         return false;
      } else if (this.settings.getSpecificValue("Already Sneaking") && !InputUtils.keyDown(mc.field_1690.field_1832.method_1429().method_1444())) {
         return false;
      } else if (this.settings.getSpecificValue("Not While Moving Forward") && InputUtils.keyDown(mc.field_1690.field_1894.method_1429().method_1444())) {
         return false;
      } else if (this.settings.getSpecificValue("Holding Blocks") && !(mc.field_1724.method_31548().method_7391().method_7909() instanceof class_1747) && !(InventoryUtils.getOffHandItem().method_7909() instanceof class_1747)) {
         return false;
      } else {
         return !this.settings.getSpecificValue("Above Air") || mc.field_1687.method_8320(mc.field_1724.method_24515().method_10069(0, -5, 0)).method_26215();
      }
   }
}
