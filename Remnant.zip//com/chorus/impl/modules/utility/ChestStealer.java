package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1738;
import net.minecraft.class_1747;
import net.minecraft.class_1766;
import net.minecraft.class_1776;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1829;
import net.minecraft.class_1839;

@ModuleInfo(
   name = "ChestStealer",
   description = "Steals Items Out of Chests",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class ChestStealer extends BaseModule implements QuickImports {
   private final RangeSetting<Integer> delay = new RangeSetting("Steal Delay", "Delay to Steal Items", 0, 250, 100, 100);
   private final BooleanSetting relevantItems = new BooleanSetting("Only Relevant Items", "", false);
   private final TimerUtils waitTimer = new TimerUtils();

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1687 == null | mc.field_1724 == null) {
            return;
         }

         class_1703 var3 = mc.field_1724.field_7512;
         if (!(var3 instanceof class_1707)) {
            return;
         }

         class_1707 inventory = (class_1707)var3;
         if (InventoryUtils.isInventoryFull()) {
            return;
         }

         for(int i = 0; i < inventory.method_7629().method_5439(); ++i) {
            if (inventory.method_7611(i).method_7677().method_7960()) {
               if (i == inventory.method_7629().method_5439() - 1) {
                  mc.field_1724.method_7346();
               }
            } else {
               if (!this.waitTimer.hasReached((double)this.delay.getRandomValue().intValue())) {
                  return;
               }

               if (this.isRelevant(inventory.method_7611(i).method_7677()) || !this.relevantItems.getValue()) {
                  mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, i, 0, class_1713.field_7794, mc.field_1724);
                  this.waitTimer.reset();
               }
            }
         }
      }

   }

   private boolean isRelevant(class_1799 stack) {
      return stack.method_7909() instanceof class_1829 || stack.method_7976().equals(class_1839.field_8950) || stack.method_7909() instanceof class_1738 || stack.method_7909() instanceof class_1766 || stack.method_7909() instanceof class_1776 || stack.method_7909() instanceof class_1747 || stack.method_7909() instanceof class_1787 || stack.method_7909() instanceof class_1812;
   }

   public ChestStealer() {
      this.getSettingRepository().registerSettings(this.delay, this.relevantItems);
   }
}
