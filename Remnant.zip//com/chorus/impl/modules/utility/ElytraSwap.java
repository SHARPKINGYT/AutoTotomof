package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

@ModuleInfo(
   name = "ElytraSwap",
   description = "Swaps Elytra Automatically",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class ElytraSwap extends BaseModule implements QuickImports {
   private final BooleanSetting fireworkBoost = new BooleanSetting("Boost With Fireworks", "Uses a firework for you", false);
   boolean startedWithElytra = false;
   int originalSlot = -1;
   boolean swapped = false;
   boolean resetJump = false;

   @RegisterEvent
   private void tickEventListener(TickEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_1792 mainHand = InventoryUtils.getMainHandItem().method_7909();
         boolean wearingElytra = mc.field_1724.method_31548().method_7372(2).method_7909() == class_1802.field_8833;
         int slot;
         if (!this.swapped) {
            if (this.holdingChestplate() && this.startedWithElytra || mainHand.equals(class_1802.field_8833) && !this.startedWithElytra) {
               InputUtils.simulateClick(1, 50);
               this.swapped = true;
            } else {
               slot = this.startedWithElytra ? this.chestplateSlot() : InventoryUtils.findItemWithPredicateInHotbar((ItemStack) -> {
                  return ItemStack.method_7909().equals(class_1802.field_8833);
               });
               if (slot == -1) {
                  Chorus.getInstance().getModuleManager().toggleModule(ElytraSwap.class);
               } else {
                  InventoryUtils.swapToMainHand(slot);
               }
            }
         }

         if (this.startedWithElytra != wearingElytra && this.swapped) {
            if (this.fireworkBoost.getValue() && wearingElytra) {
               slot = InventoryUtils.findItemWithPredicateInHotbar((ItemStack) -> {
                  return ItemStack.method_7909().equals(class_1802.field_8639);
               });
               if (!mainHand.equals(class_1802.field_8639)) {
                  if (slot == -1) {
                     this.resetJump = true;
                     this.reset();
                  } else {
                     InventoryUtils.swapToMainHand(slot);
                  }
               }

               if (mc.field_1724.method_6128()) {
                  if (mainHand.equals(class_1802.field_8639)) {
                     InputUtils.simulateClick(1, 35);
                     if (this.originalSlot != -1) {
                        InventoryUtils.swapToMainHand(this.originalSlot);
                     }
                  }

                  if (mc.field_1724.method_6003() == 2) {
                     this.reset();
                  }
               } else {
                  this.resetJump = true;
                  mc.field_1690.field_1903.method_23481(mc.field_1724.method_18798().field_1351 < 0.0D || mc.field_1724.method_24828());
                  mc.field_1724.field_6017 = 0.0F;
               }
            } else {
               if (this.originalSlot != -1) {
                  InventoryUtils.swapToMainHand(this.originalSlot);
               }

               this.reset();
            }
         }

      }
   }

   private void reset() {
      this.swapped = false;
      Chorus.getInstance().getModuleManager().toggleModule(ElytraSwap.class);
      if (this.resetJump) {
         mc.field_1690.field_1903.method_23481(false);
      }

      this.originalSlot = -1;
   }

   private boolean holdingChestplate() {
      class_1792 mainHand = InventoryUtils.getMainHandItem().method_7909();
      return mainHand == class_1802.field_22028 || mainHand == class_1802.field_8873 || mainHand == class_1802.field_8523 || mainHand == class_1802.field_8678 || mainHand == class_1802.field_8058 || mainHand == class_1802.field_8577;
   }

   private int chestplateSlot() {
      class_1661 inv = mc.field_1724.method_31548();

      for(int i = 0; i <= 8; ++i) {
         if (inv.method_5438(i).method_31574(class_1802.field_22028) || inv.method_5438(i).method_31574(class_1802.field_8873) || inv.method_5438(i).method_31574(class_1802.field_8523) || inv.method_5438(i).method_31574(class_1802.field_8678) || inv.method_5438(i).method_31574(class_1802.field_8058) || inv.method_5438(i).method_31574(class_1802.field_8577)) {
            return i;
         }
      }

      return -1;
   }

   protected void onModuleEnabled() {
      this.swapped = false;
      if (mc.field_1724.method_6047().method_7909() != class_1802.field_8833) {
         this.originalSlot = mc.field_1724.method_31548().field_7545;
      }

      this.startedWithElytra = mc.field_1724.method_31548().method_7372(2).method_7909() == class_1802.field_8833;
   }

   public ElytraSwap() {
      this.getSettingRepository().registerSettings(this.fireworkBoost);
   }
}
