package com.chorus.impl.modules.utility;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_745;
import net.minecraft.class_1297.class_5529;

@ModuleInfo(
   name = "FakePlayer",
   description = "Spawn Fake Player",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class FakePlayer extends BaseModule implements QuickImports {
   public static class_745 fakePlayer;

   protected void onModuleEnabled() {
      fakePlayer = new class_745(mc.field_1687, new GameProfile(UUID.fromString("43b3ea67-5318-40d2-bbd5-dfbb80e1cb6a"), "ionreal"));
      fakePlayer.method_5719(mc.field_1724);
      mc.field_1687.method_53875(fakePlayer);
      fakePlayer.method_6092(new class_1293(class_1294.field_5907, 511100, 255));
   }

   protected void onModuleDisabled() {
      if (fakePlayer != null) {
         fakePlayer.method_31745(class_5529.field_26998);
         fakePlayer.method_36209();
         fakePlayer = null;
      }
   }
}
