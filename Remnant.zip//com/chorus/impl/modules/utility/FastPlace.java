package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.impl.events.player.ItemUseCooldownEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1747;

@ModuleInfo(
   name = "Fastplace",
   description = "Removes Place Speed Limit",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class FastPlace extends BaseModule implements QuickImports {
   private final SettingCategory generalSettings = new SettingCategory("General Settings");
   private final NumberSetting<Integer> speed;
   private final BooleanSetting onlyBlocks;

   @RegisterEvent
   private void itemUseCooldownEventEventListener(ItemUseCooldownEvent event) {
      if (!this.onlyBlocks.getValue() || InventoryUtils.getMainHandItem().method_7909() instanceof class_1747 || InventoryUtils.getOffHandItem().method_7909() instanceof class_1747) {
         event.setSpeed((Integer)this.speed.getValue());
      }
   }

   public FastPlace() {
      this.speed = new NumberSetting(this.generalSettings, "Speed", "", 4, 0, 4);
      this.onlyBlocks = new BooleanSetting(this.generalSettings, "Only Blocks", "", true);
      this.getSettingRepository().registerSettings(this.generalSettings, this.speed, this.onlyBlocks);
   }
}
