package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.common.util.player.DamageUtils;
import com.chorus.impl.events.player.TickEvent;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1747;
import net.minecraft.class_1766;
import net.minecraft.class_1776;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1812;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1839;
import net.minecraft.class_1893;
import net.minecraft.class_3489;
import net.minecraft.class_490;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_9285.class_9287;

@ModuleInfo(
   name = "InventoryManager",
   description = "Manages Your Inventory",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class InventoryManager extends BaseModule implements QuickImports {
   private final RangeSetting<Integer> delay = new RangeSetting("Delay", "Delay to Manage Items", 0, 500, 250, 200);
   private final BooleanSetting throwJunk = new BooleanSetting("Throw Junk", "Throw Not Needed Items", false);
   private final BooleanSetting goldTools = new BooleanSetting("Ignore Gold", "Set golden tools priority less when managing inventory", false);
   private final ModeSetting swordSlot = new ModeSetting("Sword Slot", "Choose Which Slot the sword is in", "1", new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"});
   private final ModeSetting pickaxeSlot = new ModeSetting("Pickaxe Slot", "Choose Which Slot the sword is in", "3", new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"});
   private final ModeSetting axeSlot = new ModeSetting("Axe Slot", "Choose Which Slot the sword is in", "4", new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"});
   private final ModeSetting shovelSlot = new ModeSetting("Shovel Slot", "Choose Which Slot the sword is in", "5", new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"});
   private final TimerUtils waitTimer = new TimerUtils();

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (!(mc.field_1687 == null | mc.field_1724 == null)) {
            if (mc.field_1755 instanceof class_490) {
               if (this.waitTimer.hasReached((double)this.delay.getRandomValue().floatValue())) {
                  class_1703 screenHandler = mc.field_1724.field_7512;
                  class_1735 bestSword = null;
                  class_1735 bestPickaxe = null;
                  class_1735 bestAxe = null;
                  class_1735 bestShovel = null;
                  int convertedSword = Integer.parseInt(this.swordSlot.getValue()) - 1;
                  int convertedPickaxe = Integer.parseInt(this.pickaxeSlot.getValue()) - 1;
                  int convertedAxe = Integer.parseInt(this.axeSlot.getValue()) - 1;
                  int convertedShovel = Integer.parseInt(this.shovelSlot.getValue()) - 1;
                  Iterator var11 = screenHandler.field_7761.iterator();

                  while(true) {
                     class_1735 slot;
                     class_1799 stack;
                     do {
                        do {
                           do {
                              if (!var11.hasNext()) {
                                 var11 = screenHandler.field_7761.iterator();

                                 label145:
                                 while(true) {
                                    do {
                                       do {
                                          if (!var11.hasNext()) {
                                             break label145;
                                          }

                                          slot = (class_1735)var11.next();
                                          if (!this.throwJunk.getValue()) {
                                             break label145;
                                          }
                                       } while(slot.method_7677().method_7960());

                                       if (!this.waitTimer.hasReached((double)this.delay.getRandomValue().floatValue())) {
                                          break label145;
                                       }
                                    } while(!(slot.method_7677().method_7909() instanceof class_1766) && !(slot.method_7677().method_7909() instanceof class_1829));

                                    if (slot != bestSword && slot != bestPickaxe && slot != bestAxe && slot != bestShovel) {
                                       mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot.field_7874, 0, class_1713.field_7795, mc.field_1724);
                                       this.waitTimer.reset();
                                    }
                                 }

                                 class_1799 currentShovel;
                                 if (bestSword != null) {
                                    currentShovel = mc.field_1724.method_31548().method_5438(convertedSword);
                                    if (currentShovel.method_7960() || this.isBetterSword(currentShovel, bestSword.method_7677())) {
                                       this.swap(bestSword.field_7874, this.convertToSlot(this.swordSlot.getValue()), this.throwJunk.getValue());
                                    }
                                 }

                                 if (bestPickaxe != null) {
                                    currentShovel = mc.field_1724.method_31548().method_5438(convertedPickaxe);
                                    if (currentShovel.method_7960() || this.isBetterTool(currentShovel, bestPickaxe.method_7677())) {
                                       this.swap(bestPickaxe.field_7874, this.convertToSlot(this.pickaxeSlot.getValue()), this.throwJunk.getValue());
                                    }
                                 }

                                 if (bestAxe != null) {
                                    currentShovel = mc.field_1724.method_31548().method_5438(convertedAxe);
                                    if (currentShovel.method_7960() || this.isBetterTool(currentShovel, bestAxe.method_7677())) {
                                       this.swap(bestAxe.field_7874, this.convertToSlot(this.axeSlot.getValue()), this.throwJunk.getValue());
                                    }
                                 }

                                 if (bestShovel != null) {
                                    currentShovel = mc.field_1724.method_31548().method_5438(convertedShovel);
                                    if (currentShovel.method_7960() || this.isBetterTool(currentShovel, bestShovel.method_7677())) {
                                       this.swap(bestShovel.field_7874, this.convertToSlot(this.shovelSlot.getValue()), this.throwJunk.getValue());
                                       return;
                                    }
                                 }

                                 return;
                              }

                              slot = (class_1735)var11.next();
                              stack = slot.method_7677();
                           } while(stack.method_7960());

                           if (stack.method_7909() instanceof class_1829 && (mc.field_1724.method_31548().method_5438(convertedSword).method_7960() || this.isBetterSword(bestSword != null ? bestSword.method_7677() : null, stack))) {
                              bestSword = slot;
                           }

                           if (stack.method_7909() instanceof class_1810 && (mc.field_1724.method_31548().method_5438(convertedPickaxe).method_7960() || this.isBetterTool(bestPickaxe != null ? bestPickaxe.method_7677() : null, stack))) {
                              bestPickaxe = slot;
                           }

                           if (stack.method_7909() instanceof class_1743 && (mc.field_1724.method_31548().method_5438(convertedAxe).method_7960() || this.isBetterTool(bestAxe != null ? bestAxe.method_7677() : null, stack))) {
                              bestAxe = slot;
                           }
                        } while(!(stack.method_7909() instanceof class_1821));
                     } while(!mc.field_1724.method_31548().method_5438(convertedShovel).method_7960() && !this.isBetterTool(bestShovel != null ? bestShovel.method_7677() : null, stack));

                     bestShovel = slot;
                  }
               }
            }
         }
      }
   }

   private void swap(int fromSlot, int toSlot, boolean throwItem) {
      if (this.waitTimer.hasReached((double)this.delay.getRandomValue().floatValue())) {
         if (throwItem) {
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, toSlot, 0, class_1713.field_7795, mc.field_1724);
         }

         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, fromSlot, 0, class_1713.field_7790, mc.field_1724);
         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, toSlot, 0, class_1713.field_7790, mc.field_1724);
         if (!throwItem) {
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, fromSlot, 0, class_1713.field_7790, mc.field_1724);
         }

         this.waitTimer.reset();
      }
   }

   public boolean isBetterTool(class_1799 currentTool, class_1799 consideredTool) {
      if (consideredTool.method_7909() != null && currentTool != null) {
         return this.getBreakingStrength(currentTool) < this.getBreakingStrength(consideredTool);
      } else {
         return true;
      }
   }

   public float getBreakingStrength(class_1799 stack) {
      class_1792 var3 = stack.method_7909();
      if (var3 instanceof class_1766) {
         class_1766 toolItem = (class_1766)var3;
         int efficiency = DamageUtils.getEnchantmentLevel(stack, class_1893.field_9131);
         int baseSpeed = this.getBaseSpeed(toolItem);
         baseSpeed = (int)((double)baseSpeed * (double)efficiency * 0.2D);
         return (float)baseSpeed;
      } else {
         return 1.0F;
      }
   }

   public int getBaseSpeed(class_1792 item) {
      if (item instanceof class_1766) {
         class_6880<class_1792> itemEntry = class_7923.field_41178.method_47983(item);
         if (itemEntry.method_40220(class_3489.field_52381)) {
            return 2;
         }

         if (itemEntry.method_40220(class_3489.field_23802)) {
            return 4;
         }

         if (itemEntry.method_40220(class_3489.field_52382)) {
            return 6;
         }

         if (itemEntry.method_40220(class_3489.field_52386)) {
            return 8;
         }

         if (itemEntry.method_40220(class_3489.field_52387)) {
            return 9;
         }

         if (itemEntry.method_40220(class_3489.field_52385)) {
            return this.goldTools.getValue() ? 5 : 12;
         }
      }

      return 1;
   }

   public boolean isBetterSword(class_1799 currentSword, class_1799 consideredSword) {
      if (consideredSword.method_7909() != null && currentSword != null) {
         return this.getDamage(currentSword) < this.getDamage(consideredSword);
      } else {
         return true;
      }
   }

   public double getDamage(class_1799 sword) {
      double sharpness = 0.5D * (double)DamageUtils.getEnchantmentLevel(sword, class_1893.field_9118) + 0.5D;
      return getBaseDamage(sword) + sharpness;
   }

   public static double getBaseDamage(class_1799 weapon) {
      double baseDamage = 0.0D;
      class_9285 modifiers = (class_9285)weapon.method_57824(class_9334.field_49636);
      if (modifiers != null) {
         Iterator var4 = modifiers.comp_2393().iterator();

         while(var4.hasNext()) {
            class_9287 entry = (class_9287)var4.next();
            if (entry.comp_2395().equals(class_5134.field_23721)) {
               baseDamage += entry.comp_2396().comp_2449();
            }
         }
      }

      return baseDamage;
   }

   public int convertToSlot(String number) {
      int num = Integer.parseInt(number);
      return num >= 1 && num <= 9 ? 35 + num : -1;
   }

   private boolean isRelevant(class_1799 stack) {
      return stack.method_7909() instanceof class_1829 || stack.method_7976().equals(class_1839.field_8950) || stack.method_7909() instanceof class_1738 || stack.method_7909() instanceof class_1766 || stack.method_7909() instanceof class_1776 || stack.method_7909() instanceof class_1747 || stack.method_7909() instanceof class_1787 || stack.method_7909() instanceof class_1812;
   }

   public InventoryManager() {
      this.getSettingRepository().registerSettings(this.delay, this.throwJunk, this.swordSlot, this.pickaxeSlot, this.axeSlot, this.shovelSlot, this.goldTools);
   }
}
