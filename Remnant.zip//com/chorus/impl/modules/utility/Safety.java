package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.DamageUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.common.util.world.BlockUtils;
import com.chorus.impl.events.player.TickEvent;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1701;
import net.minecraft.class_1802;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_465;
import net.minecraft.class_4969;

@ModuleInfo(
   name = "Safety",
   description = "Automatically Swaps to shield or totem when in danger",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class Safety extends BaseModule implements QuickImports {
   private final MultiSetting dangers = new MultiSetting("Considered Dangers", "Decide what dangers to consider when calculating damage", new String[]{"Beds", "Players", "Anchors", "Carts", "Fall Damage", "Crystals"});
   float maxCrystalDamage = 0.0F;
   float maxAnchorDamage = 0.0F;
   float maxMeleeDamage = 0.0F;
   float maxCartDamage = 0.0F;
   float maxFallDamage = 0.0F;
   float maxBedDamage = 0.0F;
   int slot = -1;
   boolean saved = false;

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (event.getMode().equals(TickEvent.Mode.PRE)) {
         if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
         }

         if (mc.field_1755 instanceof class_465) {
            return;
         }

         if (InventoryUtils.findItemInHotBar(class_1802.field_8288) == -1) {
            return;
         }

         if (this.slot != -1 && this.saved) {
            mc.field_1724.method_31548().field_7545 = this.slot;
            this.slot = -1;
            this.saved = false;
         }

         Iterator var2 = mc.field_1687.method_18112().iterator();

         while(var2.hasNext()) {
            class_1297 real = (class_1297)var2.next();
            if (real instanceof class_1511 && real.method_5739(mc.field_1724) < 6.0F && mc.field_1687.method_18456().stream().anyMatch((player) -> {
               return player.method_5739(real) <= 4.0F;
            }) && DamageUtils.calculateCrystalDamage(mc.field_1724, real.method_19538()) > this.maxCrystalDamage) {
               this.maxCrystalDamage = DamageUtils.calculateCrystalDamage(mc.field_1724, real.method_19538());
            }

            if (real instanceof class_1657 && real.method_5739(mc.field_1724) < 6.0F && DamageUtils.calculateCombatDamage((class_1309)real, mc.field_1724) > this.maxMeleeDamage) {
               this.maxMeleeDamage = DamageUtils.calculateCombatDamage((class_1309)real, mc.field_1724);
            }

            if (real instanceof class_1701 && real.method_5739(mc.field_1724) < 6.0F && DamageUtils.calculateExplosionDamage(mc.field_1724, real.method_19538(), 10.0F) > this.maxCartDamage) {
               this.maxCartDamage = DamageUtils.calculateExplosionDamage(mc.field_1724, real.method_19538(), 10.0F);
            }
         }

         if (DamageUtils.calculateFallDamage(mc.field_1724) > this.maxFallDamage) {
            this.maxFallDamage = DamageUtils.calculateFallDamage(mc.field_1724);
         }

         int radius = 5;

         for(int x = -radius; x <= radius; ++x) {
            for(int y = -radius; y <= radius; ++y) {
               for(int z = -radius; z <= radius; ++z) {
                  class_2338 pos = mc.field_1724.method_24515().method_10069(x, y, z);
                  if (BlockUtils.isBlockType(pos, class_2246.field_23152)) {
                     int charges = (Integer)mc.field_1687.method_8320(pos).method_11654(class_4969.field_23153);
                     if (charges != 0) {
                        float damage = DamageUtils.calculateAnchorDamage(mc.field_1724, new class_243((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()));
                        if (damage > this.maxAnchorDamage) {
                           this.maxAnchorDamage = damage;
                        }
                     }
                  }

                  if (mc.field_1687.method_8320(pos).method_26204() instanceof class_2244) {
                     float damage = DamageUtils.calculateBedDamage(mc.field_1724, new class_243((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()));
                     if (damage > this.maxBedDamage) {
                        this.maxBedDamage = damage;
                     }
                  }
               }
            }
         }

         if (this.dangers.getSpecificValue("Beds") && this.checkHealth(this.maxBedDamage)) {
            this.doubleHand();
         }

         if (this.dangers.getSpecificValue("Anchors") && this.checkHealth(this.maxAnchorDamage)) {
            this.doubleHand();
         }

         if (this.dangers.getSpecificValue("Players") && this.checkHealth(this.maxMeleeDamage)) {
            this.doubleHand();
         }

         if (this.dangers.getSpecificValue("Crystals") && this.checkHealth(this.maxCrystalDamage)) {
            this.doubleHand();
         }

         if (this.dangers.getSpecificValue("Carts") && this.checkHealth(this.maxCartDamage)) {
            this.doubleHand();
         }

         if (this.dangers.getSpecificValue("Fall Damage") && this.checkHealth(this.maxFallDamage)) {
            this.doubleHand();
         }

         this.maxCrystalDamage = 0.0F;
         this.maxAnchorDamage = 0.0F;
         this.maxMeleeDamage = 0.0F;
         this.maxCartDamage = 0.0F;
         this.maxFallDamage = 0.0F;
         this.maxBedDamage = 0.0F;
      }

   }

   private boolean checkHealth(float maxDamage) {
      return mc.field_1724.method_6032() + mc.field_1724.method_6067() - maxDamage < 0.0F;
   }

   private void doubleHand() {
      if (InventoryUtils.getOffHandItem().method_7960() && this.slot == -1) {
         this.slot = mc.field_1724.method_31548().field_7545;
         this.saved = true;
         InventoryUtils.swap(class_1802.field_8288);
      }

   }

   public Safety() {
      this.getSettingRepository().registerSettings(this.dangers);
   }
}
