package com.chorus.impl.modules.utility;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.api.system.rotation.RotationComponent;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.rotation.RotationUtils;
import com.chorus.common.util.player.InventoryUtils;
import com.chorus.impl.events.player.SilentRotationEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_239.class_240;

@ModuleInfo(
   name = "Scaffold",
   description = "Bridges Automatically",
   category = ModuleCategory.UTILITY
)
@Environment(EnvType.CLIENT)
public class Scaffold extends BaseModule implements QuickImports {
   private final SettingCategory behaviorSettings = new SettingCategory("Behavior");
   private final ModeSetting mode;
   private final ModeSetting aimMode;
   private final RangeSetting<Double> horizontalSpeed;
   private final RangeSetting<Double> verticalSpeed;
   int[][] offsets;
   private float[] lastRotations;
   int originalSlot;

   @RegisterEvent
   private void render3DEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         rotationComponent.setSilentRotation(true);
         rotationComponent.setHorizontalSpeed(this.horizontalSpeed.getRandomValue().floatValue());
         rotationComponent.setVerticalSpeed(this.verticalSpeed.getRandomValue().floatValue());
         this.setSuffix(this.mode.getValue());
         if (InventoryUtils.getMainHandItem().method_7909() instanceof class_1747) {
            class_243 closestPoint = this.findScaffoldPoints(4, event.getMatrices());
            if (closestPoint == null) {
               return;
            }

            class_2350 closestSide = RotationUtils.getClosestSide(class_2338.method_49638(closestPoint), mc.field_1724.method_19538());
            if (this.allowScaffold()) {
               Render3DEngine.renderOutlinedShadedBox(closestPoint, Color.WHITE, 1, event.getMatrices(), 0.5F, 1.0F);
               float[] targetRotations = RotationUtils.getRotationToBlock(class_2338.method_49638(closestPoint), closestSide);
               if (closestSide != class_2350.field_11036) {
                  rotationComponent.queueRotation(targetRotations, RotationComponent.RotationPriority.HIGH, this.getAimMode());
               } else {
                  rotationComponent.queueRotation(this.lastRotations, RotationComponent.RotationPriority.HIGH, this.getAimMode());
               }
            } else if (this.mode.getValue().equals("Telly")) {
               rotationComponent.queueRotation(new float[]{mc.field_1724.method_36454(), mc.field_1724.method_36455()}, RotationComponent.RotationPriority.HIGH, this.getAimMode());
            } else {
               rotationComponent.queueRotation(this.lastRotations, RotationComponent.RotationPriority.HIGH, this.getAimMode());
            }
         } else {
            int slot = InventoryUtils.findItemWithPredicateInHotbar((item) -> {
               class_1792 patt0$temp = item.method_7909();
               if (patt0$temp instanceof class_1747) {
                  class_1747 blockItem = (class_1747)patt0$temp;
                  if (!blockItem.method_7711().method_9564().method_26234(mc.field_1687, class_2338.field_10980)) {
                     return false;
                  } else {
                     return !blockItem.method_7711().method_9564().method_31709();
                  }
               } else {
                  return false;
               }
            });
            if (slot != -1) {
               if (this.originalSlot == -1) {
                  this.originalSlot = mc.field_1724.method_31548().field_7545;
               }

               mc.field_1724.method_31548().field_7545 = slot;
            }
         }

         this.lastRotations = rotationComponent.getLastRotations();
      }
   }

   @RegisterEvent(1)
   private void silentRotationEventListener(SilentRotationEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (InventoryUtils.getMainHandItem().method_7909() instanceof class_1747) {
            class_3965 hitResult = RotationUtils.rayTrace(this.lastRotations[0], this.lastRotations[1], 4.0F);
            if (hitResult.method_17783().equals(class_240.field_1332)) {
               if (!this.allowScaffold()) {
                  return;
               }

               mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
               mc.field_1724.method_6104(class_1268.field_5808);
            }

         }
      }
   }

   protected void onModuleDisabled() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (this.originalSlot != -1) {
            mc.field_1724.method_31548().field_7545 = this.originalSlot;
            this.originalSlot = -1;
         }
      }
   }

   public boolean allowScaffold() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 closestPoint = this.findScaffoldPoints(4, (class_4587)null);
         if (closestPoint == null) {
            return false;
         } else {
            class_2338 closestBlockPos = class_2338.method_49638(closestPoint);
            class_2350 closestSide = RotationUtils.getClosestSide(closestBlockPos, mc.field_1724.method_19538());
            String mode = this.mode.getValue();
            if (mode.equals("Telly")) {
               double distance = closestPoint.method_1022(mc.field_1724.method_19538());
               if (mc.field_1724.field_6017 < 0.0F || distance < 1.05D) {
                  return false;
               }
            }

            return !mode.equals("Keep-y");
         }
      } else {
         return false;
      }
   }

   private RotationComponent.AimType getAimMode() {
      String var1 = this.aimMode.getValue();
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -2018804923:
         if (var1.equals("Linear")) {
            var2 = 2;
         }
         break;
      case -1955878649:
         if (var1.equals("Normal")) {
            var2 = 0;
         }
         break;
      case -1241367914:
         if (var1.equals("Adaptive")) {
            var2 = 1;
         }
         break;
      case 1630783146:
         if (var1.equals("Blatant")) {
            var2 = 3;
         }
      }

      RotationComponent.AimType var10000;
      switch(var2) {
      case 0:
         var10000 = RotationComponent.AimType.REGULAR;
         break;
      case 1:
         var10000 = RotationComponent.AimType.ADAPTIVE;
         break;
      case 2:
         var10000 = RotationComponent.AimType.LINEAR;
         break;
      case 3:
         var10000 = RotationComponent.AimType.BLATANT;
         break;
      default:
         var10000 = RotationComponent.AimType.REGULAR;
      }

      return var10000;
   }

   public class_243 findScaffoldPoints(int offset, class_4587 matrices) {
      ArrayList<class_243> possibleScaffoldPoints = new ArrayList();

      for(float x = (float)(-offset); x <= (float)offset; ++x) {
         for(float y = -3.0F; y <= -1.0F; ++y) {
            for(float z = (float)(-offset); z <= (float)offset; ++z) {
               class_243 point = new class_243((double)((float)mc.field_1724.method_24515().method_10263() + x) + 0.5D, (double)((float)mc.field_1724.method_24515().method_10264() + y), (double)((float)mc.field_1724.method_24515().method_10260() + z) + 0.5D);
               int[][] var8 = this.offsets;
               int var9 = var8.length;

               for(int var10 = 0; var10 < var9; ++var10) {
                  int[] blockOffset = var8[var10];
                  class_243 newPoint = point.method_1031((double)blockOffset[0], (double)blockOffset[1], (double)blockOffset[2]);
                  class_2680 blockState = mc.field_1687.method_8320(class_2338.method_49638(newPoint));
                  if (!blockState.method_26215() && !blockState.method_31709() && RotationUtils.rayTrace(point).method_17784().equals(point) && blockState.method_26234(mc.field_1687, class_2338.method_49638(newPoint)) && !blockState.method_26204().equals(class_2246.field_10382) && !blockState.method_26204().equals(class_2246.field_10164) && !blockState.method_26204().equals(class_2246.field_10422) && possibleScaffoldPoints.stream().noneMatch((pos) -> {
                     return newPoint == pos;
                  })) {
                     if (matrices != null) {
                        Render3DEngine.renderOutlinedBox(newPoint, Color.GREEN, matrices, 0.5F, 1.0F);
                     }

                     possibleScaffoldPoints.add(newPoint);
                  }
               }
            }
         }
      }

      possibleScaffoldPoints.sort(Comparator.comparingDouble((pos) -> {
         return pos.method_1022(mc.field_1724.method_19538());
      }));
      return possibleScaffoldPoints.isEmpty() ? null : (class_243)possibleScaffoldPoints.getFirst();
   }

   public Scaffold() {
      this.mode = new ModeSetting(this.behaviorSettings, "Mode", "Select the scaffold behavior", "Normal", new String[]{"Normal", "Eagle", "Keep-y", "Telly"});
      this.aimMode = new ModeSetting(this.behaviorSettings, "Aim Mode", "Select the aiming behavior", "Linear", new String[]{"Normal", "Adaptive", "Linear", "Blatant"});
      this.horizontalSpeed = new RangeSetting(this.behaviorSettings, "Horizontal Aim Speed", "Adjust the speed", 0.0D, 100.0D, 50.0D, 50.0D);
      this.verticalSpeed = new RangeSetting(this.behaviorSettings, "Vertical Aim Speed", "Adjust the speed", 0.0D, 100.0D, 50.0D, 50.0D);
      this.offsets = new int[][]{{1, 0, 0}, {0, 0, 1}, {-1, 0, 0}, {0, 0, -1}, {0, 1, 0}};
      this.lastRotations = new float[2];
      this.originalSlot = -1;
      this.getSettingRepository().registerSettings(this.behaviorSettings, this.mode, this.aimMode, this.horizontalSpeed, this.verticalSpeed);
   }
}
