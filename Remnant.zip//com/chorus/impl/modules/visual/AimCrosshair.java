package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.player.SilentRotationEvent;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_3966;

@ModuleInfo(
   name = "AimCrosshair",
   description = "Shows you where you are aiming",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class AimCrosshair extends BaseModule implements QuickImports {
   double yaw;
   double pitch;
   private class_243 pos;

   @RegisterEvent
   private void silentRotationEventEventListener(SilentRotationEvent event) {
      if (mc.field_1724 != null) {
         this.yaw = event.getYaw() == mc.field_1724.method_36454() ? 0.0D : (double)event.getYaw();
         this.pitch = event.getPitch() == mc.field_1724.method_36455() ? 0.0D : (double)event.getPitch();
      }
   }

   @RegisterEvent
   private void render3DEventEventListener(Render3DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1765 != null) {
         if (this.yaw != 0.0D && this.pitch != 0.0D) {
            if (this.pos == null) {
               this.pos = mc.field_1765.method_17784();
            }

            Render3DEngine.renderOutlinedShadedBox(this.pos.method_1023(0.0D, 0.05000000074505806D, 0.0D), mc.field_1765 instanceof class_3966 ? Color.red : Color.white, 50, event.getMatrices(), 0.05F, 0.1F);
            this.pos = this.pos.method_35590(mc.field_1765.method_17784(), (double)(40.0F / (float)mc.method_47599()));
         }
      }
   }
}
