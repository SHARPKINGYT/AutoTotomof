package com.chorus.impl.modules.visual;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "AntiDebuff",
   description = "Removes Visual Debuffs",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class AntiDebuff extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   public final MultiSetting mode;

   public AntiDebuff() {
      this.mode = new MultiSetting(this.general, "Mode", "Choose Debuffs to hide", new String[]{"Blindness", "Darkness", "Nausea", "Fire", "Explosion Particle"});
      this.getSettingRepository().registerSettings(this.general, this.mode);
   }
}
