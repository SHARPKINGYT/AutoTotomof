package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.Module;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ColorSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.ColorUtils;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "Arraylist",
   description = "Displays client information on your HUD",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Arraylist extends BaseModule implements QuickImports {
   private final SettingCategory text = new SettingCategory("Text Settings");
   private final SettingCategory visual = new SettingCategory("Visual Settings");
   private final SettingCategory position = new SettingCategory("Position Settings");
   private final SettingCategory colors = new SettingCategory("Color Settings");
   private final NumberSetting<Integer> xPos;
   private final NumberSetting<Integer> yPos;
   private final ModeSetting type;
   private final ModeSetting font;
   private final ModeSetting capitalization;
   private final ModeSetting brackets;
   private final MultiSetting hideCategories;
   private final NumberSetting<Integer> textSize;
   private final MultiSetting outlineSettings;
   private final NumberSetting<Integer> outlineOverall;
   private final NumberSetting<Integer> outlineSides;
   private final NumberSetting<Integer> hPadding;
   private final NumberSetting<Integer> vPadding;
   private final ColorSetting primaryColor;
   private final ColorSetting secondaryColor;
   private final ColorSetting suffixColor;
   String leftBracket;
   String rightBracket;
   String spacing;
   public int alignment;
   private final Map<String, float[]> modulePositions;

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && !mc.method_53526().method_53536()) {
         class_4587 matrices = event.getContext().method_51448();
         FontAtlas font = this.getFont();
         int screenWidth = mc.method_22683().method_4486();
         int screenHeight = mc.method_22683().method_4502();
         List<Module> filteredModules = new ArrayList(Chorus.getInstance().getModuleManager().getModules().stream().filter((modulex) -> {
            return this.hideCategories.getValue().stream().noneMatch((condition) -> {
               byte var3 = -1;
               switch(condition.hashCode()) {
               case -1732349088:
                  if (condition.equals("Visual")) {
                     var3 = 2;
                  }
                  break;
               case -39033649:
                  if (condition.equals("Movement")) {
                     var3 = 1;
                  }
                  break;
               case 76517104:
                  if (condition.equals("Other")) {
                     var3 = 4;
                  }
                  break;
               case 1549674828:
                  if (condition.equals("Utility")) {
                     var3 = 3;
                  }
                  break;
               case 2024008468:
                  if (condition.equals("Combat")) {
                     var3 = 0;
                  }
               }

               boolean var10000;
               switch(var3) {
               case 0:
                  var10000 = modulex.getCategory() == ModuleCategory.COMBAT;
                  break;
               case 1:
                  var10000 = modulex.getCategory() == ModuleCategory.MOVEMENT;
                  break;
               case 2:
                  var10000 = modulex.getCategory() == ModuleCategory.VISUAL;
                  break;
               case 3:
                  var10000 = modulex.getCategory() == ModuleCategory.UTILITY;
                  break;
               case 4:
                  var10000 = modulex.getCategory() == ModuleCategory.OTHER;
                  break;
               default:
                  throw new IllegalStateException("Unexpected value: " + condition);
               }

               return var10000;
            });
         }).sorted(Comparator.comparingDouble((m) -> {
            return (double)(-font.getWidth(this.getName(m) + " " + this.getSuffix(m), (float)(Integer)this.textSize.getValue()));
         })).toList());
         List<Module> enabledModules = new ArrayList(Chorus.getInstance().getModuleManager().getModules().stream().filter((modulex) -> {
            return this.hideCategories.getValue().stream().noneMatch((condition) -> {
               byte var3 = -1;
               switch(condition.hashCode()) {
               case -1732349088:
                  if (condition.equals("Visual")) {
                     var3 = 2;
                  }
                  break;
               case -39033649:
                  if (condition.equals("Movement")) {
                     var3 = 1;
                  }
                  break;
               case 76517104:
                  if (condition.equals("Other")) {
                     var3 = 4;
                  }
                  break;
               case 1549674828:
                  if (condition.equals("Utility")) {
                     var3 = 3;
                  }
                  break;
               case 2024008468:
                  if (condition.equals("Combat")) {
                     var3 = 0;
                  }
               }

               boolean var10000;
               switch(var3) {
               case 0:
                  var10000 = modulex.getCategory() == ModuleCategory.COMBAT;
                  break;
               case 1:
                  var10000 = modulex.getCategory() == ModuleCategory.MOVEMENT;
                  break;
               case 2:
                  var10000 = modulex.getCategory() == ModuleCategory.VISUAL;
                  break;
               case 3:
                  var10000 = modulex.getCategory() == ModuleCategory.UTILITY;
                  break;
               case 4:
                  var10000 = modulex.getCategory() == ModuleCategory.OTHER;
                  break;
               default:
                  throw new IllegalStateException("Unexpected value: " + condition);
               }

               return var10000;
            });
         }).filter(Module::isEnabled).sorted(Comparator.comparingDouble((m) -> {
            return (double)(-font.getWidth(this.getName(m) + " " + this.getSuffix(m), (float)(Integer)this.textSize.getValue()));
         })).toList());
         float yPosition = 0.0F;
         double scale = mc.method_22683().method_4495();
         RenderSystem.enableScissor((int)((double)((float)(Integer)this.xPos.getValue() + this.getWidth() - (float)((Integer)this.hPadding.getValue() * 2) - 2.0F - font.getWidth(this.getFullName((Module)enabledModules.getFirst()), (float)(Integer)this.textSize.getValue())) * scale), 0, (int)((double)(font.getWidth(this.getFullName((Module)enabledModules.getFirst()), (float)(Integer)this.textSize.getValue()) + (float)((Integer)this.hPadding.getValue() * 2) + 4.0F) * scale), screenHeight * 2);

         for(int i = 0; i < filteredModules.size(); ++i) {
            Module module = (Module)filteredModules.get(i);
            String moduleKey = module.toString();
            this.modulePositions.putIfAbsent(moduleKey, new float[]{(float)(-screenWidth), yPosition - 25.0F});
            int size = (Integer)this.textSize.getValue();
            int padding = (Integer)this.hPadding.getValue();
            float lineHeight = font.getLineHeight((float)size) + (float)(Integer)this.vPadding.getValue();
            float thickness = (float)(Integer)this.outlineOverall.getValue();
            float sideHeight = (float)(Integer)this.outlineSides.getValue() * 0.01F;
            float moduleX = ((float[])this.modulePositions.get(module.toString()))[0];
            float moduleY = ((float[])this.modulePositions.get(module.toString()))[1];
            if (module.isEnabled() && enabledModules.getFirst() == module) {
               this.setWidth(font.getWidth(this.getFullName((Module)enabledModules.getFirst()), (float)size) + (float)(padding * 2) + thickness * 2.0F + 1.0F + 2.0F);
               this.setHeight((float)enabledModules.size() * lineHeight);
            }

            float lerp = mc.field_1755 == null ? 3.0F / (float)mc.method_47599() : 1.0F;
            moduleX = class_3532.method_16439(lerp, moduleX, (float)((module.isEnabled() ? 0 : -200) + screenWidth) - this.getWidth() - (float)(Integer)this.xPos.getValue());
            moduleY = class_3532.method_16439(lerp, moduleY, yPosition + (float)class_3532.method_15340((Integer)this.yPos.getValue(), mc.field_1724.method_6088().isEmpty() ? 0 : 25, 1000));
            this.modulePositions.put(module.toString(), new float[]{moduleX, moduleY});
            float x = (float)screenWidth - moduleX - (float)padding - 1.0F;
            Color firstColor = ColorUtils.interpolateColor(this.primaryColor.getValue(), this.secondaryColor.getValue(), 3, (int)(-(yPosition * 2.0F)));
            Color secondColor = ColorUtils.interpolateColor(this.primaryColor.getValue(), this.secondaryColor.getValue(), 3, (int)(-((yPosition + lineHeight) * 2.0F)));
            Color bgFirst = new Color(firstColor.getRed(), firstColor.getGreen(), firstColor.getBlue(), 25);
            Color bgNext = new Color(secondColor.getRed(), secondColor.getGreen(), secondColor.getBlue(), 25);
            Render2DEngine.drawVerticalGradient(matrices, x - font.getWidth(this.getFullName(module), (float)size) - (float)padding, moduleY, font.getWidth(this.getFullName(module), (float)size) + (float)(padding * 2), lineHeight, bgFirst, bgNext);
            Render2DEngine.drawBlurredRoundedRect(matrices, x - font.getWidth(this.getFullName(module), (float)size) - (float)padding, moduleY, font.getWidth(this.getFullName(module), (float)size) + (float)(padding * 2), lineHeight, 1.0F, 8.0F, new Color(0, 0, 0, 10));
            if (this.type.getValue().equals("Outlined")) {
               if (this.outlineSettings.getSpecificValue("Bottom")) {
                  Module next = enabledModules.indexOf(module) < enabledModules.size() - 1 ? (Module)enabledModules.get(enabledModules.indexOf(module) + 1) : (Module)enabledModules.get(enabledModules.indexOf(module));
                  if (module.isEnabled() && next != null) {
                     float nextWidth = font.getWidth(this.getFullName(next), (float)size);
                     Render2DEngine.drawRect(matrices, x - font.getWidth(this.getFullName(module), (float)size) - (float)padding - thickness, moduleY + lineHeight, font.getWidth(this.getFullName(module), (float)size) - (module == enabledModules.getLast() ? -((float)(padding * 2) + thickness * 2.0F) - 1.0F : nextWidth), 1.0F + thickness, secondColor);
                  }
               }

               if (module == enabledModules.getFirst() && this.outlineSettings.getSpecificValue("Top")) {
                  Render2DEngine.drawRect(matrices, x - font.getWidth(this.getFullName(module), (float)size) - (float)padding - thickness, moduleY - thickness, font.getWidth(this.getFullName(module), (float)size) + (float)(padding * 2) + thickness * 2.0F + 1.0F, 1.0F + thickness, firstColor);
               }

               if (this.outlineSettings.getSpecificValue("Right")) {
                  Render2DEngine.drawVerticalGradient(matrices, x + (float)padding, moduleY + lineHeight / 2.0F - sideHeight * lineHeight / 2.0F, 1.0F + thickness, sideHeight * lineHeight + (float)(filteredModules.getLast() == module ? 1 : 0), firstColor, secondColor);
               }

               if (this.outlineSettings.getSpecificValue("Left")) {
                  Render2DEngine.drawVerticalGradient(matrices, x - font.getWidth(this.getFullName(module), (float)size) - (float)padding - thickness, moduleY + lineHeight / 2.0F - sideHeight * lineHeight / 2.0F, 1.0F + thickness, sideHeight * lineHeight, firstColor, secondColor);
               }
            }

            if (filteredModules.getLast() == module) {
               this.alignment = (int)(moduleY + lineHeight);
            }

            font.renderWithShadow(matrices, this.getName(module), x - font.getWidth(this.getFullName(module), (float)size), moduleY + lineHeight / 2.0F - font.getLineHeight((float)size) / 2.0F + 0.5F, (float)size, firstColor.getRGB());
            if (!this.getSuffix(module).isEmpty()) {
               font.renderWithShadow(matrices, this.getSuffix(module), x - font.getWidth(this.getSuffix(module), (float)size) - 1.0F, moduleY + lineHeight / 2.0F - font.getLineHeight((float)size) / 2.0F + 1.0F, (float)size, this.suffixColor.getValue().getRGB());
            }

            if (module.isEnabled()) {
               yPosition += lineHeight;
            }
         }

         RenderSystem.disableScissor();
      } else {
         this.modulePositions.clear();
      }
   }

   public String getSuffix(Module module) {
      String suffix = this.brackets.getValue();
      byte var3 = -1;
      switch(suffix.hashCode()) {
      case 1281:
         if (suffix.equals("()")) {
            var3 = 0;
         }
         break;
      case 1922:
         if (suffix.equals("<>")) {
            var3 = 2;
         }
         break;
      case 1982:
         if (suffix.equals("><")) {
            var3 = 3;
         }
         break;
      case 2914:
         if (suffix.equals("[]")) {
            var3 = 1;
         }
      }

      switch(var3) {
      case 0:
         this.leftBracket = "(";
         this.rightBracket = ")";
         break;
      case 1:
         this.leftBracket = "[";
         this.rightBracket = "]";
         break;
      case 2:
         this.leftBracket = "<";
         this.rightBracket = ">";
         break;
      case 3:
         this.leftBracket = ">";
         this.rightBracket = "<";
      }

      suffix = module.getSuffix();
      String var5 = this.capitalization.getValue();
      byte var4 = -1;
      switch(var5.hashCode()) {
      case -2067475790:
         if (var5.equals("Uppercase")) {
            var4 = 1;
         }
         break;
      case 1489460625:
         if (var5.equals("Lowercase")) {
            var4 = 0;
         }
      }

      switch(var4) {
      case 0:
         suffix = suffix.toLowerCase();
         break;
      case 1:
         suffix = suffix.toUpperCase();
      }

      this.spacing = " ";
      return suffix.isEmpty() ? "" : this.spacing + this.leftBracket + suffix + this.rightBracket;
   }

   public String getName(Module module) {
      String moduleName = module.getName();
      String var3 = this.capitalization.getValue();
      byte var4 = -1;
      switch(var3.hashCode()) {
      case -2067475790:
         if (var3.equals("Uppercase")) {
            var4 = 1;
         }
         break;
      case 1489460625:
         if (var3.equals("Lowercase")) {
            var4 = 0;
         }
      }

      switch(var4) {
      case 0:
         moduleName = moduleName.toLowerCase();
         break;
      case 1:
         moduleName = moduleName.toUpperCase();
      }

      return moduleName;
   }

   public String getFullName(Module module) {
      String var10000 = this.getName(module);
      return var10000 + this.getSuffix(module);
   }

   public FontAtlas getFont() {
      String var1 = this.font.getValue();
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -1000021127:
         if (var1.equals("Inter Medium")) {
            var2 = 2;
         }
         break;
      case -366120160:
         if (var1.equals("Inter Semi-Bold")) {
            var2 = 0;
         }
         break;
      case 329367433:
         if (var1.equals("Inter Bold")) {
            var2 = 1;
         }
         break;
      case 1270561583:
         if (var1.equals("Poppins")) {
            var2 = 4;
         }
         break;
      case 1336207093:
         if (var1.equals("Proggy Clean")) {
            var2 = 3;
         }
      }

      FontAtlas var10000;
      switch(var2) {
      case 0:
         var10000 = Chorus.getInstance().getFonts().getInterSemiBold();
         break;
      case 1:
         var10000 = Chorus.getInstance().getFonts().getInterBold();
         break;
      case 2:
         var10000 = Chorus.getInstance().getFonts().getInterMedium();
         break;
      case 3:
         var10000 = Chorus.getInstance().getFonts().getProggyClean();
         break;
      case 4:
         var10000 = Chorus.getInstance().getFonts().getPoppins();
         break;
      default:
         throw new IllegalStateException("Unexpected value: " + this.font.getValue());
      }

      return var10000;
   }

   public Arraylist() {
      this.xPos = new NumberSetting(this.position, "xPos", "Internal setting", 5, 0, 1920);
      this.yPos = new NumberSetting(this.position, "yPos", "Internal setting", 5, 0, 1080);
      this.type = new ModeSetting(this.text, "Type", "Choose Arraylist Type", "Outlined", new String[]{"Outlined", "Rounded", "Basic"});
      this.font = new ModeSetting(this.text, "Font", "Choose Font to use", "Poppins", new String[]{"Inter Semi-Bold", "Inter Bold", "Inter Medium", "Proggy Clean", "Poppins"});
      this.capitalization = new ModeSetting(this.text, "Capitalization", "Choose Module Capitalization", "Default", new String[]{"Lowercase", "Default", "Uppercase"});
      this.brackets = new ModeSetting(this.text, "Suffix Brackets", "Choose Suffix Brackets", "()", new String[]{"()", "[]", "<>", "><"});
      this.hideCategories = new MultiSetting(this.text, "Hide Categories", "Hide Specific Module Categories", new String[]{"Combat", "Movement", "Visual", "Utility", "Other"});
      this.textSize = new NumberSetting(this.text, "Text Size", "Adjust Text Size", 10, 5, 20);
      this.outlineSettings = new MultiSetting(this.visual, "Outline", "Choose Which Side Outline To Render", new String[]{"Left", "Right", "Top", "Bottom"});
      this.outlineOverall = new NumberSetting(this.visual, "Outline Thickness", "The Thickness of the outlines", 0, 0, 10);
      this.outlineSides = new NumberSetting(this.visual, "Side Outline Height", "The Height of the sides of the outlines (%)", 100, 0, 100);
      this.hPadding = new NumberSetting(this.visual, "Horizontal Padding", "", 4, 0, 10);
      this.vPadding = new NumberSetting(this.position, "Vertical Padding", "", 2, 0, 25);
      this.primaryColor = new ColorSetting(this.colors, "Primary Color", "The main color for module names", new Color(184, 112, 242));
      this.secondaryColor = new ColorSetting(this.colors, "Secondary Color", "The secondary color for module names", new Color(184, 112, 242));
      this.suffixColor = new ColorSetting(this.colors, "Suffix Color", "The color for module suffixes", new Color(235, 235, 235));
      this.leftBracket = "";
      this.rightBracket = "";
      this.spacing = "";
      this.alignment = 0;
      this.modulePositions = new HashMap();
      this.xPos.setRenderCondition(() -> {
         return false;
      });
      this.yPos.setRenderCondition(() -> {
         return false;
      });
      this.outlineSides.setRenderCondition(() -> {
         return this.type.getValue().equals("Outlined");
      });
      this.outlineOverall.setRenderCondition(() -> {
         return this.type.getValue().equals("Outlined");
      });
      this.outlineSettings.setRenderCondition(() -> {
         return this.type.getValue().equals("Outlined");
      });
      this.setDraggable(true);
      this.getSettingRepository().registerSettings(this.font, this.text, this.position, this.visual, this.type, this.xPos, this.yPos, this.colors, this.capitalization, this.brackets, this.hideCategories, this.outlineSettings, this.textSize, this.outlineOverall, this.outlineSides, this.hPadding, this.vPadding, this.primaryColor, this.secondaryColor, this.suffixColor);
   }
}
