package com.chorus.impl.modules.visual;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.NumberSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "AspectRatio",
   description = "Changes the aspect ratio of the game",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class AspectRatio extends BaseModule {
   private final NumberSetting<Float> aspectRatio = new NumberSetting("Aspect Ratio", "The aspect ratio of the game", 1.65F, 0.1F, 5.0F);

   public AspectRatio() {
      this.getSettingRepository().registerSettings(this.aspectRatio);
   }
}
