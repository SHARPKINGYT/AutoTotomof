package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.network.PacketReceiveEvent;
import com.chorus.impl.events.player.TickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2761;

@ModuleInfo(
   name = "Atmosphere",
   description = "Changes World Time and Weather",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Atmosphere extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final ModeSetting weather;
   private final NumberSetting<Double> time;

   @RegisterEvent
   private void PacketReceiveEventListener(PacketReceiveEvent event) {
      if (mc.field_1724 != null) {
         if (event.getPacket() instanceof class_2761) {
            event.setCancelled(true);
         }

      }
   }

   @RegisterEvent
   private void TickEventListener(TickEvent event) {
      if (mc.field_1687 != null) {
         mc.field_1687.method_29089(((Double)this.time.getValue()).longValue(), ((Double)this.time.getValue()).longValue(), true);
         if (this.weather.getValue().equals("Rain") || this.weather.getValue().equals("Thunderstorm")) {
            mc.field_1687.method_8519(1.0F);
         }

         if (this.weather.getValue().equals("Clear")) {
            mc.field_1687.method_8519(0.0F);
            mc.field_1687.method_8496(0.0F);
         }

         if (this.weather.getValue().equals("Thunderstorm")) {
            mc.field_1687.method_8496(1.0F);
         }

      }
   }

   protected void onModuleDisabled() {
      if (mc.field_1687 != null) {
         mc.field_1687.method_8519(0.0F);
         mc.field_1687.method_8496(0.0F);
      }
   }

   public Atmosphere() {
      this.weather = new ModeSetting(this.general, "Weather", "Set World Weather", "Clear", new String[]{"Clear", "Thunder", "Rain"});
      this.time = new NumberSetting(this.general, "Time", "Change World Time", 1000.0D, 0.0D, 24000.0D);
      this.getSettingRepository().registerSettings(this.general, this.weather, this.time);
   }
}
