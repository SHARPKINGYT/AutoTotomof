package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import com.chorus.impl.events.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_2189;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_332;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_9779;

@ModuleInfo(
   name = "BedPlates",
   description = "Renders Defense A Bed Has.",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class BedPlates extends BaseModule implements QuickImports {
   private final SettingCategory visual = new SettingCategory("Visual Settings");
   private final BooleanSetting showBackground;
   private Map<class_2586, class_3545<BedPlates.Rectangle, Boolean>> hashMap;
   class_9779 renderTickCounter;
   int[][] offsets;

   @RegisterEvent
   private void Render3DEvent(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         this.hashMap.clear();
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_1923 currentPosition = mc.field_1724.method_31476();
         int viewDistance = mc.field_1690.method_38521();
         class_1923 start = new class_1923(currentPosition.field_9181 - viewDistance, currentPosition.field_9180 - viewDistance);
         class_1923 end = new class_1923(currentPosition.field_9181 + viewDistance, currentPosition.field_9180 + viewDistance);

         for(int x = start.field_9181; x <= end.field_9181; ++x) {
            label78:
            for(int z = start.field_9180; z <= end.field_9180; ++z) {
               if (mc.field_1687.method_8393(x, z)) {
                  Iterator var8 = mc.field_1687.method_8497(x, z).method_12021().iterator();

                  while(true) {
                     class_2338 pos;
                     class_2680 blockState;
                     do {
                        do {
                           if (!var8.hasNext()) {
                              continue label78;
                           }

                           pos = (class_2338)var8.next();
                           blockState = mc.field_1687.method_8320(pos);
                        } while(!(blockState.method_26204() instanceof class_2244));
                     } while(blockState.method_11654(class_2244.field_9967) == class_2742.field_12560);

                     class_2586 blockEntity = mc.field_1687.method_8321(pos);
                     int tickDelta = (int)this.renderTickCounter.method_60637(false);
                     class_243 prevPos = new class_243((double)blockEntity.method_11016().method_10263() + 0.5D, (double)blockEntity.method_11016().method_10264(), (double)blockEntity.method_11016().method_10260() + 0.5D);
                     class_243 interpolated = prevPos.method_1019(blockEntity.method_11016().method_46558().method_1019(prevPos).method_1021((double)tickDelta));
                     float halfWidth = 0.25F;
                     class_238 boundingBox = (new class_238(interpolated.field_1352, interpolated.field_1351, interpolated.field_1350, interpolated.field_1352, interpolated.field_1351 + 1.0D, interpolated.field_1350)).method_1009(0.1D, 0.1D, 0.1D);
                     class_243[] corners = new class_243[]{new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1324)};
                     BedPlates.Rectangle rectangle = null;
                     boolean visible = false;
                     class_243[] var20 = corners;
                     int var21 = corners.length;

                     for(int var22 = 0; var22 < var21; ++var22) {
                        class_243 corner = var20[var22];
                        class_3545<class_243, Boolean> projection = Render3DEngine.project(event.getMatrices().method_23760().method_23761(), event.getProjectionMatrix(), corner);
                        if ((Boolean)projection.method_15441()) {
                           visible = true;
                        }

                        class_243 projected = (class_243)projection.method_15442();
                        if (rectangle == null) {
                           rectangle = new BedPlates.Rectangle((double)((int)projected.method_10216()), (double)((int)projected.method_10214()), (double)((int)projected.method_10216()), (double)((int)projected.method_10214()));
                        } else {
                           if (rectangle.x > projected.method_10216()) {
                              rectangle.x = (double)((int)projected.method_10216());
                           }

                           if (rectangle.y > projected.method_10214()) {
                              rectangle.y = (double)((int)projected.method_10214());
                           }

                           if (rectangle.z < projected.method_10216()) {
                              rectangle.z = (double)((int)projected.method_10216());
                           }

                           if (rectangle.w < projected.method_10214()) {
                              rectangle.w = (double)((int)projected.method_10214());
                           }
                        }
                     }

                     this.hashMap.put(blockEntity, new class_3545(rectangle, visible));
                  }
               }
            }
         }
      }

   }

   @RegisterEvent
   private void Render2DEvent(Render2DEvent event) {
      if (event.getMode().equals(Render2DEvent.Mode.PRE)) {
         class_4587 matrix = event.getContext().method_51448();
         class_332 context = event.getContext();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.setShader(class_10142.field_53876);
         if (!this.hashMap.isEmpty() && this.hashMap.entrySet().stream().anyMatch((entityPairEntry) -> {
            return (Boolean)((class_3545)entityPairEntry.getValue()).method_15441();
         })) {
            Iterator var4 = this.hashMap.entrySet().iterator();

            label61:
            while(true) {
               class_3545 pair;
               float y;
               LinkedHashSet blocks;
               int itemOffset;
               do {
                  Entry entry;
                  do {
                     if (!var4.hasNext()) {
                        break label61;
                     }

                     entry = (Entry)var4.next();
                     pair = (class_3545)entry.getValue();
                     FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
                  } while(!(Boolean)pair.method_15441());

                  y = (float)(((BedPlates.Rectangle)pair.method_15442()).y - 2.0D - 1.0D - 4.5D);
                  blocks = new LinkedHashSet();
                  int[][] var10 = this.offsets;
                  int var11 = var10.length;

                  for(itemOffset = 0; itemOffset < var11; ++itemOffset) {
                     int[] offsetArr = var10[itemOffset];
                     class_2338 newPos = ((class_2586)entry.getKey()).method_11016().method_10069(offsetArr[0], 0, offsetArr[2]);
                     class_2248 block = mc.field_1687.method_8320(newPos).method_26204();
                     class_1799 itemStack = block.method_8389().method_7854();
                     if (!(block instanceof class_2244) && !(block instanceof class_2189)) {
                        boolean exists = blocks.stream().noneMatch((existingStack) -> {
                           return existingStack.method_7909().equals(itemStack.method_7909());
                        });
                        if (exists) {
                           blocks.add(itemStack);
                        }
                     }
                  }
               } while(blocks.isEmpty());

               int xOffset = blocks.size() * 18;
               float centerX = (float)((((BedPlates.Rectangle)pair.method_15442()).x + ((BedPlates.Rectangle)pair.method_15442()).z) / 2.0D);
               if (this.showBackground.getValue()) {
                  context.method_25294((int)(centerX - 2.0F), (int)(y - 2.0F), (int)(centerX + (float)xOffset), (int)(y + 18.0F), Integer.MIN_VALUE);
               }

               itemOffset = 0;

               for(Iterator var20 = blocks.iterator(); var20.hasNext(); itemOffset += 18) {
                  class_1799 item = (class_1799)var20.next();
                  context.method_51427(item, (int)(centerX + (float)itemOffset), (int)y);
               }
            }
         }

         RenderSystem.disableBlend();
      }

   }

   public BedPlates() {
      this.showBackground = new BooleanSetting(this.visual, "Show Background", "Display a background behind the text", true);
      this.hashMap = new HashMap();
      this.renderTickCounter = mc.method_61966();
      this.offsets = new int[][]{{1, 0, 0}, {0, 0, 1}, {-1, 0, 0}, {0, 0, -1}, {0, 1, 0}};
      this.getSettingRepository().registerSettings(this.visual, this.showBackground);
   }

   @Environment(EnvType.CLIENT)
   public static class Rectangle {
      public double x;
      public double y;
      public double z;
      public double w;

      public Rectangle(double x, double y, double z, double w) {
         this.x = x;
         this.y = y;
         this.z = z;
         this.w = w;
      }
   }
}
