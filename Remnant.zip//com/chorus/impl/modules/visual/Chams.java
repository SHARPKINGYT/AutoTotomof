package com.chorus.impl.modules.visual;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "Chams",
   description = "mahha",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Chams extends BaseModule {
}
