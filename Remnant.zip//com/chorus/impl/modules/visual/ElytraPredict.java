package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.ColorUtils;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.common.util.world.SimulatedPlayer;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@ModuleInfo(
   name = "Predict",
   description = "Predicts the path of players",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class ElytraPredict extends BaseModule implements QuickImports {
   private final NumberSetting<Float> predictionTime = new NumberSetting((SettingCategory)null, "Prediction Time", "How many ticks to predict ahead", 1.0F, 0.1F, 25.0F);
   private final BooleanSetting showSelf = new BooleanSetting((SettingCategory)null, "Show Self", "Show your own Elytra path", false);

   public ElytraPredict() {
      this.getSettingRepository().registerSettings(this.predictionTime, this.showSelf);
   }

   @RegisterEvent
   private void Render3DEvent(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            SimulatedPlayer simulator = new SimulatedPlayer(mc.field_1724);
            simulator.setInput(mc.field_1690.field_1894.method_1434(), mc.field_1690.field_1881.method_1434(), mc.field_1690.field_1913.method_1434(), mc.field_1690.field_1849.method_1434(), mc.field_1690.field_1903.method_1434(), mc.field_1724.method_5624());

            for(int i = 0; i <= ((Float)this.predictionTime.getValue()).intValue(); ++i) {
               simulator.tick();
            }

            Render3DEngine.renderShadedBox(simulator.getPosition(), Color.white, 25, event.getMatrices(), 0.5F, 1.0F);
            Iterator var7 = mc.field_1687.method_18456().iterator();

            while(true) {
               class_1657 entity;
               do {
                  if (!var7.hasNext()) {
                     return;
                  }

                  entity = (class_1657)var7.next();
               } while(entity == mc.field_1724 && !this.showSelf.getValue());

               Color settingColor = ColorUtils.getAssociatedColor(entity);
               if (entity.method_6128()) {
                  ElytraPredict.PredictedPlayer predictedPlayer = this.predictElytraPosition(entity.method_30950(mc.method_61966().method_60637(false)), entity.method_18798(), (double)(Float)this.predictionTime.getValue());
                  Render3DEngine.renderOutlinedBox(predictedPlayer.getLerpedPos(event.getTickDelta()), settingColor, event.getMatrices(), predictedPlayer.getWidth(), predictedPlayer.getHeight());
               }
            }
         }
      }
   }

   private ElytraPredict.PredictedPlayer predictElytraPosition(class_243 currentPos, class_243 currentMotion, double time) {
      ElytraPredict.PredictedPlayer player = new ElytraPredict.PredictedPlayer(this, currentPos, currentMotion, mc.field_1724.method_17681(), mc.field_1724.method_17682());
      int steps = (int)(time * 20.0D);
      double stepTime = time / (double)steps;

      for(int i = 0; i < steps; ++i) {
         if (player.isOnGround()) {
            return player;
         }

         player.applyElytraPhysics(stepTime);
         class_243 nextPos = player.getPosition().method_1019(player.getMotion().method_1021(stepTime));
         class_3959 context = new class_3959(player.getPosition(), nextPos, class_3960.field_17558, class_242.field_1348, mc.field_1724);
         class_3965 result = mc.field_1687.method_17742(context);
         if (result.method_17783() != class_240.field_1333) {
            player.handleCollision(result);
         } else {
            player.update(nextPos, player.getMotion());
         }
      }

      return player;
   }

   @Environment(EnvType.CLIENT)
   class PredictedPlayer {
      private class_243 position;
      private class_243 motion;
      private float width;
      private float height;
      private class_243 prevPosition;

      public PredictedPlayer(final ElytraPredict this$0, class_243 position, class_243 motion, float width, float height) {
         this.position = position;
         this.motion = motion;
         this.width = width;
         this.height = height;
         this.prevPosition = position;
      }

      public void update(class_243 position, class_243 motion) {
         this.prevPosition = this.position;
         this.position = position;
         this.motion = motion;
      }

      public final class_243 getLerpedPos(float delta) {
         double d = class_3532.method_16436((double)delta, this.prevPosition.field_1352, this.position.field_1352);
         double e = class_3532.method_16436((double)delta, this.prevPosition.field_1351, this.position.field_1351);
         double f = class_3532.method_16436((double)delta, this.prevPosition.field_1350, this.position.field_1350);
         return new class_243(d, e, f);
      }

      public boolean isOnGround() {
         class_2338 floorPos = class_2338.method_49638(this.position.method_1023(0.0D, 0.2D, 0.0D));
         class_2680 state = QuickImports.mc.field_1687.method_8320(floorPos);
         return !state.method_26215() && state.method_26212(QuickImports.mc.field_1687, floorPos);
      }

      public float getWidth() {
         return !this.isOnGround() ? this.width : this.width / 0.8F;
      }

      public float getHeight() {
         return !this.isOnGround() ? this.height : this.height / 0.8F;
      }

      public void applyElytraPhysics(double stepTime) {
         double horizontalDrag = 0.99D;
         double verticalDrag = 0.98D;
         double gravity = 0.08D;
         this.motion = new class_243(this.motion.field_1352 * horizontalDrag, this.motion.field_1351 * verticalDrag - gravity * stepTime, this.motion.field_1350 * horizontalDrag);
      }

      public void handleCollision(class_3965 result) {
         if (result.method_17783() != class_240.field_1333) {
            class_2680 hitState = QuickImports.mc.field_1687.method_8320(result.method_17777());
            if (!hitState.method_26212(QuickImports.mc.field_1687, result.method_17777())) {
               this.position = result.method_17784();
               return;
            }

            class_243 normal = class_243.method_24954(result.method_17780().method_62675());
            if (normal.field_1351 != 0.0D) {
               this.position = result.method_17784();
               return;
            }

            double dot = this.motion.method_1026(normal);
            class_243 reflection = this.motion.method_1020(normal.method_1021(2.0D * dot));
            double angle = Math.abs(dot / (this.motion.method_1033() * normal.method_1033()));
            double slideRatio = 1.0D - angle;
            class_243 slideMotion = this.motion.method_1020(normal.method_1021(dot));
            this.motion = reflection.method_1021(angle).method_1019(slideMotion.method_1021(slideRatio)).method_1021(0.7D);
            this.position = result.method_17784();
         }

      }

      public class_243 getPosition() {
         return this.position;
      }

      public class_243 getMotion() {
         return this.motion;
      }

      public class_243 getPrevPosition() {
         return this.prevPosition;
      }

      public PredictedPlayer(final ElytraPredict this$0, final class_243 position, final class_243 motion, final float width, final float height, final class_243 prevPosition) {
         this.position = position;
         this.motion = motion;
         this.width = width;
         this.height = height;
         this.prevPosition = prevPosition;
      }
   }
}
