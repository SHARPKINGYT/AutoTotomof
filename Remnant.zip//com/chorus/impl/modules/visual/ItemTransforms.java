package com.chorus.impl.modules.visual;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.common.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1007;
import net.minecraft.class_10090;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1664;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1806;
import net.minecraft.class_1819;
import net.minecraft.class_1921;
import net.minecraft.class_22;
import net.minecraft.class_2960;
import net.minecraft.class_330;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_9209;
import net.minecraft.class_9334;
import org.joml.Matrix4f;

@ModuleInfo(
   name = "ItemTransforms",
   description = "Transforms Held Items",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class ItemTransforms extends BaseModule implements QuickImports {
   private final NumberSetting<Double> x = new NumberSetting("X", "Offset Item's Position On X Axis", 0.0D, -1.0D, 1.0D);
   private final NumberSetting<Double> y = new NumberSetting("Y", "Offset Item's Position On Y Axis", 0.0D, -1.0D, 1.0D);
   private final NumberSetting<Double> z = new NumberSetting("Z", "Offset Item's Position On Z Axis", 0.0D, -1.0D, 1.0D);
   private final NumberSetting<Double> scale = new NumberSetting("Scale", "Scale Your Held Item", 1.0D, 0.01D, 2.0D);
   private final ModeSetting mode = new ModeSetting("Mode", "Choose Animation", "Swong", new String[]{"Swong", "Swank", "Static", "Static 2", "Balls", "Ion", "Test"});
   private final MultiSetting handSetting = new MultiSetting("Hand", "Choose Which Hand", new String[]{"Main Hand", "Offhand"});

   public void swordAnimation(float swingProgress, float equipProgress, class_4587 matrices, int armMultiplier, class_1306 arm) {
      float swingX = -0.4F * class_3532.method_15374(class_3532.method_15355(swingProgress) * 3.1415927F);
      float swingY = 0.2F * class_3532.method_15374(class_3532.method_15355(swingProgress) * 6.2831855F);
      float swingZ = -0.2F * class_3532.method_15374(swingProgress * 3.1415927F);
      int hand = arm == class_1306.field_6183 ? 1 : -1;
      if (!this.handSetting.getSpecificValue("Main Hand") && hand == 1 || !this.handSetting.getSpecificValue("Offhand") && hand == -1) {
         matrices.method_46416((float)armMultiplier * swingX, swingY, swingZ);
         this.applyEquipOffset(matrices, arm, equipProgress);
         this.applySwingOffset(matrices, arm, swingProgress);
      } else {
         matrices.method_46416(((Double)this.x.getValue()).floatValue(), ((Double)this.y.getValue()).floatValue(), ((Double)this.z.getValue()).floatValue());
         String var10 = this.mode.getValue();
         byte var11 = -1;
         switch(var10.hashCode()) {
         case -1808614770:
            if (var10.equals("Static")) {
               var11 = 2;
            }
            break;
         case 73704:
            if (var10.equals("Ion")) {
               var11 = 5;
            }
            break;
         case 63949364:
            if (var10.equals("Balls")) {
               var11 = 4;
            }
            break;
         case 80294106:
            if (var10.equals("Swank")) {
               var11 = 1;
            }
            break;
         case 80307556:
            if (var10.equals("Swong")) {
               var11 = 0;
            }
            break;
         case 1382961952:
            if (var10.equals("Static 2")) {
               var11 = 3;
            }
         }

         float g;
         float bounce;
         switch(var11) {
         case 0:
            g = class_3532.method_15374(class_3532.method_15355(swingProgress) * 3.1415927F);
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(50.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-30.0F * (1.0F - g) - 30.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(110.0F));
            break;
         case 1:
            g = (float)hand * class_3532.method_15374(class_3532.method_15355(swingProgress) * 3.1415927F);
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(g * 30.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-g * 40.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(g * 30.0F));
            bounce = class_3532.method_15374(swingProgress * 6.2831855F) * 0.2F;
            matrices.method_46416(0.0F, bounce, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(g * 20.0F));
            break;
         case 2:
            this.applyEquipOffset(matrices, arm, 0.0F);
            this.applySwingOffset(matrices, arm, swingProgress);
            break;
         case 3:
            this.applyEquipOffset(matrices, arm, equipProgress);
            this.applySwingOffset(matrices, arm, 0.0F);
            break;
         case 4:
            g = (float)hand * class_3532.method_15374(class_3532.method_15355(swingProgress) * 3.1415927F);
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(g * -20.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(g * 70.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(g * -20.0F));
            bounce = (float)hand * class_3532.method_15374(swingProgress * 3.1415927F * 2.0F) * 0.3F;
            matrices.method_46416(0.0F, bounce, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(swingProgress * 40.0F));
            break;
         case 5:
            matrices.method_22905(0.5F, 0.5F, 0.5F);
            if (mc.field_1690.field_1904.method_1434()) {
               g = (float)hand * class_3532.method_15374(class_3532.method_15355(swingProgress) * 3.1415927F);
               this.applyEquipOffset(matrices, arm, 0.0F);
               matrices.method_22907(class_7833.field_40714.rotationDegrees(50.0F));
               matrices.method_22907(class_7833.field_40716.rotationDegrees(-30.0F * (1.0F - g) - 30.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(110.0F));
            } else {
               this.applyEquipOffset(matrices, arm, 0.0F);
               this.applySwingOffset(matrices, arm, swingProgress);
            }
            break;
         default:
            matrices.method_46416((float)armMultiplier * swingX, swingY, swingZ);
            this.applyEquipOffset(matrices, arm, equipProgress);
            this.applySwingOffset(matrices, arm, swingProgress);
         }

      }
   }

   public void renderFirstPersonItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light) {
      if (!player.method_31550()) {
         boolean isMainHand = hand == class_1268.field_5808;
         class_1306 arm = isMainHand ? player.method_6068() : player.method_6068().method_5928();
         matrices.method_22903();
         if (item.method_7960()) {
            if (isMainHand && !player.method_5767()) {
               this.renderArmHoldingItem(matrices, vertexConsumers, light, equipProgress, swingProgress, arm);
            }
         } else if (item.method_57826(class_9334.field_49646)) {
            if (isMainHand && player.method_6079().method_7960()) {
               this.renderMapInBothHands(matrices, vertexConsumers, light, pitch, equipProgress, swingProgress);
            } else {
               this.renderMapInOneHand(matrices, vertexConsumers, light, equipProgress, arm, swingProgress, item);
            }
         } else {
            boolean isRightHand;
            float useTimeRemaining;
            float progress;
            float sinValue;
            float offsetProgress;
            if (item.method_31574(class_1802.field_8399)) {
               isRightHand = class_1764.method_7781(item);
               boolean rightSide = arm == class_1306.field_6183;
               int handMultiplier = rightSide ? 1 : -1;
               if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
                  this.applyEquipOffset(matrices, arm, equipProgress);
                  matrices.method_46416((float)handMultiplier * -0.4785682F, -0.094387F, 0.05731531F);
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(-11.935F));
                  matrices.method_22907(class_7833.field_40716.rotationDegrees((float)handMultiplier * 65.3F));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees((float)handMultiplier * -9.785F));
                  useTimeRemaining = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
                  progress = useTimeRemaining / (float)class_1764.method_7775(item, player);
                  if (progress > 1.0F) {
                     progress = 1.0F;
                  }

                  if (progress > 0.1F) {
                     sinValue = class_3532.method_15374((useTimeRemaining - 0.1F) * 1.3F);
                     offsetProgress = progress - 0.1F;
                     float animationFactor = sinValue * offsetProgress;
                     matrices.method_46416(animationFactor * 0.0F, animationFactor * 0.004F, animationFactor * 0.0F);
                  }

                  matrices.method_46416(progress * 0.0F, progress * 0.0F, progress * 0.04F);
                  matrices.method_22905(1.0F, 1.0F, 1.0F + progress * 0.2F);
                  matrices.method_22907(class_7833.field_40715.rotationDegrees((float)handMultiplier * 45.0F));
               } else {
                  this.swingArm(swingProgress, equipProgress, matrices, handMultiplier, arm);
                  if (isRightHand && swingProgress < 0.001F && isMainHand) {
                     matrices.method_46416((float)handMultiplier * -0.641864F, 0.0F, 0.0F);
                     matrices.method_22907(class_7833.field_40716.rotationDegrees((float)handMultiplier * 10.0F));
                  }
               }

               this.renderItem(player, item, rightSide ? class_811.field_4322 : class_811.field_4321, !rightSide, matrices, vertexConsumers, light);
            } else {
               isRightHand = arm == class_1306.field_6183;
               int handMultiplier = isRightHand ? 1 : -1;
               if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
                  float drawTime;
                  switch(item.method_7976()) {
                  case field_8952:
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     break;
                  case field_8950:
                  case field_8946:
                     this.applyEatOrDrinkTransformation(matrices, tickDelta, arm, item, player);
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     break;
                  case field_8949:
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     if (!(item.method_7909() instanceof class_1819)) {
                        matrices.method_46416((float)handMultiplier * -0.14142136F, 0.08F, 0.14142136F);
                        matrices.method_22907(class_7833.field_40714.rotationDegrees(-102.25F));
                        matrices.method_22907(class_7833.field_40716.rotationDegrees((float)handMultiplier * 13.365F));
                        matrices.method_22907(class_7833.field_40718.rotationDegrees((float)handMultiplier * 78.05F));
                     }
                     break;
                  case field_8953:
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     matrices.method_46416((float)handMultiplier * -0.2785682F, 0.18344387F, 0.15731531F);
                     matrices.method_22907(class_7833.field_40714.rotationDegrees(-13.935F));
                     matrices.method_22907(class_7833.field_40716.rotationDegrees((float)handMultiplier * 35.3F));
                     matrices.method_22907(class_7833.field_40718.rotationDegrees((float)handMultiplier * -9.785F));
                     drawTime = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
                     useTimeRemaining = drawTime / 20.0F;
                     useTimeRemaining = (useTimeRemaining * useTimeRemaining + useTimeRemaining * 2.0F) / 3.0F;
                     if (useTimeRemaining > 1.0F) {
                        useTimeRemaining = 1.0F;
                     }

                     if (useTimeRemaining > 0.1F) {
                        progress = class_3532.method_15374((drawTime - 0.1F) * 1.3F);
                        sinValue = useTimeRemaining - 0.1F;
                        offsetProgress = progress * sinValue;
                        matrices.method_46416(offsetProgress * 0.0F, offsetProgress * 0.004F, offsetProgress * 0.0F);
                     }

                     matrices.method_46416(useTimeRemaining * 0.0F, useTimeRemaining * 0.0F, useTimeRemaining * 0.04F);
                     matrices.method_22905(1.0F, 1.0F, 1.0F + useTimeRemaining * 0.2F);
                     matrices.method_22907(class_7833.field_40715.rotationDegrees((float)handMultiplier * 45.0F));
                     break;
                  case field_8951:
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     matrices.method_46416((float)handMultiplier * -0.5F, 0.7F, 0.1F);
                     matrices.method_22907(class_7833.field_40714.rotationDegrees(-55.0F));
                     matrices.method_22907(class_7833.field_40716.rotationDegrees((float)handMultiplier * 35.3F));
                     matrices.method_22907(class_7833.field_40718.rotationDegrees((float)handMultiplier * -9.785F));
                     drawTime = (float)item.method_7935(player) - ((float)player.method_6014() - tickDelta + 1.0F);
                     useTimeRemaining = drawTime / 10.0F;
                     if (useTimeRemaining > 1.0F) {
                        useTimeRemaining = 1.0F;
                     }

                     if (useTimeRemaining > 0.1F) {
                        progress = class_3532.method_15374((drawTime - 0.1F) * 1.3F);
                        sinValue = useTimeRemaining - 0.1F;
                        offsetProgress = progress * sinValue;
                        matrices.method_46416(offsetProgress * 0.0F, offsetProgress * 0.004F, offsetProgress * 0.0F);
                     }

                     matrices.method_46416(0.0F, 0.0F, useTimeRemaining * 0.2F);
                     matrices.method_22905(1.0F, 1.0F, 1.0F + useTimeRemaining * 0.2F);
                     matrices.method_22907(class_7833.field_40715.rotationDegrees((float)handMultiplier * 45.0F));
                     break;
                  case field_42717:
                     this.applyBrushTransformation(matrices, tickDelta, arm, item, player, equipProgress);
                     break;
                  case field_55494:
                     this.swingArm(swingProgress, equipProgress, matrices, handMultiplier, arm);
                  }
               } else if (player.method_6123()) {
                  this.applyEquipOffset(matrices, arm, equipProgress);
                  matrices.method_46416((float)handMultiplier * -0.4F, 0.8F, 0.3F);
                  matrices.method_22907(class_7833.field_40716.rotationDegrees((float)handMultiplier * 65.0F));
                  matrices.method_22907(class_7833.field_40718.rotationDegrees((float)handMultiplier * -85.0F));
               } else {
                  this.swordAnimation(swingProgress, equipProgress, matrices, handMultiplier, arm);
               }

               this.renderItem(player, item, isRightHand ? class_811.field_4322 : class_811.field_4321, !isRightHand, matrices, vertexConsumers, light);
            }
         }

         matrices.method_22909();
      }

   }

   public void renderArmHoldingItem(class_4587 matrixStack, class_4597 renderBuffers, int lightLevel, float equipmentProgress, float swingProgress, class_1306 armSide) {
      boolean isRightArm = armSide != class_1306.field_6182;
      float armDirectionFactor = isRightArm ? 1.0F : -1.0F;
      float swingProgressSqrt = class_3532.method_15355(swingProgress);
      float horizontalSwingOffset = -0.3F * class_3532.method_15374(swingProgressSqrt * 3.1415927F);
      float verticalSwingOffset = 0.4F * class_3532.method_15374(swingProgressSqrt * 6.2831855F);
      float forwardSwingOffset = -0.4F * class_3532.method_15374(swingProgress * 3.1415927F);
      matrixStack.method_46416(armDirectionFactor * (horizontalSwingOffset + 0.64000005F), verticalSwingOffset + -0.6F + equipmentProgress * -0.6F, forwardSwingOffset + -0.71999997F);
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(armDirectionFactor * 45.0F));
      float swingSquaredSin = class_3532.method_15374(swingProgress * swingProgress * 3.1415927F);
      float swingSin = class_3532.method_15374(swingProgressSqrt * 3.1415927F);
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(armDirectionFactor * swingSin * 70.0F));
      matrixStack.method_22907(class_7833.field_40718.rotationDegrees(armDirectionFactor * swingSquaredSin * -20.0F));
      class_742 playerEntity = mc.field_1724;
      matrixStack.method_46416(armDirectionFactor * -1.0F, 3.6F, 3.5F);
      matrixStack.method_22907(class_7833.field_40718.rotationDegrees(armDirectionFactor * 120.0F));
      matrixStack.method_22907(class_7833.field_40714.rotationDegrees(200.0F));
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(armDirectionFactor * -135.0F));
      matrixStack.method_46416(armDirectionFactor * 5.6F, 0.0F, 0.0F);
      class_1007 playerRenderer = (class_1007)mc.method_1561().method_3953(playerEntity);
      class_2960 skinTexture = playerEntity.method_52814().comp_1626();
      if (isRightArm) {
         playerRenderer.method_4220(matrixStack, renderBuffers, lightLevel, skinTexture, playerEntity.method_7348(class_1664.field_7570));
      } else {
         playerRenderer.method_4221(matrixStack, renderBuffers, lightLevel, skinTexture, playerEntity.method_7348(class_1664.field_7568));
      }

   }

   public void applyBrushTransformation(class_4587 matrices, float tickDelta, class_1306 arm, class_1799 stack, class_1657 player, float equipProgress) {
      this.applyEquipOffset(matrices, arm, equipProgress);
      float brushCycle = (float)(player.method_6014() % 10);
      float brushTimeRemaining = brushCycle - tickDelta + 1.0F;
      float brushProgress = 1.0F - brushTimeRemaining / 10.0F;
      float brushRotation = -15.0F + 75.0F * class_3532.method_15362(brushProgress * 2.0F * 3.1415927F);
      if (arm != class_1306.field_6183) {
         matrices.method_22904(0.1D, 0.83D, 0.35D);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-90.0F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(brushRotation));
         matrices.method_22904(-0.3D, 0.22D, 0.35D);
      } else {
         matrices.method_22904(-0.25D, 0.22D, 0.35D);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
         matrices.method_22907(class_7833.field_40718.rotationDegrees(0.0F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(brushRotation));
      }

   }

   public void applyEquipOffset(class_4587 matrices, class_1306 arm, float equipProgress) {
      int handMultiplier = arm == class_1306.field_6183 ? 1 : -1;
      matrices.method_46416((float)handMultiplier * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
   }

   public void applySwingOffset(class_4587 matrices, class_1306 arm, float swingProgress) {
      int i = arm == class_1306.field_6183 ? 1 : -1;
      float f = class_3532.method_15374(swingProgress * swingProgress * 3.1415927F);
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * (45.0F + f * -20.0F)));
      float g = class_3532.method_15374(class_3532.method_15355(swingProgress) * 3.1415927F);
      matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * g * -20.0F));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(g * -80.0F));
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * -45.0F));
   }

   public void renderItem(class_1309 entity, class_1799 stack, class_811 renderMode, boolean leftHanded, class_4587 matrices, class_4597 vertexConsumers, int light) {
      if (!stack.method_7960()) {
         mc.method_1480().method_23177(entity, stack, renderMode, leftHanded, matrices, vertexConsumers, entity.method_37908(), light, class_4608.field_21444, entity.method_5628() + renderMode.ordinal());
      }

   }

   public void swingArm(float swingProgress, float equipProgress, class_4587 matrices, int armMultiplier, class_1306 arm) {
      float swingX = -0.4F * class_3532.method_15374(class_3532.method_15355(swingProgress) * 3.1415927F);
      float swingY = 0.2F * class_3532.method_15374(class_3532.method_15355(swingProgress) * 6.2831855F);
      float swingZ = -0.2F * class_3532.method_15374(swingProgress * 3.1415927F);
      matrices.method_46416((float)armMultiplier * swingX, swingY, swingZ);
      this.applyEquipOffset(matrices, arm, equipProgress);
      this.applySwingOffset(matrices, arm, swingProgress);
   }

   public void renderFirstPersonMap(class_4587 matrixStack, class_4597 renderBuffers, int lightLevel, class_1799 itemStack) {
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
      matrixStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
      matrixStack.method_22905(0.38F, 0.38F, 0.38F);
      matrixStack.method_46416(-0.5F, -0.5F, 0.0F);
      matrixStack.method_22905(0.0078125F, 0.0078125F, 0.0078125F);
      class_9209 mapId = (class_9209)itemStack.method_57824(class_9334.field_49646);
      class_22 mapData = class_1806.method_7997(mapId, mc.field_1687);
      class_1921 MAP_BACKGROUND = class_1921.method_23028(class_2960.method_60656("textures/map/map_background.png"));
      class_1921 MAP_BACKGROUND_CHECKERBOARD = class_1921.method_23028(class_2960.method_60656("textures/map/map_background_checkerboard.png"));
      class_4588 vertexBuffer = renderBuffers.getBuffer(mapData == null ? MAP_BACKGROUND : MAP_BACKGROUND_CHECKERBOARD);
      Matrix4f transformMatrix = matrixStack.method_23760().method_23761();
      vertexBuffer.method_22918(transformMatrix, -7.0F, 135.0F, 0.0F).method_39415(-1).method_22913(0.0F, 1.0F).method_60803(lightLevel);
      vertexBuffer.method_22918(transformMatrix, 135.0F, 135.0F, 0.0F).method_39415(-1).method_22913(1.0F, 1.0F).method_60803(lightLevel);
      vertexBuffer.method_22918(transformMatrix, 135.0F, -7.0F, 0.0F).method_39415(-1).method_22913(1.0F, 0.0F).method_60803(lightLevel);
      vertexBuffer.method_22918(transformMatrix, -7.0F, -7.0F, 0.0F).method_39415(-1).method_22913(0.0F, 0.0F).method_60803(lightLevel);
      if (mapData != null) {
         class_330 mapRenderer = mc.method_61965();
         mapRenderer.method_62230(mapId, mapData, new class_10090());
         mapRenderer.method_1773(new class_10090(), matrixStack, renderBuffers, false, lightLevel);
      }

   }

   public void renderMapInOneHand(class_4587 matrixStack, class_4597 renderBuffers, int lightLevel, float equipmentProgress, class_1306 armSide, float swingProgress, class_1799 itemStack) {
      float armDirectionFactor = armSide == class_1306.field_6183 ? 1.0F : -1.0F;
      matrixStack.method_46416(armDirectionFactor * 0.125F, -0.125F, 0.0F);
      if (!mc.field_1724.method_5767()) {
         matrixStack.method_22903();
         matrixStack.method_22907(class_7833.field_40718.rotationDegrees(armDirectionFactor * 10.0F));
         this.renderArmHoldingItem(matrixStack, renderBuffers, lightLevel, equipmentProgress, swingProgress, armSide);
         matrixStack.method_22909();
      }

      matrixStack.method_22903();
      matrixStack.method_46416(armDirectionFactor * 0.51F, -0.08F + equipmentProgress * -1.2F, -0.75F);
      float swingProgressSqrt = class_3532.method_15355(swingProgress);
      float swingSin = class_3532.method_15374(swingProgressSqrt * 3.1415927F);
      float horizontalOffset = -0.5F * swingSin;
      float verticalOffset = 0.4F * class_3532.method_15374(swingProgressSqrt * 6.2831855F);
      float forwardOffset = -0.3F * class_3532.method_15374(swingProgress * 3.1415927F);
      matrixStack.method_46416(armDirectionFactor * horizontalOffset, verticalOffset - 0.3F * swingSin, forwardOffset);
      matrixStack.method_22907(class_7833.field_40714.rotationDegrees(swingSin * -45.0F));
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(armDirectionFactor * swingSin * -30.0F));
      this.renderFirstPersonMap(matrixStack, renderBuffers, lightLevel, itemStack);
      matrixStack.method_22909();
   }

   public float getMapAngle(float pitchAngle) {
      float normalizedAngle = 1.0F - pitchAngle / 45.0F + 0.1F;
      normalizedAngle = class_3532.method_15363(normalizedAngle, 0.0F, 1.0F);
      normalizedAngle = -class_3532.method_15362(normalizedAngle * 3.1415927F) * 0.5F + 0.5F;
      return normalizedAngle;
   }

   public void renderMapInBothHands(class_4587 matrixStack, class_4597 renderBuffers, int lightLevel, float pitchAngle, float equipmentProgress, float swingProgress) {
      float swingProgressSqrt = class_3532.method_15355(swingProgress);
      float verticalSwingOffset = -0.2F * class_3532.method_15374(swingProgress * 3.1415927F);
      float forwardSwingOffset = -0.4F * class_3532.method_15374(swingProgressSqrt * 3.1415927F);
      matrixStack.method_46416(0.0F, -verticalSwingOffset / 2.0F, forwardSwingOffset);
      float mapAngle = this.getMapAngle(pitchAngle);
      matrixStack.method_46416(0.0F, 0.04F + equipmentProgress * -1.2F + mapAngle * -0.5F, -0.72F);
      matrixStack.method_22907(class_7833.field_40714.rotationDegrees(mapAngle * -85.0F));
      if (!mc.field_1724.method_5767()) {
         matrixStack.method_22903();
         matrixStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
         this.renderArm(matrixStack, renderBuffers, lightLevel, class_1306.field_6183);
         this.renderArm(matrixStack, renderBuffers, lightLevel, class_1306.field_6182);
         matrixStack.method_22909();
      }

      float swingSin = class_3532.method_15374(swingProgressSqrt * 3.1415927F);
      matrixStack.method_22907(class_7833.field_40714.rotationDegrees(swingSin * 20.0F));
      matrixStack.method_22905(2.0F, 2.0F, 2.0F);
      this.renderFirstPersonMap(matrixStack, renderBuffers, lightLevel, mc.field_1724.method_6047());
   }

   public void renderArm(class_4587 matrixStack, class_4597 renderBuffers, int lightLevel, class_1306 armSide) {
      class_1007 playerRenderer = (class_1007)mc.method_1561().method_3953(mc.field_1724);
      matrixStack.method_22903();
      float armDirectionFactor = armSide == class_1306.field_6183 ? 1.0F : -1.0F;
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(92.0F));
      matrixStack.method_22907(class_7833.field_40714.rotationDegrees(45.0F));
      matrixStack.method_22907(class_7833.field_40718.rotationDegrees(armDirectionFactor * -41.0F));
      matrixStack.method_46416(armDirectionFactor * 0.3F, -1.1F, 0.45F);
      class_2960 skinTexture = mc.field_1724.method_52814().comp_1626();
      if (armSide == class_1306.field_6183) {
         playerRenderer.method_4220(matrixStack, renderBuffers, lightLevel, skinTexture, mc.field_1724.method_7348(class_1664.field_7570));
      } else {
         playerRenderer.method_4221(matrixStack, renderBuffers, lightLevel, skinTexture, mc.field_1724.method_7348(class_1664.field_7568));
      }

      matrixStack.method_22909();
   }

   public void applyEatOrDrinkTransformation(class_4587 matrices, float tickDelta, class_1306 arm, class_1799 stack, class_1657 player) {
      float useTimeRemaining = (float)player.method_6014() - tickDelta + 1.0F;
      float useProgress = useTimeRemaining / (float)stack.method_7935(player);
      float bobHeight;
      if (useProgress < 0.8F) {
         bobHeight = class_3532.method_15379(class_3532.method_15362(useTimeRemaining / 4.0F * 3.1415927F) * 0.1F);
         matrices.method_46416(0.0F, bobHeight, 0.0F);
      }

      bobHeight = 1.0F - (float)Math.pow((double)useProgress, 27.0D);
      int handMultiplier = arm == class_1306.field_6183 ? 1 : -1;
      matrices.method_46416(bobHeight * 0.6F * (float)handMultiplier, bobHeight * -0.5F, bobHeight * 0.0F);
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)handMultiplier * bobHeight * 90.0F));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(bobHeight * 10.0F));
      matrices.method_22907(class_7833.field_40718.rotationDegrees((float)handMultiplier * bobHeight * 30.0F));
   }

   public ItemTransforms() {
      this.getSettingRepository().registerSettings(this.x, this.y, this.z, this.mode, this.handSetting);
   }
}
