package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.Module;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.events.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "KeyBinds",
   description = "Shows Binded Modules",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Keybinds extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final ModeSetting mode;
   private final NumberSetting<Integer> xPos;
   private final NumberSetting<Integer> yPos;

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      class_332 context = event.getContext();
      class_4587 matrices = context.method_51448();
      if (mc.field_1724 != null && mc.field_1687 != null && !mc.method_53526().method_53536()) {
         String var4 = this.mode.getValue();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case 2017619398:
            if (var4.equals("Chorus")) {
               var5 = 0;
            }
         default:
            switch(var5) {
            case 0:
               this.renderChorus(matrices, context);
            default:
            }
         }
      }
   }

   private void renderChorus(class_4587 matrices, class_332 context) {
      FontAtlas interMedium = Chorus.getInstance().getFonts().getInterMedium();
      FontAtlas interBold = Chorus.getInstance().getFonts().getInterSemiBold();
      int x = (Integer)this.xPos.getValue();
      int y = (Integer)this.yPos.getValue();
      int padding = 6;
      List<Module> enabledModules = new ArrayList(Chorus.getInstance().getModuleManager().getModules().stream().filter((modulex) -> {
         return modulex.getKey() != -1;
      }).sorted(Comparator.comparingDouble((m) -> {
         return (double)(-interMedium.getWidth(m.getName() + InputUtils.getKeyName(m.getKey()), 8.0F));
      })).toList());
      float yPos = (float)y;
      if (!enabledModules.isEmpty()) {
         for(Iterator var10 = enabledModules.iterator(); var10.hasNext(); yPos += interMedium.getLineHeight() + 5.0F) {
            Module module = (Module)var10.next();
            String var10000 = module.getName();
            String moduleString = var10000 + " | " + InputUtils.getKeyName(module.getKey());
            Render2DEngine.drawRoundedBlur(matrices, (float)x, yPos, interMedium.getWidth(moduleString, 8.0F) + (float)padding, interMedium.getLineHeight() + 3.0F, 4.0F, 8.0F, new Color(255, 255, 255, 10));
            Render2DEngine.drawRoundedOutline(matrices, (float)x, yPos, interMedium.getWidth(moduleString, 8.0F) + (float)padding, interMedium.getLineHeight() + 3.0F, 4.0F, 1.0F, new Color(200, 200, 200, 75));
            if (module == enabledModules.getFirst()) {
               this.setWidth(interMedium.getWidth(moduleString, 8.0F) + (float)padding);
            }

            interMedium.render(matrices, moduleString, (float)x + 3.0F, yPos + interMedium.getLineHeight() / 2.0F - 3.0F, 8.0F, Color.WHITE.getRGB());
         }

         this.setHeight(yPos - (float)y);
      }
   }

   public Keybinds() {
      this.mode = new ModeSetting(this.general, "Mode", "Choose style", "Chorus", new String[]{"Chorus"});
      this.xPos = new NumberSetting(this.general, "xPos", "Internal setting", 5, 0, 1920);
      this.yPos = new NumberSetting(this.general, "yPos", "Internal setting", 105, 0, 1080);
      this.getSettingRepository().registerSettings(this.general, this.mode, this.xPos, this.yPos);
      this.setDraggable(true);
      this.xPos.setRenderCondition(() -> {
         return false;
      });
      this.yPos.setRenderCondition(() -> {
         return false;
      });
   }
}
