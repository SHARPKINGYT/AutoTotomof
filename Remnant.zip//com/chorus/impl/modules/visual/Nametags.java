package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.ColorUtils;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import com.chorus.impl.events.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_9779;

@ModuleInfo(
   name = "Nametags",
   description = "mahahah slink slink",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Nametags extends BaseModule implements QuickImports {
   private final SettingCategory visual = new SettingCategory("Visual Settings");
   private final BooleanSetting showHealth;
   private final BooleanSetting showDistance;
   private final BooleanSetting showBackground;
   private final BooleanSetting combine;
   private final BooleanSetting showArmor;
   private final NumberSetting<Integer> range;
   private final NumberSetting<Integer> scale;
   private final BooleanSetting scaleWithDistance;
   private Map<class_1297, class_3545<Nametags.Rectangle, Boolean>> hashMap;
   class_9779 renderTickCounter;

   @RegisterEvent
   private void Render3DEvent(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         this.hashMap.clear();
         if (mc.field_1724 != null && mc.field_1687 != null) {
            Iterator var2 = mc.field_1687.method_18456().iterator();

            while(true) {
               class_1657 entity;
               do {
                  do {
                     if (!var2.hasNext()) {
                        return;
                     }

                     entity = (class_1657)var2.next();
                  } while(entity == null);
               } while(npcRepository.isNPC(entity.method_5820()));

               class_243 prevPos = new class_243(entity.field_6038, entity.field_5971, entity.field_5989);
               class_243 interpolated = prevPos.method_1019(entity.method_19538().method_1020(prevPos).method_1021((double)this.renderTickCounter.method_60637(false))).method_1031(0.0D, 0.05000000074505806D, 0.0D);
               class_238 boundingBox = new class_238(interpolated.field_1352, interpolated.field_1351, interpolated.field_1350, interpolated.field_1352, interpolated.field_1351 + (double)entity.method_17682() + (entity.method_5715() ? -0.2D : 0.0D), interpolated.field_1350);
               class_243[] corners = new class_243[]{new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1324)};
               Nametags.Rectangle rectangle = null;
               boolean visible = false;
               class_243[] var10 = corners;
               int var11 = corners.length;

               for(int var12 = 0; var12 < var11; ++var12) {
                  class_243 corner = var10[var12];
                  class_3545<class_243, Boolean> projection = Render3DEngine.project(event.getMatrices().method_23760().method_23761(), event.getProjectionMatrix(), corner);
                  if ((Boolean)projection.method_15441()) {
                     visible = true;
                  }

                  class_243 projected = (class_243)projection.method_15442();
                  if (rectangle == null) {
                     rectangle = new Nametags.Rectangle((double)((int)projected.method_10216()), (double)((int)projected.method_10214()), (double)((int)projected.method_10216()), (double)((int)projected.method_10214()));
                  } else {
                     if (rectangle.x > projected.method_10216()) {
                        rectangle.x = (double)((int)projected.method_10216());
                     }

                     if (rectangle.y > projected.method_10214()) {
                        rectangle.y = (double)((int)projected.method_10214());
                     }

                     if (rectangle.z < projected.method_10216()) {
                        rectangle.z = (double)((int)projected.method_10216());
                     }

                     if (rectangle.w < projected.method_10214()) {
                        rectangle.w = (double)((int)projected.method_10214());
                     }
                  }
               }

               this.hashMap.put(entity, new class_3545(rectangle, visible));
            }
         }
      }
   }

   @RegisterEvent
   private void Render2DEvent(Render2DEvent event) {
      if (event.getMode().equals(Render2DEvent.Mode.PRE)) {
         class_4587 matrix = event.getContext().method_51448();
         class_332 context = event.getContext();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.setShader(class_10142.field_53876);
         if (!this.hashMap.isEmpty() && this.hashMap.entrySet().stream().anyMatch((entityPairEntry) -> {
            return (Boolean)((class_3545)entityPairEntry.getValue()).method_15441();
         })) {
            Iterator var4 = this.hashMap.entrySet().iterator();

            label141:
            while(true) {
               class_3545 pair;
               FontAtlas font;
               class_1657 player;
               do {
                  Entry entry;
                  do {
                     if (!var4.hasNext()) {
                        break label141;
                     }

                     entry = (Entry)var4.next();
                     pair = (class_3545)entry.getValue();
                     font = Chorus.getInstance().getFonts().getInterBold();
                  } while(!(Boolean)pair.method_15441());

                  player = (class_1657)entry.getKey();
               } while(player == mc.field_1724 && mc.field_1690.method_31044() == class_5498.field_26664);

               if (!player.method_36608() || player.method_31481() || player.method_7325()) {
                  return;
               }

               float distance = mc.field_1724.method_5739(player);
               if (distance <= (float)(Integer)this.range.getValue()) {
                  float currentScale = this.scaleWithDistance.getValue() ? Math.max((float)(Integer)this.scale.getValue() / 100.0F * (1.0F - distance / (float)(Integer)this.range.getValue()), 0.5F * ((float)(Integer)this.scale.getValue() / 100.0F)) : (float)(Integer)this.scale.getValue() / 100.0F;
                  float centerX = (float)((((Nametags.Rectangle)pair.method_15442()).x + ((Nametags.Rectangle)pair.method_15442()).z) / 2.0D);
                  float y = (float)(((Nametags.Rectangle)pair.method_15442()).y - (double)player.method_17682() - 4.5D) - 10.0F;
                  String name = player.method_5820();
                  if (name == null || name.isEmpty()) {
                     name = "Unknown";
                  }

                  name = name.replaceAll("§", "");
                  StringBuilder combinedText = new StringBuilder(name);
                  Color backgroundColor = new Color(0, 0, 0, 200);
                  DecimalFormat format = new DecimalFormat("#.#");
                  float nameWidth = font.getWidth(combinedText.toString(), 10.0F) * currentScale;
                  float textHeight = font.getLineHeight(10.0F) * currentScale;
                  String var10000 = format.format((double)Math.clamp(player.method_6032() / 2.0F, 0.0F, 1.0E7F));
                  String healthText = var10000 + "hp";
                  float healthWidth = font.getWidth(healthText, 10.0F) * currentScale;
                  var10000 = format.format((double)(player.method_6067() / 2.0F));
                  String absorptionText = " +" + var10000;
                  float absorptionWidth = player.method_6067() != 0.0F ? font.getWidth(absorptionText, 10.0F) * currentScale : 0.0F;
                  var10000 = format.format((double)distance);
                  String distanceText = var10000 + "m";
                  float distanceWidth = font.getWidth(distanceText, 10.0F) * currentScale;
                  float padding = 10.0F * currentScale;
                  float totalWidth = nameWidth;
                  if (this.showHealth.getValue()) {
                     totalWidth = nameWidth + healthWidth + padding + absorptionWidth;
                  }

                  if (this.showDistance.getValue()) {
                     totalWidth += distanceWidth + padding;
                  }

                  float contentLeftEdge = centerX - totalWidth / 2.0F;
                  float currentX = contentLeftEdge;
                  if (this.showDistance.getValue()) {
                     currentX = contentLeftEdge + distanceWidth + padding;
                  }

                  float nameX = currentX;
                  currentX += nameWidth + padding;
                  if (this.showArmor.getValue()) {
                     int armorAmount = 0;

                     int i;
                     for(i = 3; i >= 0; --i) {
                        if (!player.method_31548().method_7372(i).method_7960()) {
                           ++armorAmount;
                        }
                     }

                     i = armorAmount * 15;
                     float startX = contentLeftEdge - 5.0F + (totalWidth + 10.0F) / 2.0F + (float)i / 2.0F;

                     for(int i = 3; i >= 0; --i) {
                        if (!player.method_31548().method_7372(i).method_7960()) {
                           context.method_51427((class_1799)player.method_31548().field_7548.get(i), (int)(startX - (float)(armorAmount * 15)), (int)y - 15);
                           --armorAmount;
                        }
                     }
                  }

                  if (this.combine.getValue() && this.showBackground.getValue()) {
                     Render2DEngine.drawRoundedBlur(matrix, contentLeftEdge - 5.0F, y - 1.0F, totalWidth + 10.0F, textHeight + 2.0F, 3.0F, 8.0F, backgroundColor);
                     Render2DEngine.drawRoundedRect(matrix, contentLeftEdge - 5.0F, y - 1.0F, totalWidth + 10.0F, textHeight + 2.0F, 3.0F, backgroundColor);
                  }

                  if (this.showDistance.getValue()) {
                     if (this.showBackground.getValue() && !this.combine.getValue()) {
                        Render2DEngine.drawRoundedRect(matrix, contentLeftEdge - 5.0F, y - 1.0F, distanceWidth + 10.0F, textHeight + 2.0F, 3.0F, backgroundColor);
                     }

                     font.renderWithShadow(matrix, distanceText, contentLeftEdge, y, 10.0F * currentScale, Color.GRAY.getRGB());
                  }

                  if (this.showBackground.getValue() && !this.combine.getValue()) {
                     Render2DEngine.drawRoundedRect(matrix, nameX - 5.0F, y - 1.0F, nameWidth + 10.0F, textHeight + 2.0F, 3.0F, backgroundColor);
                  }

                  font.renderWithShadow(matrix, combinedText.toString(), nameX, y, 10.0F * currentScale, getAssociatedColor(player).getRGB());
                  if (this.showHealth.getValue()) {
                     float multiplier;
                     if (this.showBackground.getValue() && !this.combine.getValue()) {
                        multiplier = healthWidth + absorptionWidth + 10.0F;
                        Render2DEngine.drawRoundedRect(matrix, currentX - 5.0F, y - 1.0F, multiplier, textHeight + 2.0F, 3.0F, backgroundColor);
                     }

                     multiplier = player.method_6032() / player.method_6063();
                     font.renderWithShadow(matrix, healthText, currentX, y, 10.0F * currentScale, ColorUtils.interpolateColor(new Color(255, 127, 127), new Color(127, 255, 127), multiplier * multiplier * multiplier).getRGB());
                     if (player.method_6067() != 0.0F) {
                        font.renderWithShadow(matrix, absorptionText, currentX + healthWidth, y, 10.0F * currentScale, (new Color(254, 222, 53)).getRGB());
                     }
                  }
               }
            }
         }

         RenderSystem.disableBlend();
      }

   }

   public static Color getAssociatedColor(class_1657 player) {
      if (player == mc.field_1724) {
         return new Color(127, 255, 127);
      } else if (friendRepository.isFriend(player.method_5667())) {
         return new Color(127, 255, 127);
      } else if (npcRepository.isNPC(player.method_5820())) {
         return new Color(118, 118, 118);
      } else {
         return player.method_5781() != null && player.method_5781().method_1202().method_532() != null ? ColorUtils.formattingToRGB(player.method_5781().method_1202().method_532()) : new Color(255, 127, 127);
      }
   }

   public Nametags() {
      this.showHealth = new BooleanSetting(this.visual, "Show Health", "Display player health", true);
      this.showDistance = new BooleanSetting(this.visual, "Show Distance", "Display distance to player", true);
      this.showBackground = new BooleanSetting(this.visual, "Show Background", "Display a background behind the text", true);
      this.combine = new BooleanSetting(this.visual, "Combine", "Background", false);
      this.showArmor = new BooleanSetting(this.visual, "Show Armor", "Display the players armor", true);
      this.range = new NumberSetting(this.visual, "Range", "Maximum distance to render nametags", 64, 0, 256);
      this.scale = new NumberSetting(this.visual, "Scale", "Size of the nametags", 100, 50, 200);
      this.scaleWithDistance = new BooleanSetting(this.visual, "Scale with Distance", "Decrease size with distance", true);
      this.hashMap = new HashMap();
      this.renderTickCounter = mc.method_61966();
      this.getSettingRepository().registerSettings(this.visual, this.showHealth, this.showDistance, this.showArmor, this.showBackground, this.combine, this.range, this.scale, this.scaleWithDistance);
   }

   @Environment(EnvType.CLIENT)
   public static class Rectangle {
      public double x;
      public double y;
      public double z;
      public double w;

      public Rectangle(double x, double y, double z, double w) {
         this.x = x;
         this.y = y;
         this.z = z;
         this.w = w;
      }
   }
}
