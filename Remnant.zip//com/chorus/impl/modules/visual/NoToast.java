package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "NoToast",
   description = "Hides all minecraft toasts",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class NoToast extends BaseModule implements QuickImports {
   @RegisterEvent
   private void Render2DEvent(Render2DEvent event) {
      mc.method_1566().method_2000();
   }
}
