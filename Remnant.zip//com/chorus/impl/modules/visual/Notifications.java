package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.notification.NotificationManager;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.impl.events.render.Render2DEvent;
import java.awt.Color;
import java.util.Iterator;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "Notifications",
   description = "sigma",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Notifications extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   public final ModeSetting mode;
   public final BooleanSetting enableNotifications;

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      class_332 context = event.getContext();
      class_4587 matrices = context.method_51448();
      Iterator var4 = notificationManager.getNotifications().iterator();

      while(var4.hasNext()) {
         NotificationManager.Notification notification = (NotificationManager.Notification)var4.next();
         String var6 = ((Notifications)Chorus.getInstance().getModuleManager().getModule(Notifications.class)).mode.getValue();
         byte var7 = -1;
         switch(var6.hashCode()) {
         case -1538527693:
            if (var6.equals("Remnant")) {
               var7 = 1;
            }
            break;
         case 2017619398:
            if (var6.equals("Chorus")) {
               var7 = 0;
            }
         }

         switch(var7) {
         case 0:
            notificationManager.setStartingPos(new float[]{(float)(mc.method_22683().method_4486() + 500), 0.0F});
            this.renderAdjust(matrices, context, notification);
            break;
         case 1:
            this.renderRemnant(matrices, context, notification);
         }
      }

   }

   private void renderAdjust(class_4587 matrices, class_332 context, NotificationManager.Notification notification) {
      FontAtlas interBold = Chorus.getInstance().getFonts().getInterSemiBold();
      FontAtlas interMedium = Chorus.getInstance().getFonts().getInterMedium();
      Map<NotificationManager.Notification, float[]> notificationProgress = notificationManager.getNotificationProgress();
      Color themeColor = new Color(184, 112, 242, 255);
      Color background = new Color(0, 0, 0, 100);
      float height = 27.5F;
      float length = 40.0F;
      float[] position = (float[])notificationProgress.getOrDefault(notification, new float[]{(float)mc.method_22683().method_4486() + 100.0F, (float)mc.method_22683().method_4502()});
      int notificationIndex = notificationManager.getNotifications().indexOf(notification);
      float fullWidth = Math.max(interBold.getWidth(notification.title(), 8.0F), interMedium.getWidth(notification.content())) + length;
      boolean isFinished = System.currentTimeMillis() - notification.currentTimeMillis() > (long)notification.time();
      float targetX = (float)mc.method_22683().method_4486() - fullWidth - 5.0F;
      float smoothX = MathUtils.lerp(position[0], isFinished ? targetX + 500.0F : targetX, 3.0F / (float)mc.method_47599());
      float targetY = (float)mc.method_22683().method_4502() / 1.07F - (float)notificationIndex * (height + 5.0F);
      float smoothY = MathUtils.lerp(position[1], isFinished ? targetY + 100.0F : targetY, 3.0F / (float)mc.method_47599());
      float padding = 3.0F;
      Render2DEngine.drawGradientRect(matrices, smoothX, smoothY, fullWidth, 1.0F, themeColor, themeColor.brighter().brighter());
      Render2DEngine.drawRect(matrices, smoothX, smoothY, fullWidth, height, background);
      interBold.renderWithShadow(matrices, notification.title(), smoothX + padding, smoothY + padding + 1.0F, 8.0F, themeColor.getRGB());
      interMedium.renderWithShadow(matrices, notification.content(), smoothX + padding, smoothY + padding + interBold.getLineHeight(8.0F) + 1.0F, 7.0F, (new Color(197, 197, 197, 255)).getRGB());
      if (smoothY > targetY + 50.0F && isFinished) {
         notificationManager.getNotificationProgress().remove(notification);
         notificationManager.getNotifications().remove(notification);
      } else {
         notificationManager.getNotificationProgress().put(notification, new float[]{smoothX, smoothY});
      }

   }

   private void renderRemnant(class_4587 matrices, class_332 context, NotificationManager.Notification notification) {
      FontAtlas poppins = Chorus.getInstance().getFonts().getPoppins();
      Map<NotificationManager.Notification, float[]> notificationProgress = notificationManager.getNotificationProgress();
      float padding = 3.0F;
      float height = poppins.getLineHeight(8.0F);
      float length = 35.0F;
      float[] position = (float[])notificationProgress.getOrDefault(notification, new float[]{(float)mc.method_22683().method_4486() / 2.0F, (float)(mc.method_22683().method_4502() - 300)});
      int notificationIndex = notificationManager.getNotifications().indexOf(notification);
      String var10001 = notification.title();
      float fullWidth = Math.max(poppins.getWidth(var10001 + " " + notification.content(), 8.0F), 8.0F);
      notificationManager.setStartingPos(new float[]{(float)mc.method_22683().method_4486() / 2.0F - fullWidth / 2.0F, (float)(mc.method_22683().method_4502() - 500)});
      boolean isFinished = System.currentTimeMillis() - notification.currentTimeMillis() > (long)(notification.time() / 5);
      float targetX = (float)mc.method_22683().method_4486() / 2.0F - fullWidth / 2.0F;
      float smoothX = MathUtils.lerp(position[0], targetX, 3.0F / (float)mc.method_47599());
      float targetY = 50.0F - (float)notificationIndex * (height + 5.0F);
      float smoothY = MathUtils.lerp(position[1], isFinished ? targetY + 300.0F : targetY, 3.0F / (float)mc.method_47599());
      Render2DEngine.drawBlurredRoundedRect(matrices, smoothX - padding, smoothY + poppins.getLineHeight(8.0F) / 2.0F, fullWidth + padding, height, 4.0F, 8.0F, new Color(255, 255, 255, 10));
      Render2DEngine.drawRoundedOutline(matrices, smoothX - padding, smoothY + poppins.getLineHeight(8.0F) / 2.0F, fullWidth + padding, height, 4.0F, 1.0F, new Color(200, 200, 200, 75));
      poppins.render(matrices, notification.title().toLowerCase(), smoothX, smoothY + poppins.getLineHeight(8.0F) / 2.0F, 8.0F, Color.WHITE.getRGB());
      poppins.render(matrices, notification.content().toLowerCase(), smoothX + poppins.getWidth(notification.title().toLowerCase() + " ", 8.0F), smoothY + poppins.getLineHeight(8.0F) / 2.0F, 8.0F, Color.GREEN.getRGB());
      if (smoothY > targetY + 50.0F && isFinished) {
         notificationManager.getNotificationProgress().remove(notification);
         notificationManager.getNotifications().remove(notification);
      } else {
         notificationManager.getNotificationProgress().put(notification, new float[]{smoothX, smoothY});
      }

   }

   public Notifications() {
      this.mode = new ModeSetting(this.general, "Mode", "Choose style", "Chorus", new String[]{"Chorus", "Remnant"});
      this.enableNotifications = new BooleanSetting("Module Toggle", "Shows a notification when a module is toggled", false);
      this.getSettingRepository().registerSettings(this.general, this.mode, this.enableNotifications);
   }
}
