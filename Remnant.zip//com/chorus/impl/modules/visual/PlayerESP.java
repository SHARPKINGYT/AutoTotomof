package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.ColorUtils;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import com.chorus.impl.events.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_3545;
import net.minecraft.class_9779;
import net.minecraft.class_9801;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;

@ModuleInfo(
   name = "PlayerESP",
   description = "can u see me",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class PlayerESP extends BaseModule implements QuickImports {
   private final SettingCategory visual = new SettingCategory("Visual Settings");
   private final SettingCategory color = new SettingCategory("Color Settings");
   public final ModeSetting espMode;
   private final BooleanSetting showHealthBar;
   private final ModeSetting healthBarPosition;
   private final NumberSetting<Integer> red;
   private final NumberSetting<Integer> green;
   private final NumberSetting<Integer> blue;
   private final NumberSetting<Integer> alpha;
   public final MultiSetting exclude;
   private Map<class_1297, class_3545<PlayerESP.Rectangle, Boolean>> hashMap;
   class_9779 renderTickCounter;

   @RegisterEvent
   private void Render3DEvent(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         this.hashMap.clear();
         if (mc.field_1724 != null && mc.field_1687 != null) {
            Iterator var2 = mc.field_1687.method_18456().iterator();

            while(true) {
               class_1657 entity;
               Color settingColor;
               do {
                  if (!var2.hasNext()) {
                     return;
                  }

                  entity = (class_1657)var2.next();
                  settingColor = ColorUtils.getAssociatedColor(entity);
               } while(entity == mc.field_1724);

               if (this.exclude.getSpecificValue("Friends") && friendRepository.isFriend(entity.method_5667())) {
                  return;
               }

               if (this.exclude.getSpecificValue("Bots") && npcRepository.isNPC(entity.method_5820())) {
                  return;
               }

               if (this.exclude.getSpecificValue("Teams") && teamRepository.isMemberOfCurrentTeam(entity.method_5820())) {
                  return;
               }

               String var5 = this.espMode.getValue();
               byte var6 = -1;
               switch(var5.hashCode()) {
               case 21529402:
                  if (var5.equals("Shaded 3D")) {
                     var6 = 0;
                  }
                  break;
               case 235254479:
                  if (var5.equals("Outlined 3D")) {
                     var6 = 1;
                  }
                  break;
               case 748141811:
                  if (var5.equals("Outlined And Shaded 3D")) {
                     var6 = 2;
                  }
               }

               switch(var6) {
               case 0:
                  Render3DEngine.renderShadedBox(entity, settingColor, (Integer)this.alpha.getValue(), event.getMatrices());
                  break;
               case 1:
                  Render3DEngine.renderOutlinedBox(entity, settingColor, event.getMatrices());
                  break;
               case 2:
                  Render3DEngine.renderOutlinedShadedBox(entity, settingColor, (Integer)this.alpha.getValue(), event.getMatrices());
               }

               class_243 prevPos = new class_243(entity.field_6038, entity.field_5971, entity.field_5989);
               class_243 interpolated = prevPos.method_1019(entity.method_19538().method_1020(prevPos).method_1021((double)this.renderTickCounter.method_60637(false)));
               float halfWidth = entity.method_17681() / 2.0F;
               class_238 boundingBox = (new class_238(interpolated.field_1352 - (double)halfWidth, interpolated.field_1351, interpolated.field_1350 - (double)halfWidth, interpolated.field_1352 + (double)halfWidth, interpolated.field_1351 + (double)entity.method_17682() + (entity.method_5715() ? -0.2D : 0.0D), interpolated.field_1350 + (double)halfWidth)).method_1009(0.1D, 0.1D, 0.1D);
               class_243[] corners = new class_243[]{new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1324)};
               PlayerESP.Rectangle rectangle = null;
               boolean visible = false;
               class_243[] var12 = corners;
               int var13 = corners.length;

               for(int var14 = 0; var14 < var13; ++var14) {
                  class_243 corner = var12[var14];
                  class_3545<class_243, Boolean> projection = Render3DEngine.project(event.getMatrices().method_23760().method_23761(), event.getProjectionMatrix(), corner);
                  if ((Boolean)projection.method_15441()) {
                     visible = true;
                  }

                  class_243 projected = (class_243)projection.method_15442();
                  if (rectangle == null) {
                     rectangle = new PlayerESP.Rectangle((double)((int)projected.method_10216()), (double)((int)projected.method_10214()), (double)((int)projected.method_10216()), (double)((int)projected.method_10214()));
                  } else {
                     if (rectangle.x > projected.method_10216()) {
                        rectangle.x = (double)((int)projected.method_10216());
                     }

                     if (rectangle.y > projected.method_10214()) {
                        rectangle.y = (double)((int)projected.method_10214());
                     }

                     if (rectangle.z < projected.method_10216()) {
                        rectangle.z = (double)((int)projected.method_10216());
                     }

                     if (rectangle.w < projected.method_10214()) {
                        rectangle.w = (double)((int)projected.method_10214());
                     }
                  }
               }

               this.hashMap.put(entity, new class_3545(rectangle, visible));
            }
         }
      }
   }

   @RegisterEvent
   private void Render2DEvent(Render2DEvent event) {
      if (event.getMode().equals(Render2DEvent.Mode.PRE) && this.espMode.getValue().equals("Outlined 2D")) {
         Matrix4f matrix = event.getContext().method_51448().method_23760().method_23761();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.setShader(class_10142.field_53876);
         class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);
         if (!this.hashMap.isEmpty() && this.hashMap.entrySet().stream().anyMatch((entityPairEntry) -> {
            return (Boolean)((class_3545)entityPairEntry.getValue()).method_15441();
         })) {
            Iterator var4 = this.hashMap.entrySet().iterator();

            label72:
            while(true) {
               while(true) {
                  Color settingColor;
                  double posX;
                  double posY;
                  double endX;
                  double endY;
                  class_1657 player;
                  do {
                     Object var18;
                     do {
                        Entry entry;
                        class_3545 pair;
                        do {
                           if (!var4.hasNext()) {
                              class_286.method_43433((class_9801)Objects.requireNonNull(bufferBuilder.method_60794()));
                              break label72;
                           }

                           entry = (Entry)var4.next();
                           pair = (class_3545)entry.getValue();
                           settingColor = ColorUtils.getAssociatedColor((class_1657)entry.getKey());
                        } while(!(Boolean)pair.method_15441());

                        PlayerESP.Rectangle rect = (PlayerESP.Rectangle)pair.method_15442();
                        posX = rect.x;
                        posY = rect.y;
                        endX = rect.z;
                        endY = rect.w;
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)posX - 1.0F, (float)posY, (float)posX + 0.5F, (float)endY + 0.5F, Color.BLACK);
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)posX - 1.0F, (float)posY - 0.5F, (float)endX + 0.5F, (float)posY + 1.0F, Color.BLACK);
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)endX - 1.0F, (float)posY, (float)endX + 0.5F, (float)endY + 0.5F, Color.BLACK);
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)posX - 1.0F, (float)endY - 1.0F, (float)endX + 0.5F, (float)endY + 0.5F, Color.BLACK);
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)posX - 0.5F, (float)posY, (float)posX, (float)endY, settingColor);
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)posX, (float)endY - 0.5F, (float)endX, (float)endY, settingColor);
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)posX - 0.5F, (float)posY, (float)endX, (float)posY + 0.5F, settingColor);
                        Render2DEngine.drawQuads(bufferBuilder, matrix, (float)endX - 0.5F, (float)posY, (float)endX, (float)endY, settingColor);
                        var18 = entry.getKey();
                     } while(!(var18 instanceof class_1657));

                     player = (class_1657)var18;
                  } while(!this.showHealthBar.getValue());

                  float healthPercentage = player.method_6032() / player.method_6063();
                  float barWidth = 0.0F;
                  float barHeight = 0.0F;
                  float barPosX = 0.0F;
                  float barPosY = 0.0F;
                  String var23 = this.healthBarPosition.getValue();
                  byte var24 = -1;
                  switch(var23.hashCode()) {
                  case 84277:
                     if (var23.equals("Top")) {
                        var24 = 1;
                     }
                     break;
                  case 2364455:
                     if (var23.equals("Left")) {
                        var24 = 2;
                     }
                     break;
                  case 78959100:
                     if (var23.equals("Right")) {
                        var24 = 3;
                     }
                     break;
                  case 1995605579:
                     if (var23.equals("Bottom")) {
                        var24 = 0;
                     }
                  }

                  switch(var24) {
                  case 0:
                     barWidth = (float)(endX - posX);
                     barHeight = 2.0F;
                     barPosX = (float)posX;
                     barPosY = (float)endY + 2.0F;
                     break;
                  case 1:
                     barWidth = (float)(endX - posX);
                     barHeight = 2.0F;
                     barPosX = (float)posX;
                     barPosY = (float)posY - 4.0F;
                     break;
                  case 2:
                     barWidth = 2.0F;
                     barHeight = (float)(endY - posY);
                     barPosX = (float)posX - 4.0F;
                     barPosY = (float)posY;
                     break;
                  case 3:
                     barWidth = 2.0F;
                     barHeight = (float)(endY - posY);
                     barPosX = (float)endX + 2.0F;
                     barPosY = (float)posY;
                  }

                  Render2DEngine.drawQuads(bufferBuilder, matrix, barPosX - 0.6F, barPosY - 0.6F, barPosX + barWidth + 0.6F, barPosY + barHeight + 0.6F, Color.BLACK);
                  Render2DEngine.drawQuads(bufferBuilder, matrix, barPosX, barPosY, barPosX + barWidth, barPosY + barHeight, settingColor.darker().darker());
                  if (!this.healthBarPosition.getValue().equals("Left") && !this.healthBarPosition.getValue().equals("Right")) {
                     Render2DEngine.drawQuads(bufferBuilder, matrix, barPosX, barPosY, barPosX + barWidth * healthPercentage, barPosY + barHeight, this.getHealthColor(healthPercentage));
                  } else {
                     Render2DEngine.drawQuads(bufferBuilder, matrix, barPosX, barPosY + barHeight * (1.0F - healthPercentage), barPosX + barWidth, barPosY + barHeight, this.getHealthColor(healthPercentage));
                  }
               }
            }
         }

         RenderSystem.disableBlend();
      }

   }

   private Color getHealthColor(float healthPercentage) {
      if (healthPercentage > 0.75F) {
         return new Color(100, 255, 100);
      } else if (healthPercentage > 0.5F) {
         return new Color(255, 255, 100);
      } else {
         return healthPercentage > 0.25F ? new Color(255, 165, 100) : new Color(255, 100, 100);
      }
   }

   public PlayerESP() {
      this.espMode = new ModeSetting(this.visual, "ESP Mode", "Decide which ESP mode to use", "Shaded 3D", new String[]{"Shaded 3D", "Outlined 2D", "Outlined 3D", "Outlined And Shaded 3D", "Glow Minecraft"});
      this.showHealthBar = new BooleanSetting(this.visual, "Show Health Bar", "Displays a health bar for players", true);
      this.healthBarPosition = new ModeSetting(this.visual, "Health Bar Position", "Choose where to display the health bar", "Bottom", new String[]{"Bottom", "Top", "Left", "Right"});
      this.red = new NumberSetting(this.color, "Red", "Set Red RGB", 255, 0, 255);
      this.green = new NumberSetting(this.color, "Green", "Set Green RGB", 255, 0, 255);
      this.blue = new NumberSetting(this.color, "Blue", "Set Blue RGB", 255, 0, 255);
      this.alpha = new NumberSetting(this.color, "Alpha", "Set Alpha RGB", 100, 0, 255);
      this.exclude = new MultiSetting(this.visual, "Exclude...", "Choose Players to Exclude", new String[]{"Bots", "Friends", "Teams"});
      this.hashMap = new HashMap();
      this.renderTickCounter = mc.method_61966();
      this.getSettingRepository().registerSettings(this.visual, this.color, this.espMode, this.healthBarPosition, this.showHealthBar, this.red, this.green, this.blue, this.alpha, this.exclude);
   }

   @Environment(EnvType.CLIENT)
   public static class Rectangle {
      public double x;
      public double y;
      public double z;
      public double w;

      public Rectangle(double x, double y, double z, double w) {
         this.x = x;
         this.y = y;
         this.z = z;
         this.w = w;
      }
   }
}
