package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.ColorUtils;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.common.QuickImports;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.render.Render2DEvent;
import java.awt.Color;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "Radar",
   description = "Shows People On Radar",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Radar extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final ModeSetting mode;
   private final NumberSetting<Integer> xPos;
   private final NumberSetting<Integer> yPos;

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      class_332 context = event.getContext();
      class_4587 matrices = context.method_51448();
      if (mc.field_1724 != null && !mc.method_53526().method_53536()) {
         String var4 = this.mode.getValue();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case 2017619398:
            if (var4.equals("Chorus")) {
               var5 = 0;
            }
         default:
            switch(var5) {
            case 0:
               this.renderChorus(matrices, context);
            default:
            }
         }
      }
   }

   private void renderChorus(class_4587 matrices, class_332 context) {
      int x = (Integer)this.xPos.getValue();
      int y = (Integer)this.yPos.getValue();
      float width = 90.0F;
      float height = 90.0F;
      Render2DEngine.drawRoundedBlur(matrices, (float)x, (float)y, width, height, 4.0F, 8.0F, new Color(0, 0, 0, 150));
      Render2DEngine.drawRoundedOutline(matrices, (float)x, (float)y, width, height, 4.0F, 1.0F, new Color(200, 200, 200, 75));
      Iterator var7 = mc.field_1687.method_18456().iterator();

      while(var7.hasNext()) {
         class_1657 player = (class_1657)var7.next();
         float[] position = this.calculateRadarPosition(player);
         Color color = player == mc.field_1724 ? new Color(127, 255, 127) : (SocialManager.isTargetedPlayer(player) == player ? new Color(255, 127, 127) : Color.WHITE);
         if (!(Math.abs(position[0]) >= width / 2.0F - 1.0F) && !(Math.abs(position[1]) >= height / 2.0F - 1.0F)) {
            Render2DEngine.drawCircle(matrices, (float)x + position[0] + width / 2.0F, (float)y + position[1] + height / 2.0F, 1.5F, color);
         }
      }

      this.setWidth(width);
      this.setHeight(height);
   }

   public Color getColor(class_1657 player) {
      if (player.method_5781() != null && player.method_5781().method_1202().method_532() != null) {
         return ColorUtils.formattingToRGB(player.method_5781().method_1202().method_532());
      } else if (player == mc.field_1724) {
         return new Color(127, 255, 127);
      } else {
         return SocialManager.isTargetedPlayer(player) == player ? new Color(255, 127, 127) : Color.white;
      }
   }

   public float[] calculateRadarPosition(class_1657 player) {
      class_243 localPos = mc.field_1724.method_19538();
      class_243 pos = player.method_19538();
      double x = pos.field_1352 - localPos.field_1352;
      double z = pos.field_1350 - localPos.field_1350;
      double calculation = Math.atan2(x, z) * 57.2957795131D;
      double angle = ((double)mc.field_1724.method_36454() + calculation) * 0.01745329251D;
      double hypotenuse = (double)player.method_5739(mc.field_1724);
      return new float[]{(float)(-hypotenuse * Math.sin(angle)), (float)(-hypotenuse * Math.cos(angle))};
   }

   public Radar() {
      this.mode = new ModeSetting(this.general, "Mode", "Choose style", "Chorus", new String[]{"Chorus"});
      this.xPos = new NumberSetting(this.general, "xPos", "Internal setting", 50, 0, 1920);
      this.yPos = new NumberSetting(this.general, "yPos", "Internal setting", 75, 0, 1080);
      this.setDraggable(true);
      this.getSettingRepository().registerSettings(this.general, this.mode, this.xPos, this.yPos);
      this.xPos.setRenderCondition(() -> {
         return false;
      });
      this.yPos.setRenderCondition(() -> {
         return false;
      });
   }
}
