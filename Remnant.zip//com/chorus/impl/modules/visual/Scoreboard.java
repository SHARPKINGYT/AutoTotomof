package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_332;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import net.minecraft.class_9022;
import net.minecraft.class_9025;

@ModuleInfo(
   name = "Scoreboard",
   description = "Change the look of the scoreboard",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Scoreboard extends BaseModule implements QuickImports {
   public final BooleanSetting hideScoreboard = new BooleanSetting("Hide Scoreboard", "Hides the scoreboard", false);
   public final BooleanSetting alignToArraylist = new BooleanSetting("Align With Arraylist", "Hides the scoreboard", false);
   public final BooleanSetting hideScores = new BooleanSetting("Hide Scores", "Hides red numbers on the side", false);
   public final BooleanSetting blur = new BooleanSetting("blur", "Makes Scoreboard Blurred", false);
   private final NumberSetting<Integer> xPos = new NumberSetting("xPos", "Internal setting", 50, 0, 1920);
   private final NumberSetting<Integer> yPos = new NumberSetting("yPos", "Internal setting", 75, 0, 1080);

   protected void onModuleEnabled() {
      if ((Integer)this.xPos.getValue() == 50 || (Integer)this.yPos.getValue() == 75) {
         this.xPos.setValue((Number)(mc.method_22683().method_4486() - 1));
         this.yPos.setValue((Number)(mc.method_22683().method_4502() / 2));
      }

   }

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null && mc.field_1705 != null && mc.field_1724.method_7327() != null && mc.field_1724.method_7327().method_1189(class_8646.field_45157) != null) {
         if (!this.hideScoreboard.getValue()) {
            this.renderScoreboard(event.getContext());
         }
      }
   }

   public void renderScoreboard(class_332 drawContext) {
      class_266 objective = (class_266)Objects.requireNonNull(mc.field_1724.method_7327().method_1189(class_8646.field_45157));
      class_269 scoreboard = objective.method_1117();
      class_9022 numberFormat = objective.method_55380(class_9025.field_47567);
      List<Scoreboard.SidebarEntry> sidebarEntries = scoreboard.method_1184(objective).stream().filter((score) -> {
         return !score.method_55385();
      }).sorted(Comparator.comparing(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER)).limit(15L).map((scoreboardEntry) -> {
         class_268 team = scoreboard.method_1164(scoreboardEntry.comp_2127());
         class_2561 name = class_268.method_1142(team, scoreboardEntry.method_55387());
         class_2561 scoreText = scoreboardEntry.method_55386(numberFormat);
         int scoreWidth = mc.field_1772.method_27525(scoreText);
         return new Scoreboard.SidebarEntry(name, scoreText, scoreWidth);
      }).toList();
      class_2561 title = objective.method_1114();
      int titleWidth = mc.field_1772.method_27525(title);
      int maxWidth = titleWidth;
      int separatorWidth = mc.field_1772.method_1727(": ");

      Scoreboard.SidebarEntry entry;
      for(Iterator var10 = sidebarEntries.iterator(); var10.hasNext(); maxWidth = Math.max(maxWidth, mc.field_1772.method_27525(entry.name) + (entry.scoreWidth > 0 ? separatorWidth + entry.scoreWidth : 0))) {
         entry = (Scoreboard.SidebarEntry)var10.next();
      }

      int entryHeight = sidebarEntries.size() * 9;
      Arraylist arraylist = (Arraylist)Chorus.getInstance().getModuleManager().getModule(Arraylist.class);
      int startY = arraylist.alignment != 0 && this.alignToArraylist.getValue() ? arraylist.alignment : (Integer)this.yPos.getValue();
      int startX = (Integer)this.xPos.getValue() - 3;
      int endX = (Integer)this.xPos.getValue() + maxWidth - 1;
      int background1 = mc.field_1690.method_19345(0.15F);
      int background2 = mc.field_1690.method_19345(0.05F);
      if (this.blur.getValue()) {
         Render2DEngine.drawRoundedBlur(drawContext.method_51448(), (float)startX, (float)startY, (float)(endX - startX + 4), (float)(entryHeight + 9 + 1), 1.0F, 8.0F);
      }

      drawContext.method_25294(startX, startY, endX + 4, startY - entryHeight + 9 + entryHeight, background2);
      drawContext.method_25294(startX, startY, endX + 4, startY + entryHeight + 9 + 1, background1);
      drawContext.method_51439(mc.field_1772, title, startX + maxWidth / 2 - titleWidth / 2 + 2, startY + 1, -1, false);
      this.setHeight((float)(entryHeight + 1));
      this.setWidth((float)(maxWidth + 4));

      for(int i = 0; i < sidebarEntries.size(); ++i) {
         Scoreboard.SidebarEntry entry = (Scoreboard.SidebarEntry)sidebarEntries.get(i);
         int y = startY + 9 + i * 9;
         drawContext.method_51439(mc.field_1772, entry.name, startX + 2, y, -1, false);
         if (!this.hideScores.getValue()) {
            drawContext.method_51439(mc.field_1772, entry.score, endX - entry.scoreWidth + 2, y, -1, false);
         }
      }

   }

   public Scoreboard() {
      this.setDraggable(true);
      this.getSettingRepository().registerSettings(this.hideScoreboard, this.alignToArraylist, this.hideScores, this.blur, this.xPos, this.yPos);
      this.xPos.setRenderCondition(() -> {
         return false;
      });
      this.yPos.setRenderCondition(() -> {
         return false;
      });
   }

   @Environment(EnvType.CLIENT)
   private static record SidebarEntry(class_2561 name, class_2561 score, int scoreWidth) {
      private SidebarEntry(class_2561 name, class_2561 score, int scoreWidth) {
         this.name = name;
         this.score = score;
         this.scoreWidth = scoreWidth;
      }

      public class_2561 name() {
         return this.name;
      }

      public class_2561 score() {
         return this.score;
      }

      public int scoreWidth() {
         return this.scoreWidth;
      }
   }
}
