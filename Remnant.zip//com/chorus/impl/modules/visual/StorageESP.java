package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render3DEvent;
import java.awt.Color;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_2281;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2531;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2627;
import net.minecraft.class_2646;
import net.minecraft.class_3708;
import net.minecraft.class_3719;

@ModuleInfo(
   name = "StorageESP",
   description = "Renders Positions Of Storage Blocks",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class StorageESP extends BaseModule implements QuickImports {
   private final ModeSetting boxType = new ModeSetting("Box Type", "Choose which type of box is rendered", "Outlined Shaded", new String[]{"Outlined Shaded", "Outlined", "Shaded"});
   private final MultiSetting storageTypes = new MultiSetting("Storage", "Choose which type of storage is rendered", new String[]{"Chest", "Trapped Chest", "Ender Chest", "Barrel", "Shulker"});
   private Map<Class<? extends class_2586>, Color> blockColors = Map.of(class_2646.class, new Color(255, 50, 20), class_2595.class, new Color(176, 111, 20), class_2611.class, new Color(137, 20, 255), class_2627.class, new Color(154, 20, 178), class_3719.class, new Color(255, 160, 160));

   @RegisterEvent
   private void Render3DEvent(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_1923 currentPosition = mc.field_1724.method_31476();
         int viewDistance = mc.field_1690.method_38521();
         class_1923 start = new class_1923(currentPosition.field_9181 - viewDistance, currentPosition.field_9180 - viewDistance);
         class_1923 end = new class_1923(currentPosition.field_9181 + viewDistance, currentPosition.field_9180 + viewDistance);

         for(int x = start.field_9181; x <= end.field_9181; ++x) {
            label90:
            for(int z = start.field_9180; z <= end.field_9180; ++z) {
               if (mc.field_1687.method_8393(x, z)) {
                  Iterator var8 = mc.field_1687.method_8497(x, z).method_12021().iterator();

                  while(true) {
                     class_2338 pos;
                     do {
                        do {
                           if (!var8.hasNext()) {
                              continue label90;
                           }

                           pos = (class_2338)var8.next();
                        } while(!this.isInFov(pos));
                     } while((!(mc.field_1687.method_8320(pos).method_26204() instanceof class_2281) || !this.storageTypes.getSpecificValue("Chest")) && (!(mc.field_1687.method_8320(pos).method_26204() instanceof class_2480) || !this.storageTypes.getSpecificValue("Shulker")) && (!(mc.field_1687.method_8320(pos).method_26204() instanceof class_3708) || !this.storageTypes.getSpecificValue("Barrel")) && (!(mc.field_1687.method_8320(pos).method_26204() instanceof class_2336) || !this.storageTypes.getSpecificValue("Ender Chest")) && (!(mc.field_1687.method_8320(pos).method_26204() instanceof class_2531) || !this.storageTypes.getSpecificValue("Trapped Chest")));

                     String var10 = this.boxType.getValue();
                     byte var11 = -1;
                     switch(var10.hashCode()) {
                     case -1819712521:
                        if (var10.equals("Shaded")) {
                           var11 = 1;
                        }
                        break;
                     case -1811566251:
                        if (var10.equals("Outlined Shaded")) {
                           var11 = 0;
                        }
                        break;
                     case 130770050:
                        if (var10.equals("Outlined")) {
                           var11 = 2;
                        }
                     }

                     switch(var11) {
                     case 0:
                        Render3DEngine.renderOutlinedShadedBox(pos.method_46558().method_1023(0.0D, 0.5D, 0.0D), this.getColor((class_2586)Objects.requireNonNull(mc.field_1687.method_8321(pos))), 50, event.getMatrices(), 0.5F, 1.0F);
                        break;
                     case 1:
                        Render3DEngine.renderShadedBox(pos.method_46558().method_1023(0.0D, 0.5D, 0.0D), this.getColor((class_2586)Objects.requireNonNull(mc.field_1687.method_8321(pos))), 50, event.getMatrices(), 0.5F, 1.0F);
                        break;
                     case 2:
                        Render3DEngine.renderOutlinedBox(pos.method_46558().method_1023(0.0D, 0.5D, 0.0D), this.getColor((class_2586)Objects.requireNonNull(mc.field_1687.method_8321(pos))), event.getMatrices(), 0.5F, 1.0F);
                     }
                  }
               }
            }
         }
      }

   }

   private Color getColor(class_2586 blockEntity) {
      return (Color)this.blockColors.getOrDefault(blockEntity.getClass(), new Color(255, 255, 255, 0));
   }

   public boolean isInFov(class_2338 blockPos) {
      class_243 playerPos = mc.field_1724.method_19538().method_1031(0.0D, (double)mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D);
      class_243 lookVec = mc.field_1724.method_5828(1.0F);
      class_243 blockVec = (new class_243((double)blockPos.method_10263() + 0.5D, (double)blockPos.method_10264() + 0.5D, (double)blockPos.method_10260() + 0.5D)).method_1020(playerPos).method_1029();
      double dotProduct = lookVec.method_1026(blockVec);
      double fovThreshold = Math.cos(Math.toRadians(((Integer)mc.field_1690.method_41808().method_41753()).doubleValue()));
      return dotProduct > fovThreshold;
   }

   public StorageESP() {
      this.getSettingRepository().registerSettings(this.boxType, this.storageTypes);
   }
}
