package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.impl.events.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Comparator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_1657;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import org.lwjgl.opengl.GL11;

@ModuleInfo(
   name = "TargetESP",
   description = "Renders a ring effect around the target",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class TargetESP extends BaseModule implements QuickImports {
   private final SettingCategory visual = new SettingCategory("Visual Settings");
   private final ModeSetting espMode;
   private final NumberSetting<Integer> red;
   private final NumberSetting<Integer> green;
   private final NumberSetting<Integer> blue;
   private final NumberSetting<Integer> alpha;

   public TargetESP() {
      this.espMode = new ModeSetting(this.visual, "ESP Mode", "Choose the ESP effect", "Ring", new String[]{"Ring"});
      this.red = new NumberSetting(this.visual, "Red", "Set Red RGB", 255, 0, 255);
      this.green = new NumberSetting(this.visual, "Green", "Set Green RGB", 127, 0, 255);
      this.blue = new NumberSetting(this.visual, "Blue", "Set Blue RGB", 127, 0, 255);
      this.alpha = new NumberSetting(this.visual, "Alpha", "Set Alpha RGB", 225, 0, 255);
      this.getSettingRepository().registerSettings(this.visual, this.espMode, this.red, this.green, this.blue, this.alpha);
   }

   @RegisterEvent
   private void render3DEventListener(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         class_1657 target = (class_1657)mc.field_1687.method_18456().stream().filter((player) -> {
            return player != mc.field_1724 && (double)mc.field_1724.method_5739(player) <= 6.0D && Math.toDegrees(MathUtils.angleBetween(mc.field_1724.method_5720(), player.method_19538().method_1031(0.0D, (double)player.method_18381(player.method_18376()), 0.0D).method_1020(mc.field_1724.method_33571()))) <= 90.0D;
         }).min(Comparator.comparingDouble((player) -> {
            return (double)mc.field_1724.method_5739(player);
         })).orElse((Object)null);
         if (target == null) {
            return;
         }

         event.getMatrices().method_22903();
         double duration = 2000.0D;
         double elapsed = (double)System.currentTimeMillis() % duration;
         boolean side = elapsed > duration / 2.0D;
         double progress = elapsed / (duration / 2.0D);
         if (side) {
            --progress;
         } else {
            progress = 1.0D - progress;
         }

         progress = progress < 0.5D ? 2.0D * progress * progress : 1.0D - Math.pow(-2.0D * progress + 2.0D, 2.0D) / 2.0D;
         double x = target.field_6038 + (target.method_23317() - target.field_6038) * (double)event.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10216();
         double y = target.field_5971 + (target.method_23318() - target.field_5971) * (double)event.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10214();
         double z = target.field_5989 + (target.method_23321() - target.field_5989) * (double)event.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10215();
         float height = target.method_17682();
         double eased = (double)height / 1.2D * (progress > 0.5D ? 1.0D - progress : progress) * (double)(side ? -1 : 1);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.setShader(class_10142.field_53876);
         RenderSystem.depthMask(false);
         RenderSystem.disableCull();
         GL11.glLineWidth(1.5F);
         class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
         Color color = new Color((Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue(), (Integer)this.alpha.getValue());
         Color fadeColor = new Color((Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue(), 1);

         int i;
         double rad;
         double cos;
         double sin;
         double width;
         for(i = 0; i <= 360; ++i) {
            rad = Math.toRadians((double)i);
            cos = Math.cos(rad);
            sin = Math.sin(rad);
            width = (double)target.method_17681() * 0.8D;
            buffer.method_22912((float)(x + cos * width), (float)(y + (double)height * progress), (float)(z + sin * width)).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            buffer.method_22912((float)(x + cos * width), (float)(y + (double)height * progress + eased), (float)(z + sin * width)).method_1336(fadeColor.getRed(), fadeColor.getGreen(), fadeColor.getBlue(), fadeColor.getAlpha());
         }

         class_286.method_43433(buffer.method_60800());
         buffer = class_289.method_1348().method_60827(class_5596.field_27378, class_290.field_1576);

         for(i = 0; i <= 360; ++i) {
            rad = Math.toRadians((double)i);
            cos = Math.cos(rad);
            sin = Math.sin(rad);
            width = (double)target.method_17681() * 0.8D;
            buffer.method_22912((float)(x + cos * width), (float)(y + (double)height * progress), (float)(z + sin * width)).method_1336(fadeColor.getRed(), fadeColor.getGreen(), fadeColor.getBlue(), fadeColor.getAlpha());
         }

         class_286.method_43433(buffer.method_60800());
         RenderSystem.enableCull();
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
         event.getMatrices().method_22909();
      }

   }
}
