package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.common.util.math.MathUtils;
import com.chorus.common.util.math.TimerUtils;
import com.chorus.impl.events.render.Render2DEvent;
import com.chorus.impl.modules.other.Target;
import com.chorus.impl.screen.hud.HUDEditorScreen;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_742;
import net.minecraft.class_7532;
import net.minecraft.class_7833;

@ModuleInfo(
   name = "TargetHUD",
   description = "Renders Target Information",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class TargetHud extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final ModeSetting mode;
   private final NumberSetting<Integer> xPos;
   private final NumberSetting<Integer> yPos;
   private final int ENEMY_TIMEOUT;
   private TimerUtils enemyTimer;
   public class_1657 enemy;
   private float animationProgress;
   private boolean wasEnemyNull;
   private static final float ANIMATION_SPEED = 0.035F;
   private boolean isDisappearing;
   private float disappearY;
   private class_1657 lastEnemy;
   private boolean forceReappearCheck;
   public float firstHealth;
   public float secondHealth;
   public float absorption;
   public float armorBar;
   public float totemPops;
   class_1304[] armorSlots;

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      class_332 context = event.getContext();
      class_4587 matrices = context.method_51448();
      boolean inHudEditor = mc.field_1755 instanceof HUDEditorScreen;
      class_1657 currentEnemy = ((Target)Chorus.getInstance().getModuleManager().getModule(Target.class)).enemy;
      boolean hasTargetEnemy = currentEnemy != null;
      boolean hasAttackingEnemy = mc.field_1724 != null && mc.field_1724.method_6052() instanceof class_1657;
      boolean recentAttack = mc.field_1724 != null && mc.field_1724.field_6012 - mc.field_1724.method_6083() < 40;
      boolean shouldHaveEnemy = (hasTargetEnemy || hasAttackingEnemy) && recentAttack;
      if (this.forceReappearCheck) {
         shouldHaveEnemy = true;
         this.forceReappearCheck = false;
      }

      if (this.enemy != null && !shouldHaveEnemy && !this.isDisappearing) {
         this.isDisappearing = true;
         this.lastEnemy = this.enemy;
      }

      boolean updatedEnemy;
      class_1657 displayEnemy;
      if (this.isDisappearing && this.animationProgress <= 0.0F) {
         this.enemy = null;
         this.lastEnemy = null;
         this.isDisappearing = false;
         this.forceReappearCheck = true;
      } else if (shouldHaveEnemy) {
         if (this.isDisappearing) {
            this.isDisappearing = false;
            this.disappearY = 0.0F;
         }

         updatedEnemy = false;
         if (hasAttackingEnemy) {
            class_1309 var12 = mc.field_1724.method_6052();
            if (var12 instanceof class_1657) {
               displayEnemy = (class_1657)var12;
               if (displayEnemy != this.enemy) {
                  this.enemy = displayEnemy;
                  this.enemyTimer.reset();
                  this.totemPops = 0.0F;
                  updatedEnemy = true;
               }
            }
         }

         if (!updatedEnemy && hasTargetEnemy && currentEnemy != this.enemy) {
            this.enemy = currentEnemy;
            this.enemyTimer.reset();
            this.totemPops = 0.0F;
            updatedEnemy = true;
         }

         if (updatedEnemy) {
            this.wasEnemyNull = true;
         }
      }

      updatedEnemy = this.enemy == null && !inHudEditor;
      if (inHudEditor) {
         this.isDisappearing = false;
         this.disappearY = 0.0F;
         this.animationProgress = 1.0F;
      } else if (updatedEnemy != this.wasEnemyNull || updatedEnemy && this.animationProgress > 0.0F || !updatedEnemy && this.animationProgress < 1.0F || this.isDisappearing) {
         if (!updatedEnemy && !this.isDisappearing) {
            this.isDisappearing = false;
            this.disappearY = 0.0F;
            this.animationProgress = Math.min(1.0F, this.animationProgress + 0.035F);
         } else {
            this.animationProgress = Math.max(0.0F, this.animationProgress - 0.035F);
            this.disappearY = this.animationProgress > 0.0F ? (1.0F - this.animationProgress) * 100.0F : 0.0F;
         }

         this.wasEnemyNull = updatedEnemy;
      }

      if (this.animationProgress > 0.0F || inHudEditor) {
         displayEnemy = this.enemy != null ? this.enemy : (this.isDisappearing ? this.lastEnemy : null);
         if (displayEnemy != null || inHudEditor) {
            String var14 = this.mode.getValue();
            byte var13 = -1;
            switch(var14.hashCode()) {
            case -857357669:
               if (var14.equals("Remnant Info")) {
                  var13 = 2;
               }
               break;
            case -366642666:
               if (var14.equals("Remnant Compact")) {
                  var13 = 1;
               }
               break;
            case 1956520879:
               if (var14.equals("Adjust")) {
                  var13 = 0;
               }
            }

            switch(var13) {
            case 0:
               this.renderAdjust(matrices, context, displayEnemy);
               break;
            case 1:
               this.renderRemnantCompact(matrices, context, displayEnemy);
               break;
            case 2:
               this.renderRemnantInfo(matrices, context, displayEnemy);
            }
         }
      }

      if (this.enemy != null && this.enemyTimer.delay(1000.0F)) {
         this.isDisappearing = true;
         this.lastEnemy = this.enemy;
      }

   }

   private void renderAdjust(class_4587 matrices, class_332 context, class_1657 displayEnemy) {
      FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
      boolean resetToNull = false;
      if (displayEnemy == null) {
         if (!(mc.field_1755 instanceof HUDEditorScreen)) {
            return;
         }

         displayEnemy = mc.field_1724;
         resetToNull = true;
      }

      String name = ((class_1657)displayEnemy).method_5820();
      float hpDiff = mc.field_1724.method_6032() - ((class_1657)displayEnemy).method_6032();
      DecimalFormat format = new DecimalFormat("#.##");
      String hp = (hpDiff < 0.0F ? "-" : "+") + format.format((double)Math.abs(hpDiff)) + "hp";
      Color themeColor = new Color(184, 112, 242, 255);
      Color background = new Color(0, 0, 0, 100);
      int height = 35;
      int length = 105;
      int size = 25;
      int x = (Integer)this.xPos.getValue();
      int y = (Integer)this.yPos.getValue();
      float padding = 3.0F;
      float centerPadding = padding * 2.0F;
      float thickness = 3.0F;
      float fullWidth = font.getWidth(name, 6.0F) + (float)length;
      matrices.method_22903();
      float scale = 0.5F + 0.5F * this.animationProgress;
      float alpha = this.animationProgress;
      float scaleX = (float)x + fullWidth / 2.0F;
      float scaleY = (float)(y + height / 2);
      matrices.method_46416(scaleX, scaleY, 0.0F);
      if (this.isDisappearing) {
         matrices.method_46416(0.0F, this.disappearY, 0.0F);
         matrices.method_22907(class_7833.field_40718.rotationDegrees(this.disappearY * 0.8F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(this.disappearY * 0.3F));
      }

      matrices.method_22905(scale, scale, 1.0F);
      matrices.method_46416(-scaleX, -scaleY, 0.0F);
      background = new Color(background.getRed(), background.getGreen(), background.getBlue(), (int)((float)background.getAlpha() * alpha));
      themeColor = new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), (int)((float)themeColor.getAlpha() * alpha));
      Render2DEngine.drawRect(matrices, (float)x, (float)y, fullWidth, (float)height, background);
      this.setWidth(fullWidth);
      this.setHeight((float)height);
      if (alpha > 0.05F) {
         int adjustedSize = (int)((float)size * Math.min(1.0F, alpha * 1.2F));
         if (adjustedSize > 0) {
            class_7532.method_52722(context, ((class_742)displayEnemy).method_52814(), (int)((float)x + padding), (int)((float)y + padding), adjustedSize);
         }
      }

      font.render(matrices, name, (float)(x + size) + centerPadding, (float)y + padding, 10.0F, (new Color(255, 255, 255, (int)(255.0F * alpha))).getRGB());
      font.render(matrices, hp, (float)x + fullWidth - font.getWidth(hp, 7.0F) - padding, (float)(y + size) - centerPadding, 7.0F, (new Color(255, 255, 255, (int)(255.0F * alpha))).getRGB());
      if (this.firstHealth == 0.0F || this.firstHealth != ((class_1657)displayEnemy).method_6032()) {
         this.firstHealth = MathUtils.lerp(this.firstHealth == 0.0F ? ((class_1657)displayEnemy).method_6032() : this.firstHealth, ((class_1657)displayEnemy).method_6032(), 0.05F);
         this.secondHealth = MathUtils.lerp(this.secondHealth == 0.0F ? ((class_1657)displayEnemy).method_6032() : this.secondHealth, ((class_1657)displayEnemy).method_6032(), 0.005F);
      }

      float firstWidth = (fullWidth - centerPadding) * this.firstHealth / ((class_1657)displayEnemy).method_6063();
      float secondWidth = (fullWidth - centerPadding) * this.secondHealth / ((class_1657)displayEnemy).method_6063();
      Render2DEngine.drawRect(matrices, (float)x + padding, (float)(y + height) - thickness * 2.0F, secondWidth, thickness, themeColor.darker().darker());
      Render2DEngine.drawRect(matrices, (float)x + padding, (float)(y + height) - thickness * 2.0F, firstWidth, thickness, themeColor);
      int armorX = (int)((float)(x + size) + centerPadding);
      int armorY = (int)((float)y + padding + 10.0F);
      matrices.method_22903();
      matrices.method_46416((float)armorX, (float)armorY, 0.0F);
      matrices.method_22905(0.9F, 0.9F, 1.0F);
      context.method_51428(((class_1657)displayEnemy).method_6118(class_1304.field_6173), 0, 0, 0);
      context.method_51428(((class_1657)displayEnemy).method_6118(class_1304.field_6169), 15, 0, 0);
      context.method_51428(((class_1657)displayEnemy).method_6118(class_1304.field_6174), 30, 0, 0);
      context.method_51428(((class_1657)displayEnemy).method_6118(class_1304.field_6172), 45, 0, 0);
      context.method_51428(((class_1657)displayEnemy).method_6118(class_1304.field_6166), 60, 0, 0);
      matrices.method_22909();
      matrices.method_22909();
      if (resetToNull) {
         this.enemy = null;
      }

   }

   private void renderRemnantCompact(class_4587 matrices, class_332 context, class_1657 displayEnemy) {
      FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
      boolean resetToNull = false;
      if (displayEnemy == null) {
         if (!(mc.field_1755 instanceof HUDEditorScreen)) {
            return;
         }

         displayEnemy = mc.field_1724;
         resetToNull = true;
      }

      String name = ((class_1657)displayEnemy).method_5820();
      float hpDiff = mc.field_1724.method_6032() - ((class_1657)displayEnemy).method_6032();
      DecimalFormat format = new DecimalFormat("#.##");
      String hp = (hpDiff < 0.0F ? "-" : "+") + format.format((double)Math.abs(hpDiff)) + "hp";
      Color themeColor = new Color(255, 127, 127, 255);
      Color background = new Color(150, 150, 150, 75);
      int height = 35;
      int length = 120;
      int size = 30;
      int x = (Integer)this.xPos.getValue();
      int y = (Integer)this.yPos.getValue();
      float padding = 3.0F;
      float centerPadding = padding * 2.0F;
      float thickness = 3.5F;
      float fullWidth = font.getWidth(name, 6.0F) + (float)length;
      matrices.method_22903();
      float scale = 0.5F + 0.5F * this.animationProgress;
      float alpha = this.animationProgress;
      float scaleX = (float)x + fullWidth / 2.0F;
      float scaleY = (float)(y + height / 2);
      matrices.method_46416(scaleX, scaleY, 0.0F);
      if (this.isDisappearing) {
         matrices.method_46416(0.0F, this.disappearY, 0.0F);
         matrices.method_22907(class_7833.field_40718.rotationDegrees(this.disappearY * 0.8F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(this.disappearY * 0.3F));
      }

      matrices.method_22905(scale, scale, 1.0F);
      matrices.method_46416(-scaleX, -scaleY, 0.0F);
      background = new Color(background.getRed(), background.getGreen(), background.getBlue(), (int)((float)background.getAlpha() * alpha));
      themeColor = new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), (int)((float)themeColor.getAlpha() * alpha));
      Render2DEngine.drawRoundedBlur(matrices, (float)x, (float)y, fullWidth, (float)height, 4.0F, 8.0F, new Color(255, 255, 255, (int)(10.0F * alpha)));
      Render2DEngine.drawRoundedOutline(matrices, (float)x, (float)y, fullWidth, (float)height, 4.0F, 1.0F, background);
      this.setWidth(fullWidth);
      this.setHeight((float)height);
      int armorX;
      if (alpha > 0.05F) {
         int hurtTimeOffset = (int)((float)((class_1657)displayEnemy).field_6235 / 4.0F);
         int hurtTimeSize = (int)((float)((class_1657)displayEnemy).field_6235 / 2.0F);
         armorX = (int)((float)(size - hurtTimeSize) * Math.min(1.0F, alpha * 1.2F));
         if (armorX > 0) {
            class_7532.method_52722(context, ((class_742)displayEnemy).method_52814(), (int)((float)x + padding + (float)hurtTimeOffset), (int)((float)y + padding + (float)hurtTimeOffset), armorX);
            Render2DEngine.drawRect(matrices, (float)((int)((float)x + padding + (float)hurtTimeOffset)), (float)((int)((float)y + padding + (float)hurtTimeOffset)), (float)armorX, (float)armorX, new Color(255, 0, 0, (int)((float)(25 * ((class_1657)displayEnemy).field_6235) * alpha)));
         }
      }

      font.render(matrices, name, (float)(x + size) + centerPadding, (float)y + padding, 10.0F, (new Color(255, 255, 255, (int)(255.0F * alpha))).getRGB());
      font.render(matrices, hp, (float)x + fullWidth - font.getWidth(hp, 7.0F) - padding, (float)y + centerPadding, 7.0F, (new Color(255, 255, 255, (int)(255.0F * alpha))).getRGB());
      if (this.firstHealth == 0.0F || this.firstHealth != ((class_1657)displayEnemy).method_6032()) {
         this.firstHealth = MathUtils.lerp(this.firstHealth == 0.0F ? ((class_1657)displayEnemy).method_6032() : this.firstHealth, ((class_1657)displayEnemy).method_6032(), 0.05F);
         this.secondHealth = MathUtils.lerp(this.secondHealth == 0.0F ? ((class_1657)displayEnemy).method_6032() : this.secondHealth, ((class_1657)displayEnemy).method_6032(), 0.005F);
      }

      float firstWidth = (fullWidth - centerPadding - (float)size - padding) * this.firstHealth / ((class_1657)displayEnemy).method_6063();
      float secondWidth = (fullWidth - centerPadding - (float)size - padding) * this.secondHealth / ((class_1657)displayEnemy).method_6063();
      Render2DEngine.drawRoundedRect(matrices, (float)(x + size) + centerPadding, (float)(y + height) - thickness - padding, secondWidth, thickness, 1.0F, themeColor.darker().darker());
      Render2DEngine.drawRoundedRect(matrices, (float)(x + size) + centerPadding, (float)(y + height) - thickness - padding, firstWidth, thickness, 1.0F, themeColor);
      armorX = (int)((float)(x + size) + centerPadding);
      int armorY = (int)((float)y + padding + 10.0F);
      matrices.method_22903();
      matrices.method_46416((float)armorX, (float)armorY, 0.0F);
      matrices.method_22905(0.85F, 0.85F, 1.0F);
      int armorPosition = 0;
      class_1304[] var30 = this.armorSlots;
      int var31 = var30.length;

      for(int var32 = 0; var32 < var31; ++var32) {
         class_1304 slot = var30[var32];
         class_1799 itemStack = ((class_1657)displayEnemy).method_6118(slot);
         if (!itemStack.method_7960()) {
            context.method_51428(itemStack, armorPosition, 0, 0);
            armorPosition += 15;
         }
      }

      matrices.method_22909();
      matrices.method_22909();
      if (resetToNull) {
         this.enemy = null;
      }

   }

   private void renderRemnantInfo(class_4587 matrices, class_332 context, class_1657 displayEnemy) {
      FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
      boolean resetToNull = false;
      if (displayEnemy == null) {
         if (!(mc.field_1755 instanceof HUDEditorScreen)) {
            return;
         }

         displayEnemy = mc.field_1724;
         resetToNull = true;
      }

      String name = ((class_1657)displayEnemy).method_5820();
      name = name.replaceAll("§", "");
      float hpDiff = mc.field_1724.method_6032() - ((class_1657)displayEnemy).method_6032();
      float absDiff = mc.field_1724.method_6067() - ((class_1657)displayEnemy).method_6067();
      DecimalFormat format = new DecimalFormat("#.##");
      Color healthColor = new Color(255, 127, 127, 255);
      Color absorptionColor = new Color(255, 255, 127, 255);
      Color armorColor = new Color(127, 127, 255, 255);
      Color background = new Color(150, 150, 150, 75);
      float height = 47.5F;
      float length = 130.0F;
      float size = 30.0F;
      int x = (Integer)this.xPos.getValue();
      int y = (Integer)this.yPos.getValue();
      float padding = 3.0F;
      float centerPadding = padding * 2.0F;
      float thickness = 3.5F;
      float fullWidth = Math.max(font.getWidth(name, 10.0F) + 80.0F, length);
      matrices.method_22903();
      float scale = 0.5F + 0.5F * this.animationProgress;
      float alpha = this.animationProgress;
      float scaleX = (float)x + fullWidth / 2.0F;
      float scaleY = (float)y + height / 2.0F;
      matrices.method_46416(scaleX, scaleY, 0.0F);
      if (this.isDisappearing) {
         matrices.method_46416(0.0F, this.disappearY, 0.0F);
         matrices.method_22907(class_7833.field_40718.rotationDegrees(this.disappearY * 0.8F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(this.disappearY * 0.3F));
      }

      matrices.method_22905(scale, scale, 1.0F);
      matrices.method_46416(-scaleX, -scaleY, 0.0F);
      background = new Color(background.getRed(), background.getGreen(), background.getBlue(), (int)((float)background.getAlpha() * alpha));
      healthColor = new Color(healthColor.getRed(), healthColor.getGreen(), healthColor.getBlue(), (int)((float)healthColor.getAlpha() * alpha));
      absorptionColor = new Color(absorptionColor.getRed(), absorptionColor.getGreen(), absorptionColor.getBlue(), (int)((float)absorptionColor.getAlpha() * alpha));
      new Color(armorColor.getRed(), armorColor.getGreen(), armorColor.getBlue(), (int)((float)armorColor.getAlpha() * alpha));
      Render2DEngine.drawRoundedBlur(matrices, (float)x, (float)y, fullWidth, height, 4.0F, 8.0F, new Color(255, 255, 255, (int)(10.0F * alpha)));
      Render2DEngine.drawRoundedOutline(matrices, (float)x, (float)y, fullWidth, height, 4.0F, 1.0F, background);
      this.setWidth(fullWidth);
      this.setHeight(height);
      if (alpha > 0.05F) {
         int hurtTimeOffset = (int)((float)((class_1657)displayEnemy).field_6235 / 4.0F);
         int hurtTimeSize = (int)((float)((class_1657)displayEnemy).field_6235 / 2.0F);
         int adjustedSize = (int)((size - (float)hurtTimeSize) * Math.min(1.0F, alpha * 1.2F));
         if (adjustedSize > 0) {
            class_7532.method_52722(context, ((class_742)displayEnemy).method_52814(), (int)((float)x + padding + (float)hurtTimeOffset), (int)((float)y + padding + (float)hurtTimeOffset), adjustedSize);
            Render2DEngine.drawRect(matrices, (float)((int)((float)x + padding + (float)hurtTimeOffset)), (float)((int)((float)y + padding + (float)hurtTimeOffset)), (float)adjustedSize, (float)adjustedSize, new Color(255, 0, 0, (int)((float)(25 * ((class_1657)displayEnemy).field_6235) * alpha)));
         }
      }

      font.render(matrices, name, (float)x + size + centerPadding, (float)y + padding, 10.0F, (new Color(255, 255, 255, (int)(255.0F * alpha))).getRGB());
      font.render(matrices, name, (float)x + size + centerPadding, (float)y + padding, 10.0F, (new Color(255, 0, 0, (int)((float)(25 * ((class_1657)displayEnemy).field_6235) * alpha))).getRGB());
      String hp = (hpDiff < 0.0F ? "-" : "+") + format.format((double)Math.abs(hpDiff)) + "hp";
      String var10000 = format.format((double)Math.abs(absDiff));
      String absHp = "+" + var10000;
      font.render(matrices, hp, (float)x + fullWidth - font.getWidth(hp, 8.0F) - (absDiff != 0.0F ? font.getWidth(absHp, 8.0F) : 0.0F) - padding, (float)y + height - centerPadding - padding - font.getLineHeight(8.0F), 8.0F, healthColor.getRGB());
      font.render(matrices, hp, (float)x + fullWidth - font.getWidth(hp, 8.0F) - (absDiff != 0.0F ? font.getWidth(absHp, 8.0F) : 0.0F) - padding, (float)y + height - centerPadding - padding - font.getLineHeight(8.0F), 8.0F, (new Color(255, 0, 0, (int)((float)(25 * ((class_1657)displayEnemy).field_6235) * alpha))).getRGB());
      if (absDiff != 0.0F) {
         font.render(matrices, absHp, (float)x + fullWidth - font.getWidth(absHp, 8.0F) - padding, (float)y + height - centerPadding - padding - font.getLineHeight(8.0F), 8.0F, absorptionColor.getRGB());
      }

      String popCount = (int)this.totemPops + " totem used";
      font.render(matrices, popCount, (float)x + fullWidth - font.getWidth(popCount, 6.0F) - centerPadding, (float)y + padding, 6.0F, (new Color(255, 255, 255, (int)(255.0F * alpha))).getRGB());
      if (this.firstHealth == 0.0F || this.firstHealth != ((class_1657)displayEnemy).method_6032()) {
         this.firstHealth = MathUtils.lerp(this.firstHealth == 0.0F ? ((class_1657)displayEnemy).method_6032() : this.firstHealth, ((class_1657)displayEnemy).method_6032(), 0.05F);
         this.secondHealth = MathUtils.lerp(this.secondHealth == 0.0F ? ((class_1657)displayEnemy).method_6032() : this.secondHealth, ((class_1657)displayEnemy).method_6032(), 0.005F);
         this.absorption = MathUtils.lerp(this.absorption == 0.0F ? ((class_1657)displayEnemy).method_6067() : this.absorption, ((class_1657)displayEnemy).method_6067(), 0.005F);
         this.armorBar = MathUtils.lerp(this.armorBar == 0.0F ? this.getArmorAmount((class_1309)displayEnemy) : this.armorBar, this.getArmorAmount((class_1309)displayEnemy), 0.005F);
      }

      float slowHealthWidth = (fullWidth - centerPadding) * this.firstHealth / ((class_1657)displayEnemy).method_6063();
      float fastHealthWidth = (fullWidth - centerPadding) * this.secondHealth / ((class_1657)displayEnemy).method_6063();
      float absorptionWidth = (fullWidth - centerPadding) * this.absorption / ((class_1657)displayEnemy).method_52541();
      Render2DEngine.drawRoundedRect(matrices, (float)x + padding, (float)y + height - thickness - padding, fastHealthWidth, thickness, 1.0F, healthColor.darker().darker());
      Render2DEngine.drawRoundedRect(matrices, (float)x + padding, (float)y + height - thickness - padding, slowHealthWidth, thickness, 1.0F, healthColor);
      Render2DEngine.drawRoundedGradient(matrices, (float)x + padding, (float)y + height - thickness - padding, absorptionWidth, thickness, 1.0F, absorptionColor, new Color(255, 127, 255, (int)(125.0F * alpha)));
      int armorX = (int)((float)x + size + centerPadding);
      int armorY = (int)((float)y + padding + 10.0F);
      matrices.method_22903();
      matrices.method_46416((float)armorX, (float)armorY, 0.0F);
      int armorPosition = 0;
      class_1304[] var36 = this.armorSlots;
      int var37 = var36.length;

      for(int var38 = 0; var38 < var37; ++var38) {
         class_1304 slot = var36[var38];
         class_1799 itemStack = ((class_1657)displayEnemy).method_6118(slot);
         if (!itemStack.method_7960()) {
            context.method_51428(itemStack, armorPosition, 0, 0);
            armorPosition += 15;
         }
      }

      matrices.method_22909();
      matrices.method_22909();
      if (resetToNull) {
         this.enemy = null;
      }

   }

   public float getProtectionValue(class_1799 stack) {
      if (stack != null && stack.method_7909() instanceof class_1738) {
         int protLevel = class_1890.method_8225((class_6880)((class_2378)mc.field_1687.method_30349().method_46759(class_1893.field_9111.method_58273()).get()).method_10223(class_1893.field_9111.method_29177()).get(), stack);
         return (float)(1 + protLevel);
      } else {
         return 0.0F;
      }
   }

   public float getArmorAmount(class_1309 enemy) {
      float effectiveArmor = 0.0F;

      class_1799 stack;
      for(Iterator var3 = enemy.method_5661().iterator(); var3.hasNext(); effectiveArmor += this.getProtectionValue(stack)) {
         stack = (class_1799)var3.next();
      }

      float maxEffectiveArmor = 100.0F;
      return effectiveArmor / maxEffectiveArmor;
   }

   public TargetHud() {
      this.mode = new ModeSetting(this.general, "Mode", "Choose style", "Remnant Compact", new String[]{"Adjust", "Remnant Compact", "Remnant Info"});
      this.xPos = new NumberSetting(this.general, "xPos", "Internal setting", 5, 0, 1920);
      this.yPos = new NumberSetting(this.general, "yPos", "Internal setting", 5, 0, 1080);
      this.ENEMY_TIMEOUT = 1000;
      this.enemyTimer = new TimerUtils();
      this.enemy = null;
      this.animationProgress = 0.0F;
      this.wasEnemyNull = true;
      this.isDisappearing = false;
      this.disappearY = 0.0F;
      this.lastEnemy = null;
      this.forceReappearCheck = false;
      this.firstHealth = 0.0F;
      this.secondHealth = 0.0F;
      this.absorption = 0.0F;
      this.armorBar = 0.0F;
      this.totemPops = 0.0F;
      this.armorSlots = new class_1304[]{class_1304.field_6173, class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6171};
      this.setDraggable(true);
      this.getSettingRepository().registerSettings(this.general, this.mode, this.xPos, this.yPos);
      this.xPos.setRenderCondition(() -> {
         return false;
      });
      this.yPos.setRenderCondition(() -> {
         return false;
      });
   }
}
