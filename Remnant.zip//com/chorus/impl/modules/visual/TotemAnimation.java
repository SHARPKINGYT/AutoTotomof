package com.chorus.impl.modules.visual;

import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.common.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(
   name = "TotemAnimation",
   description = "Changes Totem Animation Duration",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class TotemAnimation extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   public final NumberSetting<Integer> time;

   public TotemAnimation() {
      this.time = new NumberSetting(this.general, "Reduction", "Change Totem Time", 50, 0, 100);
      this.getSettingRepository().registerSettings(this.general, this.time);
   }
}
