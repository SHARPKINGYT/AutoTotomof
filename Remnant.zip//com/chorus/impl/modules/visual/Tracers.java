package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.common.util.world.SocialManager;
import com.chorus.impl.events.render.Render2DEvent;
import com.chorus.impl.events.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_332;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_9779;
import net.minecraft.class_9801;
import net.minecraft.class_293.class_5596;
import org.lwjgl.opengl.GL11;

@ModuleInfo(
   name = "Tracers",
   description = "Draw Lines to players",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Tracers extends BaseModule implements QuickImports {
   private Map<class_1297, class_3545<Tracers.Rectangle, Boolean>> hashMap = new HashMap();
   class_9779 renderTickCounter;

   @RegisterEvent
   private void Render3DEvent(Render3DEvent event) {
      if (event.getMode().equals(Render3DEvent.Mode.PRE)) {
         this.hashMap.clear();
         if (mc.field_1724 != null && mc.field_1687 != null) {
            Iterator var2 = mc.field_1687.method_18456().iterator();

            while(true) {
               class_1657 entity;
               do {
                  do {
                     do {
                        if (!var2.hasNext()) {
                           return;
                        }

                        entity = (class_1657)var2.next();
                     } while(entity == mc.field_1724);
                  } while(entity == null);
               } while(!SocialManager.isEnemy(entity));

               class_243 prevPos = new class_243(entity.field_6038, entity.field_5971, entity.field_5989);
               class_243 interpolated = prevPos.method_1019(entity.method_19538().method_1020(prevPos).method_1021((double)this.renderTickCounter.method_60637(false)));
               float halfWidth = entity.method_17681() / 2.0F;
               class_238 boundingBox = (new class_238(interpolated.field_1352, interpolated.field_1351, interpolated.field_1350, interpolated.field_1352, interpolated.field_1351 + (double)entity.method_17682() + (entity.method_5715() ? -0.2D : 0.0D), interpolated.field_1350)).method_1009(0.1D, 0.1D, 0.1D);
               class_243[] corners = new class_243[]{new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1321), new class_243(boundingBox.field_1320, boundingBox.field_1325 + 0.1D, boundingBox.field_1324), new class_243(boundingBox.field_1323, boundingBox.field_1325 + 0.1D, boundingBox.field_1324)};
               Tracers.Rectangle rectangle = null;
               boolean visible = false;
               class_243[] var11 = corners;
               int var12 = corners.length;

               for(int var13 = 0; var13 < var12; ++var13) {
                  class_243 corner = var11[var13];
                  class_3545<class_243, Boolean> projection = Render3DEngine.project(event.getMatrices().method_23760().method_23761(), event.getProjectionMatrix(), corner);
                  if ((Boolean)projection.method_15441()) {
                     visible = true;
                  }

                  class_243 projected = (class_243)projection.method_15442();
                  if (rectangle == null) {
                     rectangle = new Tracers.Rectangle((double)((int)projected.method_10216()), (double)((int)projected.method_10214()), (double)((int)projected.method_10216()), (double)((int)projected.method_10214()));
                  } else {
                     if (rectangle.x > projected.method_10216()) {
                        rectangle.x = (double)((int)projected.method_10216());
                     }

                     if (rectangle.y > projected.method_10214()) {
                        rectangle.y = (double)((int)projected.method_10214());
                     }

                     if (rectangle.z < projected.method_10216()) {
                        rectangle.z = (double)((int)projected.method_10216());
                     }

                     if (rectangle.w < projected.method_10214()) {
                        rectangle.w = (double)((int)projected.method_10214());
                     }
                  }
               }

               this.hashMap.put(entity, new class_3545(rectangle, visible));
            }
         }
      }
   }

   @RegisterEvent
   private void Render2DEvent(Render2DEvent event) {
      if (event.getMode().equals(Render2DEvent.Mode.PRE)) {
         class_4587 matrix = event.getContext().method_51448();
         class_332 context = event.getContext();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.setShader(class_10142.field_53876);
         if (!this.hashMap.isEmpty() && this.hashMap.entrySet().stream().anyMatch((entityPairEntry) -> {
            return (Boolean)((class_3545)entityPairEntry.getValue()).method_15441();
         })) {
            Iterator var4 = this.hashMap.entrySet().iterator();

            while(var4.hasNext()) {
               Entry<class_1297, class_3545<Tracers.Rectangle, Boolean>> entry = (Entry)var4.next();
               class_3545<Tracers.Rectangle, Boolean> pair = (class_3545)entry.getValue();
               if ((Boolean)pair.method_15441()) {
                  Tracers.Rectangle rect = (Tracers.Rectangle)pair.method_15442();
                  Color color = new Color(184, 112, 242);
                  int screenWidth = mc.method_22683().method_4486() / 2;
                  int screenHeight = -5;
                  RenderSystem.enableBlend();
                  RenderSystem.defaultBlendFunc();
                  GL11.glEnable(2848);
                  class_287 buffer = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
                  buffer.method_56824(matrix.method_23760(), (float)screenWidth, (float)screenHeight, 0.0F).method_39415(color.getRGB());
                  buffer.method_56824(matrix.method_23760(), (float)rect.x, (float)rect.y, (float)rect.z).method_39415(color.getRGB());
                  class_286.method_43433((class_9801)Objects.requireNonNull(buffer.method_60794()));
                  GL11.glDisable(2848);
                  RenderSystem.disableBlend();
               }
            }
         }

         RenderSystem.disableBlend();
      }

   }

   public Tracers() {
      this.renderTickCounter = mc.method_61966();
      this.getSettingRepository().registerSettings();
   }

   @Environment(EnvType.CLIENT)
   public static class Rectangle {
      public double x;
      public double y;
      public double z;
      public double w;

      public Rectangle(double x, double y, double z, double w) {
         this.x = x;
         this.y = y;
         this.z = z;
         this.w = w;
      }
   }
}
