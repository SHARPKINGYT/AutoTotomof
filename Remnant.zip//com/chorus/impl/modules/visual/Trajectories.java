package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.system.render.Render3DEngine;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Objects;
import java.util.function.Predicate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1753;
import net.minecraft.class_1776;
import net.minecraft.class_1777;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1803;
import net.minecraft.class_1828;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import net.minecraft.class_239.class_240;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

@ModuleInfo(
   name = "Trajectories",
   description = "where projectile",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Trajectories extends BaseModule implements QuickImports {
   @RegisterEvent
   private void render2DListener(Render3DEvent event) {
      Matrix4f matrix = event.getMatrices().method_23760().method_23761();
      class_1799 itemStack = mc.field_1724.method_6047();
      if (isThrowable(itemStack)) {
         float initialVelocity = 52.0F;
         if (itemStack.method_7909() == class_1802.field_8102 && mc.field_1724.method_6115()) {
            initialVelocity *= class_1753.method_7722(mc.field_1724.method_6048());
         }

         class_4184 camera = mc.field_1773.method_19418();
         class_243 offset = Render3DEngine.getEntityPositionOffsetInterpolated(mc.field_1719, event.getTickDelta());
         class_243 eyePos = mc.field_1719.method_33571();
         class_243 right = class_243.method_1030(0.0F, camera.method_19330() + 90.0F).method_1021(0.14000000059604645D);
         class_243 lookDirection = class_243.method_1030(camera.method_19329(), camera.method_19330());
         class_243 velocity = lookDirection.method_1021((double)initialVelocity).method_1021(0.20000000298023224D);
         class_243 prevPoint = (new class_243(0.0D, 0.0D, 0.0D)).method_1019(eyePos).method_1020(offset).method_1019(right);
         class_243 landPosition = null;
         GL11.glEnable(3042);
         GL11.glDisable(2929);
         class_289 tessellator = RenderSystem.renderThreadTesselator();

         for(int iteration = 0; iteration < 150; ++iteration) {
            class_287 buffer = tessellator.method_60827(class_5596.field_29344, class_290.field_1576);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            GL11.glEnable(2848);
            class_243 nextPoint = prevPoint.method_1019(velocity.method_1021(0.1D));
            class_243 start = mc.field_1724.method_30950(mc.method_61966().method_60637(true)).method_1031(0.0D, (double)mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D).method_1020(mc.field_1773.method_19418().method_19326());
            if (iteration == 0) {
               buffer.method_22918(matrix, (float)start.field_1352, (float)start.field_1351, (float)start.field_1350).method_1336(255, 255, 255, 255).method_22915(0.003921569F, 255.0F, 0.003921569F, 255.0F);
            }

            class_243 x1 = prevPoint.method_1020(mc.field_1773.method_19418().method_19326());
            class_243 x2 = nextPoint.method_1020(mc.field_1773.method_19418().method_19326());
            buffer.method_22918(matrix, (float)x1.field_1352, (float)x1.field_1351, (float)x1.field_1350).method_1336(255, 255, 255, 255).method_22915(0.003921569F, 1.0F, 0.003921569F, 255.0F);
            buffer.method_22918(matrix, (float)x2.field_1352, (float)x2.field_1351, (float)x2.field_1350).method_1336(255, 255, 255, 255).method_22915(0.003921569F, 1.0F, 0.003921569F, 255.0F);
            class_3959 context = new class_3959(prevPoint, nextPoint, class_3960.field_17558, class_242.field_1348, mc.field_1724);
            class_3965 result = mc.field_1687.method_17742(context);
            if (result.method_17783() != class_240.field_1333) {
               landPosition = result.method_17784();
               break;
            }

            class_238 box = new class_238(prevPoint, nextPoint);
            Predicate<class_1297> predicate = (e) -> {
               return !e.method_7325() && e.method_5863();
            };
            class_3966 entityResult = class_1675.method_18075(mc.field_1724, prevPoint, nextPoint, box, predicate, 4096.0D);
            if (entityResult != null && entityResult.method_17783() != class_240.field_1333) {
               landPosition = entityResult.method_17784();
               break;
            }

            class_286.method_43433((class_9801)Objects.requireNonNull(buffer.method_60794()));
            GL11.glDisable(2848);
            RenderSystem.disableBlend();
            prevPoint = nextPoint;
            velocity = velocity.method_1021(0.99D).method_1031(0.0D, this.throwableGravity(itemStack.method_7909()), 0.0D);
         }

         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(2929);
         GL11.glDisable(3042);
         if (landPosition != null) {
            float size = 0.15F;
            class_243 pos = landPosition.method_1031(0.0D, (double)size, 0.0D).method_1023((double)(size / 2.0F), (double)(size / 2.0F), (double)(size / 2.0F));
            Color color = Color.WHITE;
            class_4587 matrixStack = event.getMatrices();
            Render3DEngine.renderOutlinedBox(pos, color, matrixStack, size, size * 2.0F);
         }
      }

   }

   public double throwableGravity(class_1792 item) {
      return item == class_1802.field_8102 ? -0.04500000178813934D : -0.12999999523162842D;
   }

   public static boolean isThrowable(class_1799 stack) {
      class_1792 item = stack.method_7909();
      return item == class_1802.field_8102 || item == class_1802.field_8543 || item == class_1802.field_8803 || item == class_1802.field_8814 || item == class_1802.field_8547 || item instanceof class_1776 || item instanceof class_1828 || item instanceof class_1803 || item instanceof class_1787 || item instanceof class_1777;
   }
}
