package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.ColorUtils;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.function.Function;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_155;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "Watermark",
   description = "bah",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Watermark extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final ModeSetting mode;
   private final NumberSetting<Integer> xPos;
   private final NumberSetting<Integer> yPos;

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      class_332 context = event.getContext();
      class_4587 matrices = context.method_51448();
      if (mc.field_1724 != null && !mc.method_53526().method_53536()) {
         String var4 = this.mode.getValue();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case -1538527693:
            if (var4.equals("Remnant")) {
               var5 = 0;
            }
            break;
         case -1271816484:
            if (var4.equals("Gamesense")) {
               var5 = 1;
            }
            break;
         case 83945109:
            if (var4.equals("Wurst")) {
               var5 = 2;
            }
         }

         switch(var5) {
         case 0:
            this.renderRemnant(matrices, context);
            break;
         case 1:
            this.renderGamesense(matrices, context);
            break;
         case 2:
            this.renderWurst(matrices, context);
         }

      }
   }

   private void renderRemnant(class_4587 matrices, class_332 context) {
      FontAtlas font = Chorus.getInstance().getFonts().getInterMedium();
      FontAtlas icons = Chorus.getInstance().getFonts().getLucide();
      float rectWidth = 65.0F;
      float rectHeight = 15.0F;
      float textHeight = font.getLineHeight();
      float textX = (float)((Integer)this.xPos.getValue() + 5);
      float textY = (float)(Integer)this.yPos.getValue() + rectHeight / 2.0F - textHeight / 2.0F + 1.0F;
      Render2DEngine.drawBlurredRoundedRect(matrices, (float)(Integer)this.xPos.getValue(), (float)(Integer)this.yPos.getValue(), rectWidth, rectHeight, 4.0F, 8.0F, new Color(255, 255, 255, 10));
      Render2DEngine.drawRoundedOutline(matrices, (float)(Integer)this.xPos.getValue(), (float)(Integer)this.yPos.getValue(), rectWidth, rectHeight, 4.0F, 1.0F, new Color(200, 200, 200, 75));
      icons.render(matrices, "\ue530", textX, textY, 9.0F, Color.WHITE.getRGB());
      font.render(matrices, "remnant.wtf", textX + 13.0F, textY, 7.0F, Color.WHITE.getRGB());
      this.setWidth(rectWidth);
      this.setHeight(rectHeight);
   }

   private void renderGamesense(class_4587 matrices, class_332 context) {
      FontAtlas font = Chorus.getInstance().getFonts().getInterMedium();
      String text = String.format("chorus | " + mc.field_1724.method_5820() + " | %s", mc.method_1558() != null ? mc.method_1558().field_3761 : (mc.method_1542() ? "Local" : "Disconnected"));
      int height = 15;
      int x = (Integer)this.xPos.getValue() + 5;
      int y = (Integer)this.yPos.getValue() + 5;
      int padding = 12;
      Color darkBlack = new Color(45, 45, 45, 255);
      Color middleBlack = new Color(60, 60, 60, 255);
      Color lightBlack = new Color(100, 100, 100, 255);
      Render2DEngine.drawRect(matrices, (float)x - 2.5F, (float)y - 2.5F, font.getWidth(text, 8.0F) + (float)padding + 6.0F, (float)height + 6.0F, darkBlack.darker());
      Render2DEngine.drawRect(matrices, (float)x - 1.5F, (float)y - 1.5F, font.getWidth(text, 8.0F) + (float)padding + 4.0F, (float)(height + 4), lightBlack);
      Render2DEngine.drawRect(matrices, (float)x - 1.0F, (float)y - 1.0F, font.getWidth(text, 8.0F) + (float)padding + 3.0F, (float)height + 3.0F, middleBlack);
      Render2DEngine.drawRect(matrices, (float)x + 0.5F, (float)y + 0.5F, font.getWidth(text, 8.0F) + (float)padding, (float)height, lightBlack);
      Render2DEngine.drawRect(matrices, (float)(x + 1), (float)(y + 1), font.getWidth(text, 8.0F) + (float)padding - 1.0F, (float)(height - 1), darkBlack);
      Color primary = new Color(184, 112, 242);
      Color secondary = primary.brighter().brighter();
      Color color1 = ColorUtils.interpolateColor(secondary, primary, 2, mc.field_1724.field_6012 % 10 * 2);
      Color color2 = ColorUtils.interpolateColor(primary, secondary, 2, mc.field_1724.field_6012 % 10 * 2);
      Render2DEngine.drawGradientRect(matrices, (float)(x + 1), (float)(y + 1), (font.getWidth(text, 8.0F) + (float)padding - 1.0F) / 2.0F, 1.5F, color1, color2);
      Render2DEngine.drawGradientRect(matrices, (float)(x + 1) + (font.getWidth(text, 8.0F) + (float)padding - 1.0F) / 2.0F, (float)(y + 1), (font.getWidth(text, 8.0F) + (float)padding - 1.0F) / 2.0F, 1.5F, color2, color1);
      float xPos = (float)(x + 4);
      String[] parts = text.split(" \\| ");

      for(int i = 0; i < parts.length; ++i) {
         font.render(matrices, parts[i], xPos, (float)y + 3.5F, 8.0F, Color.WHITE.getRGB());
         xPos += font.getWidth(parts[i], 8.0F);
         if (i < parts.length - 1) {
            font.render(matrices, "|", xPos + 1.0F, (float)y + 4.5F, 7.0F, Color.white.getRGB());
            xPos += font.getWidth("|", 8.0F) + 2.0F;
         }
      }

      this.setWidth(font.getWidth(text, 8.0F) + (float)padding + 8.5F);
      this.setHeight((float)height + 8.5F);
   }

   private void renderWurst(class_4587 matrices, class_332 context) {
      String var10000 = Chorus.getInstance().getClientInfo().version();
      String version = "v" + var10000 + " MC" + class_155.method_16673().method_48019();
      context.method_25294(0, 6, mc.field_1772.method_1727(version) + 76, 17, (new Color(255, 255, 255, 128)).getRGB());
      context.method_51433(mc.field_1772, version, 74, 8, Color.BLACK.getRGB(), false);
      RenderSystem.enableBlend();
      Function<class_2960, class_1921> renderLayers = class_1921::method_62277;
      class_2960 wurst = class_2960.method_60655("chorus", "img/wurst.png");
      context.method_25290(renderLayers, wurst, 0, 3, 0.0F, 0.0F, 72, 18, 72, 18);
      RenderSystem.disableBlend();
   }

   public Watermark() {
      this.mode = new ModeSetting(this.general, "Mode", "Choose watermark style", "Remnant", new String[]{"Remnant", "Gamesense", "Wurst"});
      this.xPos = new NumberSetting(this.general, "xPos", "Internal setting", 5, 0, 1920);
      this.yPos = new NumberSetting(this.general, "yPos", "Internal setting", 5, 0, 1080);
      this.setDraggable(true);
      this.getSettingRepository().registerSettings(this.general, this.mode, this.xPos, this.yPos);
      this.xPos.setRenderCondition(() -> {
         return false;
      });
      this.yPos.setRenderCondition(() -> {
         return false;
      });
   }
}
