package com.chorus.impl.modules.visual;

import cc.polymorphism.eventbus.RegisterEvent;
import chorus0.Chorus;
import com.chorus.api.module.BaseModule;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.ModuleInfo;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.impl.events.render.Render2DEvent;
import java.awt.Color;
import java.text.DecimalFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_4587;

@ModuleInfo(
   name = "Widgets",
   description = "Information Widgets",
   category = ModuleCategory.VISUAL
)
@Environment(EnvType.CLIENT)
public class Widgets extends BaseModule implements QuickImports {
   private final SettingCategory general = new SettingCategory("General");
   private final ModeSetting mode;
   private final NumberSetting<Integer> xPos;
   private final NumberSetting<Integer> yPos;

   @RegisterEvent
   private void render2DListener(Render2DEvent event) {
      class_332 context = event.getContext();
      class_4587 matrices = context.method_51448();
      if (mc.field_1724 != null && !mc.method_53526().method_53536()) {
         String var4 = this.mode.getValue();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case -1538527693:
            if (var4.equals("Remnant")) {
               var5 = 0;
            }
         default:
            switch(var5) {
            case 0:
               this.renderRemnant(matrices, context);
            default:
            }
         }
      }
   }

   private void renderRemnant(class_4587 matrices, class_332 context) {
      FontAtlas font = Chorus.getInstance().getFonts().getPoppins();
      DecimalFormat format = new DecimalFormat("#.##");
      float rectHeight = 15.0F;
      float textX = (float)(Integer)this.xPos.getValue();
      float textY = (float)(Integer)this.yPos.getValue();
      double speed = Math.hypot(mc.field_1724.method_23317() - mc.field_1724.field_6014, mc.field_1724.method_23321() - mc.field_1724.field_5969);
      String var10000 = format.format(speed * 20.0D);
      String speedText = "b/s: " + var10000;
      long var13 = Math.round(mc.field_1724.method_23317());
      String coordsText = "XYZ: " + var13 + " " + Math.round(mc.field_1724.method_23318()) + " " + Math.round(mc.field_1724.method_23321());
      float centerY = textY - font.getLineHeight(7.0F) / 2.0F + rectHeight / 2.0F;
      Render2DEngine.drawBlurredRoundedRect(matrices, textX, textY, font.getWidth(coordsText, 7.0F) + 7.5F, rectHeight, 4.0F, 8.0F, new Color(255, 255, 255, 10));
      Render2DEngine.drawRoundedOutline(matrices, textX, textY, font.getWidth(coordsText, 7.0F) + 7.5F, rectHeight, 4.0F, 1.0F, new Color(200, 200, 200, 75));
      font.render(matrices, coordsText, textX + 2.5F, centerY, 7.0F, Color.WHITE.getRGB());
      Render2DEngine.drawBlurredRoundedRect(matrices, textX + font.getWidth(coordsText, 7.0F) + 12.5F, textY, font.getWidth(speedText, 7.0F) + 7.5F, rectHeight, 4.0F, 8.0F, new Color(255, 255, 255, 10));
      Render2DEngine.drawRoundedOutline(matrices, textX + font.getWidth(coordsText, 7.0F) + 12.5F, textY, font.getWidth(speedText, 7.0F) + 7.5F, rectHeight, 4.0F, 1.0F, new Color(200, 200, 200, 75));
      font.render(matrices, speedText, textX + font.getWidth(coordsText, 7.0F) + 15.5F, centerY, 7.0F, Color.WHITE.getRGB());
      this.setWidth(font.getWidth(speedText, 7.0F) + 7.5F + font.getWidth(coordsText, 7.0F) + 12.5F);
      this.setHeight(rectHeight);
   }

   public Widgets() {
      this.mode = new ModeSetting(this.general, "Mode", "Choose widget style", "Remnant", new String[]{"Remnant"});
      this.xPos = new NumberSetting(this.general, "xPos", "Internal setting", 5, 0, 1920);
      this.yPos = new NumberSetting(this.general, "yPos", "Internal setting", 5, 0, 1080);
      this.setDraggable(true);
      this.getSettingRepository().registerSettings(this.general, this.mode, this.xPos, this.yPos);
      this.xPos.setRenderCondition(() -> {
         return false;
      });
      this.yPos.setRenderCondition(() -> {
         return false;
      });
   }
}
