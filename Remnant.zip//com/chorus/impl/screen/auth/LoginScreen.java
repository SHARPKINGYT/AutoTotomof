package com.chorus.impl.screen.auth;

import chorus0.Chorus;
import com.chorus.api.system.networking.NetworkManager;
import com.chorus.api.system.networking.auth.UserData;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public class LoginScreen extends class_437 {
   private String statusMessage = "Please enter your credentials to login";
   private int statusColor = -5636096;
   private boolean isAuthenticating = false;
   private class_342 usernameField;
   private class_342 passwordField;

   public LoginScreen() {
      super(class_2561.method_43470("Login"));
   }

   public static String getHWID() {
      try {
         StringBuilder systemInfo = new StringBuilder();
         String osName = System.getProperty("os.name").toLowerCase(Locale.ROOT);
         int var6;
         int var7;
         Stream var10000;
         if (osName.contains("win")) {
            File psDir = new File(System.getenv("SystemRoot"), "System32" + File.separatorChar + "WindowsPowerShell" + File.separatorChar + "v1.0");
            if (!psDir.exists() || !psDir.isDirectory()) {
               throw new IOException("PowerShell directory missing: " + psDir.getAbsolutePath());
            }

            String psPath = psDir.getAbsolutePath() + "\\powershell.exe";
            String[] winCommands = new String[]{psPath + " (get-wmiobject -class win32_physicalmemory -namespace root\\CIMV2).Capacity", psPath + " (get-wmiobject -class win32_processor -namespace root\\CIMV2)", psPath + " (get-wmiobject -class win32_physicalmemory -namespace root\\CIMV2).SMBiosMemoryType", psPath + " (get-wmiobject -class win32_videocontroller -namespace root\\CIMV2).Description"};
            String[] var5 = winCommands;
            var6 = winCommands.length;

            for(var7 = 0; var7 < var6; ++var7) {
               String cmd = var5[var7];
               Process proc = Runtime.getRuntime().exec(cmd);
               proc.waitFor();
               BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
               var10000 = reader.lines();
               Objects.requireNonNull(systemInfo);
               var10000.forEach(systemInfo::append);
            }
         } else {
            String[] macCommands;
            if (osName.contains("mac")) {
               macCommands = new String[]{"sysctl -n machdep.cpu.brand_string", "system_profiler SPHardwareDataType | awk '/Serial/ {print $4}'", "sysctl hw.ncpu", "sysctl hw.memsize"};
               String[] var15 = macCommands;
               int var18 = macCommands.length;

               for(int var21 = 0; var21 < var18; ++var21) {
                  String cmd = var15[var21];
                  Process proc = Runtime.getRuntime().exec(cmd);
                  proc.waitFor();
                  BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                  var10000 = reader.lines();
                  Objects.requireNonNull(systemInfo);
                  var10000.forEach(systemInfo::append);
               }
            } else {
               macCommands = new String[]{"/bin/sh", "-c", "lscpu | grep -e \"Architecture:\" -e \"Byte Order:\" -e \"Model name:\""};
               Process proc = Runtime.getRuntime().exec(macCommands);
               proc.waitFor();
               BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));

               String line;
               while((line = reader.readLine()) != null) {
                  systemInfo.append(line);
               }
            }
         }

         MessageDigest hasher;
         try {
            hasher = MessageDigest.getInstance("MD5");
         } catch (NoSuchAlgorithmException var11) {
            return "";
         }

         hasher.update(systemInfo.toString().getBytes(StandardCharsets.UTF_8));
         byte[] digest = hasher.digest();
         StringBuilder hexString = new StringBuilder();
         byte[] var24 = digest;
         var6 = digest.length;

         for(var7 = 0; var7 < var6; ++var7) {
            byte b = var24[var7];
            String hex = Integer.toHexString(255 & b);
            if (hex.length() == 1) {
               hexString.append('0');
            }

            hexString.append(hex);
         }

         return hexString.toString();
      } catch (Exception var12) {
         throw new RuntimeException();
      }
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25300(this.field_22793, "Authentication Required", this.field_22789 / 2, this.field_22790 / 2 - 170, 16777215);
      context.method_25300(this.field_22793, this.statusMessage, this.field_22789 / 2, this.field_22790 / 2 - 150, this.statusColor);
      super.method_25394(context, mouseX, mouseY, delta);
   }

   public boolean method_25422() {
      return false;
   }

   protected void method_25426() {
      super.method_25426();
      int fieldWidth = 200;
      int fieldHeight = 20;
      int centerX = this.field_22789 / 2 - fieldWidth / 2;
      int startY = this.field_22790 / 2 - fieldHeight - 50;
      this.usernameField = new class_342(this.field_22793, centerX, startY, fieldWidth, fieldHeight, class_2561.method_43470(""));
      this.usernameField.method_1880(32);
      this.usernameField.method_1852("");
      this.usernameField.method_47404(class_2561.method_30163("Username"));
      this.method_37063(this.usernameField);
      this.passwordField = new class_342(this.field_22793, centerX, startY + 30, fieldWidth, fieldHeight, class_2561.method_43470(""));
      this.passwordField.method_1880(32);
      this.passwordField.method_1852("");
      this.passwordField.method_47404(class_2561.method_30163("Password"));
      this.passwordField.method_1854((text, index) -> {
         return class_2561.method_43470(text.replaceAll(".", "*")).method_30937();
      });
      this.method_37063(this.passwordField);
      class_4185 loginButton = class_4185.method_46430(class_2561.method_43470("Login"), (button) -> {
         if (!this.isAuthenticating) {
            String username = this.usernameField.method_1882().trim();
            String password = this.passwordField.method_1882().trim();
            if (!username.isEmpty() && !password.isEmpty()) {
               this.isAuthenticating = true;
               this.statusMessage = "Authenticating...";
               this.statusColor = -22016;
               button.field_22763 = false;
               synchronized(Chorus.getInstance().authLock) {
                  try {
                     String hwid = getHWID();
                     NetworkManager networkManager = NetworkManager.getInstance();
                     CompletableFuture loginFuture;
                     if (!networkManager.isConnected()) {
                        this.statusMessage = "Connection lost. Reconnecting...";
                        loginFuture = networkManager.connect();

                        try {
                           loginFuture.get(5L, TimeUnit.SECONDS);
                           this.statusMessage = "Connected. Sending login request...";
                        } catch (Exception var12) {
                           this.statusMessage = "Failed to connect: " + var12.getMessage();
                           this.statusColor = -5636096;
                           this.isAuthenticating = false;
                           button.field_22763 = true;
                           return;
                        }
                     }

                     loginFuture = networkManager.login(username, password, hwid);

                     UserData userData;
                     try {
                        System.out.println("Waiting for login future to complete...");
                        userData = (UserData)loginFuture.get(10L, TimeUnit.SECONDS);
                        System.out.println("Login future completed, userData: " + (userData != null ? "not null" : "null"));
                     } catch (Exception var11) {
                        this.statusMessage = "Login failed: " + var11.getMessage();
                        this.statusColor = -5636096;
                        this.isAuthenticating = false;
                        button.field_22763 = true;
                        System.out.println("Exception while waiting for login: " + var11.getMessage());
                        var11.printStackTrace();
                        return;
                     }

                     if (userData != null) {
                        System.out.println("Authentication successful for user: " + userData.getUsername());
                        Chorus.getInstance().isAuthenticated = true;
                        this.statusMessage = "Authentication successful!";
                        this.statusColor = -16733696;
                        this.field_22787.method_1507((class_437)null);
                     } else {
                        System.out.println("Authentication failed - userData is null");
                        String response = networkManager.readResponse();
                        if (response != null && response.contains("expiry=N/A") && !response.contains("type=Lifetime")) {
                           this.statusMessage = "Authentication failed - Your license has expired";
                           System.out.println("License expired detected in response: " + response);
                        } else if (response != null && !response.contains("type=Lifetime")) {
                           this.statusMessage = "Authentication failed - Requires lifetime license";
                           System.out.println("Non-lifetime license detected in response: " + response);
                        } else {
                           this.statusMessage = "Authentication failed - Invalid credentials";
                        }

                        this.statusColor = -5636096;
                     }
                  } catch (Exception var13) {
                     this.statusMessage = "Error: " + var13.getMessage();
                     this.statusColor = -5636096;
                     var13.printStackTrace();
                  }
               }

               this.isAuthenticating = false;
               button.field_22763 = true;
            } else {
               this.statusMessage = "Please enter both username and password";
               this.statusColor = -5636096;
            }
         }
      }).method_46434(centerX, startY + 60, fieldWidth, fieldHeight).method_46431();
      this.method_37063(loginButton);
      this.method_37063(class_4185.method_46430(class_2561.method_43470("Quit Game"), (button) -> {
         this.field_22787.method_1592();
      }).method_46434(centerX, startY + 90, fieldWidth, fieldHeight).method_46431());
   }
}
