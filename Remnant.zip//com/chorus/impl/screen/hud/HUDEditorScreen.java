package com.chorus.impl.screen.hud;

import chorus0.Chorus;
import com.chorus.api.module.Module;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public class HUDEditorScreen extends class_437 implements QuickImports {
   private static final HUDEditorScreen INSTANCE = new HUDEditorScreen();
   private final ArrayList<Module> hudModules = new ArrayList();
   private Module draggingModule = null;
   private int dragStartX = 0;
   private int dragStartY = 0;

   public HUDEditorScreen() {
      super(class_2561.method_43470("HUD Editor"));
      Iterator var1 = Chorus.getInstance().getModuleManager().getModules().iterator();

      while(var1.hasNext()) {
         Module module = (Module)var1.next();
         if (module.isDraggable()) {
            this.hudModules.add(module);
         }
      }

   }

   public boolean method_25421() {
      return false;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      if (context != null) {
         int width = context.method_51421();
         int height = context.method_51443();
         context.method_25301(width / 2, 0, height, 16777215);
         context.method_25292(0, height / 2, width, 16777215);
         int gridX;
         int gridY;
         if (this.draggingModule != null) {
            gridX = Math.max(1, height / 4);
            gridY = Math.max(1, width / 4);

            int i;
            float xPos;
            for(i = 0; i <= gridX; ++i) {
               xPos = (float)i * ((float)height / (float)gridX);
               Render2DEngine.drawRect(context.method_51448(), 0.0F, xPos, (float)width, 0.5F, new Color(255, 255, 255, 50));
            }

            for(i = 0; i <= gridY; ++i) {
               xPos = (float)i * ((float)width / (float)gridY);
               Render2DEngine.drawRect(context.method_51448(), xPos, 0.0F, 0.5F, (float)height, new Color(255, 255, 255, 50));
            }
         }

         gridX = Math.round((float)mouseX / 4.0F) * 4;
         gridY = Math.round((float)mouseY / 4.0F) * 4;
         Iterator var20 = this.hudModules.iterator();

         while(true) {
            Module module;
            do {
               do {
                  if (!var20.hasNext()) {
                     return;
                  }

                  module = (Module)var20.next();
               } while(module == null);
            } while(!module.isEnabled());

            int xPos = (Integer)module.getSettingRepository().getSetting("xPos").getValue();
            int yPos = (Integer)module.getSettingRepository().getSetting("yPos").getValue();
            int moduleWidth = (int)module.getWidth();
            int moduleHeight = (int)module.getHeight();
            int middleX = xPos + moduleWidth / 2;
            int middleY = yPos + moduleHeight / 2;
            if (this.draggingModule == module) {
               int snap = 10;
               int middleXDistance = Math.abs(width / 2 - middleX);
               int middleYDistance = Math.abs(height / 2 - middleY);
               if (middleXDistance < 5 && Math.abs(middleX - mouseX) < snap) {
                  Render2DEngine.drawRect(context.method_51448(), (float)width / 2.0F, 0.0F, 1.0F, (float)height, Color.white);
                  ((NumberSetting)module.getSettingRepository().getSetting("xPos")).setValue((Number)Math.clamp((long)(middleX - moduleWidth / 2), 0, width - moduleWidth));
               } else {
                  ((NumberSetting)module.getSettingRepository().getSetting("xPos")).setValue((Number)Math.clamp((long)(gridX - this.dragStartX), 0, width - moduleWidth));
               }

               if (middleYDistance < 5 && Math.abs(middleY - mouseY) < snap) {
                  Render2DEngine.drawRect(context.method_51448(), 0.0F, (float)height / 2.0F, (float)width, 1.0F, Color.white);
                  ((NumberSetting)module.getSettingRepository().getSetting("yPos")).setValue((Number)Math.clamp((long)(middleY - moduleHeight / 2), 0, height - moduleHeight));
               } else {
                  ((NumberSetting)module.getSettingRepository().getSetting("yPos")).setValue((Number)Math.clamp((long)(gridY - this.dragStartY), 0, height - moduleHeight));
               }
            }

            FontAtlas font = Chorus.getInstance().getFonts().getPoppins();
            font.render(context.method_51448(), module.getName(), (float)xPos + (float)moduleWidth / 2.0F - font.getWidth(module.getName(), 8.0F) / 2.0F, (float)yPos - font.getLineHeight(8.0F), 8.0F, Color.white.getRGB());
            Render2DEngine.drawRoundedOutline(context.method_51448(), (float)xPos, (float)yPos, (float)moduleWidth, (float)moduleHeight, 5.0F, 1.0F, new Color(255, 255, 255, 255));
         }
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (button == 0 && this.draggingModule == null) {
         Iterator var6 = this.hudModules.iterator();

         while(var6.hasNext()) {
            Module module = (Module)var6.next();
            if (module != null && module.isEnabled()) {
               int xPos = (Integer)module.getSettingRepository().getSetting("xPos").getValue();
               int yPos = (Integer)module.getSettingRepository().getSetting("yPos").getValue();
               int moduleWidth = (int)module.getWidth();
               int moduleHeight = (int)module.getHeight();
               int gridX = (int)(Math.round(mouseX / 4.0D) * 4L);
               int gridY = (int)(Math.round(mouseY / 4.0D) * 4L);
               if (gridX >= xPos && gridX <= xPos + moduleWidth && gridY >= yPos && gridY <= yPos + moduleHeight) {
                  this.draggingModule = module;
                  this.dragStartX = gridX - xPos;
                  this.dragStartY = gridY - yPos;
                  break;
               }
            }
         }
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      if (button == 0 && this.draggingModule != null) {
         this.draggingModule = null;
      }

      return super.method_25406(mouseX, mouseY, button);
   }

   public static HUDEditorScreen getINSTANCE() {
      return INSTANCE;
   }
}
