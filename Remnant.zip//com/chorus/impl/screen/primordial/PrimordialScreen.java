package com.chorus.impl.screen.primordial;

import chorus0.Chorus;
import com.chorus.api.module.Module;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.animation.Animation;
import com.chorus.api.system.render.animation.EasingType;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.impl.modules.client.ClickGUI;
import com.chorus.impl.screen.primordial.component.ModuleComponent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Iterator;
import java.util.function.Function;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;

@Environment(EnvType.CLIENT)
public class PrimordialScreen extends class_437 implements QuickImports {
   private static final float MIN_WIDTH = 415.0F;
   private static final float MIN_HEIGHT = 295.0F;
   private static final float RESIZE_HANDLE_SIZE = 11.0F;
   private float x;
   private float y;
   private float width = 600.0F;
   private float height = 380.0F;
   private float moduleY = 0.0F;
   private boolean dragging = false;
   private boolean resizing = false;
   private double lastMouseX;
   private double lastMouseY;
   private final Animation moduleAnimation;
   private ModuleCategory selectedCategory;
   private Module selectedModule;
   private ModuleComponent component;
   private static final PrimordialScreen INSTANCE = new PrimordialScreen();

   public PrimordialScreen() {
      super(class_2561.method_43473());
      this.moduleAnimation = new Animation(EasingType.LINEAR, 4000L);
      this.selectedCategory = ModuleCategory.COMBAT;
      this.x = Math.max(((float)mc.method_22683().method_4486() - this.width) / 2.0F, 10.0F);
      this.y = Math.max(((float)mc.method_22683().method_4502() - this.height) / 2.0F, 10.0F);
      this.selectedModule = (Module)Chorus.getInstance().getModuleManager().getModules().stream().filter((m) -> {
         return m.getCategory() == this.selectedCategory;
      }).toList().getFirst();
      this.component = new ModuleComponent(this.selectedModule);
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      super.method_25394(context, mouseX, mouseY, delta);
      class_4587 matrices = context.method_51448();
      this.drawBackgroundAndBorders(context, matrices, mouseX, mouseY);
      this.drawResizeHandle(context);
      this.drawCategorySelector(matrices);
      context.method_44379((int)this.x, (int)this.y + 28, (int)this.x + 75, (int)(this.y + this.height - 38.0F));
      this.drawModuleSelector(matrices);
      context.method_44380();
   }

   private void drawBackgroundAndBorders(class_332 context, class_4587 matrices, int mouseX, int mouseY) {
      Render2DEngine.drawRoundedRect(matrices, this.x, this.y, this.width, this.height, 7.5F, new Color(-14935012));
      int innerHeight = (int)(this.height - 65.0F);
      int innerY = (int)(this.y + 27.0F);
      Render2DEngine.drawLine(matrices, this.x, (float)(innerY - 1), this.x + this.width, (float)(innerY - 1), 1.0F, new Color(-4689678));
      Render2DEngine.drawLine(matrices, this.x, (float)(innerY + innerHeight + 1), this.x + this.width, (float)(innerY + innerHeight + 1), 1.0F, new Color(-4689678));
      float innerX = this.x + 85.0F;
      float innerWidth = this.width - 85.0F;
      Render2DEngine.drawRect(matrices, innerX, (float)innerY, innerWidth, (float)innerHeight, new Color(-15263977));
      RenderSystem.enableBlend();
      Function<class_2960, class_1921> renderLayers = class_1921::method_62277;
      class_2960 logo = class_2960.method_60655("chorus", "img/logo.png");
      context.method_25290(renderLayers, logo, (int)(this.x + 4.0F), (int)(this.y + 3.0F), 0.0F, 0.0F, 21, 21, 21, 21);
      RenderSystem.disableBlend();
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), "Chorus", this.x + 27.5F, this.y + 4.0F, 14.0F, -4689678);
      this.component.setBounds(innerX, (float)innerY, innerWidth, (float)innerHeight);
      this.component.render(context, mouseX, mouseY);
   }

   private void drawResizeHandle(class_332 context) {
      float handleX = this.x + this.width - 11.0F;
      float handleY = this.y + this.height - 11.0F;
   }

   private void drawModuleSelector(class_4587 matrices) {
      FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
      FontAtlas medium = Chorus.getInstance().getFonts().getInterMedium();
      float moduleX = this.x + 7.0F;
      float currentY = this.y + 31.0F + this.moduleY;

      for(Iterator var6 = Chorus.getInstance().getModuleManager().getModules().stream().filter((m) -> {
         return m.getCategory() == this.selectedCategory;
      }).toList().iterator(); var6.hasNext(); currentY += 24.0F) {
         Module module = (Module)var6.next();
         String name = module.getName();
         String description = medium.truncate(module.getDescription(), 58.0F, 6.0F);
         if (module == this.selectedModule) {
            Render2DEngine.drawGradientRect(matrices, this.x + 4.0F, currentY, 75.0F, 23.0F, new Color(699953394, true), new Color(12087538, true));
            Render2DEngine.drawLine(matrices, this.x + 4.0F, currentY, this.x + 4.0F, currentY + 23.0F, 2.0F, new Color(-4689678));
         }

         font.render(matrices, name, moduleX, currentY + 3.0F, 7.0F, module.isEnabled() ? (new Color(174, 102, 232, 255)).getRGB() : (module == this.selectedModule ? (new Color(255, 255, 255, 255)).darker().getRGB() : (new Color(197, 197, 197, 255)).darker().getRGB()));
         medium.render(matrices, description, moduleX, currentY + 12.5F, 6.0F, (new Color(197, 197, 197, 255)).darker().getRGB());
      }

   }

   private void drawCategorySelector(class_4587 matrices) {
      FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
      float totalWidth = this.computeTotalWidth(font);
      float startX = this.x + (this.width - totalWidth) / 2.0F;
      float categoryY = this.y + this.height - 15.0F;
      float currentX = startX;
      ModuleCategory[] var7 = ModuleCategory.values();
      int var8 = var7.length;

      for(int var9 = 0; var9 < var8; ++var9) {
         ModuleCategory category = var7[var9];
         String name = category.getName();
         float nameWidth = font.getWidth(name, 6.0F);
         if (this.selectedCategory == category) {
            Render2DEngine.drawRoundedRect(matrices, currentX - 6.0F, categoryY - 16.5F, nameWidth + 12.0F, 26.0F, 4.0F, new Color(-13948117));
         }

         font.render(matrices, name, currentX, categoryY, 6.0F, this.selectedCategory == category ? (new Color(197, 197, 197, 255)).getRGB() : (new Color(197, 197, 197, 255)).darker().getRGB());
         Chorus.getInstance().getFonts().getIcons().renderCenteredString(matrices, category.getIcon(), currentX + nameWidth / 2.0F - 1.5F, categoryY - 14.0F, 12.0F, this.selectedCategory == category ? (new Color(197, 197, 197, 255)).getRGB() : (new Color(197, 197, 197, 255)).darker().getRGB());
         currentX += nameWidth + 22.0F;
      }

   }

   private float computeTotalWidth(FontAtlas font) {
      float totalWidth = 0.0F;
      ModuleCategory[] var3 = ModuleCategory.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         ModuleCategory category = var3[var5];
         totalWidth += font.getWidth(category.getName(), 6.0F);
      }

      totalWidth += (float)(ModuleCategory.values().length - 1) * 22.0F;
      return totalWidth;
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      float currentY;
      if (button == 0) {
         if (mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + 27.0F)) {
            this.dragging = true;
            this.lastMouseX = mouseX;
            this.lastMouseY = mouseY;
            return true;
         }

         currentY = this.x + this.width - 11.0F;
         float handleY = this.y + this.height - 11.0F;
         if (mouseX >= (double)currentY && mouseX <= (double)(currentY + 11.0F) && mouseY >= (double)handleY && mouseY <= (double)(handleY + 11.0F)) {
            this.resizing = true;
            this.lastMouseX = mouseX;
            this.lastMouseY = mouseY;
            return true;
         }

         FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
         float totalWidth = this.computeTotalWidth(font);
         float startX = this.x + (this.width - totalWidth) / 2.0F;
         float categoryY = this.y + this.height - 15.0F;
         float currentX = startX;
         ModuleCategory[] var13 = ModuleCategory.values();
         int var14 = var13.length;

         for(int var15 = 0; var15 < var14; ++var15) {
            ModuleCategory category = var13[var15];
            String name = category.getName();
            float nameWidth = font.getWidth(name, 6.0F);
            float boxStartX = currentX - 6.0F;
            float boxEndX = currentX + nameWidth + 12.0F;
            float boxStartY = categoryY - 16.5F;
            float boxEndY = categoryY + 9.5F;
            if (mouseX >= (double)boxStartX && mouseX <= (double)boxEndX && mouseY >= (double)boxStartY && mouseY <= (double)boxEndY) {
               this.selectedCategory = category;
               this.moduleY = 0.0F;
               this.selectedModule = (Module)Chorus.getInstance().getModuleManager().getModules().stream().filter((m) -> {
                  return m.getCategory() == this.selectedCategory;
               }).findFirst().orElse(this.selectedModule);
               if (this.selectedModule != this.component.getModule()) {
                  this.component = new ModuleComponent(this.selectedModule);
               }

               return true;
            }

            currentX += nameWidth + 22.0F;
         }
      }

      currentY = this.y + 31.0F + this.moduleY;

      for(Iterator var23 = Chorus.getInstance().getModuleManager().getModules().stream().filter((m) -> {
         return m.getCategory() == this.selectedCategory;
      }).toList().iterator(); var23.hasNext(); currentY += 24.0F) {
         Module module = (Module)var23.next();
         if (mouseX >= (double)this.x && mouseX <= (double)(this.x + 85.0F) && mouseY >= (double)currentY && mouseY <= (double)(currentY + 24.0F)) {
            if (button == 0) {
               if (module.isEnabled()) {
                  module.onDisable();
               } else {
                  module.onEnable();
               }
            }

            if (button == 1 && !module.getSettingRepository().getSettings().isEmpty()) {
               this.selectedModule = module;
               if (this.selectedModule != this.component.getModule()) {
                  this.component = new ModuleComponent(this.selectedModule);
               }
            }
         }
      }

      if (this.component.isHovered(mouseX, mouseY)) {
         this.component.mouseClicked(mouseX, mouseY, button);
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.dragging && button == 0) {
         this.x += (float)(mouseX - this.lastMouseX);
         this.y += (float)(mouseY - this.lastMouseY);
         this.lastMouseX = mouseX;
         this.lastMouseY = mouseY;
         return true;
      } else if (this.resizing && button == 0) {
         float newWidth = (float)((double)this.width + (mouseX - this.lastMouseX));
         float newHeight = (float)((double)this.height + (mouseY - this.lastMouseY));
         this.width = Math.max(newWidth, 415.0F);
         this.height = Math.max(newHeight, 295.0F);
         this.lastMouseX = mouseX;
         this.lastMouseY = mouseY;
         return true;
      } else {
         if (this.component.isHovered(mouseX, mouseY)) {
            this.component.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
         }

         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.dragging = false;
         this.resizing = false;
      }

      this.component.mouseReleased(mouseX, mouseY, button);
      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (mouseX > (double)this.x && mouseX <= (double)(this.x + 75.0F) && mouseY > (double)(this.y + 27.0F) && mouseY <= (double)(this.y + this.height - 38.0F)) {
         this.moduleY += (float)verticalAmount * 5.0F;
         this.moduleY = Math.min(this.moduleY, 0.0F);
         return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
      } else {
         if (this.component.isHovered(mouseX, mouseY)) {
            this.component.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
         }

         return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
      }
   }

   public void method_25419() {
      ((ClickGUI)Chorus.getInstance().getModuleManager().getModule(ClickGUI.class)).onDisable();
      super.method_25419();
   }

   public static PrimordialScreen getINSTANCE() {
      return INSTANCE;
   }
}
