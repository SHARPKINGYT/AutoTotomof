package com.chorus.impl.screen.primordial.component;

import com.chorus.api.module.Module;
import com.chorus.api.module.setting.Setting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.impl.screen.primordial.component.impl.CategoryComponent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class ModuleComponent extends Component {
   private final Module module;
   private final List<CategoryComponent> components = new ArrayList();
   private float scrollHeight = 0.0F;

   public ModuleComponent(Module module) {
      this.module = module;
      List<Setting<?>> noParent = module.getSettingRepository().getSettings().values().stream().filter((settingx) -> {
         return settingx.getParent() == null && !(settingx instanceof SettingCategory);
      }).toList();
      if (!noParent.isEmpty()) {
         this.components.add(new CategoryComponent("General", noParent));
      }

      Iterator var3 = module.getSettingRepository().getSettings().values().stream().filter((settingx) -> {
         return settingx instanceof SettingCategory;
      }).toList().iterator();

      while(var3.hasNext()) {
         Setting<?> setting = (Setting)var3.next();
         SettingCategory categorySetting = (SettingCategory)setting;
         List<Setting<?>> children = module.getSettingRepository().getSettings().values().stream().filter((s) -> {
            return s.getParent() != null && s.getParent() == categorySetting;
         }).toList();
         this.components.add(new CategoryComponent(categorySetting.getName(), children));
      }

   }

   public void render(class_332 context, int mouseX, int mouseY) {
      context.method_44379((int)this.getX(), (int)this.getY(), (int)(this.getX() + this.getWidth()), (int)(this.getY() + this.getHeight()));
      float startX = this.getX() + 5.0F;
      float startY = this.getY() + 5.0F;
      float width = (this.getWidth() - 15.0F) / 2.0F;
      float spacing = 5.0F;
      float leftX = startX;
      float rightX = startX + width + spacing;
      float leftY = startY;
      float rightY = startY;
      float totalHeight = 0.0F;

      CategoryComponent component;
      for(Iterator var13 = this.components.iterator(); var13.hasNext(); totalHeight += component.getHeight() + spacing) {
         component = (CategoryComponent)var13.next();
      }

      if (!this.components.isEmpty()) {
         totalHeight -= spacing;
      }

      float availableScrollSpace = -Math.max(0.0F, totalHeight - this.getHeight());
      this.scrollHeight = Math.max(this.scrollHeight, availableScrollSpace - 15.0F);
      if (totalHeight <= this.getHeight()) {
         this.scrollHeight = 0.0F;
      }

      CategoryComponent component;
      for(Iterator var18 = this.components.iterator(); var18.hasNext(); component.render(context, mouseX, mouseY)) {
         component = (CategoryComponent)var18.next();
         float componentHeight = component.getHeight();
         if (leftY <= rightY) {
            component.setBounds(leftX, leftY + this.scrollHeight, width, componentHeight);
            leftY += componentHeight + spacing;
         } else {
            component.setBounds(rightX, rightY + this.scrollHeight, width, componentHeight);
            rightY += componentHeight + spacing;
         }
      }

      Render2DEngine.drawVerticalGradient(context.method_51448(), this.getX(), this.getY() + this.getHeight() - 20.0F, this.getWidth(), 20.0F, new Color(1513239, true), new Color(-585689321, true));
      context.method_44380();
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      this.components.forEach((c) -> {
         c.mouseClicked(mouseX, mouseY, button);
      });
      return this.isHovered(mouseX, mouseY);
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      this.components.forEach((c) -> {
         c.mouseReleased(mouseX, mouseY, button);
      });
   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      this.components.forEach((c) -> {
         c.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
      });
   }

   public void mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.scrollHeight += (float)verticalAmount * 5.0F;
      this.scrollHeight = Math.min(this.scrollHeight, 0.0F);
      super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
   }

   public Module getModule() {
      return this.module;
   }
}
