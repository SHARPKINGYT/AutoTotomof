package com.chorus.impl.screen.primordial.component.impl;

import chorus0.Chorus;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.animation.Animation;
import com.chorus.api.system.render.animation.EasingType;
import com.chorus.impl.screen.primordial.component.Component;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class BooleanComponent extends Component {
   private final BooleanSetting setting;
   Animation colorAnimation;

   public BooleanComponent(BooleanSetting setting) {
      this.colorAnimation = new Animation(EasingType.LINEAR, 250L);
      this.setting = setting;
      this.setHeight(15.0F);
   }

   public void render(class_332 context, int mouseX, int mouseY) {
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), this.setting.getName(), this.getX() + 16.0F, this.getY() + 4.0F, 6.0F, -1315861);
      double animation = this.colorAnimation.getValue();
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, this.getY() + 3.5F, this.getHeight() - 7.0F, this.getHeight() - 7.0F, 2.0F, new Color(-15461356));
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, this.getY() + 3.5F, this.getHeight() - 7.0F, this.getHeight() - 7.0F, 2.0F, new Color(184, 112, 242, (int)(255.0D * animation)));
      this.colorAnimation.run(this.setting.getValue() ? 1.0D : 0.0D);
      if (!this.setting.getValue()) {
         this.colorAnimation.setStartPoint(1.0D);
      }

   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         this.setting.setValue(!this.setting.getValue());
      }

      return this.isHovered(mouseX, mouseY);
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
   }

   public BooleanSetting getSetting() {
      return this.setting;
   }

   public Animation getColorAnimation() {
      return this.colorAnimation;
   }
}
