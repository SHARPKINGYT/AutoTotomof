package com.chorus.impl.screen.primordial.component.impl;

import chorus0.Chorus;
import com.chorus.api.module.setting.Setting;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ColorSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.impl.screen.primordial.component.Component;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class CategoryComponent extends Component {
   private final String name;
   private final List<Setting<?>> settings;
   private final List<Component> components = new ArrayList();

   public CategoryComponent(String name, List<Setting<?>> settings) {
      this.name = name;
      this.settings = settings;
      Iterator var3 = settings.iterator();

      while(var3.hasNext()) {
         Setting<?> setting = (Setting)var3.next();
         if (setting instanceof BooleanSetting) {
            BooleanSetting booleanSetting = (BooleanSetting)setting;
            this.components.add(new BooleanComponent(booleanSetting));
         }

         if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            this.components.add(new SliderComponent(numberSetting));
         }

         if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            this.components.add(new ModeComponent(modeSetting));
         }

         if (setting instanceof RangeSetting) {
            RangeSetting rangeSetting = (RangeSetting)setting;
            this.components.add(new RangeComponent(rangeSetting));
         }

         if (setting instanceof MultiSetting) {
            MultiSetting multiSetting = (MultiSetting)setting;
            this.components.add(new MultiComponent(multiSetting));
         }

         if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            this.components.add(new ColorComponent(colorSetting));
         }
      }

      float height = 15.0F;

      Component component;
      for(Iterator var7 = this.components.iterator(); var7.hasNext(); height += component.getHeight()) {
         component = (Component)var7.next();
      }

      this.setHeight(height);
   }

   public void render(class_332 context, int mouseX, int mouseY) {
      float height = 15.0F;

      Component component;
      for(Iterator var5 = this.components.iterator(); var5.hasNext(); height += component.getHeight()) {
         component = (Component)var5.next();
      }

      this.setHeight(height);
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX(), this.getY(), this.getWidth(), this.getHeight(), 4.0F, new Color(1842204));
      Render2DEngine.drawTopRoundedRect(context.method_51448(), this.getX(), this.getY(), this.getWidth(), 13.0F, 4.0F, new Color(2368548));
      Render2DEngine.drawLine(context.method_51448(), this.getX(), this.getY() + 13.0F, this.getX() + this.getWidth(), this.getY() + 13.0F, 1.0F, new Color(12087538));
      Chorus.getInstance().getFonts().getInterSemiBold().render(context.method_51448(), (String)this.name, this.getX() + 4.0F, this.getY() + 3.0F, 6.0F, -1);
      float y = 0.0F;

      Component component;
      for(Iterator var9 = this.components.iterator(); var9.hasNext(); y += component.getHeight()) {
         component = (Component)var9.next();
         component.setBounds(this.getX(), this.getY() + 13.5F + y, this.getWidth(), component.getHeight());
         component.render(context, mouseX, mouseY);
      }

   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      this.components.forEach((c) -> {
         c.mouseClicked(mouseX, mouseY, button);
      });
      return this.isHovered(mouseX, mouseY);
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      this.components.forEach((c) -> {
         c.mouseReleased(mouseX, mouseY, button);
      });
   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      this.components.forEach((c) -> {
         c.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
      });
   }

   public String getName() {
      return this.name;
   }

   public List<Setting<?>> getSettings() {
      return this.settings;
   }

   public List<Component> getComponents() {
      return this.components;
   }
}
