package com.chorus.impl.screen.primordial.component.impl;

import chorus0.Chorus;
import com.chorus.api.module.setting.implement.ColorSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.animation.Animation;
import com.chorus.api.system.render.animation.EasingType;
import com.chorus.impl.screen.primordial.component.Component;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class ColorComponent extends Component {
   private final ColorSetting setting;
   private boolean expanded = false;
   private boolean draggingHue = false;
   private boolean draggingAlpha = false;
   private boolean draggingSaturationBrightness = false;
   private final Animation expandAnimation;

   public ColorComponent(ColorSetting setting) {
      this.expandAnimation = new Animation(EasingType.LINEAR, 250L);
      this.setting = setting;
      this.setHeight(20.0F);
   }

   public void render(class_332 context, int mouseX, int mouseY) {
      float expandProgress = (float)this.expandAnimation.getValue();
      this.setHeight(20.0F + 80.0F * expandProgress);
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), this.setting.getName(), this.getX() + 16.0F, this.getY() + 4.0F, 6.0F, -1315861);
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, this.getY() + 3.5F, this.getHeight() - 7.0F, this.getHeight() - 7.0F, 2.0F, this.setting.getValue());
      if (this.expanded) {
         this.expandAnimation.run(1.0D);
         float baseY = this.getY() + 20.0F;
         Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, baseY, this.getWidth() - 10.0F, 60.0F, 2.0F, new Color(-15461356));
         float hueSliderY = baseY + 65.0F;
         Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, hueSliderY, this.getWidth() - 10.0F, 5.0F, 1.0F, new Color(-15461356));
         float alphaSliderY = hueSliderY + 10.0F;
         Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, alphaSliderY, this.getWidth() - 10.0F, 5.0F, 1.0F, new Color(-15461356));
      } else {
         this.expandAnimation.run(0.0D);
      }

   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         if (mouseY <= (double)(this.getY() + 20.0F)) {
            this.expanded = !this.expanded;
            return true;
         }

         if (this.expanded) {
            float baseY = this.getY() + 20.0F;
            if (mouseY >= (double)baseY && mouseY <= (double)(baseY + 60.0F)) {
               this.draggingSaturationBrightness = true;
               this.updateColor(mouseX, mouseY);
               return true;
            }

            float hueSliderY = baseY + 65.0F;
            if (mouseY >= (double)hueSliderY && mouseY <= (double)(hueSliderY + 5.0F)) {
               this.draggingHue = true;
               this.updateColor(mouseX, mouseY);
               return true;
            }

            float alphaSliderY = hueSliderY + 10.0F;
            if (mouseY >= (double)alphaSliderY && mouseY <= (double)(alphaSliderY + 5.0F)) {
               this.draggingAlpha = true;
               this.updateColor(mouseX, mouseY);
               return true;
            }
         }
      }

      return false;
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      this.draggingHue = false;
      this.draggingAlpha = false;
      this.draggingSaturationBrightness = false;
   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.draggingHue || this.draggingAlpha || this.draggingSaturationBrightness) {
         this.updateColor(mouseX, mouseY);
      }

   }

   private void updateColor(double mouseX, double mouseY) {
      float alpha;
      if (this.draggingSaturationBrightness) {
         alpha = this.getY() + 20.0F;
         float saturation = (float)(mouseX - (double)(this.getX() + 5.0F)) / (this.getWidth() - 10.0F);
         float brightness = 1.0F - (float)(mouseY - (double)alpha) / 60.0F;
         saturation = Math.max(0.0F, Math.min(1.0F, saturation));
         brightness = Math.max(0.0F, Math.min(1.0F, brightness));
         float[] hsb = Color.RGBtoHSB(this.setting.getRed(), this.setting.getGreen(), this.setting.getBlue(), (float[])null);
         Color newColor = Color.getHSBColor(hsb[0], saturation, brightness);
         this.setting.setColor(newColor.getRed(), newColor.getGreen(), newColor.getBlue(), this.setting.getAlpha());
      } else if (this.draggingHue) {
         alpha = (float)(mouseX - (double)(this.getX() + 5.0F)) / (this.getWidth() - 10.0F);
         alpha = Math.max(0.0F, Math.min(1.0F, alpha));
         float[] hsb = Color.RGBtoHSB(this.setting.getRed(), this.setting.getGreen(), this.setting.getBlue(), (float[])null);
         Color newColor = Color.getHSBColor(alpha, hsb[1], hsb[2]);
         this.setting.setColor(newColor.getRed(), newColor.getGreen(), newColor.getBlue(), this.setting.getAlpha());
      } else if (this.draggingAlpha) {
         alpha = (float)(mouseX - (double)(this.getX() + 5.0F)) / (this.getWidth() - 10.0F);
         alpha = Math.max(0.0F, Math.min(1.0F, alpha));
         this.setting.setColor(this.setting.getRed(), this.setting.getGreen(), this.setting.getBlue(), (int)(alpha * 255.0F));
      }

   }

   public ColorSetting getSetting() {
      return this.setting;
   }

   public boolean isExpanded() {
      return this.expanded;
   }

   public boolean isDraggingHue() {
      return this.draggingHue;
   }

   public boolean isDraggingAlpha() {
      return this.draggingAlpha;
   }

   public boolean isDraggingSaturationBrightness() {
      return this.draggingSaturationBrightness;
   }

   public Animation getExpandAnimation() {
      return this.expandAnimation;
   }
}
