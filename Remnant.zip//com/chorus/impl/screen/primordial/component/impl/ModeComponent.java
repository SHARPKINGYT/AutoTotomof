package com.chorus.impl.screen.primordial.component.impl;

import chorus0.Chorus;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.animation.Animation;
import com.chorus.api.system.render.animation.EasingType;
import com.chorus.impl.screen.primordial.component.Component;
import java.awt.Color;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class ModeComponent extends Component {
   private boolean open = false;
   private final ModeSetting setting;
   Animation animation;

   public ModeComponent(ModeSetting setting) {
      this.animation = new Animation(EasingType.LINEAR, 250L);
      this.setting = setting;
      this.setHeight(24.0F);
   }

   public void render(class_332 context, int mouseX, int mouseY) {
      float extraHeight = (float)(9 * this.setting.getModes().size());
      this.setHeight((float)(24.0D + (double)extraHeight * this.animation.getValue()));
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), this.setting.getName(), this.getX() + 5.0F, this.getY() + 2.5F, 6.0F, -1315861);
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, this.getY() + 12.0F, this.getWidth() - 10.0F, (float)(9.0D + (double)extraHeight * this.animation.getValue()), 1.5F, new Color(-15461356));
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), this.setting.getValue(), this.getX() + 7.0F, this.getY() + 12.5F, 6.0F, -4473925);
      this.animation.run(this.open ? 1.0D : 0.0D);
      if (!this.open) {
         this.animation.setStartPoint(1.0D);
      }

      float y = 21.5F + (float)(!this.open ? 9 * this.setting.getModes().size() : 0);

      for(Iterator var6 = this.setting.getModes().iterator(); var6.hasNext(); y += this.open ? 9.0F : -9.0F) {
         String mode = (String)var6.next();
         if ((double)this.getY() + (double)y * this.animation.getValue() > (double)this.getY() + 15.5D) {
            Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), mode, this.getX() + 7.0F, (float)((double)this.getY() + (double)y * this.animation.getValue()), 6.0F, mode.equals(this.setting.getValue()) ? -4689678 : -9408400);
         }
      }

   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0) {
         if (mouseY <= (double)(this.getY() + 21.0F)) {
            this.open = !this.open;
         }

         if (this.open) {
            float y = 21.5F;

            for(Iterator var7 = this.setting.getModes().iterator(); var7.hasNext(); y += 9.0F) {
               String mode = (String)var7.next();
               if (mouseY >= (double)(this.getY() + y) && mouseY <= (double)(this.getY() + y + 9.0F)) {
                  this.setting.setMode(mode);
               }
            }
         }
      }

      return this.isHovered(mouseX, mouseY);
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
   }

   public boolean isOpen() {
      return this.open;
   }

   public ModeSetting getSetting() {
      return this.setting;
   }

   public Animation getAnimation() {
      return this.animation;
   }
}
