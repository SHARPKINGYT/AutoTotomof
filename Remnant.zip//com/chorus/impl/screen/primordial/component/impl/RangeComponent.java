package com.chorus.impl.screen.primordial.component.impl;

import chorus0.Chorus;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.impl.screen.primordial.component.Component;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class RangeComponent extends Component {
   private boolean draggingMin;
   private boolean draggingMax;
   private final RangeSetting<? extends Number> setting;

   public RangeComponent(RangeSetting<?> setting) {
      this.setting = setting;
      this.setHeight(20.0F);
   }

   public void render(class_332 context, int mouseX, int mouseY) {
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), this.setting.getName(), this.getX() + 5.0F, this.getY() + 2.5F, 6.0F, -1315861);
      String var10000 = String.format("%.2f", this.setting.getValueMin().floatValue());
      String value = var10000 + "-" + String.format("%.2f", this.setting.getValueMax().floatValue());
      float valueWidth = Chorus.getInstance().getFonts().getInterMedium().getWidth(value, 6.0F);
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), value, this.getX() + this.getWidth() - 5.0F - valueWidth, this.getY() + 2.5F, 6.0F, -7303024);
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, this.getY() + 13.0F, this.getWidth() - 10.0F, this.getHeight() - 17.0F, 1.0F, new Color(-15461356));
      float minX = this.getX() + 5.0F + (this.getWidth() - 10.0F) * (this.setting.getValueMin().floatValue() / this.setting.getMax().floatValue());
      float maxX = this.getX() + 5.0F + (this.getWidth() - 10.0F) * (this.setting.getValueMax().floatValue() / this.setting.getMax().floatValue());
      float width = maxX - minX;
      Render2DEngine.drawRoundedRect(context.method_51448(), minX, this.getY() + 13.0F, width, this.getHeight() - 17.0F, 1.0F, new Color(-4689678));
      Render2DEngine.drawRoundedRect(context.method_51448(), minX - 1.0F, this.getY() + 12.0F, 2.0F, this.getHeight() - 15.0F, 0.5F, new Color(-134145));
      Render2DEngine.drawRoundedRect(context.method_51448(), maxX - 1.0F, this.getY() + 12.0F, 2.0F, this.getHeight() - 15.0F, 0.5F, new Color(-134145));
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0) {
         double relativeX = mouseX - (double)(this.getX() + 5.0F);
         double minHandleX = (double)(this.getWidth() - 10.0F) * (this.setting.getValueMin().doubleValue() - this.setting.getMin().doubleValue()) / (this.setting.getMax().doubleValue() - this.setting.getMin().doubleValue());
         double maxHandleX = (double)(this.getWidth() - 10.0F) * (this.setting.getValueMax().doubleValue() - this.setting.getMin().doubleValue()) / (this.setting.getMax().doubleValue() - this.setting.getMin().doubleValue());
         double handleWidth = 2.0D;
         double halfHandleWidth = handleWidth / 2.0D;
         if (Math.abs(relativeX - minHandleX) < halfHandleWidth) {
            this.draggingMin = true;
         } else if (Math.abs(relativeX - maxHandleX) < halfHandleWidth) {
            this.draggingMax = true;
         } else {
            this.draggingMin = Math.abs(relativeX - minHandleX) < Math.abs(relativeX - maxHandleX);
            this.draggingMax = !this.draggingMin;
         }

         this.slide(mouseX);
      }

      return this.isHovered(mouseX, mouseY);
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      this.draggingMin = false;
      this.draggingMax = false;
   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.draggingMin || this.draggingMax) {
         this.slide(mouseX);
      }

   }

   private Number convertToSettingType(double value) {
      if (this.setting.getValueMin() instanceof Integer) {
         return (int)Math.round(value);
      } else if (this.setting.getValueMin() instanceof Float) {
         return (float)value;
      } else if (this.setting.getValueMin() instanceof Double) {
         return value;
      } else {
         return (Number)(this.setting.getValueMin() instanceof Long ? Math.round(value) : value);
      }
   }

   private void slide(double mouseX) {
      double relativeX = mouseX - (double)(this.getX() + 5.0F);
      double range = this.setting.getMax().doubleValue() - this.setting.getMin().doubleValue();
      double relativeMin = class_3532.method_15350(relativeX / (double)(this.getWidth() - 10.0F), 0.0D, 1.0D);
      double relativeMax = class_3532.method_15350((relativeX + 0.01D) / (double)(this.getWidth() - 10.0F), 0.0D, 1.0D);
      double valueMin = relativeMin * range + this.setting.getMin().doubleValue();
      double valueMax = relativeMax * range + this.setting.getMin().doubleValue();
      if (this.draggingMin && !this.draggingMax) {
         valueMin = Math.min(valueMin, this.setting.getValueMax().doubleValue());
         this.setting.setValue(new Number[]{this.convertToSettingType(valueMin), this.setting.getValueMax()});
      } else if (this.draggingMax && !this.draggingMin) {
         valueMax = Math.max(valueMax, this.setting.getValueMin().doubleValue());
         this.setting.setValue(new Number[]{this.setting.getValueMin(), this.convertToSettingType(valueMax)});
      }

   }
}
