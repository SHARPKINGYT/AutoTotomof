package com.chorus.impl.screen.primordial.component.impl;

import chorus0.Chorus;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.impl.screen.primordial.component.Component;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class SliderComponent<T extends Number & Comparable<T>> extends Component {
   private final NumberSetting<T> setting;
   public boolean dragging;

   public SliderComponent(NumberSetting<T> setting) {
      this.setting = setting;
      this.setHeight(20.0F);
   }

   public void render(class_332 context, int mouseX, int mouseY) {
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), this.setting.getName(), this.getX() + 5.0F, this.getY() + 2.5F, 6.0F, -1315861);
      String value = String.format("%.2f", this.setting.getValue().floatValue());
      float valueWidth = Chorus.getInstance().getFonts().getInterMedium().getWidth(value, 6.0F);
      Chorus.getInstance().getFonts().getInterMedium().render(context.method_51448(), value, this.getX() + this.getWidth() - 5.0F - valueWidth, this.getY() + 2.5F, 6.0F, -7303024);
      float width = (this.getWidth() - 10.0F) * ((this.setting.getValue().floatValue() - this.setting.getMinValue().floatValue()) / (this.setting.getMaxValue().floatValue() - this.setting.getMinValue().floatValue()));
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, this.getY() + 13.0F, this.getWidth() - 10.0F, this.getHeight() - 17.0F, 1.0F, new Color(-15461356));
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F, this.getY() + 13.0F, width, this.getHeight() - 17.0F, 1.0F, new Color(-4689678));
      Render2DEngine.drawRoundedRect(context.method_51448(), this.getX() + 5.0F + width - 1.0F, this.getY() + 12.0F, 2.0F, this.getHeight() - 15.0F, 0.5F, new Color(-134145));
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0) {
         this.dragging = true;
         this.slide(mouseX);
      }

      return this.isHovered(mouseX, mouseY);
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      if (this.dragging && button == 0) {
         this.dragging = false;
      }

   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.dragging) {
         this.slide(mouseX);
      }

   }

   private T convertToSettingType(double value) {
      if (this.setting.getValue() instanceof Integer) {
         return (int)Math.round(value);
      } else if (this.setting.getValue() instanceof Float) {
         return (float)value;
      } else if (this.setting.getValue() instanceof Double) {
         return value;
      } else {
         return (Number)(this.setting.getValue() instanceof Long ? Math.round(value) : value);
      }
   }

   private void slide(double mouseX) {
      double relativeX = class_3532.method_15350(mouseX - (double)(this.getX() + 5.0F), 0.0D, (double)(this.getWidth() - 10.0F));
      double percentage = relativeX / (double)(this.getWidth() - 10.0F);
      double range = this.setting.getMaxValue().doubleValue() - this.setting.getMinValue().doubleValue();
      double newValue = percentage * range + this.setting.getMinValue().doubleValue();
      this.setting.setValue(this.convertToSettingType(newValue));
   }

   public NumberSetting<T> getSetting() {
      return this.setting;
   }

   public boolean isDragging() {
      return this.dragging;
   }
}
