package com.chorus.impl.screen.remnant;

import chorus0.Chorus;
import com.chorus.api.module.Module;
import com.chorus.api.module.ModuleCategory;
import com.chorus.api.module.setting.Setting;
import com.chorus.api.module.setting.implement.BooleanSetting;
import com.chorus.api.module.setting.implement.ColorSetting;
import com.chorus.api.module.setting.implement.ModeSetting;
import com.chorus.api.module.setting.implement.MultiSetting;
import com.chorus.api.module.setting.implement.NumberSetting;
import com.chorus.api.module.setting.implement.RangeSetting;
import com.chorus.api.module.setting.implement.SettingCategory;
import com.chorus.api.system.render.Render2DEngine;
import com.chorus.api.system.render.font.FontAtlas;
import com.chorus.common.QuickImports;
import com.chorus.common.util.player.input.InputUtils;
import com.chorus.impl.modules.client.ClickGUI;
import com.chorus.impl.screen.hud.HUDEditorScreen;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5611;

@Environment(EnvType.CLIENT)
public class RemnantScreen extends class_437 implements QuickImports {
   private static final RemnantScreen INSTANCE = new RemnantScreen();
   private static final float PANEL_WIDTH = 120.0F;
   private static final float PANEL_HEIGHT = 17.5F;
   private static final float ANIMATION_DURATION = 500.0F;
   private static final float TOGGLE_WIDTH = 18.0F;
   private static final float TOGGLE_HEIGHT = 9.0F;
   private static final float KNOB_SIZE = 6.0F;
   private static final float PANEL_SPACING = 8.0F;
   private static final float INITIAL_Y = 15.0F;
   private static final float SETTING_PADDING = 6.0F;
   private static final float SETTING_TEXT_SIZE = 6.0F;
   private static final float TITLE_TEXT_SIZE = 8.0F;
   private static final float SLIDER_THICKNESS = 2.0F;
   private static final float OUTLINE_THICKNESS = 1.0F;
   private static final float TOGGLE_KNOB_OFFSET = 1.5F;
   private static final float COLOR_PICKER_HEIGHT = 80.0F;
   private static final float TOOLTIP_DELAY = 1000.0F;
   private static final float TOOLTIP_PADDING = 4.0F;
   private static final float TOOLTIP_TEXT_SIZE = 7.0F;
   private static final Color HIGHLIGHT_COLOR = new Color(150, 150, 150);
   private static final Color DISABLED_COLOR = new Color(70, 70, 70);
   private static final Color BACKGROUND_COLOR = new Color(0, 0, 0, 175);
   private static final Color OUTLINE_COLOR = new Color(100, 100, 100, 100);
   private static final Color TOGGLE_KNOB_COLOR = new Color(255, 255, 255, 200);
   private static final int TEXT_PRIMARY = -1;
   private static final int TEXT_SECONDARY = -5592406;
   private static final int TEXT_DISABLED = -7303024;
   private Module selectedModule;
   private RemnantScreen.Panel selectedPanel;
   private Module hoveredModule;
   private long hoverStartTime;
   private boolean showingTooltip;
   private NumberSetting<?> draggingNumberSetting = null;
   private RangeSetting<?> draggingRangeSetting = null;
   private boolean draggingRangeMin = false;
   private ColorSetting draggedColorSetting = null;
   private boolean draggingHue = false;
   private boolean draggingAlpha = false;
   private boolean draggingSaturationBrightness = false;
   private final Map<ModuleCategory, RemnantScreen.Panel> panels = new HashMap();
   private int lastScreenWidth = -1;
   private int lastScreenHeight = -1;

   public RemnantScreen() {
      super(class_2561.method_43470("Remnant"));
      float totalWidth = (float)ModuleCategory.values().length * 120.0F + (float)(ModuleCategory.values().length - 1) * 8.0F;
      float x = (float)mc.method_22683().method_4486() / 2.0F - totalWidth / 2.0F;
      ModuleCategory[] var3 = ModuleCategory.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         ModuleCategory category = var3[var5];
         this.panels.put(category, new RemnantScreen.Panel(this, category, true, new class_5611(x, 15.0F)));
         ((RemnantScreen.Panel)this.panels.get(category)).setModules((List)moduleManager.getModules().stream().filter((module) -> {
            return module.getCategory() == category;
         }).collect(Collectors.toList()));
         x += 128.0F;
      }

   }

   private void recenterPanels() {
      float totalWidth = (float)ModuleCategory.values().length * 120.0F + (float)(ModuleCategory.values().length - 1) * 8.0F;
      float x = (float)mc.method_22683().method_4486() / 2.0F - totalWidth / 2.0F;
      ModuleCategory[] var3 = ModuleCategory.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         ModuleCategory category = var3[var5];
         RemnantScreen.Panel panel = (RemnantScreen.Panel)this.panels.get(category);
         if (panel != null) {
            float currentY = panel.getPosition().method_32119();
            panel.position = new class_5611(x, currentY);
            x += 128.0F;
         }
      }

   }

   private void renderSetting(Setting<?> setting, class_332 context, class_5611 position, float moduleY, FontAtlas font) {
      if (setting.shouldRender()) {
         int size = 25;
         float posX = position.method_32118();
         String result = setting.getName() != null && setting.getName().length() > size ? setting.getName().substring(0, size) + "..." : setting.getName();
         font.render(context.method_51448(), result, posX + 6.0F, moduleY + 4.0F, 6.0F, -5592406);
         Objects.requireNonNull(setting);
         byte var10 = 0;
         float animationProgress;
         long lastAnimationTime;
         long currentTime;
         float smoothProgress;
         float smoothProgress;
         float baseY;
         Iterator var27;
         float colorAlphaY;
         float alpha;
         Color outlineColor;
         float animationProgress;
         float animationProgress;
         float targetProgress;
         float t;
         float knobStartX;
         float optionY;
         float hueSliderY;
         float saturationX;
         switch(setting.typeSwitch<invokedynamic>(setting, var10)) {
         case 0:
            BooleanSetting booleanSetting = (BooleanSetting)setting;
            float toggleY = moduleY + 4.25F;
            RemnantScreen.Panel panel = this.selectedPanel;
            animationProgress = (Float)panel.booleanAnimations.computeIfAbsent(booleanSetting, (k) -> {
               return booleanSetting.getValue() ? 1.0F : 0.0F;
            });
            long lastAnimationTime = (Long)panel.booleanAnimationTimes.computeIfAbsent(booleanSetting, (k) -> {
               return System.currentTimeMillis();
            });
            long currentTime = System.currentTimeMillis();
            targetProgress = Math.min(1.0F, (float)(currentTime - lastAnimationTime) / 500.0F * 3.0F);
            animationProgress = this.setAnimationDuration(booleanSetting.getValue(), animationProgress, targetProgress, -1.0F);
            float smoothProgress;
            if (animationProgress < 0.5F) {
               smoothProgress = 2.0F * animationProgress * animationProgress;
            } else {
               t = -2.0F * animationProgress + 2.0F;
               smoothProgress = 1.0F - t * t / 2.0F;
            }

            panel.booleanAnimations.put(booleanSetting, animationProgress);
            panel.booleanAnimationTimes.put(booleanSetting, currentTime);
            Color toggleColor = new Color(DISABLED_COLOR.getRed() + (int)((float)(HIGHLIGHT_COLOR.getRed() - DISABLED_COLOR.getRed()) * smoothProgress), DISABLED_COLOR.getGreen() + (int)((float)(HIGHLIGHT_COLOR.getGreen() - DISABLED_COLOR.getGreen()) * smoothProgress), DISABLED_COLOR.getBlue() + (int)((float)(HIGHLIGHT_COLOR.getBlue() - DISABLED_COLOR.getBlue()) * smoothProgress));
            Render2DEngine.drawRoundedRect(context.method_51448(), posX + 120.0F - 18.0F - 6.0F - 2.0F, toggleY, 18.0F, 9.0F, 3.9130435F, toggleColor);
            knobStartX = posX + 120.0F - 18.0F - 6.0F;
            smoothProgress = posX + 120.0F - 6.0F - 6.0F - 4.0F;
            smoothProgress = knobStartX + (smoothProgress - knobStartX) * smoothProgress;
            Render2DEngine.drawRoundedRect(context.method_51448(), smoothProgress, toggleY + 1.5F, 6.0F, 6.0F, 3.0F, TOGGLE_KNOB_COLOR);
            break;
         case 1:
            NumberSetting<?> numberSetting = (NumberSetting)setting;
            float sliderY = moduleY + 17.5F;
            DecimalFormat format = new DecimalFormat("#.##");
            String value = format.format(numberSetting.getValue().doubleValue());
            float valueWidth = font.getWidth(value, 6.0F);
            font.render(context.method_51448(), value, posX + 120.0F - 6.0F - 2.0F - valueWidth, moduleY + 4.0F, 6.0F, -7303024);
            Render2DEngine.drawRoundedRect(context.method_51448(), posX + 6.0F, sliderY, 108.0F, 2.0F, 1.0F, DISABLED_COLOR);
            double progress = (numberSetting.getValue().doubleValue() - numberSetting.getMinValue().doubleValue()) / (numberSetting.getMaxValue().doubleValue() - numberSetting.getMinValue().doubleValue());
            targetProgress = (float)progress;
            RemnantScreen.Panel panel = this.selectedPanel;
            t = (Float)panel.numberAnimations.computeIfAbsent(numberSetting, (k) -> {
               return targetProgress;
            });
            currentTime = (Long)panel.numberAnimationTimes.computeIfAbsent(numberSetting, (k) -> {
               return System.currentTimeMillis();
            });
            long currentTime = System.currentTimeMillis();
            optionY = Math.min(1.0F, (float)(currentTime - currentTime) / 500.0F * 3.0F);
            t = this.setAnimationDuration(t < targetProgress, t, optionY, targetProgress);
            panel.numberAnimations.put(numberSetting, t);
            panel.numberAnimationTimes.put(numberSetting, currentTime);
            Render2DEngine.drawRoundedRect(context.method_51448(), posX + 6.0F, sliderY, 108.0F * t, 2.0F, 1.0F, HIGHLIGHT_COLOR);
            Render2DEngine.drawRoundedRect(context.method_51448(), posX + 6.0F + 108.0F * t - 3.0F, sliderY - 2.0F, 6.0F, 6.0F, 3.0F, TOGGLE_KNOB_COLOR);
            break;
         case 2:
            RangeSetting rangeSetting = (RangeSetting)setting;
            animationProgress = moduleY + 17.5F;
            DecimalFormat format = new DecimalFormat("#.##");
            String var10000 = format.format(rangeSetting.getValueMin().doubleValue());
            String value = var10000 + " - " + format.format(rangeSetting.getValueMax().doubleValue());
            animationProgress = font.getWidth(value, 6.0F);
            font.render(context.method_51448(), value, posX + 120.0F - 6.0F - 2.0F - animationProgress, moduleY + 4.0F, 6.0F, -7303024);
            Render2DEngine.drawRoundedRect(context.method_51448(), posX + 6.0F, animationProgress, 108.0F, 2.0F, 1.0F, DISABLED_COLOR);
            double minProgress = (rangeSetting.getValueMin().doubleValue() - rangeSetting.getMin().doubleValue()) / (rangeSetting.getMax().doubleValue() - rangeSetting.getMin().doubleValue());
            double maxProgress = (rangeSetting.getValueMax().doubleValue() - rangeSetting.getMin().doubleValue()) / (rangeSetting.getMax().doubleValue() - rangeSetting.getMin().doubleValue());
            knobStartX = (float)minProgress;
            smoothProgress = (float)maxProgress;
            RemnantScreen.Panel panel = this.selectedPanel;
            Float[] animationProgress = (Float[])panel.rangeAnimations.computeIfAbsent(rangeSetting, (k) -> {
               return new Float[]{knobStartX, smoothProgress};
            });
            long lastAnimationTime = (Long)panel.rangeAnimationTimes.computeIfAbsent(rangeSetting, (k) -> {
               return System.currentTimeMillis();
            });
            long currentTime = System.currentTimeMillis();
            colorAlphaY = Math.min(1.0F, (float)(currentTime - lastAnimationTime) / 500.0F * 3.0F);
            animationProgress[0] = this.setAnimationDuration(animationProgress[0] < knobStartX, animationProgress[0], colorAlphaY, knobStartX);
            animationProgress[1] = this.setAnimationDuration(animationProgress[1] < smoothProgress, animationProgress[1], colorAlphaY, smoothProgress);
            panel.rangeAnimations.put(rangeSetting, animationProgress);
            panel.rangeAnimationTimes.put(rangeSetting, currentTime);
            Render2DEngine.drawRoundedRect(context.method_51448(), posX + 6.0F + 108.0F * animationProgress[0], animationProgress, 108.0F * (animationProgress[1] - animationProgress[0]), 2.0F, 1.0F, HIGHLIGHT_COLOR);
            alpha = posX + 6.0F + 108.0F * animationProgress[0];
            float maxKnobX = posX + 6.0F + 108.0F * animationProgress[1];
            saturationX = animationProgress + 2.0F;
            Render2DEngine.drawRoundedRect(context.method_51448(), alpha - 4.0F + 3.0F, saturationX - 4.0F, 6.0F, 6.0F, 3.0F, TOGGLE_KNOB_COLOR);
            Render2DEngine.drawRoundedRect(context.method_51448(), maxKnobX - 4.0F, saturationX - 4.0F, 6.0F, 6.0F, 3.0F, TOGGLE_KNOB_COLOR);
            break;
         case 3:
            ModeSetting modeSetting = (ModeSetting)setting;
            RemnantScreen.Panel panel = this.selectedPanel;
            boolean isOpen = panel.getOpenModeSetting() == modeSetting;
            animationProgress = (Float)panel.modeAnimations.computeIfAbsent(modeSetting, (k) -> {
               return isOpen ? 1.0F : 0.0F;
            });
            long lastAnimationTime = (Long)panel.modeAnimationTimes.computeIfAbsent(modeSetting, (k) -> {
               return System.currentTimeMillis();
            });
            long currentTime = System.currentTimeMillis();
            knobStartX = Math.min(1.0F, (float)(currentTime - lastAnimationTime) / 500.0F * 3.0F);
            animationProgress = this.setAnimationDuration(isOpen, animationProgress, knobStartX, -1.0F);
            if (animationProgress < 0.5F) {
               smoothProgress = 2.0F * animationProgress * animationProgress;
            } else {
               smoothProgress = -2.0F * animationProgress + 2.0F;
               smoothProgress = 1.0F - smoothProgress * smoothProgress / 2.0F;
            }

            panel.modeAnimations.put(modeSetting, animationProgress);
            panel.modeAnimationTimes.put(modeSetting, currentTime);
            String value = modeSetting.getValue();
            baseY = font.getWidth(value, 6.0F);
            font.render(context.method_51448(), value, posX + 120.0F - 10.0F - baseY, moduleY + 4.0F, 6.0F, -7303024);
            if (animationProgress > 0.0F) {
               optionY = moduleY + 17.5F;

               for(var27 = modeSetting.getModes().iterator(); var27.hasNext(); optionY += 15.5F) {
                  String mode = (String)var27.next();
                  boolean isSelected = mode.equals(modeSetting.getValue());
                  colorAlphaY = (float)((int)(smoothProgress * 255.0F));
                  Color outlineColor = isSelected ? new Color(255, 255, 255, (int)(100.0F * smoothProgress)) : new Color(100, 100, 100, (int)(100.0F * smoothProgress));
                  Render2DEngine.drawRoundedOutline(context.method_51448(), posX + 6.0F, optionY, 108.0F, 15.5F, 1.0F, 1.0F, outlineColor);
                  font.render(context.method_51448(), mode, posX + 10.0F, optionY + 7.75F - font.getLineHeight() / 2.0F + 1.0F, 6.0F, isSelected ? 16777215 | (int)colorAlphaY << 24 : 9474192 | (int)colorAlphaY << 24);
               }
            }
            break;
         case 4:
            MultiSetting multiSetting = (MultiSetting)setting;
            RemnantScreen.Panel panel = this.selectedPanel;
            boolean isOpen = panel.getOpenMultiSetting() == multiSetting;
            animationProgress = (Float)panel.multiAnimations.computeIfAbsent(multiSetting, (k) -> {
               return isOpen ? 1.0F : 0.0F;
            });
            lastAnimationTime = (Long)panel.multiAnimationTimes.computeIfAbsent(multiSetting, (k) -> {
               return System.currentTimeMillis();
            });
            long currentTime = System.currentTimeMillis();
            smoothProgress = Math.min(1.0F, (float)(currentTime - lastAnimationTime) / 500.0F * 3.0F);
            animationProgress = this.setAnimationDuration(isOpen, animationProgress, smoothProgress, -1.0F);
            if (animationProgress < 0.5F) {
               smoothProgress = 2.0F * animationProgress * animationProgress;
            } else {
               baseY = -2.0F * animationProgress + 2.0F;
               smoothProgress = 1.0F - baseY * baseY / 2.0F;
            }

            panel.multiAnimations.put(multiSetting, animationProgress);
            panel.multiAnimationTimes.put(multiSetting, currentTime);
            String value = multiSetting.getValue().isEmpty() ? "None" : String.valueOf(multiSetting.getValue().size());
            optionY = font.getWidth(value, 6.0F);
            font.render(context.method_51448(), value, posX + 120.0F - 10.0F - optionY, moduleY + 4.0F, 6.0F, -7303024);
            if (animationProgress > 0.0F) {
               hueSliderY = moduleY + 17.5F;

               for(Iterator var73 = multiSetting.getModes().iterator(); var73.hasNext(); hueSliderY += 15.5F) {
                  String mode = (String)var73.next();
                  boolean isSelected = multiSetting.getSpecificValue(mode);
                  alpha = (float)((int)(smoothProgress * 255.0F));
                  outlineColor = isSelected ? new Color(255, 255, 255, (int)(100.0F * smoothProgress)) : new Color(100, 100, 100, (int)(100.0F * smoothProgress));
                  Render2DEngine.drawRoundedOutline(context.method_51448(), posX + 6.0F, hueSliderY, 108.0F, 15.5F, 1.0F, 1.0F, outlineColor);
                  font.render(context.method_51448(), mode, posX + 10.0F, hueSliderY + 7.75F - font.getLineHeight() / 2.0F + 1.0F, 6.0F, isSelected ? 16777215 | (int)alpha << 24 : 9474192 | (int)alpha << 24);
               }
            }
            break;
         case 5:
            ColorSetting colorSetting = (ColorSetting)setting;
            RemnantScreen.Panel panel = this.selectedPanel;
            animationProgress = (Float)panel.colorAnimations.computeIfAbsent(colorSetting, (k) -> {
               return 0.0F;
            });
            lastAnimationTime = (Long)panel.colorAnimationTimes.computeIfAbsent(colorSetting, (k) -> {
               return System.currentTimeMillis();
            });
            boolean expanded = (Boolean)panel.colorSettingExpanded.computeIfAbsent(colorSetting, (k) -> {
               return false;
            });
            currentTime = System.currentTimeMillis();
            smoothProgress = Math.min(1.0F, (float)(currentTime - lastAnimationTime) / 500.0F * 3.0F);
            animationProgress = this.setAnimationDuration(expanded, animationProgress, smoothProgress, -1.0F);
            panel.colorAnimations.put(colorSetting, animationProgress);
            panel.colorAnimationTimes.put(colorSetting, currentTime);
            float colorAlphaX;
            if (animationProgress > 0.0F && animationProgress < 1.0F && this.selectedModule != null && this.selectedPanel == panel) {
               baseY = 17.5F;
               baseY += 19.5F;
               List<Setting<?>> settings = new ArrayList();
               var27 = this.selectedModule.getSettingRepository().getSettings().values().iterator();

               Setting s;
               while(var27.hasNext()) {
                  s = (Setting)var27.next();
                  if (!(s instanceof SettingCategory)) {
                     settings.add(s);
                  }
               }

               baseY += 19.5F * (float)settings.size() + 6.0F;
               var27 = settings.iterator();

               while(true) {
                  if (!var27.hasNext()) {
                     baseY += 2.0F;
                     panel.updateHeight(baseY);
                     break;
                  }

                  s = (Setting)var27.next();
                  colorAlphaX = this.getSettingHeight(s, panel) - 17.5F;
                  colorAlphaY = !(s instanceof NumberSetting) && !(s instanceof RangeSetting) ? 0.0F : 2.0F;
                  baseY += colorAlphaX + colorAlphaY - 2.0F;
               }
            }

            font.render(context.method_51448(), colorSetting.getName(), posX + 6.0F, moduleY + 4.0F, 6.0F, -5592406);
            Render2DEngine.drawRoundedRect(context.method_51448(), posX + 120.0F - 18.0F - 6.0F - 2.0F, moduleY + 4.25F, 18.0F, 9.0F, 3.9130435F, colorSetting.getValue());
            if (expanded) {
               baseY = moduleY + 17.5F;
               Render2DEngine.drawRoundedRect(context.method_51448(), posX + 6.0F, baseY, 108.0F, 60.0F * animationProgress, 2.0F, new Color(-15461356));
               float[] hsb = Color.RGBtoHSB(colorSetting.getRed(), colorSetting.getGreen(), colorSetting.getBlue(), (float[])null);
               Render2DEngine.drawColorPicker(context.method_51448(), posX + 6.0F, baseY, 108.0F, 60.0F, hsb[0], 255.0F);
               hueSliderY = baseY + 65.0F * animationProgress;
               float segmentWidth = 18.0F;

               for(int i = 0; i < 6; ++i) {
                  colorAlphaY = (float)i / 6.0F;
                  alpha = (float)(i + 1) / 6.0F;
                  outlineColor = Color.getHSBColor(colorAlphaY, 1.0F, 1.0F);
                  Color color2 = Color.getHSBColor(alpha, 1.0F, 1.0F);
                  Render2DEngine.drawGradientRect(context.method_51448(), posX + 6.0F + segmentWidth * (float)i, hueSliderY, segmentWidth, 5.0F, outlineColor, color2);
               }

               colorAlphaX = posX + 6.0F;
               colorAlphaY = hueSliderY + 10.0F;
               alpha = 108.0F;
               outlineColor = new Color(colorSetting.getRed(), colorSetting.getGreen(), colorSetting.getBlue());
               Render2DEngine.drawGradientRect(context.method_51448(), colorAlphaX, colorAlphaY, alpha, 5.0F, new Color((float)outlineColor.getRed() / 255.0F, (float)outlineColor.getGreen() / 255.0F, (float)outlineColor.getBlue() / 255.0F, 0.003921569F), new Color((float)outlineColor.getRed() / 255.0F, (float)outlineColor.getGreen() / 255.0F, (float)outlineColor.getBlue() / 255.0F, 1.0F));
               if (this.draggedColorSetting == colorSetting) {
                  if (this.draggingHue) {
                     saturationX = posX + 6.0F + 108.0F * hsb[0];
                     Render2DEngine.drawRoundedRect(context.method_51448(), saturationX - 2.0F, hueSliderY - 2.0F, 4.0F, 9.0F, 2.0F, Color.WHITE);
                  }

                  if (this.draggingAlpha) {
                     saturationX = posX + 6.0F + 108.0F * ((float)colorSetting.getAlpha() / 255.0F);
                     Render2DEngine.drawRoundedRect(context.method_51448(), saturationX - 2.0F, colorAlphaY - 2.0F, 4.0F, 9.0F, 2.0F, Color.WHITE);
                  }

                  if (this.draggingSaturationBrightness) {
                     saturationX = posX + 6.0F + 108.0F * hsb[1];
                     float constrainedBrightness = Math.max(0.0F, Math.min(1.0F, hsb[2]));
                     float brightnessY = baseY + 60.0F * (1.0F - constrainedBrightness);
                     Render2DEngine.drawRoundedRect(context.method_51448(), saturationX - 2.0F, brightnessY - 2.0F, 4.0F, 4.0F, 2.0F, Color.WHITE);
                  }
               }
            }
         }

      }
   }

   public float setAnimationDuration(boolean condition, float progress, float elapsed, float targetProgress) {
      if (condition) {
         progress = Math.min(targetProgress != -1.0F ? targetProgress : 1.0F, progress + elapsed);
      } else {
         progress = Math.max(targetProgress != -1.0F ? targetProgress : 0.0F, progress - elapsed);
      }

      return progress;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      int currentWidth = mc.method_22683().method_4486();
      int currentHeight = mc.method_22683().method_4502();
      if (currentWidth != this.lastScreenWidth || currentHeight != this.lastScreenHeight) {
         this.recenterPanels();
         this.lastScreenWidth = currentWidth;
         this.lastScreenHeight = currentHeight;
      }

      if (mc.field_1687 == null) {
         super.method_25394(context, mouseX, mouseY, delta);
      }

      FontAtlas inter = Chorus.getInstance().getFonts().getInterSemiBold();
      FontAtlas icons = Chorus.getInstance().getFonts().getLucide();
      class_4587 matrices = context.method_51448();
      if (mc.field_1724 != null) {
         inter.render(matrices, "HUD Editor", (float)mc.method_22683().method_4486() - inter.getWidth("HUD Editor", 8.0F) - 10.0F, 10.0F, 8.0F, Color.WHITE.getRGB());
      }

      boolean foundHoveredModule = false;
      long currentTime = System.currentTimeMillis();
      Iterator var13 = this.panels.values().iterator();

      while(true) {
         while(true) {
            RemnantScreen.Panel panel;
            float panelBottom;
            float screenHeight;
            do {
               if (!var13.hasNext()) {
                  if (!foundHoveredModule) {
                     this.hoveredModule = null;
                     this.showingTooltip = false;
                  }

                  var13 = this.panels.values().iterator();

                  float targetHeight;
                  while(var13.hasNext()) {
                     panel = (RemnantScreen.Panel)var13.next();
                     float moduleY;
                     float settingsOffset;
                     float posX;
                     float panelHeight;
                     if (panel.isOpen()) {
                        targetHeight = 19.5F * (float)panel.getModules().size();
                        panelBottom = panel.getPosition().method_32119() + targetHeight + 17.5F + 4.0F;
                        screenHeight = (float)mc.method_22683().method_4502();
                        if (panelBottom > screenHeight) {
                           posX = screenHeight - panel.getPosition().method_32119() - 17.5F - 4.0F;
                           panel.maxModuleScrollOffset = Math.max(0.0F, targetHeight - posX);
                        } else {
                           panel.maxModuleScrollOffset = 0.0F;
                        }

                        panel.setModuleScrollOffset(Math.max(0.0F, Math.min(panel.getModuleScrollOffset(), panel.getMaxModuleScrollOffset())));
                        if (panel.isShowingSettings() && this.selectedModule != null && this.selectedPanel == panel) {
                           posX = 21.5F;
                           List<Setting<?>> settings = new ArrayList();
                           Iterator var20 = this.selectedModule.getSettingRepository().getSettings().values().iterator();

                           label188:
                           while(true) {
                              Setting setting;
                              do {
                                 if (!var20.hasNext()) {
                                    panelHeight = screenHeight - panel.getPosition().method_32119() - 17.5F - 4.0F;
                                    panel.maxSettingScrollOffset = Math.max(0.0F, posX - panelHeight);
                                    panel.settingScrollOffset = Math.max(0.0F, Math.min(panel.settingScrollOffset, panel.maxSettingScrollOffset));
                                    break label188;
                                 }

                                 setting = (Setting)var20.next();
                              } while(setting instanceof SettingCategory);

                              settings.add(setting);
                              moduleY = this.getSettingHeight(setting, panel);
                              settingsOffset = !(setting instanceof NumberSetting) && !(setting instanceof RangeSetting) ? 0.0F : 2.0F;
                              posX += moduleY + settingsOffset;
                           }
                        }
                     }

                     if (panel.isShowingSettings()) {
                        if (panel.getSettingsAnimationProgress() < 1.0F) {
                           targetHeight = (float)(currentTime - panel.lastSettingsAnimationTime) / 100.0F;
                           panel.setSettingsAnimationProgress(Math.min(1.0F, panel.getSettingsAnimationProgress() + targetHeight));
                           panel.lastSettingsAnimationTime = currentTime;
                        }
                     } else if (panel.getSettingsAnimationProgress() > 0.0F) {
                        targetHeight = (float)(currentTime - panel.lastSettingsAnimationTime) / 100.0F;
                        panel.setSettingsAnimationProgress(Math.max(0.0F, panel.getSettingsAnimationProgress() - targetHeight));
                        panel.lastSettingsAnimationTime = currentTime;
                     }

                     targetHeight = 17.5F;
                     float posY;
                     if (panel.isOpen()) {
                        if (panel.isShowingSettings() && this.selectedModule != null && this.selectedPanel == panel) {
                           targetHeight += 19.5F;
                           List<Setting<?>> settings = new ArrayList();
                           Iterator var37 = this.selectedModule.getSettingRepository().getSettings().values().iterator();

                           Setting setting;
                           while(var37.hasNext()) {
                              setting = (Setting)var37.next();
                              if (!(setting instanceof SettingCategory)) {
                                 settings.add(setting);
                              }
                           }

                           targetHeight += 19.5F * (float)settings.size() + 6.0F;

                           for(var37 = settings.iterator(); var37.hasNext(); targetHeight += posY + panelHeight - 2.0F) {
                              setting = (Setting)var37.next();
                              posY = this.getSettingHeight(setting, panel) - 17.5F;
                              panelHeight = !(setting instanceof NumberSetting) && !(setting instanceof RangeSetting) ? 0.0F : 2.0F;
                           }
                        } else {
                           targetHeight += 19.5F * (float)panel.getModules().size();
                        }
                     }

                     targetHeight += 2.0F;
                     panel.updateHeight(targetHeight);
                     panel.animateHeight();
                     class_5611 position = panel.getPosition();
                     String icon = panel.getCategory().getLucideIcon();
                     posX = position.method_32118();
                     posY = position.method_32119();
                     panelHeight = panel.getCurrentHeight();
                     Render2DEngine.drawBlurredRoundedRect(matrices, posX, posY, 120.0F, panelHeight + 1.0F, 5.0F, 8.0F, BACKGROUND_COLOR);
                     Render2DEngine.drawRoundedOutline(matrices, posX, posY, 120.0F, panelHeight, 5.0F, 1.0F, OUTLINE_COLOR);
                     inter.render(matrices, (String)panel.getCategory().getName(), posX + 6.0F, posY + 8.75F - inter.getLineHeight() / 2.5F, 8.0F, -1);
                     float iconWidth = icons.getWidth(icon, 8.0F);
                     icons.render(matrices, (String)icon, posX + 120.0F - 6.0F - iconWidth, posY + 8.75F - inter.getLineHeight() / 2.5F, 8.0F, -1);
                     moduleY = posY + 17.5F + 2.0F - panel.getModuleScrollOffset();
                     if (panel.isOpen()) {
                        context.method_44379((int)posX + 1, (int)(posY + 17.5F + 2.0F), (int)(posX + 120.0F - 1.0F), (int)(posY + panelHeight));
                        settingsOffset = (1.0F - this.easeInOutCubic(panel.getSettingsAnimationProgress())) * 120.0F;
                        float moduleXOffset = -this.easeInOutCubic(panel.getSettingsAnimationProgress()) * 120.0F;
                        if (!panel.isShowingSettings() || panel.getSettingsAnimationProgress() < 1.0F) {
                           for(Iterator var25 = panel.getModules().iterator(); var25.hasNext(); moduleY += 19.5F) {
                              Module module = (Module)var25.next();
                              if (moduleY + 17.5F >= posY + 17.5F + 2.0F && moduleY <= posY + panelHeight) {
                                 Render2DEngine.drawRoundedOutline(matrices, posX + 2.0F + moduleXOffset, moduleY, 116.0F, 17.5F, 2.0F, 1.0F, OUTLINE_COLOR);
                                 if (module.isEnabled()) {
                                    Render2DEngine.drawRoundedRect(matrices, posX + 2.0F + moduleXOffset, moduleY, 116.0F, 17.5F, 2.0F, OUTLINE_COLOR);
                                 }

                                 String bind = InputUtils.getKeyName(module.getKey());
                                 if (!bind.equals("None")) {
                                    float bindLength = inter.getWidth(bind, 7.0F);
                                    float bindX = posX + 2.0F + moduleXOffset + 120.0F - bindLength - 20.0F;
                                    Render2DEngine.drawRoundedOutline(matrices, bindX, moduleY + 8.75F - inter.getLineHeight(7.0F) / 2.0F, bindLength + 5.0F, 8.75F, 2.0F, 1.0F, OUTLINE_COLOR);
                                    inter.render(matrices, bind, bindX + 2.5F, moduleY + 8.75F - inter.getLineHeight(7.0F) / 2.0F, 7.0F, module.isEnabled() ? -1 : -5592406);
                                 }

                                 inter.renderWithShadow(matrices, module.getName(), posX + 6.0F + moduleXOffset, moduleY + 8.75F - inter.getLineHeight() / 2.0F, 8.0F, module.isEnabled() ? -1 : -5592406);
                                 if (!module.getSettingRepository().getSettings().isEmpty()) {
                                    icons.render(matrices, "\ue073", posX + moduleXOffset + 120.0F - 14.0F, moduleY + 8.75F - inter.getLineHeight() / 2.0F, 10.0F, module.isEnabled() ? -1 : -5592406);
                                 }
                              }
                           }
                        }

                        if (panel.isShowingSettings() && this.selectedModule != null && this.selectedPanel == panel) {
                           moduleY = posY + 17.5F + 2.0F - panel.settingScrollOffset;
                           float settingsX = posX + settingsOffset;
                           inter.render(matrices, this.selectedModule.getName(), settingsX + 6.0F, moduleY + 8.75F - inter.getLineHeight() / 2.0F, 7.0F, this.selectedModule.isEnabled() ? -1 : -5592406);
                           String backArrow = "\ue0ab";
                           float arrowWidth = icons.getWidth(backArrow, 8.0F);
                           icons.render(matrices, backArrow, settingsX + 120.0F - 10.0F - arrowWidth, moduleY + 8.75F - inter.getLineHeight() / 2.0F, 8.0F, -7303024);
                           Render2DEngine.drawLine(matrices, settingsX + 4.0F, moduleY + 17.5F, settingsX + 120.0F - 4.0F, moduleY + 17.5F, 1.0F, new Color(100, 100, 100, 100));
                           moduleY += 21.5F;
                           List<Setting<?>> settings = new ArrayList();
                           Iterator var49 = this.selectedModule.getSettingRepository().getSettings().values().iterator();

                           Setting setting;
                           while(var49.hasNext()) {
                              setting = (Setting)var49.next();
                              if (!(setting instanceof SettingCategory)) {
                                 settings.add(setting);
                              }
                           }

                           context.method_44379((int)settingsX + 1, (int)(posY + 17.5F + 2.0F), (int)(settingsX + 120.0F - 1.0F), (int)(posY + panelHeight));

                           float padding;
                           for(var49 = settings.iterator(); var49.hasNext(); moduleY += this.getSettingHeight(setting, panel) + padding) {
                              setting = (Setting)var49.next();
                              if (moduleY + this.getSettingHeight(setting, panel) >= posY + 17.5F + 2.0F && moduleY <= posY + panelHeight) {
                                 this.renderSetting(setting, context, new class_5611(settingsX, posY), moduleY, inter);
                              }

                              padding = !(setting instanceof NumberSetting) && !(setting instanceof RangeSetting) ? 0.0F : 2.0F;
                           }

                           context.method_44380();
                        }

                        context.method_44380();
                     }

                     if (panel.isDragging()) {
                        panel.updatePosition((double)mouseX, (double)mouseY);
                     }
                  }

                  if (this.showingTooltip && this.hoveredModule != null && this.hoveredModule.getDescription() != null) {
                     String description = this.hoveredModule.getDescription();
                     float tooltipWidth = inter.getWidth(description, 7.0F) + 12.0F;
                     targetHeight = inter.getLineHeight(7.0F) + 8.0F;
                     panelBottom = Math.min((float)(mouseX + 10), (float)mc.method_22683().method_4486() - tooltipWidth - 5.0F);
                     screenHeight = Math.min((float)(mouseY + 10), (float)mc.method_22683().method_4502() - targetHeight - 5.0F);
                     Render2DEngine.drawBlurredRoundedRect(matrices, panelBottom, screenHeight, tooltipWidth, targetHeight, 4.0F, 8.0F, BACKGROUND_COLOR);
                     Render2DEngine.drawRoundedOutline(matrices, panelBottom, screenHeight, tooltipWidth, targetHeight, 4.0F, 1.0F, OUTLINE_COLOR);
                     inter.render(matrices, (String)description, panelBottom + 4.0F, screenHeight + 4.0F, 7.0F, -1);
                  }

                  return;
               }

               panel = (RemnantScreen.Panel)var13.next();
            } while(!panel.isOpen());

            class_5611 pos = panel.getPosition();
            panelBottom = pos.method_32119() + 17.5F + 2.0F - panel.getModuleScrollOffset();
            screenHeight = -panel.getSettingsAnimationProgress() * 120.0F;

            for(Iterator var18 = panel.getModules().iterator(); var18.hasNext(); panelBottom += 19.5F) {
               Module module = (Module)var18.next();
               if ((float)mouseX >= pos.method_32118() + screenHeight && (float)mouseX <= pos.method_32118() + 120.0F + screenHeight && (float)mouseY >= panelBottom && (float)mouseY <= panelBottom + 17.5F && (float)mouseY >= pos.method_32119() + 17.5F + 2.0F && (float)mouseY <= pos.method_32119() + panel.getCurrentHeight()) {
                  foundHoveredModule = true;
                  if (this.hoveredModule != module) {
                     this.hoveredModule = module;
                     this.hoverStartTime = currentTime;
                     this.showingTooltip = false;
                  } else if ((float)(currentTime - this.hoverStartTime) >= 1000.0F && !this.showingTooltip) {
                     this.showingTooltip = true;
                  }
                  break;
               }
            }
         }
      }
   }

   private float getSettingHeight(Setting<?> setting, RemnantScreen.Panel panel) {
      float height = 17.5F;
      if (!setting.shouldRender()) {
         return 0.0F;
      } else {
         Objects.requireNonNull(setting);
         byte var5 = 0;
         switch(setting.typeSwitch<invokedynamic>(setting, var5)) {
         case 0:
            RangeSetting<?> rangeSetting = (RangeSetting)setting;
            height += 2.0F;
            break;
         case 1:
            NumberSetting<?> numberSetting = (NumberSetting)setting;
            height += 2.0F;
            break;
         case 2:
            ColorSetting colorSetting = (ColorSetting)setting;
            boolean expanded = (Boolean)panel.colorSettingExpanded.getOrDefault(colorSetting, false);
            float animationProgress = (Float)panel.colorAnimations.getOrDefault(colorSetting, expanded ? 1.0F : 0.0F);
            if (expanded || animationProgress > 0.0F) {
               height += 80.0F * animationProgress;
            }
            break;
         case 3:
            ModeSetting modeSetting = (ModeSetting)setting;
            if (panel.getOpenModeSetting() == modeSetting && !modeSetting.getModes().isEmpty()) {
               height += 15.5F * (float)modeSetting.getModes().size();
            }
            break;
         case 4:
            MultiSetting multiSetting = (MultiSetting)setting;
            if (panel.getOpenMultiSetting() == multiSetting && !multiSetting.getModes().isEmpty()) {
               height += 15.5F * (float)multiSetting.getModes().size();
            }
         }

         return height;
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      float moduleY;
      float adjustedMouseY;
      float moduleXOffset;
      float settingsX;
      float adjustedSettingsMouseY;
      Iterator var36;
      RemnantScreen.Panel panel;
      class_5611 pos;
      Iterator var39;
      Module module;
      if (button == 0) {
         if (mc.field_1724 != null) {
            FontAtlas font = Chorus.getInstance().getFonts().getInterSemiBold();
            String hudEditorText = "HUD Editor";
            float hudEditorWidth = font.getWidth(hudEditorText, 8.0F);
            moduleY = (float)mc.method_22683().method_4486() - hudEditorWidth - 10.0F;
            adjustedMouseY = 10.0F;
            if (mouseX >= (double)moduleY && mouseX <= (double)(moduleY + hudEditorWidth) && mouseY >= (double)adjustedMouseY && mouseY <= (double)(adjustedMouseY + font.getLineHeight(8.0F))) {
               mc.method_1507(HUDEditorScreen.getINSTANCE());
               ((ClickGUI)Chorus.getInstance().getModuleManager().getModule(ClickGUI.class)).onDisable();
               return true;
            }
         }

         var36 = this.panels.values().iterator();

         while(true) {
            while(true) {
               do {
                  if (!var36.hasNext()) {
                     return super.method_25402(mouseX, mouseY, button);
                  }

                  panel = (RemnantScreen.Panel)var36.next();
                  pos = panel.getPosition();
                  if (mouseX >= (double)pos.method_32118() && mouseX <= (double)(pos.method_32118() + 120.0F) && mouseY >= (double)pos.method_32119() && mouseY <= (double)(pos.method_32119() + 17.5F)) {
                     panel.startDragging(mouseX, mouseY);
                     return true;
                  }
               } while(!panel.isOpen());

               moduleY = pos.method_32119() + 17.5F + 2.0F;
               adjustedMouseY = (float)mouseY + panel.getModuleScrollOffset();
               if (!panel.isShowingSettings()) {
                  moduleXOffset = -panel.getSettingsAnimationProgress() * 120.0F;

                  for(var39 = panel.getModules().iterator(); var39.hasNext(); moduleY += 19.5F) {
                     module = (Module)var39.next();
                     if (mouseX >= (double)(pos.method_32118() + moduleXOffset) && mouseX <= (double)(pos.method_32118() + 120.0F + moduleXOffset) && adjustedMouseY >= moduleY && adjustedMouseY <= moduleY + 17.5F && mouseY >= (double)(pos.method_32119() + 17.5F + 2.0F) && mouseY <= (double)(pos.method_32119() + panel.getCurrentHeight())) {
                        if (module.isEnabled()) {
                           module.onDisable();
                        } else {
                           module.onEnable();
                        }

                        return true;
                     }
                  }
               } else if (this.selectedModule != null && this.selectedPanel == panel) {
                  moduleXOffset = (1.0F - panel.getSettingsAnimationProgress()) * 120.0F;
                  settingsX = pos.method_32118() + moduleXOffset;
                  adjustedSettingsMouseY = (float)mouseY + panel.settingScrollOffset;
                  if (mouseX >= (double)settingsX && mouseX <= (double)(settingsX + 120.0F) && mouseY >= (double)moduleY && mouseY <= (double)(moduleY + 17.5F)) {
                     panel.setShowingSettings(false);
                     panel.lastSettingsAnimationTime = System.currentTimeMillis();
                     this.selectedModule = null;
                     this.selectedPanel = null;
                     return true;
                  }

                  moduleY += 21.5F;
                  List<Setting<?>> settings = new ArrayList();
                  Iterator var15 = this.selectedModule.getSettingRepository().getSettings().values().iterator();

                  Setting setting;
                  while(var15.hasNext()) {
                     setting = (Setting)var15.next();
                     if (!(setting instanceof SettingCategory)) {
                        settings.add(setting);
                     }
                  }

                  float settingHeight;
                  float padding;
                  for(var15 = settings.iterator(); var15.hasNext(); moduleY += settingHeight + padding) {
                     setting = (Setting)var15.next();
                     settingHeight = this.getSettingHeight(setting, panel);
                     if (mouseX >= (double)(settingsX + 4.0F) && mouseX <= (double)(settingsX + 120.0F - 4.0F) && adjustedSettingsMouseY >= moduleY && adjustedSettingsMouseY <= moduleY + settingHeight && mouseY >= (double)(pos.method_32119() + 17.5F + 2.0F) && mouseY <= (double)(pos.method_32119() + panel.getCurrentHeight())) {
                        Objects.requireNonNull(setting);
                        byte var19 = 0;
                        float percentage;
                        float newValue;
                        float sliderY;
                        float relativeX;
                        float relativeX;
                        float totalWidth;
                        switch(setting.typeSwitch<invokedynamic>(setting, var19)) {
                        case 0:
                           BooleanSetting booleanSetting = (BooleanSetting)setting;
                           float toggleWidth = 18.0F;
                           sliderY = 9.0F;
                           relativeX = moduleY + (17.5F - sliderY) / 2.0F;
                           if (mouseX >= (double)(settingsX + 120.0F - toggleWidth - 8.0F) && mouseX <= (double)(settingsX + 120.0F - 8.0F) && adjustedSettingsMouseY >= relativeX && adjustedSettingsMouseY <= relativeX + sliderY) {
                              booleanSetting.toggle();
                              panel.booleanAnimationTimes.put(booleanSetting, System.currentTimeMillis());
                              return true;
                           }
                           break;
                        case 1:
                           NumberSetting<?> numberSetting = (NumberSetting)setting;
                           sliderY = moduleY + 17.5F;
                           if (adjustedSettingsMouseY >= sliderY - 5.0F && adjustedSettingsMouseY <= sliderY + 7.0F) {
                              this.draggingNumberSetting = numberSetting;
                              relativeX = (float)(mouseX - (double)(settingsX + 6.0F));
                              relativeX = 108.0F;
                              totalWidth = Math.max(0.0F, Math.min(1.0F, relativeX / relativeX));
                              percentage = numberSetting.getMaxValue().floatValue() - numberSetting.getMinValue().floatValue();
                              newValue = numberSetting.getMinValue().floatValue() + percentage * totalWidth;
                              if (numberSetting.getValue() instanceof Integer) {
                                 numberSetting.setValue((Number)Math.round(newValue));
                              } else if (numberSetting.getValue() instanceof Float) {
                                 numberSetting.setValue((Number)newValue);
                              } else if (numberSetting.getValue() instanceof Double) {
                                 numberSetting.setValue((Number)((double)newValue));
                              }

                              return true;
                           }
                           break;
                        case 2:
                           RangeSetting rangeSetting = (RangeSetting)setting;
                           relativeX = moduleY + 17.5F;
                           if (adjustedSettingsMouseY >= relativeX - 5.0F && adjustedSettingsMouseY <= relativeX + 7.0F) {
                              this.draggingRangeSetting = rangeSetting;
                              relativeX = (float)(mouseX - (double)(settingsX + 6.0F));
                              totalWidth = 108.0F;
                              percentage = Math.max(0.0F, Math.min(1.0F, relativeX / totalWidth));
                              newValue = (rangeSetting.getValueMin().floatValue() - rangeSetting.getMin().floatValue()) / (rangeSetting.getMax().floatValue() - rangeSetting.getMin().floatValue());
                              float maxProgress = (rangeSetting.getValueMax().floatValue() - rangeSetting.getMin().floatValue()) / (rangeSetting.getMax().floatValue() - rangeSetting.getMin().floatValue());
                              this.draggingRangeMin = Math.abs(percentage - newValue) < Math.abs(percentage - maxProgress);
                              float range = rangeSetting.getMax().floatValue() - rangeSetting.getMin().floatValue();
                              Number var31 = rangeSetting.getMin();
                              byte var32 = 0;
                              Object var10000;
                              switch(var31.typeSwitch<invokedynamic>(var31, var32)) {
                              case -1:
                              default:
                                 var10000 = rangeSetting.getMin().floatValue() + range * percentage;
                                 break;
                              case 0:
                                 Double v = (Double)var31;
                                 var10000 = rangeSetting.getMin().doubleValue() + (double)(range * percentage);
                                 break;
                              case 1:
                                 Float v = (Float)var31;
                                 var10000 = rangeSetting.getMin().floatValue() + range * percentage;
                                 break;
                              case 2:
                                 Integer i = (Integer)var31;
                                 var10000 = (int)((float)rangeSetting.getMin().intValue() + range * percentage);
                              }

                              Number newValue = var10000;
                              Number[] currentValues = rangeSetting.getValue();
                              if (this.draggingRangeMin) {
                                 if (((Number)newValue).floatValue() <= currentValues[1].floatValue()) {
                                    rangeSetting.setValue(new Number[]{(Number)newValue, currentValues[1]});
                                 }
                              } else if (((Number)newValue).floatValue() >= currentValues[0].floatValue()) {
                                 rangeSetting.setValue(new Number[]{currentValues[0], (Number)newValue});
                              }

                              return true;
                           }
                           break;
                        case 3:
                           ModeSetting modeSetting = (ModeSetting)setting;
                           if (adjustedSettingsMouseY <= moduleY + 17.5F) {
                              panel.setOpenModeSetting(panel.getOpenModeSetting() == modeSetting ? null : modeSetting);
                              return true;
                           }
                           break;
                        case 4:
                           MultiSetting multiSetting = (MultiSetting)setting;
                           if (adjustedSettingsMouseY <= moduleY + 17.5F) {
                              panel.setOpenMultiSetting(panel.getOpenMultiSetting() == multiSetting ? null : multiSetting);
                              return true;
                           }
                           break;
                        case 5:
                           ColorSetting colorSetting = (ColorSetting)setting;
                           if (this.handleSettingClick(setting, panel, moduleY, settingsX, mouseX, (double)adjustedSettingsMouseY)) {
                              return true;
                           }
                        }
                     }

                     label357: {
                        label358: {
                           if (setting instanceof ModeSetting) {
                              ModeSetting modeSetting = (ModeSetting)setting;
                              if (panel.getOpenModeSetting() == modeSetting) {
                                 break label358;
                              }
                           }

                           if (!(setting instanceof MultiSetting)) {
                              break label357;
                           }

                           MultiSetting multiSetting = (MultiSetting)setting;
                           if (panel.getOpenMultiSetting() != multiSetting) {
                              break label357;
                           }
                        }

                        float optionY = moduleY + 17.5F;
                        List<String> modes = setting instanceof ModeSetting ? ((ModeSetting)setting).getModes() : ((MultiSetting)setting).getModes();

                        for(Iterator var49 = modes.iterator(); var49.hasNext(); optionY += 15.5F) {
                           String mode = (String)var49.next();
                           if (mouseX >= (double)(settingsX + 6.0F) && mouseX <= (double)(settingsX + 120.0F - 6.0F) && adjustedSettingsMouseY >= optionY && adjustedSettingsMouseY <= optionY + 17.5F - 2.0F && mouseY >= (double)(pos.method_32119() + 17.5F + 2.0F) && mouseY <= (double)(pos.method_32119() + panel.getCurrentHeight())) {
                              if (setting instanceof ModeSetting) {
                                 ModeSetting modeSetting2 = (ModeSetting)setting;
                                 modeSetting2.setValue(mode);
                              } else if (setting instanceof MultiSetting) {
                                 MultiSetting multiSetting2 = (MultiSetting)setting;
                                 if (multiSetting2.getSpecificValue(mode)) {
                                    multiSetting2.deselectMode(mode);
                                 } else {
                                    multiSetting2.selectMode(mode);
                                 }
                              }

                              return true;
                           }
                        }
                     }

                     padding = !(setting instanceof NumberSetting) && !(setting instanceof RangeSetting) ? 0.0F : 2.0F;
                  }
               }
            }
         }
      } else if (button == 1) {
         var36 = this.panels.values().iterator();

         while(true) {
            while(true) {
               do {
                  if (!var36.hasNext()) {
                     return super.method_25402(mouseX, mouseY, button);
                  }

                  panel = (RemnantScreen.Panel)var36.next();
                  pos = panel.getPosition();
                  if (mouseX >= (double)pos.method_32118() && mouseX <= (double)(pos.method_32118() + 120.0F) && mouseY >= (double)pos.method_32119() && mouseY <= (double)(pos.method_32119() + 17.5F)) {
                     panel.setOpen(!panel.isOpen());
                     if (!panel.isOpen()) {
                        panel.setShowingSettings(false);
                        if (this.selectedPanel == panel) {
                           this.selectedModule = null;
                           this.selectedPanel = null;
                        }
                     }

                     return true;
                  }
               } while(!panel.isOpen());

               moduleY = pos.method_32119() + 17.5F + 2.0F;
               adjustedMouseY = -panel.getSettingsAnimationProgress() * 120.0F;
               moduleXOffset = (float)mouseY + panel.getModuleScrollOffset();
               if (panel.isShowingSettings() && this.selectedModule != null && this.selectedPanel == panel) {
                  settingsX = (1.0F - panel.getSettingsAnimationProgress()) * 120.0F;
                  adjustedSettingsMouseY = pos.method_32118() + settingsX;
                  if (mouseX >= (double)adjustedSettingsMouseY && mouseX <= (double)(adjustedSettingsMouseY + 120.0F) && mouseY >= (double)moduleY && mouseY <= (double)(moduleY + 17.5F)) {
                     panel.setShowingSettings(false);
                     panel.lastSettingsAnimationTime = System.currentTimeMillis();
                     this.selectedModule = null;
                     this.selectedPanel = null;
                     return true;
                  }
               } else {
                  for(var39 = panel.getModules().iterator(); var39.hasNext(); moduleY += 19.5F) {
                     module = (Module)var39.next();
                     if (mouseX >= (double)(pos.method_32118() + adjustedMouseY) && mouseX <= (double)(pos.method_32118() + 120.0F + adjustedMouseY) && moduleXOffset >= moduleY && moduleXOffset <= moduleY + 17.5F && mouseY >= (double)(pos.method_32119() + 17.5F + 2.0F) && mouseY <= (double)(pos.method_32119() + panel.getCurrentHeight()) && !module.getSettingRepository().getSettings().isEmpty()) {
                        Iterator var41 = this.panels.values().iterator();

                        while(var41.hasNext()) {
                           RemnantScreen.Panel otherPanel = (RemnantScreen.Panel)var41.next();
                           if (otherPanel != panel) {
                              otherPanel.setShowingSettings(false);
                           }
                        }

                        panel.setShowingSettings(true);
                        panel.lastSettingsAnimationTime = System.currentTimeMillis();
                        this.selectedModule = module;
                        this.selectedPanel = panel;
                        return true;
                     }
                  }
               }
            }
         }
      } else {
         return super.method_25402(mouseX, mouseY, button);
      }
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      if (button == 0) {
         Iterator var6 = this.panels.values().iterator();

         while(true) {
            if (!var6.hasNext()) {
               if (this.draggingNumberSetting != null || this.draggingRangeSetting != null) {
                  this.draggingNumberSetting = null;
                  this.draggingRangeSetting = null;
                  return true;
               }
               break;
            }

            RemnantScreen.Panel panel = (RemnantScreen.Panel)var6.next();
            if (panel.isDragging()) {
               panel.setDragging(false);
               return true;
            }
         }
      }

      this.draggedColorSetting = null;
      this.draggingHue = false;
      this.draggingAlpha = false;
      this.draggingSaturationBrightness = false;
      return super.method_25406(mouseX, mouseY, button);
   }

   public void method_25419() {
      ((ClickGUI)Chorus.getInstance().getModuleManager().getModule(ClickGUI.class)).onDisable();
      super.method_25419();
   }

   public void method_49589() {
      Iterator var1 = this.panels.values().iterator();

      while(var1.hasNext()) {
         RemnantScreen.Panel panel = (RemnantScreen.Panel)var1.next();
         panel.setCurrentHeight(0.0F);
         panel.updateHeight(panel.isOpen() ? 17.5F + 19.5F * (float)panel.getModules().size() + 2.0F : 19.5F);
         panel.lastHeightAnimationTime = System.currentTimeMillis();
         panel.animationProgress = 0.0F;
         Iterator var3 = panel.booleanAnimations.keySet().iterator();

         while(var3.hasNext()) {
            BooleanSetting setting = (BooleanSetting)var3.next();
            panel.booleanAnimations.put(setting, setting.getValue() ? 1.0F : 0.0F);
            panel.booleanAnimationTimes.put(setting, System.currentTimeMillis());
         }

         var3 = panel.modeAnimations.keySet().iterator();

         while(var3.hasNext()) {
            ModeSetting setting = (ModeSetting)var3.next();
            panel.modeAnimations.put(setting, panel.getOpenModeSetting() == setting ? 1.0F : 0.0F);
            panel.modeAnimationTimes.put(setting, System.currentTimeMillis());
         }

         var3 = panel.multiAnimations.keySet().iterator();

         while(var3.hasNext()) {
            MultiSetting setting = (MultiSetting)var3.next();
            panel.multiAnimations.put(setting, panel.getOpenMultiSetting() == setting ? 1.0F : 0.0F);
            panel.multiAnimationTimes.put(setting, System.currentTimeMillis());
         }

         var3 = panel.numberAnimations.keySet().iterator();

         double minProgress;
         while(var3.hasNext()) {
            NumberSetting<?> setting = (NumberSetting)var3.next();
            minProgress = (setting.getValue().doubleValue() - setting.getMinValue().doubleValue()) / (setting.getMaxValue().doubleValue() - setting.getMinValue().doubleValue());
            panel.numberAnimations.put(setting, (float)minProgress);
            panel.numberAnimationTimes.put(setting, System.currentTimeMillis());
         }

         var3 = panel.rangeAnimations.keySet().iterator();

         while(var3.hasNext()) {
            RangeSetting<?> setting = (RangeSetting)var3.next();
            minProgress = (setting.getValueMin().doubleValue() - setting.getMin().doubleValue()) / (setting.getMax().doubleValue() - setting.getMin().doubleValue());
            double maxProgress = (setting.getValueMax().doubleValue() - setting.getMin().doubleValue()) / (setting.getMax().doubleValue() - setting.getMin().doubleValue());
            panel.rangeAnimations.put(setting, new Float[]{(float)minProgress, (float)maxProgress});
            panel.rangeAnimationTimes.put(setting, System.currentTimeMillis());
         }
      }

   }

   public boolean method_25421() {
      return false;
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      float settingsX;
      float moduleY;
      float range;
      class_5611 pos;
      float settingsOffset;
      if (button == 0) {
         Iterator var10 = this.panels.values().iterator();

         while(var10.hasNext()) {
            RemnantScreen.Panel panel = (RemnantScreen.Panel)var10.next();
            if (panel.isDragging()) {
               panel.updatePosition(mouseX, mouseY);
               return true;
            }
         }

         float totalWidth;
         float percentage;
         if (this.draggingNumberSetting != null) {
            pos = this.selectedPanel.getPosition();
            settingsOffset = (1.0F - this.selectedPanel.getSettingsAnimationProgress()) * 120.0F;
            settingsX = pos.method_32118() + settingsOffset;
            moduleY = (float)(mouseX - (double)(settingsX + 6.0F));
            totalWidth = 108.0F;
            percentage = Math.max(0.0F, Math.min(1.0F, moduleY / totalWidth));
            range = this.draggingNumberSetting.getMaxValue().floatValue() - this.draggingNumberSetting.getMinValue().floatValue();
            float newValue = this.draggingNumberSetting.getMinValue().floatValue() + range * percentage;
            NumberSetting doubleSetting;
            if (this.draggingNumberSetting.getValue() instanceof Integer) {
               doubleSetting = this.draggingNumberSetting;
               doubleSetting.setValue((Number)Math.round(newValue));
            } else if (this.draggingNumberSetting.getValue() instanceof Float) {
               doubleSetting = this.draggingNumberSetting;
               doubleSetting.setValue((Number)newValue);
            } else if (this.draggingNumberSetting.getValue() instanceof Double) {
               doubleSetting = this.draggingNumberSetting;
               doubleSetting.setValue((Number)((double)newValue));
            }

            return true;
         }

         if (this.draggingRangeSetting != null) {
            pos = this.selectedPanel.getPosition();
            settingsOffset = (1.0F - this.selectedPanel.getSettingsAnimationProgress()) * 120.0F;
            settingsX = pos.method_32118() + settingsOffset;
            moduleY = (float)(mouseX - (double)(settingsX + 6.0F));
            totalWidth = 108.0F;
            percentage = Math.max(0.0F, Math.min(1.0F, moduleY / totalWidth));
            range = this.draggingRangeSetting.getMax().floatValue() - this.draggingRangeSetting.getMin().floatValue();
            Object newValue;
            if (this.draggingRangeSetting.getMin() instanceof Double) {
               newValue = this.draggingRangeSetting.getMin().doubleValue() + (double)(range * percentage);
            } else if (this.draggingRangeSetting.getMin() instanceof Float) {
               newValue = this.draggingRangeSetting.getMin().floatValue() + range * percentage;
            } else if (this.draggingRangeSetting.getMin() instanceof Integer) {
               newValue = (int)((float)this.draggingRangeSetting.getMin().intValue() + range * percentage);
            } else {
               newValue = this.draggingRangeSetting.getMin().floatValue() + range * percentage;
            }

            Number[] currentValues = this.draggingRangeSetting.getValue();
            if (this.draggingRangeMin) {
               if (((Number)newValue).floatValue() <= currentValues[1].floatValue()) {
                  this.draggingRangeSetting.setValue(new Number[]{(Number)newValue, currentValues[1]});
               }
            } else if (((Number)newValue).floatValue() >= currentValues[0].floatValue()) {
               this.draggingRangeSetting.setValue(new Number[]{currentValues[0], (Number)newValue});
            }

            return true;
         }
      }

      if (this.draggedColorSetting != null && this.selectedPanel != null && this.selectedModule != null) {
         pos = this.selectedPanel.getPosition();
         settingsOffset = (1.0F - this.selectedPanel.getSettingsAnimationProgress()) * 120.0F;
         settingsX = pos.method_32118() + settingsOffset;
         moduleY = pos.method_32119() + 17.5F + 2.0F;
         moduleY += 21.5F;
         Iterator var14 = this.selectedModule.getSettingRepository().getSettings().values().iterator();

         while(var14.hasNext()) {
            Setting<?> setting = (Setting)var14.next();
            if (!(setting instanceof SettingCategory)) {
               if (setting == this.draggedColorSetting) {
                  range = moduleY + 17.5F;
                  this.updateColorSetting(mouseX, mouseY, settingsX, range);
                  break;
               }

               range = !(setting instanceof NumberSetting) && !(setting instanceof RangeSetting) ? 0.0F : 2.0F;
               moduleY += this.getSettingHeight(setting, this.selectedPanel) + range;
            }
         }

         return true;
      } else {
         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   private boolean handleSettingClick(Setting<?> setting, RemnantScreen.Panel panel, float moduleY, float settingsX, double mouseX, double mouseY) {
      if (setting instanceof ColorSetting) {
         ColorSetting colorSetting = (ColorSetting)setting;
         float toggleY = moduleY + 4.25F;
         float targetHeight;
         if (mouseX >= (double)(settingsX + 120.0F - 18.0F - 6.0F - 2.0F) && mouseX <= (double)(settingsX + 120.0F - 6.0F - 2.0F) && mouseY >= (double)toggleY && mouseY <= (double)(toggleY + 9.0F)) {
            boolean newExpandedState = !(Boolean)panel.colorSettingExpanded.getOrDefault(colorSetting, false);
            panel.colorSettingExpanded.put(colorSetting, newExpandedState);
            panel.colorAnimationTimes.put(colorSetting, System.currentTimeMillis());
            panel.colorAnimations.put(colorSetting, newExpandedState ? 0.0F : 1.0F);
            if (this.selectedModule != null && this.selectedPanel == panel) {
               targetHeight = 17.5F;
               targetHeight += 19.5F;
               List<Setting<?>> settings = new ArrayList();
               Iterator var14 = this.selectedModule.getSettingRepository().getSettings().values().iterator();

               Setting s;
               while(var14.hasNext()) {
                  s = (Setting)var14.next();
                  if (!(s instanceof SettingCategory)) {
                     settings.add(s);
                  }
               }

               targetHeight += 19.5F * (float)settings.size() + 6.0F;

               float extraHeight;
               float padding;
               for(var14 = settings.iterator(); var14.hasNext(); targetHeight += extraHeight + padding - 2.0F) {
                  s = (Setting)var14.next();
                  extraHeight = this.getSettingHeight(s, panel) - 17.5F;
                  padding = !(s instanceof NumberSetting) && !(s instanceof RangeSetting) ? 0.0F : 2.0F;
               }

               targetHeight += 2.0F;
               panel.updateHeight(targetHeight);
            }

            return true;
         }

         if ((Boolean)panel.colorSettingExpanded.getOrDefault(colorSetting, false)) {
            float baseY = moduleY + 17.5F;
            if (mouseY >= (double)baseY && mouseY <= (double)(baseY + 60.0F)) {
               this.draggedColorSetting = colorSetting;
               this.draggingSaturationBrightness = true;
               this.updateColorSetting(mouseX, mouseY, settingsX, baseY);
               return true;
            }

            targetHeight = baseY + 65.0F;
            if (mouseY >= (double)targetHeight && mouseY <= (double)(targetHeight + 5.0F)) {
               this.draggedColorSetting = colorSetting;
               this.draggingHue = true;
               this.updateColorSetting(mouseX, mouseY, settingsX, baseY);
               return true;
            }

            float alphaSliderY = targetHeight + 10.0F;
            if (mouseY >= (double)alphaSliderY && mouseY <= (double)(alphaSliderY + 5.0F)) {
               this.draggedColorSetting = colorSetting;
               this.draggingAlpha = true;
               this.updateColorSetting(mouseX, mouseY, settingsX, baseY);
               return true;
            }
         }
      }

      return false;
   }

   private void updateColorSetting(double mouseX, double mouseY, float settingsX, float baseY) {
      if (this.draggedColorSetting != null) {
         double constrainedMouseX = Math.max((double)(settingsX + 6.0F), Math.min((double)(settingsX + 120.0F - 6.0F), mouseX));
         int red = this.draggedColorSetting.getRed();
         int green = this.draggedColorSetting.getGreen();
         int blue = this.draggedColorSetting.getBlue();
         float[] hsb = Color.RGBtoHSB(red, green, blue, (float[])null);
         float alpha;
         if (this.draggingSaturationBrightness) {
            alpha = Math.max(0.0F, Math.min(1.0F, (float)(constrainedMouseX - (double)(settingsX + 6.0F)) / 108.0F));
            double constrainedMouseY = Math.max((double)baseY, Math.min((double)(baseY + 60.0F), mouseY));
            float brightness = Math.max(0.0F, Math.min(1.0F, 1.0F - (float)(constrainedMouseY - (double)baseY) / 60.0F));
            Color newColor = Color.getHSBColor(hsb[0], alpha, brightness);
            this.draggedColorSetting.setColor(newColor.getRed(), newColor.getGreen(), newColor.getBlue(), this.draggedColorSetting.getAlpha());
         }

         if (this.draggingHue) {
            alpha = Math.max(0.0F, Math.min(1.0F, (float)(constrainedMouseX - (double)(settingsX + 6.0F)) / 108.0F));
            Color newColor = Color.getHSBColor(alpha, hsb[1], hsb[2]);
            this.draggedColorSetting.setColor(newColor.getRed(), newColor.getGreen(), newColor.getBlue(), this.draggedColorSetting.getAlpha());
         }

         if (this.draggingAlpha) {
            alpha = Math.max(0.0F, Math.min(1.0F, (float)(constrainedMouseX - (double)(settingsX + 6.0F)) / 108.0F));
            this.draggedColorSetting.setColor(red, green, blue, (int)(alpha * 255.0F));
         }

      }
   }

   private float easeInOutCubic(float t) {
      return (float)((double)t < 0.5D ? (double)(4.0F * t * t * t) : 1.0D - Math.pow((double)(-2.0F * t + 2.0F), 3.0D) / 2.0D);
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      Iterator var9 = this.panels.values().iterator();

      while(var9.hasNext()) {
         RemnantScreen.Panel panel = (RemnantScreen.Panel)var9.next();
         class_5611 pos = panel.getPosition();
         if (panel.isOpen() && mouseX >= (double)pos.method_32118() && mouseX <= (double)(pos.method_32118() + 120.0F) && mouseY >= (double)pos.method_32119() && mouseY <= (double)(pos.method_32119() + panel.getCurrentHeight())) {
            float newModuleScrollOffset;
            if (panel.isShowingSettings() && this.selectedModule != null && this.selectedPanel == panel) {
               newModuleScrollOffset = (1.0F - panel.getSettingsAnimationProgress()) * 120.0F;
               float settingsX = pos.method_32118() + newModuleScrollOffset;
               if (mouseX >= (double)settingsX && mouseX <= (double)(settingsX + 120.0F)) {
                  float newSettingScrollOffset = panel.settingScrollOffset - (float)(verticalAmount * 10.0D);
                  panel.settingScrollOffset = Math.max(0.0F, Math.min(panel.maxSettingScrollOffset, newSettingScrollOffset));
                  return true;
               }
            }

            if (panel.maxModuleScrollOffset > 0.0F) {
               newModuleScrollOffset = panel.getModuleScrollOffset() - (float)(verticalAmount * 10.0D);
               panel.setModuleScrollOffset(Math.max(0.0F, Math.min(panel.getMaxModuleScrollOffset(), newModuleScrollOffset)));
               return true;
            }
         }
      }

      return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
   }

   public static RemnantScreen getINSTANCE() {
      return INSTANCE;
   }

   public Module getSelectedModule() {
      return this.selectedModule;
   }

   public void setSelectedModule(Module selectedModule) {
      this.selectedModule = selectedModule;
   }

   public RemnantScreen.Panel getSelectedPanel() {
      return this.selectedPanel;
   }

   public void setSelectedPanel(RemnantScreen.Panel selectedPanel) {
      this.selectedPanel = selectedPanel;
   }

   @Environment(EnvType.CLIENT)
   class Panel {
      private final ModuleCategory category;
      private class_5611 position;
      private boolean isOpen;
      private boolean isDragging;
      private double dragX;
      private double dragY;
      private List<Module> modules;
      private boolean showingSettings;
      private MultiSetting openMultiSetting;
      private ModeSetting openModeSetting;
      private float settingsAnimationProgress = 0.0F;
      private long lastSettingsAnimationTime = 0L;
      private float currentHeight = 17.5F;
      private float targetHeight = 17.5F;
      private long lastHeightAnimationTime = System.currentTimeMillis();
      private float animationProgress = 0.0F;
      private float moduleScrollOffset = 0.0F;
      private float maxModuleScrollOffset = 0.0F;
      private float settingScrollOffset = 0.0F;
      private float maxSettingScrollOffset = 0.0F;
      private final Map<BooleanSetting, Float> booleanAnimations = new HashMap();
      private final Map<BooleanSetting, Long> booleanAnimationTimes = new HashMap();
      private final Map<ModeSetting, Float> modeAnimations = new HashMap();
      private final Map<ModeSetting, Long> modeAnimationTimes = new HashMap();
      private final Map<MultiSetting, Float> multiAnimations = new HashMap();
      private final Map<MultiSetting, Long> multiAnimationTimes = new HashMap();
      private final Map<NumberSetting<?>, Float> numberAnimations = new HashMap();
      private final Map<NumberSetting<?>, Long> numberAnimationTimes = new HashMap();
      private final Map<RangeSetting<?>, Float[]> rangeAnimations = new HashMap();
      private final Map<RangeSetting<?>, Long> rangeAnimationTimes = new HashMap();
      private final Map<ColorSetting, Float> colorAnimations = new HashMap();
      private final Map<ColorSetting, Long> colorAnimationTimes = new HashMap();
      private final Map<ColorSetting, Boolean> colorSettingExpanded = new HashMap();

      public Panel(final RemnantScreen this$0, ModuleCategory category, boolean isOpen, class_5611 position) {
         this.category = category;
         this.position = position;
         this.isOpen = isOpen;
         this.isDragging = false;
         this.showingSettings = false;
         this.openMultiSetting = null;
         this.openModeSetting = null;
         this.modules = new ArrayList();
         this.moduleScrollOffset = 0.0F;
         this.maxModuleScrollOffset = 0.0F;
         this.settingScrollOffset = 0.0F;
         this.maxSettingScrollOffset = 0.0F;
      }

      public void updateHeight(float newTargetHeight) {
         if (this.targetHeight != newTargetHeight) {
            this.targetHeight = newTargetHeight;
            this.lastHeightAnimationTime = System.currentTimeMillis();
            this.animationProgress = 0.0F;
         }

      }

      public void animateHeight() {
         if (this.currentHeight != this.targetHeight) {
            long currentTime = System.currentTimeMillis();
            float elapsed = Math.min(1.0F, (float)(currentTime - this.lastHeightAnimationTime) / 500.0F);
            this.lastHeightAnimationTime = currentTime;
            this.animationProgress = Math.min(1.0F, this.animationProgress + elapsed);
            float smoothProgress = (float)(1.0D - Math.pow((double)(1.0F - this.animationProgress), 3.0D));
            this.currentHeight += (this.targetHeight - this.currentHeight) * smoothProgress;
            if (Math.abs(this.currentHeight - this.targetHeight) < 0.01F) {
               this.currentHeight = this.targetHeight;
            }
         }

      }

      public void setShowingSettings(boolean showingSettings) {
         if (this.showingSettings != showingSettings) {
            this.showingSettings = showingSettings;
            this.lastSettingsAnimationTime = System.currentTimeMillis();
            this.animationProgress = 0.0F;
            this.lastHeightAnimationTime = System.currentTimeMillis();
            this.settingScrollOffset = 0.0F;
            this.maxSettingScrollOffset = 0.0F;
         }

      }

      public void startDragging(double mouseX, double mouseY) {
         this.isDragging = true;
         this.dragX = mouseX - (double)this.position.method_32118();
         this.dragY = mouseY - (double)this.position.method_32119();
      }

      public void updatePosition(double mouseX, double mouseY) {
         if (this.isDragging) {
            float newX = (float)(mouseX - this.dragX);
            float newY = (float)(mouseY - this.dragY);
            float screenWidth = (float)class_310.method_1551().method_22683().method_4486();
            float screenHeight = (float)class_310.method_1551().method_22683().method_4502();
            newX = Math.max(0.0F, Math.min(screenWidth - 120.0F, newX));
            newY = Math.max(0.0F, Math.min(screenHeight - 17.5F, newY));
            this.position = new class_5611(newX, newY);
         }

      }

      public ModuleCategory getCategory() {
         return this.category;
      }

      public class_5611 getPosition() {
         return this.position;
      }

      public double getDragX() {
         return this.dragX;
      }

      public double getDragY() {
         return this.dragY;
      }

      public List<Module> getModules() {
         return this.modules;
      }

      public long getLastSettingsAnimationTime() {
         return this.lastSettingsAnimationTime;
      }

      public float getTargetHeight() {
         return this.targetHeight;
      }

      public long getLastHeightAnimationTime() {
         return this.lastHeightAnimationTime;
      }

      public float getAnimationProgress() {
         return this.animationProgress;
      }

      public float getMaxModuleScrollOffset() {
         return this.maxModuleScrollOffset;
      }

      public float getSettingScrollOffset() {
         return this.settingScrollOffset;
      }

      public float getMaxSettingScrollOffset() {
         return this.maxSettingScrollOffset;
      }

      public Map<BooleanSetting, Float> getBooleanAnimations() {
         return this.booleanAnimations;
      }

      public Map<BooleanSetting, Long> getBooleanAnimationTimes() {
         return this.booleanAnimationTimes;
      }

      public Map<ModeSetting, Float> getModeAnimations() {
         return this.modeAnimations;
      }

      public Map<ModeSetting, Long> getModeAnimationTimes() {
         return this.modeAnimationTimes;
      }

      public Map<MultiSetting, Float> getMultiAnimations() {
         return this.multiAnimations;
      }

      public Map<MultiSetting, Long> getMultiAnimationTimes() {
         return this.multiAnimationTimes;
      }

      public Map<NumberSetting<?>, Float> getNumberAnimations() {
         return this.numberAnimations;
      }

      public Map<NumberSetting<?>, Long> getNumberAnimationTimes() {
         return this.numberAnimationTimes;
      }

      public Map<RangeSetting<?>, Float[]> getRangeAnimations() {
         return this.rangeAnimations;
      }

      public Map<RangeSetting<?>, Long> getRangeAnimationTimes() {
         return this.rangeAnimationTimes;
      }

      public Map<ColorSetting, Float> getColorAnimations() {
         return this.colorAnimations;
      }

      public Map<ColorSetting, Long> getColorAnimationTimes() {
         return this.colorAnimationTimes;
      }

      public Map<ColorSetting, Boolean> getColorSettingExpanded() {
         return this.colorSettingExpanded;
      }

      public void setOpen(boolean isOpen) {
         this.isOpen = isOpen;
      }

      public boolean isOpen() {
         return this.isOpen;
      }

      public void setDragging(boolean isDragging) {
         this.isDragging = isDragging;
      }

      public boolean isDragging() {
         return this.isDragging;
      }

      public void setModules(List<Module> modules) {
         this.modules = modules;
      }

      public boolean isShowingSettings() {
         return this.showingSettings;
      }

      public MultiSetting getOpenMultiSetting() {
         return this.openMultiSetting;
      }

      public void setOpenMultiSetting(MultiSetting openMultiSetting) {
         this.openMultiSetting = openMultiSetting;
      }

      public ModeSetting getOpenModeSetting() {
         return this.openModeSetting;
      }

      public void setOpenModeSetting(ModeSetting openModeSetting) {
         this.openModeSetting = openModeSetting;
      }

      public float getSettingsAnimationProgress() {
         return this.settingsAnimationProgress;
      }

      public void setSettingsAnimationProgress(float settingsAnimationProgress) {
         this.settingsAnimationProgress = settingsAnimationProgress;
      }

      public float getCurrentHeight() {
         return this.currentHeight;
      }

      public void setCurrentHeight(float currentHeight) {
         this.currentHeight = currentHeight;
      }

      public float getModuleScrollOffset() {
         return this.moduleScrollOffset;
      }

      public void setModuleScrollOffset(float moduleScrollOffset) {
         this.moduleScrollOffset = moduleScrollOffset;
      }
   }
}
