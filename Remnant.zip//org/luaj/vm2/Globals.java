package org.luaj.vm2;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.Reader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.lib.BaseLib;
import org.luaj.vm2.lib.DebugLib;
import org.luaj.vm2.lib.PackageLib;
import org.luaj.vm2.lib.ResourceFinder;

@Environment(EnvType.CLIENT)
public class Globals extends LuaTable {
   public InputStream STDIN = null;
   public PrintStream STDOUT;
   public PrintStream STDERR;
   public ResourceFinder finder;
   public LuaThread running;
   public BaseLib baselib;
   public PackageLib package_;
   public DebugLib debuglib;
   public Globals.Loader loader;
   public Globals.Compiler compiler;
   public Globals.Undumper undumper;

   public Globals() {
      this.STDOUT = System.out;
      this.STDERR = System.err;
      this.running = new LuaThread(this);
   }

   public Globals checkglobals() {
      return this;
   }

   public LuaValue loadfile(String filename) {
      try {
         return this.load(this.finder.findResource(filename), "@" + filename, "bt", this);
      } catch (Exception var3) {
         return error("load " + filename + ": " + String.valueOf(var3));
      }
   }

   public LuaValue load(String script, String chunkname) {
      return this.load((Reader)(new Globals.StrReader(script)), chunkname);
   }

   public LuaValue load(String script) {
      return this.load((Reader)(new Globals.StrReader(script)), script);
   }

   public LuaValue load(String script, String chunkname, LuaTable environment) {
      return this.load((Reader)(new Globals.StrReader(script)), chunkname, environment);
   }

   public LuaValue load(Reader reader, String chunkname) {
      return this.load(new Globals.UTF8Stream(reader), chunkname, "t", this);
   }

   public LuaValue load(Reader reader, String chunkname, LuaTable environment) {
      return this.load(new Globals.UTF8Stream(reader), chunkname, "t", environment);
   }

   public LuaValue load(InputStream is, String chunkname, String mode, LuaValue environment) {
      try {
         Prototype p = this.loadPrototype(is, chunkname, mode);
         return this.loader.load(p, chunkname, environment);
      } catch (LuaError var6) {
         throw var6;
      } catch (Exception var7) {
         return error("load " + chunkname + ": " + String.valueOf(var7));
      }
   }

   public Prototype loadPrototype(InputStream is, String chunkname, String mode) throws IOException {
      if (mode.indexOf(98) >= 0) {
         if (this.undumper == null) {
            error("No undumper.");
         }

         if (!((InputStream)is).markSupported()) {
            is = new Globals.BufferedStream((InputStream)is);
         }

         ((InputStream)is).mark(4);
         Prototype p = this.undumper.undump((InputStream)is, chunkname);
         if (p != null) {
            return p;
         }

         ((InputStream)is).reset();
      }

      if (mode.indexOf(116) >= 0) {
         return this.compilePrototype((InputStream)is, chunkname);
      } else {
         error("Failed to load prototype " + chunkname + " using mode '" + mode + "'");
         return null;
      }
   }

   public Prototype compilePrototype(Reader reader, String chunkname) throws IOException {
      return this.compilePrototype((InputStream)(new Globals.UTF8Stream(reader)), chunkname);
   }

   public Prototype compilePrototype(InputStream stream, String chunkname) throws IOException {
      if (this.compiler == null) {
         error("No compiler.");
      }

      return this.compiler.compile(stream, chunkname);
   }

   public Varargs yield(Varargs args) {
      if (this.running != null && !this.running.isMainThread()) {
         LuaThread.State s = this.running.state;
         return s.lua_yield(args);
      } else {
         throw new LuaError("cannot yield main thread");
      }
   }

   @Environment(EnvType.CLIENT)
   static class StrReader extends Reader {
      final String s;
      int i = 0;
      final int n;

      StrReader(String s) {
         this.s = s;
         this.n = s.length();
      }

      public void close() throws IOException {
         this.i = this.n;
      }

      public int read() throws IOException {
         return this.i < this.n ? this.s.charAt(this.i++) : -1;
      }

      public int read(char[] cbuf, int off, int len) throws IOException {
         int j;
         for(j = 0; j < len && this.i < this.n; ++this.i) {
            cbuf[off + j] = this.s.charAt(this.i);
            ++j;
         }

         return j <= 0 && len != 0 ? -1 : j;
      }
   }

   @Environment(EnvType.CLIENT)
   static class UTF8Stream extends Globals.AbstractBufferedStream {
      private final char[] c = new char[32];
      private final Reader r;

      UTF8Stream(Reader r) {
         super(96);
         this.r = r;
      }

      protected int avail() throws IOException {
         if (this.i < this.j) {
            return this.j - this.i;
         } else {
            int n = this.r.read(this.c);
            if (n < 0) {
               return -1;
            } else {
               if (n == 0) {
                  int u = this.r.read();
                  if (u < 0) {
                     return -1;
                  }

                  this.c[0] = (char)u;
                  n = 1;
               }

               this.j = LuaString.encodeToUtf8(this.c, n, this.b, this.i = 0);
               return this.j;
            }
         }
      }

      public void close() throws IOException {
         this.r.close();
      }
   }

   @Environment(EnvType.CLIENT)
   public interface Loader {
      LuaFunction load(Prototype var1, String var2, LuaValue var3) throws IOException;
   }

   @Environment(EnvType.CLIENT)
   public interface Undumper {
      Prototype undump(InputStream var1, String var2) throws IOException;
   }

   @Environment(EnvType.CLIENT)
   static class BufferedStream extends Globals.AbstractBufferedStream {
      private final InputStream s;

      public BufferedStream(InputStream s) {
         this(128, s);
      }

      BufferedStream(int buflen, InputStream s) {
         super(buflen);
         this.s = s;
      }

      protected int avail() throws IOException {
         if (this.i < this.j) {
            return this.j - this.i;
         } else {
            if (this.j >= this.b.length) {
               this.i = this.j = 0;
            }

            int n = this.s.read(this.b, this.j, this.b.length - this.j);
            if (n < 0) {
               return -1;
            } else {
               if (n == 0) {
                  int u = this.s.read();
                  if (u < 0) {
                     return -1;
                  }

                  this.b[this.j] = (byte)u;
                  n = 1;
               }

               this.j += n;
               return n;
            }
         }
      }

      public void close() throws IOException {
         this.s.close();
      }

      public synchronized void mark(int n) {
         if (this.i > 0 || n > this.b.length) {
            byte[] dest = n > this.b.length ? new byte[n] : this.b;
            System.arraycopy(this.b, this.i, dest, 0, this.j - this.i);
            this.j -= this.i;
            this.i = 0;
            this.b = dest;
         }

      }

      public boolean markSupported() {
         return true;
      }

      public synchronized void reset() throws IOException {
         this.i = 0;
      }
   }

   @Environment(EnvType.CLIENT)
   public interface Compiler {
      Prototype compile(InputStream var1, String var2) throws IOException;
   }

   @Environment(EnvType.CLIENT)
   abstract static class AbstractBufferedStream extends InputStream {
      protected byte[] b;
      protected int i = 0;
      protected int j = 0;

      protected AbstractBufferedStream(int buflen) {
         this.b = new byte[buflen];
      }

      protected abstract int avail() throws IOException;

      public int read() throws IOException {
         int a = this.avail();
         return a <= 0 ? -1 : 255 & this.b[this.i++];
      }

      public int read(byte[] b) throws IOException {
         return this.read(b, 0, b.length);
      }

      public int read(byte[] b, int i0, int n) throws IOException {
         int a = this.avail();
         if (a <= 0) {
            return -1;
         } else {
            int n_read = Math.min(a, n);
            System.arraycopy(this.b, this.i, b, i0, n_read);
            this.i += n_read;
            return n_read;
         }
      }

      public long skip(long n) throws IOException {
         long k = Math.min(n, (long)(this.j - this.i));
         this.i = (int)((long)this.i + k);
         return k;
      }

      public int available() throws IOException {
         return this.j - this.i;
      }
   }
}
