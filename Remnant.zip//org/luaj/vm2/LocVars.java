package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LocVars {
   public LuaString varname;
   public int startpc;
   public int endpc;

   public LocVars(LuaString varname, int startpc, int endpc) {
      this.varname = varname;
      this.startpc = startpc;
      this.endpc = endpc;
   }

   public String tojstring() {
      String var10000 = String.valueOf(this.varname);
      return var10000 + " " + this.startpc + "-" + this.endpc;
   }
}
