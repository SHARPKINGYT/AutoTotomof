package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class LuaBoolean extends LuaValue {
   static final LuaBoolean _TRUE = new LuaBoolean(true);
   static final LuaBoolean _FALSE = new LuaBoolean(false);
   public static LuaValue s_metatable;
   public final boolean v;

   LuaBoolean(boolean b) {
      this.v = b;
   }

   public int type() {
      return 1;
   }

   public String typename() {
      return "boolean";
   }

   public boolean isboolean() {
      return true;
   }

   public LuaValue not() {
      return this.v ? FALSE : LuaValue.TRUE;
   }

   public boolean booleanValue() {
      return this.v;
   }

   public boolean toboolean() {
      return this.v;
   }

   public String tojstring() {
      return this.v ? "true" : "false";
   }

   public boolean optboolean(boolean defval) {
      return this.v;
   }

   public boolean checkboolean() {
      return this.v;
   }

   public LuaValue getmetatable() {
      return s_metatable;
   }
}
