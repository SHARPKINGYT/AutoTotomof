package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LuaClosure extends LuaFunction {
   private static final UpValue[] NOUPVALUES = new UpValue[0];
   public final Prototype p;
   public UpValue[] upValues;
   final Globals globals;

   public LuaClosure(Prototype p, LuaValue env) {
      this.p = p;
      if (p.upvalues != null && p.upvalues.length != 0) {
         this.upValues = new UpValue[p.upvalues.length];
         this.upValues[0] = new UpValue(new LuaValue[]{env}, 0);
      } else {
         this.upValues = NOUPVALUES;
      }

      this.globals = env instanceof Globals ? (Globals)env : null;
   }

   public boolean isclosure() {
      return true;
   }

   public LuaClosure optclosure(LuaClosure defval) {
      return this;
   }

   public LuaClosure checkclosure() {
      return this;
   }

   public LuaValue getmetatable() {
      return s_metatable;
   }

   public String tojstring() {
      return "function: " + this.p.toString();
   }

   public final LuaValue call() {
      LuaValue[] stack = new LuaValue[this.p.maxstacksize];

      for(int i = 0; i < this.p.numparams; ++i) {
         stack[i] = NIL;
      }

      return this.execute(stack, NONE).arg1();
   }

   public final LuaValue call(LuaValue arg) {
      LuaValue[] stack = new LuaValue[this.p.maxstacksize];
      System.arraycopy(NILS, 0, stack, 0, this.p.maxstacksize);

      for(int i = 1; i < this.p.numparams; ++i) {
         stack[i] = NIL;
      }

      switch(this.p.numparams) {
      case 0:
         return this.execute(stack, arg).arg1();
      default:
         stack[0] = arg;
         return this.execute(stack, NONE).arg1();
      }
   }

   public final LuaValue call(LuaValue arg1, LuaValue arg2) {
      LuaValue[] stack = new LuaValue[this.p.maxstacksize];

      for(int i = 2; i < this.p.numparams; ++i) {
         stack[i] = NIL;
      }

      switch(this.p.numparams) {
      case 0:
         return this.execute(stack, (Varargs)(this.p.is_vararg != 0 ? varargsOf(arg1, arg2) : NONE)).arg1();
      case 1:
         stack[0] = arg1;
         return this.execute(stack, arg2).arg1();
      default:
         stack[0] = arg1;
         stack[1] = arg2;
         return this.execute(stack, NONE).arg1();
      }
   }

   public final LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
      LuaValue[] stack = new LuaValue[this.p.maxstacksize];

      for(int i = 3; i < this.p.numparams; ++i) {
         stack[i] = NIL;
      }

      switch(this.p.numparams) {
      case 0:
         return this.execute(stack, (Varargs)(this.p.is_vararg != 0 ? varargsOf(arg1, arg2, arg3) : NONE)).arg1();
      case 1:
         stack[0] = arg1;
         return this.execute(stack, (Varargs)(this.p.is_vararg != 0 ? varargsOf(arg2, arg3) : NONE)).arg1();
      case 2:
         stack[0] = arg1;
         stack[1] = arg2;
         return this.execute(stack, arg3).arg1();
      default:
         stack[0] = arg1;
         stack[1] = arg2;
         stack[2] = arg3;
         return this.execute(stack, NONE).arg1();
      }
   }

   public final Varargs invoke(Varargs varargs) {
      return this.onInvoke(varargs).eval();
   }

   public final Varargs onInvoke(Varargs varargs) {
      LuaValue[] stack = new LuaValue[this.p.maxstacksize];

      for(int i = 0; i < this.p.numparams; ++i) {
         stack[i] = varargs.arg(i + 1);
      }

      return this.execute(stack, (Varargs)(this.p.is_vararg != 0 ? varargs.subargs(this.p.numparams + 1) : NONE));
   }

   public Varargs execute(LuaValue[] stack, Varargs varargs) {
      int pc = 0;
      int top = 0;
      Varargs v = NONE;
      int[] code = this.p.code;
      LuaValue[] k = this.p.k;
      UpValue[] openups = this.p.p.length > 0 ? new UpValue[stack.length] : null;
      if (this.globals != null && this.globals.debuglib != null) {
         this.globals.debuglib.onCall(this, varargs, stack);
      }

      while(true) {
         boolean var24 = false;

         int m;
         Varargs var36;
         label1292: {
            TailcallVarargs var39;
            label1293: {
               label1294: {
                  label1295: {
                     label1296: {
                        LuaValue limit;
                        label1297: {
                           label1298: {
                              label1299: {
                                 try {
                                    label1393: {
                                       var24 = true;
                                       if (this.globals != null && this.globals.debuglib != null) {
                                          this.globals.debuglib.onInstruction(pc, (Varargs)v, top);
                                       }

                                       int i = code[pc];
                                       int a = i >> 6 & 255;
                                       int b;
                                       int c;
                                       LuaValue o;
                                       int offset;
                                       Varargs v;
                                       label1265:
                                       switch(i & 63) {
                                       case 0:
                                          stack[a] = stack[i >>> 23];
                                          break;
                                       case 1:
                                          stack[a] = k[i >>> 14];
                                          break;
                                       case 2:
                                       default:
                                          throw new IllegalArgumentException("Illegal opcode: " + (i & 63));
                                       case 3:
                                          stack[a] = i >>> 23 != 0 ? LuaValue.TRUE : LuaValue.FALSE;
                                          if ((i & 8372224) != 0) {
                                             ++pc;
                                          }
                                          break;
                                       case 4:
                                          b = i >>> 23;

                                          while(true) {
                                             if (b-- < 0) {
                                                break label1265;
                                             }

                                             stack[a++] = LuaValue.NIL;
                                          }
                                       case 5:
                                          stack[a] = this.upValues[i >>> 23].getValue();
                                          break;
                                       case 6:
                                          stack[a] = this.upValues[i >>> 23].getValue().get((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 7:
                                          stack[a] = stack[i >>> 23].get((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 8:
                                          this.upValues[a].getValue().set((b = i >>> 23) > 255 ? k[b & 255] : stack[b], (c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 9:
                                          this.upValues[i >>> 23].setValue(stack[a]);
                                          break;
                                       case 10:
                                          stack[a].set((b = i >>> 23) > 255 ? k[b & 255] : stack[b], (c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 11:
                                          stack[a] = new LuaTable(i >>> 23, i >> 14 & 511);
                                          break;
                                       case 12:
                                          stack[a + 1] = o = stack[i >>> 23];
                                          stack[a] = o.get((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 13:
                                          stack[a] = ((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).add((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 14:
                                          stack[a] = ((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).sub((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 15:
                                          stack[a] = ((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).mul((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 16:
                                          stack[a] = ((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).div((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 17:
                                          stack[a] = ((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).mod((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 18:
                                          stack[a] = ((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).pow((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]);
                                          break;
                                       case 19:
                                          stack[a] = stack[i >>> 23].neg();
                                          break;
                                       case 20:
                                          stack[a] = stack[i >>> 23].not();
                                          break;
                                       case 21:
                                          stack[a] = stack[i >>> 23].len();
                                          break;
                                       case 22:
                                          b = i >>> 23;
                                          c = i >> 14 & 511;
                                          if (c > b + 1) {
                                             Buffer sb = stack[c].buffer();

                                             while(true) {
                                                --c;
                                                if (c < b) {
                                                   stack[a] = sb.value();
                                                   break label1265;
                                                }

                                                sb = stack[c].concat(sb);
                                             }
                                          } else {
                                             stack[a] = stack[c - 1].concat(stack[c]);
                                             break;
                                          }
                                       case 23:
                                          pc += (i >>> 14) - 131071;
                                          if (a > 0) {
                                             --a;
                                             b = openups.length;

                                             while(true) {
                                                --b;
                                                if (b < 0) {
                                                   break;
                                                }

                                                if (openups[b] != null && openups[b].index >= a) {
                                                   openups[b].close();
                                                   openups[b] = null;
                                                }
                                             }
                                          }
                                          break;
                                       case 24:
                                          if (((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).eq_b((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]) == (a == 0)) {
                                             ++pc;
                                          }
                                          break;
                                       case 25:
                                          if (((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).lt_b((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]) == (a == 0)) {
                                             ++pc;
                                          }
                                          break;
                                       case 26:
                                          if (((b = i >>> 23) > 255 ? k[b & 255] : stack[b]).lteq_b((c = i >> 14 & 511) > 255 ? k[c & 255] : stack[c]) != (a != 0)) {
                                             ++pc;
                                          }
                                          break;
                                       case 27:
                                          if (stack[a].toboolean() != ((i & 8372224) != 0)) {
                                             ++pc;
                                          }
                                          break;
                                       case 28:
                                          if ((o = stack[i >>> 23]).toboolean() != ((i & 8372224) != 0)) {
                                             ++pc;
                                          } else {
                                             stack[a] = o;
                                          }
                                          break;
                                       case 29:
                                          switch(i & -16384) {
                                          case 8388608:
                                             v = stack[a].invoke((Varargs)NONE);
                                             top = a + ((Varargs)v).narg();
                                             break label1265;
                                          case 8404992:
                                             stack[a].call();
                                             break label1265;
                                          case 8421376:
                                             stack[a] = stack[a].call();
                                             break label1265;
                                          case 16777216:
                                             v = stack[a].invoke((Varargs)stack[a + 1]);
                                             top = a + ((Varargs)v).narg();
                                             break label1265;
                                          case 16793600:
                                             stack[a].call(stack[a + 1]);
                                             break label1265;
                                          case 16809984:
                                             stack[a] = stack[a].call(stack[a + 1]);
                                             break label1265;
                                          case 25182208:
                                             stack[a].call(stack[a + 1], stack[a + 2]);
                                             break label1265;
                                          case 25198592:
                                             stack[a] = stack[a].call(stack[a + 1], stack[a + 2]);
                                             break label1265;
                                          case 33570816:
                                             stack[a].call(stack[a + 1], stack[a + 2], stack[a + 3]);
                                             break label1265;
                                          case 33587200:
                                             stack[a] = stack[a].call(stack[a + 1], stack[a + 2], stack[a + 3]);
                                             break label1265;
                                          default:
                                             b = i >>> 23;
                                             c = i >> 14 & 511;
                                             v = stack[a].invoke(b > 0 ? varargsOf(stack, a + 1, b - 1) : varargsOf(stack, a + 1, top - ((Varargs)v).narg() - (a + 1), (Varargs)v));
                                             if (c > 0) {
                                                v.copyto(stack, a, c - 1);
                                                v = NONE;
                                             } else {
                                                top = a + v.narg();
                                                v = v.dealias();
                                             }
                                             break label1265;
                                          }
                                       case 30:
                                          switch(i & -8388608) {
                                          case 8388608:
                                             var39 = new TailcallVarargs(stack[a], NONE);
                                             var24 = false;
                                             break label1293;
                                          case 16777216:
                                             var39 = new TailcallVarargs(stack[a], stack[a + 1]);
                                             var24 = false;
                                             break label1393;
                                          case 25165824:
                                             var39 = new TailcallVarargs(stack[a], varargsOf(stack[a + 1], stack[a + 2]));
                                             var24 = false;
                                             break label1298;
                                          case 33554432:
                                             var39 = new TailcallVarargs(stack[a], varargsOf(stack[a + 1], stack[a + 2], stack[a + 3]));
                                             var24 = false;
                                             break label1296;
                                          default:
                                             b = i >>> 23;
                                             v = b > 0 ? varargsOf(stack, a + 1, b - 1) : varargsOf(stack, a + 1, top - ((Varargs)v).narg() - (a + 1), (Varargs)v);
                                             var39 = new TailcallVarargs(stack[a], v);
                                             var24 = false;
                                             break label1295;
                                          }
                                       case 31:
                                          b = i >>> 23;
                                          switch(b) {
                                          case 0:
                                             var36 = varargsOf(stack, a, top - ((Varargs)v).narg() - a, (Varargs)v);
                                             var24 = false;
                                             break label1292;
                                          case 1:
                                             limit = NONE;
                                             var24 = false;
                                             break label1299;
                                          case 2:
                                             limit = stack[a];
                                             var24 = false;
                                             break label1297;
                                          default:
                                             var36 = varargsOf(stack, a, b - 1);
                                             var24 = false;
                                             break label1294;
                                          }
                                       case 32:
                                          limit = stack[a + 1];
                                          LuaValue step = stack[a + 2];
                                          LuaValue idx = step.add(stack[a]);
                                          if (step.gt_b(0)) {
                                             if (!idx.lteq_b(limit)) {
                                                break;
                                             }
                                          } else if (!idx.gteq_b(limit)) {
                                             break;
                                          }

                                          stack[a] = idx;
                                          stack[a + 3] = idx;
                                          pc += (i >>> 14) - 131071;
                                          break;
                                       case 33:
                                          LuaValue init = stack[a].checknumber("'for' initial value must be a number");
                                          LuaValue limit = stack[a + 1].checknumber("'for' limit must be a number");
                                          LuaValue step = stack[a + 2].checknumber("'for' step must be a number");
                                          stack[a] = init.sub(step);
                                          stack[a + 1] = limit;
                                          stack[a + 2] = step;
                                          pc += (i >>> 14) - 131071;
                                          break;
                                       case 34:
                                          v = stack[a].invoke(varargsOf(stack[a + 1], stack[a + 2]));
                                          c = i >> 14 & 511;

                                          while(true) {
                                             --c;
                                             if (c < 0) {
                                                v = NONE;
                                                break label1265;
                                             }

                                             stack[a + 3 + c] = v.arg(c + 1);
                                          }
                                       case 35:
                                          if (!stack[a + 1].isnil()) {
                                             stack[a] = stack[a + 1];
                                             pc += (i >>> 14) - 131071;
                                          }
                                          break;
                                       case 36:
                                          if ((c = i >> 14 & 511) == 0) {
                                             ++pc;
                                             c = code[pc];
                                          }

                                          offset = (c - 1) * 50;
                                          o = stack[a];
                                          if ((b = i >>> 23) == 0) {
                                             b = top - a - 1;
                                             m = b - ((Varargs)v).narg();

                                             int j;
                                             for(j = 1; j <= m; ++j) {
                                                o.set(offset + j, stack[a + j]);
                                             }

                                             while(true) {
                                                if (j > b) {
                                                   break label1265;
                                                }

                                                o.set(offset + j, ((Varargs)v).arg(j - m));
                                                ++j;
                                             }
                                          } else {
                                             o.presize(offset + b);
                                             m = 1;

                                             while(true) {
                                                if (m > b) {
                                                   break label1265;
                                                }

                                                o.set(offset + m, stack[a + m]);
                                                ++m;
                                             }
                                          }
                                       case 37:
                                          Prototype newp = this.p.p[i >>> 14];
                                          LuaClosure ncl = new LuaClosure(newp, this.globals);
                                          Upvaldesc[] uv = newp.upvalues;
                                          int j = 0;

                                          for(int nup = uv.length; j < nup; ++j) {
                                             if (uv[j].instack) {
                                                ncl.upValues[j] = this.findupval(stack, uv[j].idx, openups);
                                             } else {
                                                ncl.upValues[j] = this.upValues[uv[j].idx];
                                             }
                                          }

                                          stack[a] = ncl;
                                          break;
                                       case 38:
                                          b = i >>> 23;
                                          if (b == 0) {
                                             top = a + varargs.narg();
                                             v = varargs;
                                             break;
                                          } else {
                                             offset = 1;

                                             while(true) {
                                                if (offset >= b) {
                                                   break label1265;
                                                }

                                                stack[a + offset - 1] = varargs.arg(offset);
                                                ++offset;
                                             }
                                          }
                                       case 39:
                                          throw new IllegalArgumentException("Uexecutable opcode: OP_EXTRAARG");
                                       }

                                       ++pc;
                                       continue;
                                    }
                                 } catch (LuaError var25) {
                                    if (var25.traceback == null) {
                                       this.processErrorHooks(var25, this.p, pc);
                                    }

                                    throw var25;
                                 } catch (Exception var26) {
                                    LuaError le = new LuaError(var26);
                                    this.processErrorHooks(le, this.p, pc);
                                    throw le;
                                 } finally {
                                    if (var24) {
                                       if (openups != null) {
                                          int u = openups.length;

                                          while(true) {
                                             --u;
                                             if (u < 0) {
                                                break;
                                             }

                                             if (openups[u] != null) {
                                                openups[u].close();
                                             }
                                          }
                                       }

                                       if (this.globals != null && this.globals.debuglib != null) {
                                          this.globals.debuglib.onReturn();
                                       }

                                    }
                                 }

                                 if (openups != null) {
                                    m = openups.length;

                                    while(true) {
                                       --m;
                                       if (m < 0) {
                                          break;
                                       }

                                       if (openups[m] != null) {
                                          openups[m].close();
                                       }
                                    }
                                 }

                                 if (this.globals != null && this.globals.debuglib != null) {
                                    this.globals.debuglib.onReturn();
                                 }

                                 return var39;
                              }

                              if (openups != null) {
                                 m = openups.length;

                                 while(true) {
                                    --m;
                                    if (m < 0) {
                                       break;
                                    }

                                    if (openups[m] != null) {
                                       openups[m].close();
                                    }
                                 }
                              }

                              if (this.globals != null && this.globals.debuglib != null) {
                                 this.globals.debuglib.onReturn();
                              }

                              return limit;
                           }

                           if (openups != null) {
                              m = openups.length;

                              while(true) {
                                 --m;
                                 if (m < 0) {
                                    break;
                                 }

                                 if (openups[m] != null) {
                                    openups[m].close();
                                 }
                              }
                           }

                           if (this.globals != null && this.globals.debuglib != null) {
                              this.globals.debuglib.onReturn();
                           }

                           return var39;
                        }

                        if (openups != null) {
                           m = openups.length;

                           while(true) {
                              --m;
                              if (m < 0) {
                                 break;
                              }

                              if (openups[m] != null) {
                                 openups[m].close();
                              }
                           }
                        }

                        if (this.globals != null && this.globals.debuglib != null) {
                           this.globals.debuglib.onReturn();
                        }

                        return limit;
                     }

                     if (openups != null) {
                        m = openups.length;

                        while(true) {
                           --m;
                           if (m < 0) {
                              break;
                           }

                           if (openups[m] != null) {
                              openups[m].close();
                           }
                        }
                     }

                     if (this.globals != null && this.globals.debuglib != null) {
                        this.globals.debuglib.onReturn();
                     }

                     return var39;
                  }

                  if (openups != null) {
                     m = openups.length;

                     while(true) {
                        --m;
                        if (m < 0) {
                           break;
                        }

                        if (openups[m] != null) {
                           openups[m].close();
                        }
                     }
                  }

                  if (this.globals != null && this.globals.debuglib != null) {
                     this.globals.debuglib.onReturn();
                  }

                  return var39;
               }

               if (openups != null) {
                  m = openups.length;

                  while(true) {
                     --m;
                     if (m < 0) {
                        break;
                     }

                     if (openups[m] != null) {
                        openups[m].close();
                     }
                  }
               }

               if (this.globals != null && this.globals.debuglib != null) {
                  this.globals.debuglib.onReturn();
               }

               return var36;
            }

            if (openups != null) {
               m = openups.length;

               while(true) {
                  --m;
                  if (m < 0) {
                     break;
                  }

                  if (openups[m] != null) {
                     openups[m].close();
                  }
               }
            }

            if (this.globals != null && this.globals.debuglib != null) {
               this.globals.debuglib.onReturn();
            }

            return var39;
         }

         if (openups != null) {
            m = openups.length;

            while(true) {
               --m;
               if (m < 0) {
                  break;
               }

               if (openups[m] != null) {
                  openups[m].close();
               }
            }
         }

         if (this.globals != null && this.globals.debuglib != null) {
            this.globals.debuglib.onReturn();
         }

         return var36;
      }
   }

   String errorHook(String msg, int level) {
      if (this.globals == null) {
         return msg;
      } else {
         LuaThread r = this.globals.running;
         if (r.errorfunc == null) {
            return this.globals.debuglib != null ? msg + "\n" + this.globals.debuglib.traceback(level) : msg;
         } else {
            LuaValue e = r.errorfunc;
            r.errorfunc = null;

            String var6;
            try {
               String var5 = e.call((LuaValue)LuaValue.valueOf(msg)).tojstring();
               return var5;
            } catch (Throwable var10) {
               var6 = "error in error handling";
            } finally {
               r.errorfunc = e;
            }

            return var6;
         }
      }
   }

   private void processErrorHooks(LuaError le, Prototype p, int pc) {
      String var10001 = p.source != null ? p.source.tojstring() : "?";
      le.fileline = var10001 + ":" + (p.lineinfo != null && pc >= 0 && pc < p.lineinfo.length ? String.valueOf(p.lineinfo[pc]) : "?");
      le.traceback = this.errorHook(le.getMessage(), le.level);
   }

   private UpValue findupval(LuaValue[] stack, short idx, UpValue[] openups) {
      int n = openups.length;

      int i;
      for(i = 0; i < n; ++i) {
         if (openups[i] != null && openups[i].index == idx) {
            return openups[i];
         }
      }

      for(i = 0; i < n; ++i) {
         if (openups[i] == null) {
            return openups[i] = new UpValue(stack, idx);
         }
      }

      error("No space for upvalue");
      return null;
   }

   protected LuaValue getUpvalue(int i) {
      return this.upValues[i].getValue();
   }

   protected void setUpvalue(int i, LuaValue v) {
      this.upValues[i].setValue(v);
   }

   public String name() {
      String var10000 = this.p.shortsource();
      return "<" + var10000 + ":" + this.p.linedefined + ">";
   }
}
