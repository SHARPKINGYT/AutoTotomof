package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.lib.MathLib;

@Environment(EnvType.CLIENT)
public class LuaDouble extends LuaNumber {
   public static final LuaDouble NAN = new LuaDouble(Double.NaN);
   public static final LuaDouble POSINF = new LuaDouble(Double.POSITIVE_INFINITY);
   public static final LuaDouble NEGINF = new LuaDouble(Double.NEGATIVE_INFINITY);
   public static final String JSTR_NAN = "nan";
   public static final String JSTR_POSINF = "inf";
   public static final String JSTR_NEGINF = "-inf";
   final double v;

   public static LuaNumber valueOf(double d) {
      int id = (int)d;
      return (LuaNumber)(d == (double)id ? LuaInteger.valueOf(id) : new LuaDouble(d));
   }

   private LuaDouble(double d) {
      this.v = d;
   }

   public int hashCode() {
      long l = Double.doubleToLongBits(this.v + 1.0D);
      return (int)(l >> 32) + (int)l;
   }

   public boolean islong() {
      return this.v == (double)((long)this.v);
   }

   public byte tobyte() {
      return (byte)((int)((long)this.v));
   }

   public char tochar() {
      return (char)((int)((long)this.v));
   }

   public double todouble() {
      return this.v;
   }

   public float tofloat() {
      return (float)this.v;
   }

   public int toint() {
      return (int)((long)this.v);
   }

   public long tolong() {
      return (long)this.v;
   }

   public short toshort() {
      return (short)((int)((long)this.v));
   }

   public double optdouble(double defval) {
      return this.v;
   }

   public int optint(int defval) {
      return (int)((long)this.v);
   }

   public LuaInteger optinteger(LuaInteger defval) {
      return LuaInteger.valueOf((int)((long)this.v));
   }

   public long optlong(long defval) {
      return (long)this.v;
   }

   public LuaInteger checkinteger() {
      return LuaInteger.valueOf((int)((long)this.v));
   }

   public LuaValue neg() {
      return valueOf(-this.v);
   }

   public boolean equals(Object o) {
      return o instanceof LuaDouble ? ((LuaDouble)o).v == this.v : false;
   }

   public LuaValue eq(LuaValue val) {
      return val.raweq(this.v) ? TRUE : FALSE;
   }

   public boolean eq_b(LuaValue val) {
      return val.raweq(this.v);
   }

   public boolean raweq(LuaValue val) {
      return val.raweq(this.v);
   }

   public boolean raweq(double val) {
      return this.v == val;
   }

   public boolean raweq(int val) {
      return this.v == (double)val;
   }

   public LuaValue add(LuaValue rhs) {
      return rhs.add(this.v);
   }

   public LuaValue add(double lhs) {
      return valueOf(lhs + this.v);
   }

   public LuaValue sub(LuaValue rhs) {
      return rhs.subFrom(this.v);
   }

   public LuaValue sub(double rhs) {
      return valueOf(this.v - rhs);
   }

   public LuaValue sub(int rhs) {
      return valueOf(this.v - (double)rhs);
   }

   public LuaValue subFrom(double lhs) {
      return valueOf(lhs - this.v);
   }

   public LuaValue mul(LuaValue rhs) {
      return rhs.mul(this.v);
   }

   public LuaValue mul(double lhs) {
      return valueOf(lhs * this.v);
   }

   public LuaValue mul(int lhs) {
      return valueOf((double)lhs * this.v);
   }

   public LuaValue pow(LuaValue rhs) {
      return rhs.powWith(this.v);
   }

   public LuaValue pow(double rhs) {
      return MathLib.dpow(this.v, rhs);
   }

   public LuaValue pow(int rhs) {
      return MathLib.dpow(this.v, (double)rhs);
   }

   public LuaValue powWith(double lhs) {
      return MathLib.dpow(lhs, this.v);
   }

   public LuaValue powWith(int lhs) {
      return MathLib.dpow((double)lhs, this.v);
   }

   public LuaValue div(LuaValue rhs) {
      return rhs.divInto(this.v);
   }

   public LuaValue div(double rhs) {
      return ddiv(this.v, rhs);
   }

   public LuaValue div(int rhs) {
      return ddiv(this.v, (double)rhs);
   }

   public LuaValue divInto(double lhs) {
      return ddiv(lhs, this.v);
   }

   public LuaValue mod(LuaValue rhs) {
      return rhs.modFrom(this.v);
   }

   public LuaValue mod(double rhs) {
      return dmod(this.v, rhs);
   }

   public LuaValue mod(int rhs) {
      return dmod(this.v, (double)rhs);
   }

   public LuaValue modFrom(double lhs) {
      return dmod(lhs, this.v);
   }

   public static LuaValue ddiv(double lhs, double rhs) {
      return (LuaValue)(rhs != 0.0D ? valueOf(lhs / rhs) : (lhs > 0.0D ? POSINF : (lhs == 0.0D ? NAN : NEGINF)));
   }

   public static double ddiv_d(double lhs, double rhs) {
      return rhs != 0.0D ? lhs / rhs : (lhs > 0.0D ? Double.POSITIVE_INFINITY : (lhs == 0.0D ? Double.NaN : Double.NEGATIVE_INFINITY));
   }

   public static LuaValue dmod(double lhs, double rhs) {
      return (LuaValue)(rhs != 0.0D ? valueOf(lhs - rhs * Math.floor(lhs / rhs)) : NAN);
   }

   public static double dmod_d(double lhs, double rhs) {
      return rhs != 0.0D ? lhs - rhs * Math.floor(lhs / rhs) : Double.NaN;
   }

   public LuaValue lt(LuaValue rhs) {
      return rhs.gt_b(this.v) ? LuaValue.TRUE : FALSE;
   }

   public LuaValue lt(double rhs) {
      return this.v < rhs ? TRUE : FALSE;
   }

   public LuaValue lt(int rhs) {
      return this.v < (double)rhs ? TRUE : FALSE;
   }

   public boolean lt_b(LuaValue rhs) {
      return rhs.gt_b(this.v);
   }

   public boolean lt_b(int rhs) {
      return this.v < (double)rhs;
   }

   public boolean lt_b(double rhs) {
      return this.v < rhs;
   }

   public LuaValue lteq(LuaValue rhs) {
      return rhs.gteq_b(this.v) ? LuaValue.TRUE : FALSE;
   }

   public LuaValue lteq(double rhs) {
      return this.v <= rhs ? TRUE : FALSE;
   }

   public LuaValue lteq(int rhs) {
      return this.v <= (double)rhs ? TRUE : FALSE;
   }

   public boolean lteq_b(LuaValue rhs) {
      return rhs.gteq_b(this.v);
   }

   public boolean lteq_b(int rhs) {
      return this.v <= (double)rhs;
   }

   public boolean lteq_b(double rhs) {
      return this.v <= rhs;
   }

   public LuaValue gt(LuaValue rhs) {
      return rhs.lt_b(this.v) ? LuaValue.TRUE : FALSE;
   }

   public LuaValue gt(double rhs) {
      return this.v > rhs ? TRUE : FALSE;
   }

   public LuaValue gt(int rhs) {
      return this.v > (double)rhs ? TRUE : FALSE;
   }

   public boolean gt_b(LuaValue rhs) {
      return rhs.lt_b(this.v);
   }

   public boolean gt_b(int rhs) {
      return this.v > (double)rhs;
   }

   public boolean gt_b(double rhs) {
      return this.v > rhs;
   }

   public LuaValue gteq(LuaValue rhs) {
      return rhs.lteq_b(this.v) ? LuaValue.TRUE : FALSE;
   }

   public LuaValue gteq(double rhs) {
      return this.v >= rhs ? TRUE : FALSE;
   }

   public LuaValue gteq(int rhs) {
      return this.v >= (double)rhs ? TRUE : FALSE;
   }

   public boolean gteq_b(LuaValue rhs) {
      return rhs.lteq_b(this.v);
   }

   public boolean gteq_b(int rhs) {
      return this.v >= (double)rhs;
   }

   public boolean gteq_b(double rhs) {
      return this.v >= rhs;
   }

   public int strcmp(LuaString rhs) {
      this.typerror("attempt to compare number with string");
      return 0;
   }

   public String tojstring() {
      long l = (long)this.v;
      if ((double)l == this.v) {
         return Long.toString(l);
      } else if (Double.isNaN(this.v)) {
         return "nan";
      } else if (Double.isInfinite(this.v)) {
         return this.v < 0.0D ? "-inf" : "inf";
      } else {
         return Float.toString((float)this.v);
      }
   }

   public LuaString strvalue() {
      return LuaString.valueOf(this.tojstring());
   }

   public LuaString optstring(LuaString defval) {
      return LuaString.valueOf(this.tojstring());
   }

   public LuaValue tostring() {
      return LuaString.valueOf(this.tojstring());
   }

   public String optjstring(String defval) {
      return this.tojstring();
   }

   public LuaNumber optnumber(LuaNumber defval) {
      return this;
   }

   public boolean isnumber() {
      return true;
   }

   public boolean isstring() {
      return true;
   }

   public LuaValue tonumber() {
      return this;
   }

   public int checkint() {
      return (int)((long)this.v);
   }

   public long checklong() {
      return (long)this.v;
   }

   public LuaNumber checknumber() {
      return this;
   }

   public double checkdouble() {
      return this.v;
   }

   public String checkjstring() {
      return this.tojstring();
   }

   public LuaString checkstring() {
      return LuaString.valueOf(this.tojstring());
   }

   public boolean isvalidkey() {
      return !Double.isNaN(this.v);
   }
}
