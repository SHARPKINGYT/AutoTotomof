package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LuaError extends RuntimeException {
   private static final long serialVersionUID = 1L;
   protected int level;
   protected String fileline;
   protected String traceback;
   protected Throwable cause;
   private LuaValue object;

   public String getMessage() {
      if (this.traceback != null) {
         return this.traceback;
      } else {
         String m = super.getMessage();
         if (m == null) {
            return null;
         } else {
            return this.fileline != null ? this.fileline + " " + m : m;
         }
      }
   }

   public LuaValue getMessageObject() {
      if (this.object != null) {
         return this.object;
      } else {
         String m = this.getMessage();
         return m != null ? LuaValue.valueOf(m) : null;
      }
   }

   public LuaError(Throwable cause) {
      super("vm error: " + String.valueOf(cause));
      this.cause = cause;
      this.level = 1;
   }

   public LuaError(String message) {
      super(message);
      this.level = 1;
   }

   public LuaError(String message, int level) {
      super(message);
      this.level = level;
   }

   public LuaError(LuaValue message_object) {
      super(message_object.tojstring());
      this.object = message_object;
      this.level = 1;
   }

   public Throwable getCause() {
      return this.cause;
   }
}
