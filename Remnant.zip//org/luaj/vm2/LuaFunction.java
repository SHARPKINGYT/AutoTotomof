package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class LuaFunction extends LuaValue {
   public static LuaValue s_metatable;

   public int type() {
      return 6;
   }

   public String typename() {
      return "function";
   }

   public boolean isfunction() {
      return true;
   }

   public LuaFunction checkfunction() {
      return this;
   }

   public LuaFunction optfunction(LuaFunction defval) {
      return this;
   }

   public LuaValue getmetatable() {
      return s_metatable;
   }

   public String tojstring() {
      return "function: " + this.classnamestub();
   }

   public LuaString strvalue() {
      return valueOf(this.tojstring());
   }

   public String classnamestub() {
      String s = this.getClass().getName();
      return s.substring(Math.max(s.lastIndexOf(46), s.lastIndexOf(36)) + 1);
   }

   public String name() {
      return this.classnamestub();
   }
}
