package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.lib.MathLib;

@Environment(EnvType.CLIENT)
public class LuaInteger extends LuaNumber {
   private static final LuaInteger[] intValues = new LuaInteger[512];
   public final int v;

   public static LuaInteger valueOf(int i) {
      return i <= 255 && i >= -256 ? intValues[i + 256] : new LuaInteger(i);
   }

   public static LuaNumber valueOf(long l) {
      int i = (int)l;
      return (LuaNumber)(l == (long)i ? (i <= 255 && i >= -256 ? intValues[i + 256] : new LuaInteger(i)) : LuaDouble.valueOf((double)l));
   }

   LuaInteger(int i) {
      this.v = i;
   }

   public boolean isint() {
      return true;
   }

   public boolean isinttype() {
      return true;
   }

   public boolean islong() {
      return true;
   }

   public byte tobyte() {
      return (byte)this.v;
   }

   public char tochar() {
      return (char)this.v;
   }

   public double todouble() {
      return (double)this.v;
   }

   public float tofloat() {
      return (float)this.v;
   }

   public int toint() {
      return this.v;
   }

   public long tolong() {
      return (long)this.v;
   }

   public short toshort() {
      return (short)this.v;
   }

   public double optdouble(double defval) {
      return (double)this.v;
   }

   public int optint(int defval) {
      return this.v;
   }

   public LuaInteger optinteger(LuaInteger defval) {
      return this;
   }

   public long optlong(long defval) {
      return (long)this.v;
   }

   public String tojstring() {
      return Integer.toString(this.v);
   }

   public LuaString strvalue() {
      return LuaString.valueOf(Integer.toString(this.v));
   }

   public LuaString optstring(LuaString defval) {
      return LuaString.valueOf(Integer.toString(this.v));
   }

   public LuaValue tostring() {
      return LuaString.valueOf(Integer.toString(this.v));
   }

   public String optjstring(String defval) {
      return Integer.toString(this.v);
   }

   public LuaInteger checkinteger() {
      return this;
   }

   public boolean isstring() {
      return true;
   }

   public int hashCode() {
      return this.v;
   }

   public static int hashCode(int x) {
      return x;
   }

   public LuaValue neg() {
      return valueOf(-((long)this.v));
   }

   public boolean equals(Object o) {
      return o instanceof LuaInteger ? ((LuaInteger)o).v == this.v : false;
   }

   public LuaValue eq(LuaValue val) {
      return val.raweq(this.v) ? TRUE : FALSE;
   }

   public boolean eq_b(LuaValue val) {
      return val.raweq(this.v);
   }

   public boolean raweq(LuaValue val) {
      return val.raweq(this.v);
   }

   public boolean raweq(double val) {
      return (double)this.v == val;
   }

   public boolean raweq(int val) {
      return this.v == val;
   }

   public LuaValue add(LuaValue rhs) {
      return rhs.add(this.v);
   }

   public LuaValue add(double lhs) {
      return LuaDouble.valueOf(lhs + (double)this.v);
   }

   public LuaValue add(int lhs) {
      return valueOf((long)lhs + (long)this.v);
   }

   public LuaValue sub(LuaValue rhs) {
      return rhs.subFrom(this.v);
   }

   public LuaValue sub(double rhs) {
      return LuaDouble.valueOf((double)this.v - rhs);
   }

   public LuaValue sub(int rhs) {
      return LuaDouble.valueOf(this.v - rhs);
   }

   public LuaValue subFrom(double lhs) {
      return LuaDouble.valueOf(lhs - (double)this.v);
   }

   public LuaValue subFrom(int lhs) {
      return valueOf((long)lhs - (long)this.v);
   }

   public LuaValue mul(LuaValue rhs) {
      return rhs.mul(this.v);
   }

   public LuaValue mul(double lhs) {
      return LuaDouble.valueOf(lhs * (double)this.v);
   }

   public LuaValue mul(int lhs) {
      return valueOf((long)lhs * (long)this.v);
   }

   public LuaValue pow(LuaValue rhs) {
      return rhs.powWith(this.v);
   }

   public LuaValue pow(double rhs) {
      return MathLib.dpow((double)this.v, rhs);
   }

   public LuaValue pow(int rhs) {
      return MathLib.dpow((double)this.v, (double)rhs);
   }

   public LuaValue powWith(double lhs) {
      return MathLib.dpow(lhs, (double)this.v);
   }

   public LuaValue powWith(int lhs) {
      return MathLib.dpow((double)lhs, (double)this.v);
   }

   public LuaValue div(LuaValue rhs) {
      return rhs.divInto((double)this.v);
   }

   public LuaValue div(double rhs) {
      return LuaDouble.ddiv((double)this.v, rhs);
   }

   public LuaValue div(int rhs) {
      return LuaDouble.ddiv((double)this.v, (double)rhs);
   }

   public LuaValue divInto(double lhs) {
      return LuaDouble.ddiv(lhs, (double)this.v);
   }

   public LuaValue mod(LuaValue rhs) {
      return rhs.modFrom((double)this.v);
   }

   public LuaValue mod(double rhs) {
      return LuaDouble.dmod((double)this.v, rhs);
   }

   public LuaValue mod(int rhs) {
      return LuaDouble.dmod((double)this.v, (double)rhs);
   }

   public LuaValue modFrom(double lhs) {
      return LuaDouble.dmod(lhs, (double)this.v);
   }

   public LuaValue lt(LuaValue rhs) {
      return rhs.gt_b(this.v) ? TRUE : FALSE;
   }

   public LuaValue lt(double rhs) {
      return (double)this.v < rhs ? TRUE : FALSE;
   }

   public LuaValue lt(int rhs) {
      return this.v < rhs ? TRUE : FALSE;
   }

   public boolean lt_b(LuaValue rhs) {
      return rhs.gt_b(this.v);
   }

   public boolean lt_b(int rhs) {
      return this.v < rhs;
   }

   public boolean lt_b(double rhs) {
      return (double)this.v < rhs;
   }

   public LuaValue lteq(LuaValue rhs) {
      return rhs.gteq_b(this.v) ? TRUE : FALSE;
   }

   public LuaValue lteq(double rhs) {
      return (double)this.v <= rhs ? TRUE : FALSE;
   }

   public LuaValue lteq(int rhs) {
      return this.v <= rhs ? TRUE : FALSE;
   }

   public boolean lteq_b(LuaValue rhs) {
      return rhs.gteq_b(this.v);
   }

   public boolean lteq_b(int rhs) {
      return this.v <= rhs;
   }

   public boolean lteq_b(double rhs) {
      return (double)this.v <= rhs;
   }

   public LuaValue gt(LuaValue rhs) {
      return rhs.lt_b(this.v) ? TRUE : FALSE;
   }

   public LuaValue gt(double rhs) {
      return (double)this.v > rhs ? TRUE : FALSE;
   }

   public LuaValue gt(int rhs) {
      return this.v > rhs ? TRUE : FALSE;
   }

   public boolean gt_b(LuaValue rhs) {
      return rhs.lt_b(this.v);
   }

   public boolean gt_b(int rhs) {
      return this.v > rhs;
   }

   public boolean gt_b(double rhs) {
      return (double)this.v > rhs;
   }

   public LuaValue gteq(LuaValue rhs) {
      return rhs.lteq_b(this.v) ? TRUE : FALSE;
   }

   public LuaValue gteq(double rhs) {
      return (double)this.v >= rhs ? TRUE : FALSE;
   }

   public LuaValue gteq(int rhs) {
      return this.v >= rhs ? TRUE : FALSE;
   }

   public boolean gteq_b(LuaValue rhs) {
      return rhs.lteq_b(this.v);
   }

   public boolean gteq_b(int rhs) {
      return this.v >= rhs;
   }

   public boolean gteq_b(double rhs) {
      return (double)this.v >= rhs;
   }

   public int strcmp(LuaString rhs) {
      this.typerror("attempt to compare number with string");
      return 0;
   }

   public int checkint() {
      return this.v;
   }

   public long checklong() {
      return (long)this.v;
   }

   public double checkdouble() {
      return (double)this.v;
   }

   public String checkjstring() {
      return String.valueOf(this.v);
   }

   public LuaString checkstring() {
      return valueOf(String.valueOf(this.v));
   }

   static {
      for(int i = 0; i < 512; ++i) {
         intValues[i] = new LuaInteger(i - 256);
      }

   }
}
