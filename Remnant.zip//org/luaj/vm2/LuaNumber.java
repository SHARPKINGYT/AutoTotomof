package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class LuaNumber extends LuaValue {
   public static LuaValue s_metatable;

   public int type() {
      return 3;
   }

   public String typename() {
      return "number";
   }

   public LuaNumber checknumber() {
      return this;
   }

   public LuaNumber checknumber(String errmsg) {
      return this;
   }

   public LuaNumber optnumber(LuaNumber defval) {
      return this;
   }

   public LuaValue tonumber() {
      return this;
   }

   public boolean isnumber() {
      return true;
   }

   public boolean isstring() {
      return true;
   }

   public LuaValue getmetatable() {
      return s_metatable;
   }

   public LuaValue concat(LuaValue rhs) {
      return rhs.concatTo(this);
   }

   public Buffer concat(Buffer rhs) {
      return rhs.concatTo(this);
   }

   public LuaValue concatTo(LuaNumber lhs) {
      return this.strvalue().concatTo(lhs.strvalue());
   }

   public LuaValue concatTo(LuaString lhs) {
      return this.strvalue().concatTo(lhs);
   }
}
