package org.luaj.vm2;

import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.lib.MathLib;

@Environment(EnvType.CLIENT)
public class LuaString extends LuaValue {
   public static LuaValue s_metatable;
   public final byte[] m_bytes;
   public final int m_offset;
   public final int m_length;
   private final int m_hashcode;
   static final int RECENT_STRINGS_CACHE_SIZE = 128;
   static final int RECENT_STRINGS_MAX_LENGTH = 32;

   public static LuaString valueOf(String string) {
      char[] c = string.toCharArray();
      byte[] b = new byte[lengthAsUtf8(c)];
      encodeToUtf8(c, c.length, b, 0);
      return valueUsing(b, 0, b.length);
   }

   public static LuaString valueOf(byte[] bytes, int off, int len) {
      if (len > 32) {
         return valueFromCopy(bytes, off, len);
      } else {
         int hash = hashCode(bytes, off, len);
         int bucket = hash & 127;
         LuaString t = LuaString.RecentShortStrings.recent_short_strings[bucket];
         if (t != null && t.m_hashcode == hash && t.byteseq(bytes, off, len)) {
            return t;
         } else {
            LuaString s = valueFromCopy(bytes, off, len);
            LuaString.RecentShortStrings.recent_short_strings[bucket] = s;
            return s;
         }
      }
   }

   private static LuaString valueFromCopy(byte[] bytes, int off, int len) {
      byte[] copy = new byte[len];

      for(int i = 0; i < len; ++i) {
         copy[i] = bytes[off + i];
      }

      return new LuaString(copy, 0, len);
   }

   public static LuaString valueUsing(byte[] bytes, int off, int len) {
      if (bytes.length > 32) {
         return new LuaString(bytes, off, len);
      } else {
         int hash = hashCode(bytes, off, len);
         int bucket = hash & 127;
         LuaString t = LuaString.RecentShortStrings.recent_short_strings[bucket];
         if (t != null && t.m_hashcode == hash && t.byteseq(bytes, off, len)) {
            return t;
         } else {
            LuaString s = new LuaString(bytes, off, len);
            LuaString.RecentShortStrings.recent_short_strings[bucket] = s;
            return s;
         }
      }
   }

   public static LuaString valueOf(char[] bytes) {
      return valueOf((char[])bytes, 0, bytes.length);
   }

   public static LuaString valueOf(char[] bytes, int off, int len) {
      byte[] b = new byte[len];

      for(int i = 0; i < len; ++i) {
         b[i] = (byte)bytes[i + off];
      }

      return valueUsing(b, 0, len);
   }

   public static LuaString valueOf(byte[] bytes) {
      return valueOf((byte[])bytes, 0, bytes.length);
   }

   public static LuaString valueUsing(byte[] bytes) {
      return valueUsing(bytes, 0, bytes.length);
   }

   private LuaString(byte[] bytes, int offset, int length) {
      this.m_bytes = bytes;
      this.m_offset = offset;
      this.m_length = length;
      this.m_hashcode = hashCode(bytes, offset, length);
   }

   public boolean isstring() {
      return true;
   }

   public LuaValue getmetatable() {
      return s_metatable;
   }

   public int type() {
      return 4;
   }

   public String typename() {
      return "string";
   }

   public String tojstring() {
      return decodeAsUtf8(this.m_bytes, this.m_offset, this.m_length);
   }

   public LuaValue neg() {
      double d = this.scannumber();
      return (LuaValue)(Double.isNaN(d) ? super.neg() : valueOf(-d));
   }

   public LuaValue add(LuaValue rhs) {
      double d = this.scannumber();
      return Double.isNaN(d) ? this.arithmt(ADD, rhs) : rhs.add(d);
   }

   public LuaValue add(double rhs) {
      return valueOf(this.checkarith() + rhs);
   }

   public LuaValue add(int rhs) {
      return valueOf(this.checkarith() + (double)rhs);
   }

   public LuaValue sub(LuaValue rhs) {
      double d = this.scannumber();
      return Double.isNaN(d) ? this.arithmt(SUB, rhs) : rhs.subFrom(d);
   }

   public LuaValue sub(double rhs) {
      return valueOf(this.checkarith() - rhs);
   }

   public LuaValue sub(int rhs) {
      return valueOf(this.checkarith() - (double)rhs);
   }

   public LuaValue subFrom(double lhs) {
      return valueOf(lhs - this.checkarith());
   }

   public LuaValue mul(LuaValue rhs) {
      double d = this.scannumber();
      return Double.isNaN(d) ? this.arithmt(MUL, rhs) : rhs.mul(d);
   }

   public LuaValue mul(double rhs) {
      return valueOf(this.checkarith() * rhs);
   }

   public LuaValue mul(int rhs) {
      return valueOf(this.checkarith() * (double)rhs);
   }

   public LuaValue pow(LuaValue rhs) {
      double d = this.scannumber();
      return Double.isNaN(d) ? this.arithmt(POW, rhs) : rhs.powWith(d);
   }

   public LuaValue pow(double rhs) {
      return MathLib.dpow(this.checkarith(), rhs);
   }

   public LuaValue pow(int rhs) {
      return MathLib.dpow(this.checkarith(), (double)rhs);
   }

   public LuaValue powWith(double lhs) {
      return MathLib.dpow(lhs, this.checkarith());
   }

   public LuaValue powWith(int lhs) {
      return MathLib.dpow((double)lhs, this.checkarith());
   }

   public LuaValue div(LuaValue rhs) {
      double d = this.scannumber();
      return Double.isNaN(d) ? this.arithmt(DIV, rhs) : rhs.divInto(d);
   }

   public LuaValue div(double rhs) {
      return LuaDouble.ddiv(this.checkarith(), rhs);
   }

   public LuaValue div(int rhs) {
      return LuaDouble.ddiv(this.checkarith(), (double)rhs);
   }

   public LuaValue divInto(double lhs) {
      return LuaDouble.ddiv(lhs, this.checkarith());
   }

   public LuaValue mod(LuaValue rhs) {
      double d = this.scannumber();
      return Double.isNaN(d) ? this.arithmt(MOD, rhs) : rhs.modFrom(d);
   }

   public LuaValue mod(double rhs) {
      return LuaDouble.dmod(this.checkarith(), rhs);
   }

   public LuaValue mod(int rhs) {
      return LuaDouble.dmod(this.checkarith(), (double)rhs);
   }

   public LuaValue modFrom(double lhs) {
      return LuaDouble.dmod(lhs, this.checkarith());
   }

   public LuaValue lt(LuaValue rhs) {
      return rhs.strcmp(this) > 0 ? LuaValue.TRUE : FALSE;
   }

   public boolean lt_b(LuaValue rhs) {
      return rhs.strcmp(this) > 0;
   }

   public boolean lt_b(int rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public boolean lt_b(double rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public LuaValue lteq(LuaValue rhs) {
      return rhs.strcmp(this) >= 0 ? LuaValue.TRUE : FALSE;
   }

   public boolean lteq_b(LuaValue rhs) {
      return rhs.strcmp(this) >= 0;
   }

   public boolean lteq_b(int rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public boolean lteq_b(double rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public LuaValue gt(LuaValue rhs) {
      return rhs.strcmp(this) < 0 ? LuaValue.TRUE : FALSE;
   }

   public boolean gt_b(LuaValue rhs) {
      return rhs.strcmp(this) < 0;
   }

   public boolean gt_b(int rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public boolean gt_b(double rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public LuaValue gteq(LuaValue rhs) {
      return rhs.strcmp(this) <= 0 ? LuaValue.TRUE : FALSE;
   }

   public boolean gteq_b(LuaValue rhs) {
      return rhs.strcmp(this) <= 0;
   }

   public boolean gteq_b(int rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public boolean gteq_b(double rhs) {
      this.typerror("attempt to compare string with number");
      return false;
   }

   public LuaValue concat(LuaValue rhs) {
      return rhs.concatTo(this);
   }

   public Buffer concat(Buffer rhs) {
      return rhs.concatTo(this);
   }

   public LuaValue concatTo(LuaNumber lhs) {
      return this.concatTo(lhs.strvalue());
   }

   public LuaValue concatTo(LuaString lhs) {
      byte[] b = new byte[lhs.m_length + this.m_length];
      System.arraycopy(lhs.m_bytes, lhs.m_offset, b, 0, lhs.m_length);
      System.arraycopy(this.m_bytes, this.m_offset, b, lhs.m_length, this.m_length);
      return valueUsing(b, 0, b.length);
   }

   public int strcmp(LuaValue lhs) {
      return -lhs.strcmp(this);
   }

   public int strcmp(LuaString rhs) {
      int i = 0;

      for(int j = 0; i < this.m_length && j < rhs.m_length; ++j) {
         if (this.m_bytes[this.m_offset + i] != rhs.m_bytes[rhs.m_offset + j]) {
            return this.m_bytes[this.m_offset + i] - rhs.m_bytes[rhs.m_offset + j];
         }

         ++i;
      }

      return this.m_length - rhs.m_length;
   }

   private double checkarith() {
      double d = this.scannumber();
      if (Double.isNaN(d)) {
         this.aritherror();
      }

      return d;
   }

   public int checkint() {
      return (int)((long)this.checkdouble());
   }

   public LuaInteger checkinteger() {
      return valueOf(this.checkint());
   }

   public long checklong() {
      return (long)this.checkdouble();
   }

   public double checkdouble() {
      double d = this.scannumber();
      if (Double.isNaN(d)) {
         this.argerror("number");
      }

      return d;
   }

   public LuaNumber checknumber() {
      return valueOf(this.checkdouble());
   }

   public LuaNumber checknumber(String msg) {
      double d = this.scannumber();
      if (Double.isNaN(d)) {
         error(msg);
      }

      return valueOf(d);
   }

   public boolean isnumber() {
      double d = this.scannumber();
      return !Double.isNaN(d);
   }

   public boolean isint() {
      double d = this.scannumber();
      if (Double.isNaN(d)) {
         return false;
      } else {
         int i = (int)d;
         return (double)i == d;
      }
   }

   public boolean islong() {
      double d = this.scannumber();
      if (Double.isNaN(d)) {
         return false;
      } else {
         long l = (long)d;
         return (double)l == d;
      }
   }

   public byte tobyte() {
      return (byte)this.toint();
   }

   public char tochar() {
      return (char)this.toint();
   }

   public double todouble() {
      double d = this.scannumber();
      return Double.isNaN(d) ? 0.0D : d;
   }

   public float tofloat() {
      return (float)this.todouble();
   }

   public int toint() {
      return (int)this.tolong();
   }

   public long tolong() {
      return (long)this.todouble();
   }

   public short toshort() {
      return (short)this.toint();
   }

   public double optdouble(double defval) {
      return this.checknumber().checkdouble();
   }

   public int optint(int defval) {
      return this.checknumber().checkint();
   }

   public LuaInteger optinteger(LuaInteger defval) {
      return this.checknumber().checkinteger();
   }

   public long optlong(long defval) {
      return this.checknumber().checklong();
   }

   public LuaNumber optnumber(LuaNumber defval) {
      return this.checknumber().checknumber();
   }

   public LuaString optstring(LuaString defval) {
      return this;
   }

   public LuaValue tostring() {
      return this;
   }

   public String optjstring(String defval) {
      return this.tojstring();
   }

   public LuaString strvalue() {
      return this;
   }

   public LuaString substring(int beginIndex, int endIndex) {
      int off = this.m_offset + beginIndex;
      int len = endIndex - beginIndex;
      return len >= this.m_length / 2 ? valueUsing(this.m_bytes, off, len) : valueOf(this.m_bytes, off, len);
   }

   public int hashCode() {
      return this.m_hashcode;
   }

   public static int hashCode(byte[] bytes, int offset, int length) {
      int h = length;
      int step = (length >> 5) + 1;

      for(int l1 = length; l1 >= step; l1 -= step) {
         h ^= (h << 5) + (h >> 2) + (bytes[offset + l1 - 1] & 255);
      }

      return h;
   }

   public boolean equals(Object o) {
      return o instanceof LuaString ? this.raweq((LuaString)o) : false;
   }

   public LuaValue eq(LuaValue val) {
      return val.raweq(this) ? TRUE : FALSE;
   }

   public boolean eq_b(LuaValue val) {
      return val.raweq(this);
   }

   public boolean raweq(LuaValue val) {
      return val.raweq(this);
   }

   public boolean raweq(LuaString s) {
      if (this == s) {
         return true;
      } else if (s.m_length != this.m_length) {
         return false;
      } else if (s.m_bytes == this.m_bytes && s.m_offset == this.m_offset) {
         return true;
      } else if (s.hashCode() != this.hashCode()) {
         return false;
      } else {
         for(int i = 0; i < this.m_length; ++i) {
            if (s.m_bytes[s.m_offset + i] != this.m_bytes[this.m_offset + i]) {
               return false;
            }
         }

         return true;
      }
   }

   public static boolean equals(LuaString a, int i, LuaString b, int j, int n) {
      return equals(a.m_bytes, a.m_offset + i, b.m_bytes, b.m_offset + j, n);
   }

   private boolean byteseq(byte[] bytes, int off, int len) {
      return this.m_length == len && equals(this.m_bytes, this.m_offset, bytes, off, len);
   }

   public static boolean equals(byte[] a, int i, byte[] b, int j, int n) {
      if (a.length >= i + n && b.length >= j + n) {
         do {
            --n;
            if (n < 0) {
               return true;
            }
         } while(a[i++] == b[j++]);

         return false;
      } else {
         return false;
      }
   }

   public void write(DataOutputStream writer, int i, int len) throws IOException {
      writer.write(this.m_bytes, this.m_offset + i, len);
   }

   public LuaValue len() {
      return LuaInteger.valueOf(this.m_length);
   }

   public int length() {
      return this.m_length;
   }

   public int rawlen() {
      return this.m_length;
   }

   public int luaByte(int index) {
      return this.m_bytes[this.m_offset + index] & 255;
   }

   public int charAt(int index) {
      if (index >= 0 && index < this.m_length) {
         return this.luaByte(index);
      } else {
         throw new IndexOutOfBoundsException();
      }
   }

   public String checkjstring() {
      return this.tojstring();
   }

   public LuaString checkstring() {
      return this;
   }

   public InputStream toInputStream() {
      return new ByteArrayInputStream(this.m_bytes, this.m_offset, this.m_length);
   }

   public void copyInto(int strOffset, byte[] bytes, int arrayOffset, int len) {
      System.arraycopy(this.m_bytes, this.m_offset + strOffset, bytes, arrayOffset, len);
   }

   public int indexOfAny(LuaString accept) {
      int ilimit = this.m_offset + this.m_length;
      int jlimit = accept.m_offset + accept.m_length;

      for(int i = this.m_offset; i < ilimit; ++i) {
         for(int j = accept.m_offset; j < jlimit; ++j) {
            if (this.m_bytes[i] == accept.m_bytes[j]) {
               return i - this.m_offset;
            }
         }
      }

      return -1;
   }

   public int indexOf(byte b, int start) {
      for(int i = start; i < this.m_length; ++i) {
         if (this.m_bytes[this.m_offset + i] == b) {
            return i;
         }
      }

      return -1;
   }

   public int indexOf(LuaString s, int start) {
      int slen = s.length();
      int limit = this.m_length - slen;

      for(int i = start; i <= limit; ++i) {
         if (equals(this.m_bytes, this.m_offset + i, s.m_bytes, s.m_offset, slen)) {
            return i;
         }
      }

      return -1;
   }

   public int lastIndexOf(LuaString s) {
      int slen = s.length();
      int limit = this.m_length - slen;

      for(int i = limit; i >= 0; --i) {
         if (equals(this.m_bytes, this.m_offset + i, s.m_bytes, s.m_offset, slen)) {
            return i;
         }
      }

      return -1;
   }

   public static String decodeAsUtf8(byte[] bytes, int offset, int length) {
      int i = offset;
      int j = offset + length;
      int n = 0;

      while(i < j) {
         switch(224 & bytes[i++]) {
         case 224:
            ++i;
         case 192:
            ++i;
         default:
            ++n;
         }
      }

      char[] chars = new char[n];
      i = offset;
      j = offset + length;

      byte b;
      for(n = 0; i < j; chars[n++] = (char)((b = bytes[i++]) < 0 && i < j ? (b >= -32 && i + 1 < j ? (b & 15) << 12 | (bytes[i++] & 63) << 6 | bytes[i++] & 63 : (b & 63) << 6 | bytes[i++] & 63) : b)) {
      }

      return new String(chars);
   }

   public static int lengthAsUtf8(char[] chars) {
      int b;
      int i = b = chars.length;

      while(true) {
         --i;
         if (i < 0) {
            return b;
         }

         char c;
         if ((c = chars[i]) >= 128) {
            b += c >= 2048 ? 2 : 1;
         }
      }
   }

   public static int encodeToUtf8(char[] chars, int nchars, byte[] bytes, int off) {
      int j = off;

      for(int i = 0; i < nchars; ++i) {
         char c;
         if ((c = chars[i]) < 128) {
            bytes[j++] = (byte)c;
         } else if (c < 2048) {
            bytes[j++] = (byte)(192 | c >> 6 & 31);
            bytes[j++] = (byte)(128 | c & 63);
         } else {
            bytes[j++] = (byte)(224 | c >> 12 & 15);
            bytes[j++] = (byte)(128 | c >> 6 & 63);
            bytes[j++] = (byte)(128 | c & 63);
         }
      }

      return j - off;
   }

   public boolean isValidUtf8() {
      int i = this.m_offset;
      int j = this.m_offset + this.m_length;

      byte c;
      do {
         do {
            do {
               if (i >= j) {
                  return true;
               }

               c = this.m_bytes[i++];
            } while(c >= 0);
         } while((c & 224) == 192 && i < j && (this.m_bytes[i++] & 192) == 128);
      } while((c & 240) == 224 && i + 1 < j && (this.m_bytes[i++] & 192) == 128 && (this.m_bytes[i++] & 192) == 128);

      return false;
   }

   public LuaValue tonumber() {
      double d = this.scannumber();
      return (LuaValue)(Double.isNaN(d) ? NIL : valueOf(d));
   }

   public LuaValue tonumber(int base) {
      double d = this.scannumber(base);
      return (LuaValue)(Double.isNaN(d) ? NIL : valueOf(d));
   }

   public double scannumber() {
      int i = this.m_offset;

      int j;
      for(j = this.m_offset + this.m_length; i < j && this.m_bytes[i] == 32; ++i) {
      }

      while(i < j && this.m_bytes[j - 1] == 32) {
         --j;
      }

      if (i >= j) {
         return Double.NaN;
      } else if (this.m_bytes[i] == 48 && i + 1 < j && (this.m_bytes[i + 1] == 120 || this.m_bytes[i + 1] == 88)) {
         return this.scanlong(16, i + 2, j);
      } else {
         double l = this.scanlong(10, i, j);
         return Double.isNaN(l) ? this.scandouble(i, j) : l;
      }
   }

   public double scannumber(int base) {
      if (base >= 2 && base <= 36) {
         int i = this.m_offset;

         int j;
         for(j = this.m_offset + this.m_length; i < j && this.m_bytes[i] == 32; ++i) {
         }

         while(i < j && this.m_bytes[j - 1] == 32) {
            --j;
         }

         return i >= j ? Double.NaN : this.scanlong(base, i, j);
      } else {
         return Double.NaN;
      }
   }

   private double scanlong(int base, int start, int end) {
      long x = 0L;
      boolean neg = this.m_bytes[start] == 45;

      for(int i = neg ? start + 1 : start; i < end; ++i) {
         int digit = this.m_bytes[i] - (base <= 10 || this.m_bytes[i] >= 48 && this.m_bytes[i] <= 57 ? 48 : (this.m_bytes[i] >= 65 && this.m_bytes[i] <= 90 ? 55 : 87));
         if (digit < 0 || digit >= base) {
            return Double.NaN;
         }

         x = x * (long)base + (long)digit;
         if (x < 0L) {
            return Double.NaN;
         }
      }

      return neg ? (double)(-x) : (double)x;
   }

   private double scandouble(int start, int end) {
      if (end > start + 64) {
         end = start + 64;
      }

      int i = start;

      while(i < end) {
         switch(this.m_bytes[i]) {
         case 43:
         case 45:
         case 46:
         case 48:
         case 49:
         case 50:
         case 51:
         case 52:
         case 53:
         case 54:
         case 55:
         case 56:
         case 57:
         case 69:
         case 101:
            ++i;
            break;
         case 44:
         case 47:
         case 58:
         case 59:
         case 60:
         case 61:
         case 62:
         case 63:
         case 64:
         case 65:
         case 66:
         case 67:
         case 68:
         case 70:
         case 71:
         case 72:
         case 73:
         case 74:
         case 75:
         case 76:
         case 77:
         case 78:
         case 79:
         case 80:
         case 81:
         case 82:
         case 83:
         case 84:
         case 85:
         case 86:
         case 87:
         case 88:
         case 89:
         case 90:
         case 91:
         case 92:
         case 93:
         case 94:
         case 95:
         case 96:
         case 97:
         case 98:
         case 99:
         case 100:
         default:
            return Double.NaN;
         }
      }

      char[] c = new char[end - start];

      for(int i = start; i < end; ++i) {
         c[i - start] = (char)this.m_bytes[i];
      }

      try {
         return Double.parseDouble(new String(c));
      } catch (Exception var5) {
         return Double.NaN;
      }
   }

   public void printToStream(PrintStream ps) {
      int i = 0;

      for(int n = this.m_length; i < n; ++i) {
         int c = this.m_bytes[this.m_offset + i];
         ps.print((char)c);
      }

   }

   @Environment(EnvType.CLIENT)
   private static final class RecentShortStrings {
      private static final LuaString[] recent_short_strings = new LuaString[128];
   }
}
