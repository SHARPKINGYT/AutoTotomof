package org.luaj.vm2;

import java.lang.ref.WeakReference;
import java.util.Vector;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LuaTable extends LuaValue implements Metatable {
   private static final int MIN_HASH_CAPACITY = 2;
   private static final LuaString N = valueOf("n");
   protected LuaValue[] array;
   protected LuaTable.Slot[] hash;
   protected int hashEntries;
   protected Metatable m_metatable;
   private static final LuaTable.Slot[] NOBUCKETS = new LuaTable.Slot[0];

   public LuaTable() {
      this.array = NOVALS;
      this.hash = NOBUCKETS;
   }

   public LuaTable(int narray, int nhash) {
      this.presize(narray, nhash);
   }

   public LuaTable(LuaValue[] named, LuaValue[] unnamed, Varargs lastarg) {
      int nn = named != null ? named.length : 0;
      int nu = unnamed != null ? unnamed.length : 0;
      int nl = lastarg != null ? lastarg.narg() : 0;
      this.presize(nu + nl, nn >> 1);

      int i;
      for(i = 0; i < nu; ++i) {
         this.rawset(i + 1, unnamed[i]);
      }

      if (lastarg != null) {
         i = 1;

         for(int n = lastarg.narg(); i <= n; ++i) {
            this.rawset(nu + i, lastarg.arg(i));
         }
      }

      for(i = 0; i < nn; i += 2) {
         if (!named[i + 1].isnil()) {
            this.rawset(named[i], named[i + 1]);
         }
      }

   }

   public LuaTable(Varargs varargs) {
      this(varargs, 1);
   }

   public LuaTable(Varargs varargs, int firstarg) {
      int nskip = firstarg - 1;
      int n = Math.max(varargs.narg() - nskip, 0);
      this.presize(n, 1);
      this.set(N, valueOf(n));

      for(int i = 1; i <= n; ++i) {
         this.set(i, varargs.arg(i + nskip));
      }

   }

   public int type() {
      return 5;
   }

   public String typename() {
      return "table";
   }

   public boolean istable() {
      return true;
   }

   public LuaTable checktable() {
      return this;
   }

   public LuaTable opttable(LuaTable defval) {
      return this;
   }

   public void presize(int narray) {
      if (narray > this.array.length) {
         this.array = resize(this.array, 1 << log2(narray));
      }

   }

   public void presize(int narray, int nhash) {
      if (nhash > 0 && nhash < 2) {
         nhash = 2;
      }

      this.array = narray > 0 ? new LuaValue[1 << log2(narray)] : NOVALS;
      this.hash = nhash > 0 ? new LuaTable.Slot[1 << log2(nhash)] : NOBUCKETS;
      this.hashEntries = 0;
   }

   private static LuaValue[] resize(LuaValue[] old, int n) {
      LuaValue[] v = new LuaValue[n];
      System.arraycopy(old, 0, v, 0, old.length);
      return v;
   }

   protected int getArrayLength() {
      return this.array.length;
   }

   protected int getHashLength() {
      return this.hash.length;
   }

   public LuaValue getmetatable() {
      return this.m_metatable != null ? this.m_metatable.toLuaValue() : null;
   }

   public LuaValue setmetatable(LuaValue metatable) {
      boolean hadWeakKeys = this.m_metatable != null && this.m_metatable.useWeakKeys();
      boolean hadWeakValues = this.m_metatable != null && this.m_metatable.useWeakValues();
      this.m_metatable = metatableOf(metatable);
      if (hadWeakKeys != (this.m_metatable != null && this.m_metatable.useWeakKeys()) || hadWeakValues != (this.m_metatable != null && this.m_metatable.useWeakValues())) {
         this.rehash(0);
      }

      return this;
   }

   public LuaValue get(int key) {
      LuaValue v = this.rawget(key);
      return v.isnil() && this.m_metatable != null ? gettable(this, valueOf(key)) : v;
   }

   public LuaValue get(LuaValue key) {
      LuaValue v = this.rawget(key);
      return v.isnil() && this.m_metatable != null ? gettable(this, key) : v;
   }

   public LuaValue rawget(int key) {
      if (key > 0 && key <= this.array.length) {
         LuaValue v = this.m_metatable == null ? this.array[key - 1] : this.m_metatable.arrayget(this.array, key - 1);
         return v != null ? v : NIL;
      } else {
         return this.hashget(LuaInteger.valueOf(key));
      }
   }

   public LuaValue rawget(LuaValue key) {
      if (key.isinttype()) {
         int ikey = key.toint();
         if (ikey > 0 && ikey <= this.array.length) {
            LuaValue v = this.m_metatable == null ? this.array[ikey - 1] : this.m_metatable.arrayget(this.array, ikey - 1);
            return v != null ? v : NIL;
         }
      }

      return this.hashget(key);
   }

   protected LuaValue hashget(LuaValue key) {
      if (this.hashEntries > 0) {
         for(LuaTable.Slot slot = this.hash[this.hashSlot(key)]; slot != null; slot = slot.rest()) {
            LuaTable.StrongSlot foundSlot;
            if ((foundSlot = slot.find(key)) != null) {
               return foundSlot.value();
            }
         }
      }

      return NIL;
   }

   public void set(int key, LuaValue value) {
      if (this.m_metatable == null || !this.rawget(key).isnil() || !settable(this, LuaInteger.valueOf(key), value)) {
         this.rawset(key, value);
      }

   }

   public void set(LuaValue key, LuaValue value) {
      if (!key.isvalidkey() && !this.metatag(NEWINDEX).isfunction()) {
         this.typerror("table index");
      }

      if (this.m_metatable == null || !this.rawget(key).isnil() || !settable(this, key, value)) {
         this.rawset(key, value);
      }

   }

   public void rawset(int key, LuaValue value) {
      if (!this.arrayset(key, value)) {
         this.hashset(LuaInteger.valueOf(key), value);
      }

   }

   public void rawset(LuaValue key, LuaValue value) {
      if (!key.isinttype() || !this.arrayset(key.toint(), value)) {
         this.hashset(key, value);
      }

   }

   private boolean arrayset(int key, LuaValue value) {
      if (key > 0 && key <= this.array.length) {
         this.array[key - 1] = value.isnil() ? null : (this.m_metatable != null ? this.m_metatable.wrap(value) : value);
         return true;
      } else {
         return false;
      }
   }

   public LuaValue remove(int pos) {
      int n = this.rawlen();
      if (pos == 0) {
         pos = n;
      } else if (pos > n) {
         return NONE;
      }

      LuaValue v = this.rawget(pos);
      LuaValue r = v;

      while(!r.isnil()) {
         r = this.rawget(pos + 1);
         this.rawset(pos++, r);
      }

      return v.isnil() ? NONE : v;
   }

   public void insert(int pos, LuaValue value) {
      if (pos == 0) {
         pos = this.rawlen() + 1;
      }

      while(!value.isnil()) {
         LuaValue v = this.rawget(pos);
         this.rawset(pos++, value);
         value = v;
      }

   }

   public LuaValue concat(LuaString sep, int i, int j) {
      Buffer sb = new Buffer();
      if (i <= j) {
         sb.append(this.get(i).checkstring());

         while(true) {
            ++i;
            if (i > j) {
               break;
            }

            sb.append(sep);
            sb.append(this.get(i).checkstring());
         }
      }

      return sb.tostring();
   }

   public int length() {
      return this.m_metatable != null ? this.len().toint() : this.rawlen();
   }

   public LuaValue len() {
      LuaValue h = this.metatag(LEN);
      return (LuaValue)(h.toboolean() ? h.call((LuaValue)this) : LuaInteger.valueOf(this.rawlen()));
   }

   public int rawlen() {
      int a = this.getArrayLength();
      int n = a + 1;

      int m;
      for(m = 0; !this.rawget(n).isnil(); n += a + this.getHashLength() + 1) {
         m = n;
      }

      while(n > m + 1) {
         int k = (n + m) / 2;
         if (!this.rawget(k).isnil()) {
            m = k;
         } else {
            n = k;
         }
      }

      return m;
   }

   public Varargs next(LuaValue key) {
      int i = 0;
      if (!key.isnil()) {
         label84: {
            if (key.isinttype()) {
               i = key.toint();
               if (i > 0 && i <= this.array.length) {
                  break label84;
               }
            }

            if (this.hash.length == 0) {
               error("invalid key to 'next'");
            }

            i = this.hashSlot(key);
            boolean found = false;

            for(LuaTable.Slot slot = this.hash[i]; slot != null; slot = slot.rest()) {
               if (found) {
                  LuaTable.StrongSlot nextEntry = slot.first();
                  if (nextEntry != null) {
                     return nextEntry.toVarargs();
                  }
               } else if (slot.keyeq(key)) {
                  found = true;
               }
            }

            if (!found) {
               error("invalid key to 'next'");
            }

            i += 1 + this.array.length;
         }
      }

      for(; i < this.array.length; ++i) {
         if (this.array[i] != null) {
            LuaValue value = this.m_metatable == null ? this.array[i] : this.m_metatable.arrayget(this.array, i);
            if (value != null) {
               return varargsOf(LuaInteger.valueOf(i + 1), value);
            }
         }
      }

      for(i -= this.array.length; i < this.hash.length; ++i) {
         for(LuaTable.Slot slot = this.hash[i]; slot != null; slot = slot.rest()) {
            LuaTable.StrongSlot first = slot.first();
            if (first != null) {
               return first.toVarargs();
            }
         }
      }

      return NIL;
   }

   public Varargs inext(LuaValue key) {
      int k = key.checkint() + 1;
      LuaValue v = this.rawget(k);
      return (Varargs)(v.isnil() ? NONE : varargsOf(LuaInteger.valueOf(k), v));
   }

   public void hashset(LuaValue key, LuaValue value) {
      if (value.isnil()) {
         this.hashRemove(key);
      } else {
         int index = 0;
         if (this.hash.length > 0) {
            index = this.hashSlot(key);

            for(LuaTable.Slot slot = this.hash[index]; slot != null; slot = slot.rest()) {
               LuaTable.StrongSlot foundSlot;
               if ((foundSlot = slot.find(key)) != null) {
                  this.hash[index] = this.hash[index].set(foundSlot, value);
                  return;
               }
            }
         }

         if (this.checkLoadFactor()) {
            if (key.isinttype() && key.toint() > 0) {
               this.rehash(key.toint());
               if (this.arrayset(key.toint(), value)) {
                  return;
               }
            } else {
               this.rehash(-1);
            }

            index = this.hashSlot(key);
         }

         LuaTable.Slot entry = this.m_metatable != null ? this.m_metatable.entry(key, value) : defaultEntry(key, value);
         this.hash[index] = (LuaTable.Slot)(this.hash[index] != null ? this.hash[index].add((LuaTable.Slot)entry) : entry);
         ++this.hashEntries;
      }

   }

   public static int hashpow2(int hashCode, int mask) {
      return hashCode & mask;
   }

   public static int hashmod(int hashCode, int mask) {
      return (hashCode & Integer.MAX_VALUE) % mask;
   }

   public static int hashSlot(LuaValue key, int hashMask) {
      switch(key.type()) {
      case 2:
      case 3:
      case 5:
      case 7:
      case 8:
         return hashmod(key.hashCode(), hashMask);
      case 4:
      case 6:
      default:
         return hashpow2(key.hashCode(), hashMask);
      }
   }

   private int hashSlot(LuaValue key) {
      return hashSlot(key, this.hash.length - 1);
   }

   private void hashRemove(LuaValue key) {
      if (this.hash.length > 0) {
         int index = this.hashSlot(key);

         for(LuaTable.Slot slot = this.hash[index]; slot != null; slot = slot.rest()) {
            LuaTable.StrongSlot foundSlot;
            if ((foundSlot = slot.find(key)) != null) {
               this.hash[index] = this.hash[index].remove(foundSlot);
               --this.hashEntries;
               return;
            }
         }
      }

   }

   private boolean checkLoadFactor() {
      return this.hashEntries >= this.hash.length;
   }

   private int countHashKeys() {
      int keys = 0;

      for(int i = 0; i < this.hash.length; ++i) {
         for(LuaTable.Slot slot = this.hash[i]; slot != null; slot = slot.rest()) {
            if (slot.first() != null) {
               ++keys;
            }
         }
      }

      return keys;
   }

   private void dropWeakArrayValues() {
      for(int i = 0; i < this.array.length; ++i) {
         this.m_metatable.arrayget(this.array, i);
      }

   }

   private int countIntKeys(int[] nums) {
      int total = 0;
      int i = 1;

      int k;
      for(int bit = 0; bit < 31 && i <= this.array.length; ++bit) {
         k = Math.min(this.array.length, 1 << bit);
         int c = 0;

         while(i <= k) {
            if (this.array[i++ - 1] != null) {
               ++c;
            }
         }

         nums[bit] = c;
         total += c;
      }

      for(i = 0; i < this.hash.length; ++i) {
         for(LuaTable.Slot s = this.hash[i]; s != null; s = s.rest()) {
            if ((k = s.arraykey(Integer.MAX_VALUE)) > 0) {
               ++nums[log2(k)];
               ++total;
            }
         }
      }

      return total;
   }

   static int log2(int x) {
      int lg = 0;
      --x;
      if (x < 0) {
         return Integer.MIN_VALUE;
      } else {
         if ((x & -65536) != 0) {
            lg = 16;
            x >>>= 16;
         }

         if ((x & '\uff00') != 0) {
            lg += 8;
            x >>>= 8;
         }

         if ((x & 240) != 0) {
            lg += 4;
            x >>>= 4;
         }

         switch(x) {
         case 0:
            return 0;
         case 1:
            ++lg;
            break;
         case 2:
            lg += 2;
            break;
         case 3:
            lg += 2;
            break;
         case 4:
            lg += 3;
            break;
         case 5:
            lg += 3;
            break;
         case 6:
            lg += 3;
            break;
         case 7:
            lg += 3;
            break;
         case 8:
            lg += 4;
            break;
         case 9:
            lg += 4;
            break;
         case 10:
            lg += 4;
            break;
         case 11:
            lg += 4;
            break;
         case 12:
            lg += 4;
            break;
         case 13:
            lg += 4;
            break;
         case 14:
            lg += 4;
            break;
         case 15:
            lg += 4;
         }

         return lg;
      }
   }

   private void rehash(int newKey) {
      if (this.m_metatable != null && (this.m_metatable.useWeakKeys() || this.m_metatable.useWeakValues())) {
         this.hashEntries = this.countHashKeys();
         if (this.m_metatable.useWeakValues()) {
            this.dropWeakArrayValues();
         }
      }

      int[] nums = new int[32];
      int total = this.countIntKeys(nums);
      if (newKey > 0) {
         ++total;
         ++nums[log2(newKey)];
      }

      int keys = nums[0];
      int newArraySize = 0;

      for(int log = 1; log < 32; ++log) {
         keys += nums[log];
         if (total * 2 < 1 << log) {
            break;
         }

         if (keys >= 1 << log - 1) {
            newArraySize = 1 << log;
         }
      }

      LuaValue[] oldArray = this.array;
      LuaTable.Slot[] oldHash = this.hash;
      int movingToArray = 0;
      if (newKey > 0 && newKey <= newArraySize) {
         --movingToArray;
      }

      LuaValue[] newArray;
      int i;
      int j;
      if (newArraySize != oldArray.length) {
         newArray = new LuaValue[newArraySize];
         if (newArraySize > oldArray.length) {
            i = log2(oldArray.length + 1);

            for(j = log2(newArraySize) + 1; i < j; ++i) {
               movingToArray += nums[i];
            }
         } else if (oldArray.length > newArraySize) {
            i = log2(newArraySize + 1);

            for(j = log2(oldArray.length) + 1; i < j; ++i) {
               movingToArray -= nums[i];
            }
         }

         System.arraycopy(oldArray, 0, newArray, 0, Math.min(oldArray.length, newArraySize));
      } else {
         newArray = this.array;
      }

      i = this.hashEntries - movingToArray + (newKey >= 0 && newKey <= newArraySize ? 0 : 1);
      j = oldHash.length;
      LuaTable.Slot[] newHash;
      int newHashMask;
      if (i > 0) {
         int newCapacity = i < 2 ? 2 : 1 << log2(i);
         newHashMask = newCapacity - 1;
         newHash = new LuaTable.Slot[newCapacity];
      } else {
         int newCapacity = false;
         newHashMask = 0;
         newHash = NOBUCKETS;
      }

      int i;
      int slot;
      for(i = 0; i < j; ++i) {
         for(LuaTable.Slot slot = oldHash[i]; slot != null; slot = slot.rest()) {
            if ((slot = slot.arraykey(newArraySize)) > 0) {
               LuaTable.StrongSlot entry = slot.first();
               if (entry != null) {
                  newArray[slot - 1] = entry.value();
               }
            } else {
               int j = slot.keyindex(newHashMask);
               newHash[j] = slot.relink(newHash[j]);
            }
         }
      }

      i = newArraySize;

      while(true) {
         Object newEntry;
         while(true) {
            LuaValue v;
            do {
               if (i >= oldArray.length) {
                  this.hash = newHash;
                  this.array = newArray;
                  this.hashEntries -= movingToArray;
                  return;
               }
            } while((v = oldArray[i++]) == null);

            slot = hashmod(LuaInteger.hashCode(i), newHashMask);
            if (this.m_metatable != null) {
               newEntry = this.m_metatable.entry(valueOf(i), v);
               if (newEntry == null) {
                  continue;
               }
               break;
            }

            newEntry = defaultEntry(valueOf(i), v);
            break;
         }

         newHash[slot] = (LuaTable.Slot)(newHash[slot] != null ? newHash[slot].add((LuaTable.Slot)newEntry) : newEntry);
      }
   }

   public LuaTable.Slot entry(LuaValue key, LuaValue value) {
      return defaultEntry(key, value);
   }

   protected static boolean isLargeKey(LuaValue key) {
      switch(key.type()) {
      case 1:
      case 3:
         return false;
      case 2:
      default:
         return true;
      case 4:
         return key.rawlen() > 32;
      }
   }

   protected static LuaTable.Entry defaultEntry(LuaValue key, LuaValue value) {
      if (key.isinttype()) {
         return new LuaTable.IntKeyEntry(key.toint(), value);
      } else {
         return (LuaTable.Entry)(value.type() == 3 ? new LuaTable.NumberValueEntry(key, value.todouble()) : new LuaTable.NormalEntry(key, value));
      }
   }

   public void sort(LuaValue comparator) {
      if (this.m_metatable != null && this.m_metatable.useWeakValues()) {
         this.dropWeakArrayValues();
      }

      int n;
      for(n = this.array.length; n > 0 && this.array[n - 1] == null; --n) {
      }

      if (n > 1) {
         this.heapSort(n, comparator);
      }

   }

   private void heapSort(int count, LuaValue cmpfunc) {
      this.heapify(count, cmpfunc);
      int end = count - 1;

      while(end > 0) {
         this.swap(end, 0);
         --end;
         this.siftDown(0, end, cmpfunc);
      }

   }

   private void heapify(int count, LuaValue cmpfunc) {
      for(int start = count / 2 - 1; start >= 0; --start) {
         this.siftDown(start, count - 1, cmpfunc);
      }

   }

   private void siftDown(int start, int end, LuaValue cmpfunc) {
      int child;
      for(int root = start; root * 2 + 1 <= end; root = child) {
         child = root * 2 + 1;
         if (child < end && this.compare(child, child + 1, cmpfunc)) {
            ++child;
         }

         if (!this.compare(root, child, cmpfunc)) {
            return;
         }

         this.swap(root, child);
      }

   }

   private boolean compare(int i, int j, LuaValue cmpfunc) {
      LuaValue a;
      LuaValue b;
      if (this.m_metatable == null) {
         a = this.array[i];
         b = this.array[j];
      } else {
         a = this.m_metatable.arrayget(this.array, i);
         b = this.m_metatable.arrayget(this.array, j);
      }

      if (a != null && b != null) {
         return !cmpfunc.isnil() ? cmpfunc.call(a, b).toboolean() : a.lt_b(b);
      } else {
         return false;
      }
   }

   private void swap(int i, int j) {
      LuaValue a = this.array[i];
      this.array[i] = this.array[j];
      this.array[j] = a;
   }

   public int keyCount() {
      LuaValue k = LuaValue.NIL;
      int i = 0;

      while(true) {
         Varargs n = this.next(k);
         if ((k = n.arg1()).isnil()) {
            return i;
         }

         ++i;
      }
   }

   public LuaValue[] keys() {
      Vector l = new Vector();
      LuaValue k = LuaValue.NIL;

      while(true) {
         Varargs n = this.next(k);
         if ((k = n.arg1()).isnil()) {
            LuaValue[] a = new LuaValue[l.size()];
            l.copyInto(a);
            return a;
         }

         l.addElement(k);
      }
   }

   public LuaValue eq(LuaValue val) {
      return this.eq_b(val) ? TRUE : FALSE;
   }

   public boolean eq_b(LuaValue val) {
      if (this == val) {
         return true;
      } else if (this.m_metatable != null && val.istable()) {
         LuaValue valmt = val.getmetatable();
         return valmt != null && LuaValue.eqmtcall(this, this.m_metatable.toLuaValue(), val, valmt);
      } else {
         return false;
      }
   }

   public Varargs unpack() {
      return this.unpack(1, this.rawlen());
   }

   public Varargs unpack(int i) {
      return this.unpack(i, this.rawlen());
   }

   public Varargs unpack(int i, int j) {
      int n = j + 1 - i;
      switch(n) {
      case 0:
         return NONE;
      case 1:
         return this.get(i);
      case 2:
         return varargsOf(this.get(i), this.get(i + 1));
      default:
         if (n < 0) {
            return NONE;
         } else {
            LuaValue[] v = new LuaValue[n];

            while(true) {
               --n;
               if (n < 0) {
                  return varargsOf(v);
               }

               v[n] = this.get(i + n);
            }
         }
      }
   }

   public boolean useWeakKeys() {
      return false;
   }

   public boolean useWeakValues() {
      return false;
   }

   public LuaValue toLuaValue() {
      return this;
   }

   public LuaValue wrap(LuaValue value) {
      return value;
   }

   public LuaValue arrayget(LuaValue[] array, int index) {
      return array[index];
   }

   @Environment(EnvType.CLIENT)
   interface Slot {
      int keyindex(int var1);

      LuaTable.StrongSlot first();

      LuaTable.StrongSlot find(LuaValue var1);

      boolean keyeq(LuaValue var1);

      LuaTable.Slot rest();

      int arraykey(int var1);

      LuaTable.Slot set(LuaTable.StrongSlot var1, LuaValue var2);

      LuaTable.Slot add(LuaTable.Slot var1);

      LuaTable.Slot remove(LuaTable.StrongSlot var1);

      LuaTable.Slot relink(LuaTable.Slot var1);
   }

   @Environment(EnvType.CLIENT)
   interface StrongSlot extends LuaTable.Slot {
      LuaValue key();

      LuaValue value();

      Varargs toVarargs();
   }

   @Environment(EnvType.CLIENT)
   abstract static class Entry extends Varargs implements LuaTable.StrongSlot {
      public abstract LuaValue key();

      public abstract LuaValue value();

      abstract LuaTable.Entry set(LuaValue var1);

      public abstract boolean keyeq(LuaValue var1);

      public abstract int keyindex(int var1);

      public int arraykey(int max) {
         return 0;
      }

      public LuaValue arg(int i) {
         switch(i) {
         case 1:
            return this.key();
         case 2:
            return this.value();
         default:
            return LuaValue.NIL;
         }
      }

      public int narg() {
         return 2;
      }

      public Varargs toVarargs() {
         return LuaValue.varargsOf((LuaValue)this.key(), this.value());
      }

      public LuaValue arg1() {
         return this.key();
      }

      public Varargs subargs(int start) {
         switch(start) {
         case 1:
            return this;
         case 2:
            return this.value();
         default:
            return LuaValue.NONE;
         }
      }

      public LuaTable.StrongSlot first() {
         return this;
      }

      public LuaTable.Slot rest() {
         return null;
      }

      public LuaTable.StrongSlot find(LuaValue key) {
         return this.keyeq(key) ? this : null;
      }

      public LuaTable.Slot set(LuaTable.StrongSlot target, LuaValue value) {
         return this.set(value);
      }

      public LuaTable.Slot add(LuaTable.Slot entry) {
         return new LuaTable.LinkSlot(this, entry);
      }

      public LuaTable.Slot remove(LuaTable.StrongSlot target) {
         return new LuaTable.DeadSlot(this.key(), (LuaTable.Slot)null);
      }

      public LuaTable.Slot relink(LuaTable.Slot rest) {
         return (LuaTable.Slot)(rest != null ? new LuaTable.LinkSlot(this, rest) : this);
      }
   }

   @Environment(EnvType.CLIENT)
   private static class IntKeyEntry extends LuaTable.Entry {
      private final int key;
      private LuaValue value;

      IntKeyEntry(int key, LuaValue value) {
         this.key = key;
         this.value = value;
      }

      public LuaValue key() {
         return LuaValue.valueOf(this.key);
      }

      public int arraykey(int max) {
         return this.key >= 1 && this.key <= max ? this.key : 0;
      }

      public LuaValue value() {
         return this.value;
      }

      public LuaTable.Entry set(LuaValue value) {
         this.value = value;
         return this;
      }

      public int keyindex(int mask) {
         return LuaTable.hashmod(LuaInteger.hashCode(this.key), mask);
      }

      public boolean keyeq(LuaValue key) {
         return key.raweq(this.key);
      }
   }

   @Environment(EnvType.CLIENT)
   private static class NumberValueEntry extends LuaTable.Entry {
      private double value;
      private final LuaValue key;

      NumberValueEntry(LuaValue key, double value) {
         this.key = key;
         this.value = value;
      }

      public LuaValue key() {
         return this.key;
      }

      public LuaValue value() {
         return LuaValue.valueOf(this.value);
      }

      public LuaTable.Entry set(LuaValue value) {
         LuaValue n = value.tonumber();
         if (!n.isnil()) {
            this.value = n.todouble();
            return this;
         } else {
            return new LuaTable.NormalEntry(this.key, value);
         }
      }

      public int keyindex(int mask) {
         return LuaTable.hashSlot(this.key, mask);
      }

      public boolean keyeq(LuaValue key) {
         return key.raweq(this.key);
      }
   }

   @Environment(EnvType.CLIENT)
   static class NormalEntry extends LuaTable.Entry {
      private final LuaValue key;
      private LuaValue value;

      NormalEntry(LuaValue key, LuaValue value) {
         this.key = key;
         this.value = value;
      }

      public LuaValue key() {
         return this.key;
      }

      public LuaValue value() {
         return this.value;
      }

      public LuaTable.Entry set(LuaValue value) {
         this.value = value;
         return this;
      }

      public Varargs toVarargs() {
         return this;
      }

      public int keyindex(int hashMask) {
         return LuaTable.hashSlot(this.key, hashMask);
      }

      public boolean keyeq(LuaValue key) {
         return key.raweq(this.key);
      }
   }

   @Environment(EnvType.CLIENT)
   private static class DeadSlot implements LuaTable.Slot {
      private final Object key;
      private LuaTable.Slot next;

      private DeadSlot(LuaValue key, LuaTable.Slot next) {
         this.key = LuaTable.isLargeKey(key) ? new WeakReference(key) : key;
         this.next = next;
      }

      private LuaValue key() {
         return (LuaValue)(this.key instanceof WeakReference ? ((WeakReference)this.key).get() : this.key);
      }

      public int keyindex(int hashMask) {
         return 0;
      }

      public LuaTable.StrongSlot first() {
         return null;
      }

      public LuaTable.StrongSlot find(LuaValue key) {
         return null;
      }

      public boolean keyeq(LuaValue key) {
         LuaValue k = this.key();
         return k != null && key.raweq(k);
      }

      public LuaTable.Slot rest() {
         return this.next;
      }

      public int arraykey(int max) {
         return -1;
      }

      public LuaTable.Slot set(LuaTable.StrongSlot target, LuaValue value) {
         LuaTable.Slot next = this.next != null ? this.next.set(target, value) : null;
         if (this.key() != null) {
            this.next = next;
            return this;
         } else {
            return next;
         }
      }

      public LuaTable.Slot add(LuaTable.Slot newEntry) {
         return this.next != null ? this.next.add(newEntry) : newEntry;
      }

      public LuaTable.Slot remove(LuaTable.StrongSlot target) {
         if (this.key() != null) {
            this.next = this.next.remove(target);
            return this;
         } else {
            return this.next;
         }
      }

      public LuaTable.Slot relink(LuaTable.Slot rest) {
         return rest;
      }

      public String toString() {
         StringBuffer buf = new StringBuffer();
         buf.append("<dead");
         LuaValue k = this.key();
         if (k != null) {
            buf.append(": ");
            buf.append(k.toString());
         }

         buf.append('>');
         if (this.next != null) {
            buf.append("; ");
            buf.append(this.next.toString());
         }

         return buf.toString();
      }
   }

   @Environment(EnvType.CLIENT)
   private static class LinkSlot implements LuaTable.StrongSlot {
      private LuaTable.Entry entry;
      private LuaTable.Slot next;

      LinkSlot(LuaTable.Entry entry, LuaTable.Slot next) {
         this.entry = entry;
         this.next = next;
      }

      public LuaValue key() {
         return this.entry.key();
      }

      public int keyindex(int hashMask) {
         return this.entry.keyindex(hashMask);
      }

      public LuaValue value() {
         return this.entry.value();
      }

      public Varargs toVarargs() {
         return this.entry.toVarargs();
      }

      public LuaTable.StrongSlot first() {
         return this.entry;
      }

      public LuaTable.StrongSlot find(LuaValue key) {
         return this.entry.keyeq(key) ? this : null;
      }

      public boolean keyeq(LuaValue key) {
         return this.entry.keyeq(key);
      }

      public LuaTable.Slot rest() {
         return this.next;
      }

      public int arraykey(int max) {
         return this.entry.arraykey(max);
      }

      public LuaTable.Slot set(LuaTable.StrongSlot target, LuaValue value) {
         if (target == this) {
            this.entry = this.entry.set(value);
            return this;
         } else {
            return this.setnext(this.next.set(target, value));
         }
      }

      public LuaTable.Slot add(LuaTable.Slot entry) {
         return this.setnext(this.next.add(entry));
      }

      public LuaTable.Slot remove(LuaTable.StrongSlot target) {
         if (this == target) {
            return new LuaTable.DeadSlot(this.key(), this.next);
         } else {
            this.next = this.next.remove(target);
            return this;
         }
      }

      public LuaTable.Slot relink(LuaTable.Slot rest) {
         return (LuaTable.Slot)(rest != null ? new LuaTable.LinkSlot(this.entry, rest) : this.entry);
      }

      private LuaTable.Slot setnext(LuaTable.Slot next) {
         if (next != null) {
            this.next = next;
            return this;
         } else {
            return this.entry;
         }
      }

      public String toString() {
         String var10000 = String.valueOf(this.entry);
         return var10000 + "; " + String.valueOf(this.next);
      }
   }
}
