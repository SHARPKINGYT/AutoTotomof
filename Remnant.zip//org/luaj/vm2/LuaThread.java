package org.luaj.vm2;

import java.lang.ref.WeakReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LuaThread extends LuaValue {
   public static LuaValue s_metatable;
   public static int coroutine_count = 0;
   public static long thread_orphan_check_interval = 5000L;
   public static final int STATUS_INITIAL = 0;
   public static final int STATUS_SUSPENDED = 1;
   public static final int STATUS_RUNNING = 2;
   public static final int STATUS_NORMAL = 3;
   public static final int STATUS_DEAD = 4;
   public static final String[] STATUS_NAMES = new String[]{"suspended", "suspended", "running", "normal", "dead"};
   public final LuaThread.State state;
   public static final int MAX_CALLSTACK = 256;
   public Object callstack;
   public final Globals globals;
   public LuaValue errorfunc;

   public LuaThread(Globals globals) {
      this.state = new LuaThread.State(globals, this, (LuaValue)null);
      this.state.status = 2;
      this.globals = globals;
   }

   public LuaThread(Globals globals, LuaValue func) {
      LuaValue.assert_(func != null, "function cannot be null");
      this.state = new LuaThread.State(globals, this, func);
      this.globals = globals;
   }

   public int type() {
      return 8;
   }

   public String typename() {
      return "thread";
   }

   public boolean isthread() {
      return true;
   }

   public LuaThread optthread(LuaThread defval) {
      return this;
   }

   public LuaThread checkthread() {
      return this;
   }

   public LuaValue getmetatable() {
      return s_metatable;
   }

   public String getStatus() {
      return STATUS_NAMES[this.state.status];
   }

   public boolean isMainThread() {
      return this.state.function == null;
   }

   public Varargs resume(Varargs args) {
      LuaThread.State s = this.state;
      return s.status > 1 ? LuaValue.varargsOf((LuaValue)LuaValue.FALSE, LuaValue.valueOf("cannot resume " + (s.status == 4 ? "dead" : "non-suspended") + " coroutine")) : s.lua_resume(this, args);
   }

   @Environment(EnvType.CLIENT)
   public static class State implements Runnable {
      private final Globals globals;
      final WeakReference lua_thread;
      public final LuaValue function;
      Varargs args;
      Varargs result;
      String error;
      public LuaValue hookfunc;
      public boolean hookline;
      public boolean hookcall;
      public boolean hookrtrn;
      public int hookcount;
      public boolean inhook;
      public int lastline;
      public int bytecodes;
      public int status;

      State(Globals globals, LuaThread lua_thread, LuaValue function) {
         this.args = LuaValue.NONE;
         this.result = LuaValue.NONE;
         this.error = null;
         this.status = 0;
         this.globals = globals;
         this.lua_thread = new WeakReference(lua_thread);
         this.function = function;
      }

      public synchronized void run() {
         try {
            Varargs a = this.args;
            this.args = LuaValue.NONE;
            this.result = this.function.invoke(a);
         } catch (Throwable var5) {
            this.error = var5.getMessage();
         } finally {
            this.status = 4;
            this.notify();
         }

      }

      public synchronized Varargs lua_resume(LuaThread new_thread, Varargs args) {
         LuaThread previous_thread = this.globals.running;

         Varargs var4;
         try {
            this.globals.running = new_thread;
            this.args = args;
            if (this.status == 0) {
               this.status = 2;
               int var10003 = ++LuaThread.coroutine_count;
               (new Thread(this, "Coroutine-" + var10003)).start();
            } else {
               this.notify();
            }

            if (previous_thread != null) {
               previous_thread.state.status = 3;
            }

            this.status = 2;
            this.wait();
            var4 = this.error != null ? LuaValue.varargsOf((LuaValue)LuaValue.FALSE, LuaValue.valueOf(this.error)) : LuaValue.varargsOf((LuaValue)LuaValue.TRUE, this.result);
         } catch (InterruptedException var8) {
            throw new OrphanedThread();
         } finally {
            this.args = LuaValue.NONE;
            this.result = LuaValue.NONE;
            this.error = null;
            this.globals.running = previous_thread;
            if (previous_thread != null) {
               this.globals.running.state.status = 2;
            }

         }

         return var4;
      }

      public synchronized Varargs lua_yield(Varargs args) {
         try {
            this.result = args;
            this.status = 1;
            this.notify();

            do {
               this.wait(LuaThread.thread_orphan_check_interval);
               if (this.lua_thread.get() == null) {
                  this.status = 4;
                  throw new OrphanedThread();
               }
            } while(this.status == 1);

            Varargs var2 = this.args;
            return var2;
         } catch (InterruptedException var6) {
            this.status = 4;
            throw new OrphanedThread();
         } finally {
            this.args = LuaValue.NONE;
            this.result = LuaValue.NONE;
         }
      }
   }
}
