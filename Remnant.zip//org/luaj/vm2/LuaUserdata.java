package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LuaUserdata extends LuaValue {
   public Object m_instance;
   public LuaValue m_metatable;

   public LuaUserdata(Object obj) {
      this.m_instance = obj;
   }

   public LuaUserdata(Object obj, LuaValue metatable) {
      this.m_instance = obj;
      this.m_metatable = metatable;
   }

   public String tojstring() {
      return String.valueOf(this.m_instance);
   }

   public int type() {
      return 7;
   }

   public String typename() {
      return "userdata";
   }

   public int hashCode() {
      return this.m_instance.hashCode();
   }

   public Object userdata() {
      return this.m_instance;
   }

   public boolean isuserdata() {
      return true;
   }

   public boolean isuserdata(Class c) {
      return c.isAssignableFrom(this.m_instance.getClass());
   }

   public Object touserdata() {
      return this.m_instance;
   }

   public Object touserdata(Class c) {
      return c.isAssignableFrom(this.m_instance.getClass()) ? this.m_instance : null;
   }

   public Object optuserdata(Object defval) {
      return this.m_instance;
   }

   public Object optuserdata(Class c, Object defval) {
      if (!c.isAssignableFrom(this.m_instance.getClass())) {
         this.typerror(c.getName());
      }

      return this.m_instance;
   }

   public LuaValue getmetatable() {
      return this.m_metatable;
   }

   public LuaValue setmetatable(LuaValue metatable) {
      this.m_metatable = metatable;
      return this;
   }

   public Object checkuserdata() {
      return this.m_instance;
   }

   public Object checkuserdata(Class c) {
      return c.isAssignableFrom(this.m_instance.getClass()) ? this.m_instance : this.typerror(c.getName());
   }

   public LuaValue get(LuaValue key) {
      return this.m_metatable != null ? gettable(this, key) : NIL;
   }

   public void set(LuaValue key, LuaValue value) {
      if (this.m_metatable == null || !settable(this, key, value)) {
         error("cannot set " + String.valueOf(key) + " for userdata");
      }

   }

   public boolean equals(Object val) {
      if (this == val) {
         return true;
      } else if (!(val instanceof LuaUserdata)) {
         return false;
      } else {
         LuaUserdata u = (LuaUserdata)val;
         return this.m_instance.equals(u.m_instance);
      }
   }

   public LuaValue eq(LuaValue val) {
      return this.eq_b(val) ? TRUE : FALSE;
   }

   public boolean eq_b(LuaValue val) {
      if (val.raweq(this)) {
         return true;
      } else if (this.m_metatable != null && val.isuserdata()) {
         LuaValue valmt = val.getmetatable();
         return valmt != null && LuaValue.eqmtcall(this, this.m_metatable, val, valmt);
      } else {
         return false;
      }
   }

   public boolean raweq(LuaValue val) {
      return val.raweq(this);
   }

   public boolean raweq(LuaUserdata val) {
      return this == val || this.m_metatable == val.m_metatable && this.m_instance.equals(val.m_instance);
   }

   public boolean eqmt(LuaValue val) {
      return this.m_metatable != null && val.isuserdata() ? LuaValue.eqmtcall(this, this.m_metatable, val, val.getmetatable()) : false;
   }
}
