package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class LuaValue extends Varargs {
   public static final int TINT = -2;
   public static final int TNONE = -1;
   public static final int TNIL = 0;
   public static final int TBOOLEAN = 1;
   public static final int TLIGHTUSERDATA = 2;
   public static final int TNUMBER = 3;
   public static final int TSTRING = 4;
   public static final int TTABLE = 5;
   public static final int TFUNCTION = 6;
   public static final int TUSERDATA = 7;
   public static final int TTHREAD = 8;
   public static final int TVALUE = 9;
   public static final String[] TYPE_NAMES = new String[]{"nil", "boolean", "lightuserdata", "number", "string", "table", "function", "userdata", "thread", "value"};
   public static final LuaValue NIL;
   public static final LuaBoolean TRUE;
   public static final LuaBoolean FALSE;
   public static final LuaValue NONE;
   public static final LuaNumber ZERO;
   public static final LuaNumber ONE;
   public static final LuaNumber MINUSONE;
   public static final LuaValue[] NOVALS;
   public static LuaString ENV;
   public static final LuaString INDEX;
   public static final LuaString NEWINDEX;
   public static final LuaString CALL;
   public static final LuaString MODE;
   public static final LuaString METATABLE;
   public static final LuaString ADD;
   public static final LuaString SUB;
   public static final LuaString DIV;
   public static final LuaString MUL;
   public static final LuaString POW;
   public static final LuaString MOD;
   public static final LuaString UNM;
   public static final LuaString LEN;
   public static final LuaString EQ;
   public static final LuaString LT;
   public static final LuaString LE;
   public static final LuaString TOSTRING;
   public static final LuaString CONCAT;
   public static final LuaString EMPTYSTRING;
   private static int MAXSTACK;
   public static final LuaValue[] NILS;
   private static final int MAXTAGLOOP = 100;

   public abstract int type();

   public abstract String typename();

   public boolean isboolean() {
      return false;
   }

   public boolean isclosure() {
      return false;
   }

   public boolean isfunction() {
      return false;
   }

   public boolean isint() {
      return false;
   }

   public boolean isinttype() {
      return false;
   }

   public boolean islong() {
      return false;
   }

   public boolean isnil() {
      return false;
   }

   public boolean isnumber() {
      return false;
   }

   public boolean isstring() {
      return false;
   }

   public boolean isthread() {
      return false;
   }

   public boolean istable() {
      return false;
   }

   public boolean isuserdata() {
      return false;
   }

   public boolean isuserdata(Class c) {
      return false;
   }

   public boolean toboolean() {
      return true;
   }

   public byte tobyte() {
      return 0;
   }

   public char tochar() {
      return '\u0000';
   }

   public double todouble() {
      return 0.0D;
   }

   public float tofloat() {
      return 0.0F;
   }

   public int toint() {
      return 0;
   }

   public long tolong() {
      return 0L;
   }

   public short toshort() {
      return 0;
   }

   public String tojstring() {
      String var10000 = this.typename();
      return var10000 + ": " + Integer.toHexString(this.hashCode());
   }

   public Object touserdata() {
      return null;
   }

   public Object touserdata(Class c) {
      return null;
   }

   public String toString() {
      return this.tojstring();
   }

   public LuaValue tonumber() {
      return NIL;
   }

   public LuaValue tostring() {
      return NIL;
   }

   public boolean optboolean(boolean defval) {
      this.argerror("boolean");
      return false;
   }

   public LuaClosure optclosure(LuaClosure defval) {
      this.argerror("closure");
      return null;
   }

   public double optdouble(double defval) {
      this.argerror("double");
      return 0.0D;
   }

   public LuaFunction optfunction(LuaFunction defval) {
      this.argerror("function");
      return null;
   }

   public int optint(int defval) {
      this.argerror("int");
      return 0;
   }

   public LuaInteger optinteger(LuaInteger defval) {
      this.argerror("integer");
      return null;
   }

   public long optlong(long defval) {
      this.argerror("long");
      return 0L;
   }

   public LuaNumber optnumber(LuaNumber defval) {
      this.argerror("number");
      return null;
   }

   public String optjstring(String defval) {
      this.argerror("String");
      return null;
   }

   public LuaString optstring(LuaString defval) {
      this.argerror("string");
      return null;
   }

   public LuaTable opttable(LuaTable defval) {
      this.argerror("table");
      return null;
   }

   public LuaThread optthread(LuaThread defval) {
      this.argerror("thread");
      return null;
   }

   public Object optuserdata(Object defval) {
      this.argerror("object");
      return null;
   }

   public Object optuserdata(Class c, Object defval) {
      this.argerror(c.getName());
      return null;
   }

   public LuaValue optvalue(LuaValue defval) {
      return this;
   }

   public boolean checkboolean() {
      this.argerror("boolean");
      return false;
   }

   public LuaClosure checkclosure() {
      this.argerror("closure");
      return null;
   }

   public double checkdouble() {
      this.argerror("double");
      return 0.0D;
   }

   public LuaFunction checkfunction() {
      this.argerror("function");
      return null;
   }

   public Globals checkglobals() {
      this.argerror("globals");
      return null;
   }

   public int checkint() {
      this.argerror("int");
      return 0;
   }

   public LuaInteger checkinteger() {
      this.argerror("integer");
      return null;
   }

   public long checklong() {
      this.argerror("long");
      return 0L;
   }

   public LuaNumber checknumber() {
      this.argerror("number");
      return null;
   }

   public LuaNumber checknumber(String msg) {
      throw new LuaError(msg);
   }

   public String checkjstring() {
      this.argerror("string");
      return null;
   }

   public LuaString checkstring() {
      this.argerror("string");
      return null;
   }

   public LuaTable checktable() {
      this.argerror("table");
      return null;
   }

   public LuaThread checkthread() {
      this.argerror("thread");
      return null;
   }

   public Object checkuserdata() {
      this.argerror("userdata");
      return null;
   }

   public Object checkuserdata(Class c) {
      this.argerror("userdata");
      return null;
   }

   public LuaValue checknotnil() {
      return this;
   }

   public boolean isvalidkey() {
      return true;
   }

   public static LuaValue error(String message) {
      throw new LuaError(message);
   }

   public static void assert_(boolean b, String msg) {
      if (!b) {
         throw new LuaError(msg);
      }
   }

   protected LuaValue argerror(String expected) {
      throw new LuaError("bad argument: " + expected + " expected, got " + this.typename());
   }

   public static LuaValue argerror(int iarg, String msg) {
      throw new LuaError("bad argument #" + iarg + ": " + msg);
   }

   protected LuaValue typerror(String expected) {
      throw new LuaError(expected + " expected, got " + this.typename());
   }

   protected LuaValue unimplemented(String fun) {
      throw new LuaError("'" + fun + "' not implemented for " + this.typename());
   }

   protected LuaValue illegal(String op, String typename) {
      throw new LuaError("illegal operation '" + op + "' for " + typename);
   }

   protected LuaValue lenerror() {
      throw new LuaError("attempt to get length of " + this.typename());
   }

   protected LuaValue aritherror() {
      throw new LuaError("attempt to perform arithmetic on " + this.typename());
   }

   protected LuaValue aritherror(String fun) {
      throw new LuaError("attempt to perform arithmetic '" + fun + "' on " + this.typename());
   }

   protected LuaValue compareerror(String rhs) {
      String var10002 = this.typename();
      throw new LuaError("attempt to compare " + var10002 + " with " + rhs);
   }

   protected LuaValue compareerror(LuaValue rhs) {
      String var10002 = this.typename();
      throw new LuaError("attempt to compare " + var10002 + " with " + rhs.typename());
   }

   public LuaValue get(LuaValue key) {
      return gettable(this, key);
   }

   public LuaValue get(int key) {
      return this.get((LuaValue)LuaInteger.valueOf(key));
   }

   public LuaValue get(String key) {
      return this.get((LuaValue)valueOf(key));
   }

   public void set(LuaValue key, LuaValue value) {
      settable(this, key, value);
   }

   public void set(int key, LuaValue value) {
      this.set((LuaValue)LuaInteger.valueOf(key), (LuaValue)value);
   }

   public void set(int key, String value) {
      this.set(key, (LuaValue)valueOf(value));
   }

   public void set(String key, LuaValue value) {
      this.set((LuaValue)valueOf(key), (LuaValue)value);
   }

   public void set(String key, double value) {
      this.set((LuaValue)valueOf(key), (LuaValue)valueOf(value));
   }

   public void set(String key, int value) {
      this.set((LuaValue)valueOf(key), (LuaValue)valueOf(value));
   }

   public void set(String key, String value) {
      this.set((LuaValue)valueOf(key), (LuaValue)valueOf(value));
   }

   public LuaValue rawget(LuaValue key) {
      return this.unimplemented("rawget");
   }

   public LuaValue rawget(int key) {
      return this.rawget((LuaValue)valueOf(key));
   }

   public LuaValue rawget(String key) {
      return this.rawget((LuaValue)valueOf(key));
   }

   public void rawset(LuaValue key, LuaValue value) {
      this.unimplemented("rawset");
   }

   public void rawset(int key, LuaValue value) {
      this.rawset((LuaValue)valueOf(key), (LuaValue)value);
   }

   public void rawset(int key, String value) {
      this.rawset(key, (LuaValue)valueOf(value));
   }

   public void rawset(String key, LuaValue value) {
      this.rawset((LuaValue)valueOf(key), (LuaValue)value);
   }

   public void rawset(String key, double value) {
      this.rawset((LuaValue)valueOf(key), (LuaValue)valueOf(value));
   }

   public void rawset(String key, int value) {
      this.rawset((LuaValue)valueOf(key), (LuaValue)valueOf(value));
   }

   public void rawset(String key, String value) {
      this.rawset((LuaValue)valueOf(key), (LuaValue)valueOf(value));
   }

   public void rawsetlist(int key0, Varargs values) {
      int i = 0;

      for(int n = values.narg(); i < n; ++i) {
         this.rawset(key0 + i, values.arg(i + 1));
      }

   }

   public void presize(int i) {
      this.typerror("table");
   }

   public Varargs next(LuaValue index) {
      return this.typerror("table");
   }

   public Varargs inext(LuaValue index) {
      return this.typerror("table");
   }

   public LuaValue load(LuaValue library) {
      return library.call(EMPTYSTRING, this);
   }

   public LuaValue arg(int index) {
      return index == 1 ? this : NIL;
   }

   public int narg() {
      return 1;
   }

   public LuaValue arg1() {
      return this;
   }

   public LuaValue getmetatable() {
      return null;
   }

   public LuaValue setmetatable(LuaValue metatable) {
      return this.argerror("table");
   }

   public LuaValue call() {
      return this.callmt().call(this);
   }

   public LuaValue call(LuaValue arg) {
      return this.callmt().call(this, arg);
   }

   public LuaValue call(String arg) {
      return this.call((LuaValue)valueOf(arg));
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2) {
      return this.callmt().call(this, arg1, arg2);
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
      return this.callmt().invoke(new LuaValue[]{this, arg1, arg2, arg3}).arg1();
   }

   public LuaValue method(String name) {
      return this.get(name).call(this);
   }

   public LuaValue method(LuaValue name) {
      return this.get(name).call(this);
   }

   public LuaValue method(String name, LuaValue arg) {
      return this.get(name).call(this, arg);
   }

   public LuaValue method(LuaValue name, LuaValue arg) {
      return this.get(name).call(this, arg);
   }

   public LuaValue method(String name, LuaValue arg1, LuaValue arg2) {
      return this.get(name).call(this, arg1, arg2);
   }

   public LuaValue method(LuaValue name, LuaValue arg1, LuaValue arg2) {
      return this.get(name).call(this, arg1, arg2);
   }

   public Varargs invoke() {
      return this.invoke((Varargs)NONE);
   }

   public Varargs invoke(Varargs args) {
      return this.callmt().invoke(this, args);
   }

   public Varargs invoke(LuaValue arg, Varargs varargs) {
      return this.invoke(varargsOf(arg, varargs));
   }

   public Varargs invoke(LuaValue arg1, LuaValue arg2, Varargs varargs) {
      return this.invoke(varargsOf(arg1, arg2, varargs));
   }

   public Varargs invoke(LuaValue[] args) {
      return this.invoke(varargsOf(args));
   }

   public Varargs invoke(LuaValue[] args, Varargs varargs) {
      return this.invoke(varargsOf(args, varargs));
   }

   public Varargs invokemethod(String name) {
      return this.get(name).invoke((Varargs)this);
   }

   public Varargs invokemethod(LuaValue name) {
      return this.get(name).invoke((Varargs)this);
   }

   public Varargs invokemethod(String name, Varargs args) {
      return this.get(name).invoke(varargsOf(this, args));
   }

   public Varargs invokemethod(LuaValue name, Varargs args) {
      return this.get(name).invoke(varargsOf(this, args));
   }

   public Varargs invokemethod(String name, LuaValue[] args) {
      return this.get(name).invoke(varargsOf(this, varargsOf(args)));
   }

   public Varargs invokemethod(LuaValue name, LuaValue[] args) {
      return this.get(name).invoke(varargsOf(this, varargsOf(args)));
   }

   protected LuaValue callmt() {
      return this.checkmetatag(CALL, "attempt to call ");
   }

   public LuaValue not() {
      return FALSE;
   }

   public LuaValue neg() {
      return this.checkmetatag(UNM, "attempt to perform arithmetic on ").call(this);
   }

   public LuaValue len() {
      return this.checkmetatag(LEN, "attempt to get length of ").call(this);
   }

   public int length() {
      return this.len().toint();
   }

   public int rawlen() {
      this.typerror("table or string");
      return 0;
   }

   public boolean equals(Object obj) {
      return this == obj;
   }

   public LuaValue eq(LuaValue val) {
      return this == val ? TRUE : FALSE;
   }

   public boolean eq_b(LuaValue val) {
      return this == val;
   }

   public LuaValue neq(LuaValue val) {
      return this.eq_b(val) ? FALSE : TRUE;
   }

   public boolean neq_b(LuaValue val) {
      return !this.eq_b(val);
   }

   public boolean raweq(LuaValue val) {
      return this == val;
   }

   public boolean raweq(LuaUserdata val) {
      return false;
   }

   public boolean raweq(LuaString val) {
      return false;
   }

   public boolean raweq(double val) {
      return false;
   }

   public boolean raweq(int val) {
      return false;
   }

   public static final boolean eqmtcall(LuaValue lhs, LuaValue lhsmt, LuaValue rhs, LuaValue rhsmt) {
      LuaValue h = lhsmt.rawget((LuaValue)EQ);
      return !h.isnil() && h == rhsmt.rawget((LuaValue)EQ) ? h.call(lhs, rhs).toboolean() : false;
   }

   public LuaValue add(LuaValue rhs) {
      return this.arithmt(ADD, rhs);
   }

   public LuaValue add(double rhs) {
      return this.arithmtwith(ADD, rhs);
   }

   public LuaValue add(int rhs) {
      return this.add((double)rhs);
   }

   public LuaValue sub(LuaValue rhs) {
      return this.arithmt(SUB, rhs);
   }

   public LuaValue sub(double rhs) {
      return this.aritherror("sub");
   }

   public LuaValue sub(int rhs) {
      return this.aritherror("sub");
   }

   public LuaValue subFrom(double lhs) {
      return this.arithmtwith(SUB, lhs);
   }

   public LuaValue subFrom(int lhs) {
      return this.subFrom((double)lhs);
   }

   public LuaValue mul(LuaValue rhs) {
      return this.arithmt(MUL, rhs);
   }

   public LuaValue mul(double rhs) {
      return this.arithmtwith(MUL, rhs);
   }

   public LuaValue mul(int rhs) {
      return this.mul((double)rhs);
   }

   public LuaValue pow(LuaValue rhs) {
      return this.arithmt(POW, rhs);
   }

   public LuaValue pow(double rhs) {
      return this.aritherror("pow");
   }

   public LuaValue pow(int rhs) {
      return this.aritherror("pow");
   }

   public LuaValue powWith(double lhs) {
      return this.arithmtwith(POW, lhs);
   }

   public LuaValue powWith(int lhs) {
      return this.powWith((double)lhs);
   }

   public LuaValue div(LuaValue rhs) {
      return this.arithmt(DIV, rhs);
   }

   public LuaValue div(double rhs) {
      return this.aritherror("div");
   }

   public LuaValue div(int rhs) {
      return this.aritherror("div");
   }

   public LuaValue divInto(double lhs) {
      return this.arithmtwith(DIV, lhs);
   }

   public LuaValue mod(LuaValue rhs) {
      return this.arithmt(MOD, rhs);
   }

   public LuaValue mod(double rhs) {
      return this.aritherror("mod");
   }

   public LuaValue mod(int rhs) {
      return this.aritherror("mod");
   }

   public LuaValue modFrom(double lhs) {
      return this.arithmtwith(MOD, lhs);
   }

   protected LuaValue arithmt(LuaValue tag, LuaValue op2) {
      LuaValue h = this.metatag(tag);
      if (h.isnil()) {
         h = op2.metatag(tag);
         if (h.isnil()) {
            String var10000 = String.valueOf(tag);
            error("attempt to perform arithmetic " + var10000 + " on " + this.typename() + " and " + op2.typename());
         }
      }

      return h.call(this, op2);
   }

   protected LuaValue arithmtwith(LuaValue tag, double op1) {
      LuaValue h = this.metatag(tag);
      if (h.isnil()) {
         String var10000 = String.valueOf(tag);
         error("attempt to perform arithmetic " + var10000 + " on number and " + this.typename());
      }

      return h.call(valueOf(op1), this);
   }

   public LuaValue lt(LuaValue rhs) {
      return this.comparemt(LT, rhs);
   }

   public LuaValue lt(double rhs) {
      return this.compareerror("number");
   }

   public LuaValue lt(int rhs) {
      return this.compareerror("number");
   }

   public boolean lt_b(LuaValue rhs) {
      return this.comparemt(LT, rhs).toboolean();
   }

   public boolean lt_b(int rhs) {
      this.compareerror("number");
      return false;
   }

   public boolean lt_b(double rhs) {
      this.compareerror("number");
      return false;
   }

   public LuaValue lteq(LuaValue rhs) {
      return this.comparemt(LE, rhs);
   }

   public LuaValue lteq(double rhs) {
      return this.compareerror("number");
   }

   public LuaValue lteq(int rhs) {
      return this.compareerror("number");
   }

   public boolean lteq_b(LuaValue rhs) {
      return this.comparemt(LE, rhs).toboolean();
   }

   public boolean lteq_b(int rhs) {
      this.compareerror("number");
      return false;
   }

   public boolean lteq_b(double rhs) {
      this.compareerror("number");
      return false;
   }

   public LuaValue gt(LuaValue rhs) {
      return rhs.comparemt(LE, this);
   }

   public LuaValue gt(double rhs) {
      return this.compareerror("number");
   }

   public LuaValue gt(int rhs) {
      return this.compareerror("number");
   }

   public boolean gt_b(LuaValue rhs) {
      return rhs.comparemt(LE, this).toboolean();
   }

   public boolean gt_b(int rhs) {
      this.compareerror("number");
      return false;
   }

   public boolean gt_b(double rhs) {
      this.compareerror("number");
      return false;
   }

   public LuaValue gteq(LuaValue rhs) {
      return rhs.comparemt(LT, this);
   }

   public LuaValue gteq(double rhs) {
      return this.compareerror("number");
   }

   public LuaValue gteq(int rhs) {
      return valueOf(this.todouble() >= (double)rhs);
   }

   public boolean gteq_b(LuaValue rhs) {
      return rhs.comparemt(LT, this).toboolean();
   }

   public boolean gteq_b(int rhs) {
      this.compareerror("number");
      return false;
   }

   public boolean gteq_b(double rhs) {
      this.compareerror("number");
      return false;
   }

   public LuaValue comparemt(LuaValue tag, LuaValue op1) {
      LuaValue h;
      if ((h = this.metatag(tag)).isnil() && (h = op1.metatag(tag)).isnil()) {
         if (!LE.raweq(tag) || (h = this.metatag(LT)).isnil() && (h = op1.metatag(LT)).isnil()) {
            String var10000 = String.valueOf(tag);
            return error("attempt to compare " + var10000 + " on " + this.typename() + " and " + op1.typename());
         } else {
            return h.call(op1, this).not();
         }
      } else {
         return h.call(this, op1);
      }
   }

   public int strcmp(LuaValue rhs) {
      error("attempt to compare " + this.typename());
      return 0;
   }

   public int strcmp(LuaString rhs) {
      error("attempt to compare " + this.typename());
      return 0;
   }

   public LuaValue concat(LuaValue rhs) {
      return this.concatmt(rhs);
   }

   public LuaValue concatTo(LuaValue lhs) {
      return lhs.concatmt(this);
   }

   public LuaValue concatTo(LuaNumber lhs) {
      return lhs.concatmt(this);
   }

   public LuaValue concatTo(LuaString lhs) {
      return lhs.concatmt(this);
   }

   public Buffer buffer() {
      return new Buffer(this);
   }

   public Buffer concat(Buffer rhs) {
      return rhs.concatTo(this);
   }

   public LuaValue concatmt(LuaValue rhs) {
      LuaValue h = this.metatag(CONCAT);
      if (h.isnil() && (h = rhs.metatag(CONCAT)).isnil()) {
         String var10000 = this.typename();
         error("attempt to concatenate " + var10000 + " and " + rhs.typename());
      }

      return h.call(this, rhs);
   }

   public LuaValue and(LuaValue rhs) {
      return this.toboolean() ? rhs : this;
   }

   public LuaValue or(LuaValue rhs) {
      return this.toboolean() ? this : rhs;
   }

   public boolean testfor_b(LuaValue limit, LuaValue step) {
      return step.gt_b(0) ? this.lteq_b(limit) : this.gteq_b(limit);
   }

   public LuaString strvalue() {
      this.typerror("strValue");
      return null;
   }

   public LuaValue strongvalue() {
      return this;
   }

   public static LuaBoolean valueOf(boolean b) {
      return b ? TRUE : FALSE;
   }

   public static LuaInteger valueOf(int i) {
      return LuaInteger.valueOf(i);
   }

   public static LuaNumber valueOf(double d) {
      return LuaDouble.valueOf(d);
   }

   public static LuaString valueOf(String s) {
      return LuaString.valueOf(s);
   }

   public static LuaString valueOf(byte[] bytes) {
      return LuaString.valueOf(bytes);
   }

   public static LuaString valueOf(byte[] bytes, int off, int len) {
      return LuaString.valueOf(bytes, off, len);
   }

   public static LuaTable tableOf() {
      return new LuaTable();
   }

   public static LuaTable tableOf(Varargs varargs, int firstarg) {
      return new LuaTable(varargs, firstarg);
   }

   public static LuaTable tableOf(int narray, int nhash) {
      return new LuaTable(narray, nhash);
   }

   public static LuaTable listOf(LuaValue[] unnamedValues) {
      return new LuaTable((LuaValue[])null, unnamedValues, (Varargs)null);
   }

   public static LuaTable listOf(LuaValue[] unnamedValues, Varargs lastarg) {
      return new LuaTable((LuaValue[])null, unnamedValues, lastarg);
   }

   public static LuaTable tableOf(LuaValue[] namedValues) {
      return new LuaTable(namedValues, (LuaValue[])null, (Varargs)null);
   }

   public static LuaTable tableOf(LuaValue[] namedValues, LuaValue[] unnamedValues) {
      return new LuaTable(namedValues, unnamedValues, (Varargs)null);
   }

   public static LuaTable tableOf(LuaValue[] namedValues, LuaValue[] unnamedValues, Varargs lastarg) {
      return new LuaTable(namedValues, unnamedValues, lastarg);
   }

   public static LuaUserdata userdataOf(Object o) {
      return new LuaUserdata(o);
   }

   public static LuaUserdata userdataOf(Object o, LuaValue metatable) {
      return new LuaUserdata(o, metatable);
   }

   protected static LuaValue gettable(LuaValue t, LuaValue key) {
      int loop = 0;

      do {
         LuaValue tm;
         if (t.istable()) {
            LuaValue res = t.rawget(key);
            if (!res.isnil() || (tm = t.metatag(INDEX)).isnil()) {
               return res;
            }
         } else if ((tm = t.metatag(INDEX)).isnil()) {
            t.indexerror();
         }

         if (tm.isfunction()) {
            return tm.call(t, key);
         }

         t = tm;
         ++loop;
      } while(loop < 100);

      error("loop in gettable");
      return NIL;
   }

   protected static boolean settable(LuaValue t, LuaValue key, LuaValue value) {
      int loop = 0;

      do {
         LuaValue tm;
         if (t.istable()) {
            if (!t.rawget(key).isnil() || (tm = t.metatag(NEWINDEX)).isnil()) {
               t.rawset(key, value);
               return true;
            }
         } else if ((tm = t.metatag(NEWINDEX)).isnil()) {
            t.typerror("index");
         }

         if (tm.isfunction()) {
            tm.call(t, key, value);
            return true;
         }

         t = tm;
         ++loop;
      } while(loop < 100);

      error("loop in settable");
      return false;
   }

   public LuaValue metatag(LuaValue tag) {
      LuaValue mt = this.getmetatable();
      return mt == null ? NIL : mt.rawget(tag);
   }

   protected LuaValue checkmetatag(LuaValue tag, String reason) {
      LuaValue h = this.metatag(tag);
      if (h.isnil()) {
         throw new LuaError(reason + this.typename());
      } else {
         return h;
      }
   }

   protected static Metatable metatableOf(LuaValue mt) {
      if (mt != null && mt.istable()) {
         LuaValue mode = mt.rawget((LuaValue)MODE);
         if (mode.isstring()) {
            String m = mode.tojstring();
            boolean weakkeys = m.indexOf(107) >= 0;
            boolean weakvalues = m.indexOf(118) >= 0;
            if (weakkeys || weakvalues) {
               return new WeakTable(weakkeys, weakvalues, mt);
            }
         }

         return (LuaTable)mt;
      } else {
         return mt != null ? new NonTableMetatable(mt) : null;
      }
   }

   private void indexerror() {
      error("attempt to index ? (a " + this.typename() + " value)");
   }

   public static Varargs varargsOf(LuaValue[] v) {
      switch(v.length) {
      case 0:
         return NONE;
      case 1:
         return v[0];
      case 2:
         return new Varargs.PairVarargs(v[0], v[1]);
      default:
         return new Varargs.ArrayVarargs(v, NONE);
      }
   }

   public static Varargs varargsOf(LuaValue[] v, Varargs r) {
      switch(v.length) {
      case 0:
         return r;
      case 1:
         return (Varargs)(r.narg() > 0 ? new Varargs.PairVarargs(v[0], r) : v[0]);
      case 2:
         return (Varargs)(r.narg() > 0 ? new Varargs.ArrayVarargs(v, r) : new Varargs.PairVarargs(v[0], v[1]));
      default:
         return new Varargs.ArrayVarargs(v, r);
      }
   }

   public static Varargs varargsOf(LuaValue[] v, int offset, int length) {
      switch(length) {
      case 0:
         return NONE;
      case 1:
         return v[offset];
      case 2:
         return new Varargs.PairVarargs(v[offset + 0], v[offset + 1]);
      default:
         return new Varargs.ArrayPartVarargs(v, offset, length, NONE);
      }
   }

   public static Varargs varargsOf(LuaValue[] v, int offset, int length, Varargs more) {
      switch(length) {
      case 0:
         return more;
      case 1:
         return (Varargs)(more.narg() > 0 ? new Varargs.PairVarargs(v[offset], more) : v[offset]);
      case 2:
         return (Varargs)(more.narg() > 0 ? new Varargs.ArrayPartVarargs(v, offset, length, more) : new Varargs.PairVarargs(v[offset], v[offset + 1]));
      default:
         return new Varargs.ArrayPartVarargs(v, offset, length, more);
      }
   }

   public static Varargs varargsOf(LuaValue v, Varargs r) {
      switch(r.narg()) {
      case 0:
         return v;
      default:
         return new Varargs.PairVarargs(v, r);
      }
   }

   public static Varargs varargsOf(LuaValue v1, LuaValue v2, Varargs v3) {
      switch(v3.narg()) {
      case 0:
         return new Varargs.PairVarargs(v1, v2);
      default:
         return new Varargs.ArrayPartVarargs(new LuaValue[]{v1, v2}, 0, 2, v3);
      }
   }

   public static Varargs tailcallOf(LuaValue func, Varargs args) {
      return new TailcallVarargs(func, args);
   }

   public Varargs onInvoke(Varargs args) {
      return this.invoke(args);
   }

   public void initupvalue1(LuaValue env) {
   }

   public Varargs subargs(int start) {
      if (start == 1) {
         return this;
      } else {
         return start > 1 ? NONE : argerror(1, "start must be > 0");
      }
   }

   static {
      NIL = LuaNil._NIL;
      TRUE = LuaBoolean._TRUE;
      FALSE = LuaBoolean._FALSE;
      NONE = LuaValue.None._NONE;
      ZERO = LuaInteger.valueOf(0);
      ONE = LuaInteger.valueOf(1);
      MINUSONE = LuaInteger.valueOf(-1);
      NOVALS = new LuaValue[0];
      ENV = valueOf("_ENV");
      INDEX = valueOf("__index");
      NEWINDEX = valueOf("__newindex");
      CALL = valueOf("__call");
      MODE = valueOf("__mode");
      METATABLE = valueOf("__metatable");
      ADD = valueOf("__add");
      SUB = valueOf("__sub");
      DIV = valueOf("__div");
      MUL = valueOf("__mul");
      POW = valueOf("__pow");
      MOD = valueOf("__mod");
      UNM = valueOf("__unm");
      LEN = valueOf("__len");
      EQ = valueOf("__eq");
      LT = valueOf("__lt");
      LE = valueOf("__le");
      TOSTRING = valueOf("__tostring");
      CONCAT = valueOf("__concat");
      EMPTYSTRING = valueOf("");
      MAXSTACK = 250;
      NILS = new LuaValue[MAXSTACK];

      for(int i = 0; i < MAXSTACK; ++i) {
         NILS[i] = NIL;
      }

   }

   @Environment(EnvType.CLIENT)
   private static final class None extends LuaNil {
      static LuaValue.None _NONE = new LuaValue.None();

      public LuaValue arg(int i) {
         return NIL;
      }

      public int narg() {
         return 0;
      }

      public LuaValue arg1() {
         return NIL;
      }

      public String tojstring() {
         return "none";
      }

      public Varargs subargs(int start) {
         return (Varargs)(start > 0 ? this : argerror(1, "start must be > 0"));
      }

      void copyto(LuaValue[] dest, int offset, int length) {
         while(length > 0) {
            dest[offset++] = NIL;
            --length;
         }

      }
   }
}
