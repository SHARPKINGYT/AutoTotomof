package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
interface Metatable {
   boolean useWeakKeys();

   boolean useWeakValues();

   LuaValue toLuaValue();

   LuaTable.Slot entry(LuaValue var1, LuaValue var2);

   LuaValue wrap(LuaValue var1);

   LuaValue arrayget(LuaValue[] var1, int var2);
}
