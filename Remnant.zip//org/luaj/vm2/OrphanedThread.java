package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class OrphanedThread extends Error {
   public OrphanedThread() {
      super("orphaned thread");
   }
}
