package org.luaj.vm2;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Print extends Lua {
   private static final String STRING_FOR_NULL = "null";
   public static PrintStream ps;
   public static final String[] OPNAMES;

   static void printString(PrintStream ps, LuaString s) {
      ps.print('"');
      int i = 0;

      for(int n = s.m_length; i < n; ++i) {
         int c = s.m_bytes[s.m_offset + i];
         if (c >= 32 && c <= 126 && c != 34 && c != 92) {
            ps.print((char)c);
         } else {
            switch(c) {
            case 7:
               ps.print("\\a");
               break;
            case 8:
               ps.print("\\b");
               break;
            case 9:
               ps.print("\\t");
               break;
            case 10:
               ps.print("\\n");
               break;
            case 11:
               ps.print("\\v");
               break;
            case 12:
               ps.print("\\f");
               break;
            case 13:
               ps.print("\\r");
               break;
            case 34:
               ps.print("\\\"");
               break;
            case 92:
               ps.print("\\\\");
               break;
            default:
               ps.print('\\');
               ps.print(Integer.toString(1255 & c).substring(1));
            }
         }
      }

      ps.print('"');
   }

   static void printValue(PrintStream ps, LuaValue v) {
      switch(v.type()) {
      case 4:
         printString(ps, (LuaString)v);
         break;
      default:
         ps.print(v.tojstring());
      }

   }

   static void printConstant(PrintStream ps, Prototype f, int i) {
      printValue(ps, f.k[i]);
   }

   static void printUpvalue(PrintStream ps, Upvaldesc u) {
      ps.print(u.idx + " ");
      printValue(ps, u.name);
   }

   public static void printCode(Prototype f) {
      int[] code = f.code;
      int n = code.length;

      for(int pc = 0; pc < n; ++pc) {
         printOpCode(f, pc);
         ps.println();
      }

   }

   public static void printOpCode(Prototype f, int pc) {
      printOpCode(ps, f, pc);
   }

   public static void printOpCode(PrintStream ps, Prototype f, int pc) {
      int[] code = f.code;
      int i = code[pc];
      int o = GET_OPCODE(i);
      int a = GETARG_A(i);
      int b = GETARG_B(i);
      int c = GETARG_C(i);
      int bx = GETARG_Bx(i);
      int sbx = GETARG_sBx(i);
      int line = getline(f, pc);
      ps.print("  " + (pc + 1) + "  ");
      if (line > 0) {
         ps.print("[" + line + "]  ");
      } else {
         ps.print("[-]  ");
      }

      String var10001 = OPNAMES[o];
      ps.print(var10001 + "  ");
      switch(getOpMode(o)) {
      case 0:
         ps.print(a);
         int var12;
         if (getBMode(o) != 0) {
            var12 = ISK(b) ? -1 - INDEXK(b) : b;
            ps.print(" " + var12);
         }

         if (getCMode(o) != 0) {
            var12 = ISK(c) ? -1 - INDEXK(c) : c;
            ps.print(" " + var12);
         }
         break;
      case 1:
         if (getBMode(o) == 3) {
            ps.print(a + " " + (-1 - bx));
         } else {
            ps.print(a + " " + bx);
         }
         break;
      case 2:
         if (o == 23) {
            ps.print(sbx);
         } else {
            ps.print(a + " " + sbx);
         }
      }

      switch(o) {
      case 1:
         ps.print("  ; ");
         printConstant(ps, f, bx);
      case 2:
      case 3:
      case 4:
      case 11:
      case 17:
      case 19:
      case 20:
      case 21:
      case 22:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 34:
      case 35:
      default:
         break;
      case 5:
      case 9:
         ps.print("  ; ");
         printUpvalue(ps, f.upvalues[b]);
         break;
      case 6:
         ps.print("  ; ");
         printUpvalue(ps, f.upvalues[b]);
         ps.print(" ");
         if (ISK(c)) {
            printConstant(ps, f, INDEXK(c));
         } else {
            ps.print("-");
         }
         break;
      case 7:
      case 12:
         if (ISK(c)) {
            ps.print("  ; ");
            printConstant(ps, f, INDEXK(c));
         }
         break;
      case 8:
         ps.print("  ; ");
         printUpvalue(ps, f.upvalues[a]);
         ps.print(" ");
         if (ISK(b)) {
            printConstant(ps, f, INDEXK(b));
         } else {
            ps.print("-");
         }

         ps.print(" ");
         if (ISK(c)) {
            printConstant(ps, f, INDEXK(c));
         } else {
            ps.print("-");
         }
         break;
      case 10:
      case 13:
      case 14:
      case 15:
      case 16:
      case 18:
      case 24:
      case 25:
      case 26:
         if (ISK(b) || ISK(c)) {
            ps.print("  ; ");
            if (ISK(b)) {
               printConstant(ps, f, INDEXK(b));
            } else {
               ps.print("-");
            }

            ps.print(" ");
            if (ISK(c)) {
               printConstant(ps, f, INDEXK(c));
            } else {
               ps.print("-");
            }
         }
         break;
      case 23:
      case 32:
      case 33:
         ps.print("  ; to " + (sbx + pc + 2));
         break;
      case 36:
         if (c == 0) {
            ++pc;
            ps.print("  ; " + code[pc]);
         } else {
            ps.print("  ; " + c);
         }
         break;
      case 37:
         Prototype var13 = f.p[bx];
         ps.print("  ; " + var13.getClass().getName());
         break;
      case 38:
         ps.print("  ; is_vararg=" + f.is_vararg);
      }

   }

   private static int getline(Prototype f, int pc) {
      return pc > 0 && f.lineinfo != null && pc < f.lineinfo.length ? f.lineinfo[pc] : -1;
   }

   static void printHeader(Prototype f) {
      String s = String.valueOf(f.source);
      if (!s.startsWith("@") && !s.startsWith("=")) {
         if ("\u001bLua".equals(s)) {
            s = "(bstring)";
         } else {
            s = "(string)";
         }
      } else {
         s = s.substring(1);
      }

      String a = f.linedefined == 0 ? "main" : "function";
      ps.print("\n%" + a + " <" + s + ":" + f.linedefined + "," + f.lastlinedefined + "> (" + f.code.length + " instructions, " + f.code.length * 4 + " bytes at " + id(f) + ")\n");
      ps.print(f.numparams + " param, " + f.maxstacksize + " slot, " + f.upvalues.length + " upvalue, ");
      int var10001 = f.locvars.length;
      ps.print(var10001 + " local, " + f.k.length + " constant, " + f.p.length + " function\n");
   }

   static void printConstants(Prototype f) {
      int n = f.k.length;
      ps.print("constants (" + n + ") for " + id(f) + ":\n");

      for(int i = 0; i < n; ++i) {
         ps.print("  " + (i + 1) + "  ");
         printValue(ps, f.k[i]);
         ps.print("\n");
      }

   }

   static void printLocals(Prototype f) {
      int n = f.locvars.length;
      ps.print("locals (" + n + ") for " + id(f) + ":\n");

      for(int i = 0; i < n; ++i) {
         ps.println("  " + i + "  " + String.valueOf(f.locvars[i].varname) + " " + (f.locvars[i].startpc + 1) + " " + (f.locvars[i].endpc + 1));
      }

   }

   static void printUpValues(Prototype f) {
      int n = f.upvalues.length;
      ps.print("upvalues (" + n + ") for " + id(f) + ":\n");

      for(int i = 0; i < n; ++i) {
         ps.print("  " + i + "  " + String.valueOf(f.upvalues[i]) + "\n");
      }

   }

   public static void print(Prototype prototype) {
      printFunction(prototype, true);
   }

   public static void printFunction(Prototype prototype, boolean full) {
      int n = prototype.p.length;
      printHeader(prototype);
      printCode(prototype);
      if (full) {
         printConstants(prototype);
         printLocals(prototype);
         printUpValues(prototype);
      }

      for(int i = 0; i < n; ++i) {
         printFunction(prototype.p[i], full);
      }

   }

   private static void format(String s, int maxcols) {
      int n = s.length();
      if (n > maxcols) {
         ps.print(s.substring(0, maxcols));
      } else {
         ps.print(s);
         int i = maxcols - n;

         while(true) {
            --i;
            if (i < 0) {
               break;
            }

            ps.print(' ');
         }
      }

   }

   private static String id(Prototype f) {
      return "Proto";
   }

   private void _assert(boolean b) {
      if (!b) {
         throw new NullPointerException("_assert failed");
      }
   }

   public static void printState(LuaClosure cl, int pc, LuaValue[] stack, int top, Varargs varargs) {
      PrintStream previous = ps;
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ps = new PrintStream(baos);
      printOpCode(cl.p, pc);
      ps.flush();
      ps.close();
      ps = previous;
      format(baos.toString(), 50);
      printStack(stack, top, varargs);
      ps.println();
   }

   public static void printStack(LuaValue[] stack, int top, Varargs varargs) {
      ps.print('[');

      for(int i = 0; i < stack.length; ++i) {
         LuaValue v = stack[i];
         if (v == null) {
            ps.print("null");
         } else {
            switch(v.type()) {
            case 4:
               LuaString s = v.checkstring();
               ps.print(s.length() < 48 ? s.tojstring() : s.substring(0, 32).tojstring() + "...+" + (s.length() - 32) + "b");
               break;
            case 5:
            default:
               ps.print(v.tojstring());
               break;
            case 6:
               ps.print(v.tojstring());
               break;
            case 7:
               Object o = v.touserdata();
               if (o != null) {
                  String n = o.getClass().getName();
                  n = n.substring(n.lastIndexOf(46) + 1);
                  ps.print(n + ": " + Integer.toHexString(o.hashCode()));
               } else {
                  ps.print(v.toString());
               }
            }
         }

         if (i + 1 == top) {
            ps.print(']');
         }

         ps.print(" | ");
      }

      ps.print(varargs);
   }

   static {
      ps = System.out;
      OPNAMES = new String[]{"MOVE", "LOADK", "LOADKX", "LOADBOOL", "LOADNIL", "GETUPVAL", "GETTABUP", "GETTABLE", "SETTABUP", "SETUPVAL", "SETTABLE", "NEWTABLE", "SELF", "ADD", "SUB", "MUL", "DIV", "MOD", "POW", "UNM", "NOT", "LEN", "CONCAT", "JMP", "EQ", "LT", "LE", "TEST", "TESTSET", "CALL", "TAILCALL", "RETURN", "FORLOOP", "FORPREP", "TFORCALL", "TFORLOOP", "SETLIST", "CLOSURE", "VARARG", "EXTRAARG", null};
   }
}
