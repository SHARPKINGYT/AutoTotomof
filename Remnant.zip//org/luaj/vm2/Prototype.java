package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Prototype {
   public LuaValue[] k;
   public int[] code;
   public Prototype[] p;
   public int[] lineinfo;
   public LocVars[] locvars;
   public Upvaldesc[] upvalues;
   public LuaString source;
   public int linedefined;
   public int lastlinedefined;
   public int numparams;
   public int is_vararg;
   public int maxstacksize;
   private static final Upvaldesc[] NOUPVALUES = new Upvaldesc[0];
   private static final Prototype[] NOSUBPROTOS = new Prototype[0];

   public Prototype() {
      this.p = NOSUBPROTOS;
      this.upvalues = NOUPVALUES;
   }

   public Prototype(int n_upvalues) {
      this.p = NOSUBPROTOS;
      this.upvalues = new Upvaldesc[n_upvalues];
   }

   public String toString() {
      String var10000 = String.valueOf(this.source);
      return var10000 + ":" + this.linedefined + "-" + this.lastlinedefined;
   }

   public LuaString getlocalname(int number, int pc) {
      for(int i = 0; i < this.locvars.length && this.locvars[i].startpc <= pc; ++i) {
         if (pc < this.locvars[i].endpc) {
            --number;
            if (number == 0) {
               return this.locvars[i].varname;
            }
         }
      }

      return null;
   }

   public String shortsource() {
      String name = this.source.tojstring();
      if (!name.startsWith("@") && !name.startsWith("=")) {
         if (name.startsWith("\u001b")) {
            name = "binary string";
         }
      } else {
         name = name.substring(1);
      }

      return name;
   }
}
