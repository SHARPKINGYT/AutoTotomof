package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TailcallVarargs extends Varargs {
   private LuaValue func;
   private Varargs args;
   private Varargs result;

   public TailcallVarargs(LuaValue f, Varargs args) {
      this.func = f;
      this.args = args;
   }

   public TailcallVarargs(LuaValue object, LuaValue methodname, Varargs args) {
      this.func = object.get(methodname);
      this.args = LuaValue.varargsOf(object, args);
   }

   public boolean isTailcall() {
      return true;
   }

   public Varargs eval() {
      while(this.result == null) {
         Varargs r = this.func.onInvoke(this.args);
         if (r.isTailcall()) {
            TailcallVarargs t = (TailcallVarargs)r;
            this.func = t.func;
            this.args = t.args;
         } else {
            this.result = r;
            this.func = null;
            this.args = null;
         }
      }

      return this.result;
   }

   public LuaValue arg(int i) {
      if (this.result == null) {
         this.eval();
      }

      return this.result.arg(i);
   }

   public LuaValue arg1() {
      if (this.result == null) {
         this.eval();
      }

      return this.result.arg1();
   }

   public int narg() {
      if (this.result == null) {
         this.eval();
      }

      return this.result.narg();
   }

   public Varargs subargs(int start) {
      if (this.result == null) {
         this.eval();
      }

      return this.result.subargs(start);
   }
}
