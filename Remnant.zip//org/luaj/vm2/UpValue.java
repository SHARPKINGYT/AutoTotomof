package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class UpValue {
   LuaValue[] array;
   int index;

   public UpValue(LuaValue[] stack, int index) {
      this.array = stack;
      this.index = index;
   }

   public String toString() {
      int var10000 = this.index;
      return var10000 + "/" + this.array.length + " " + String.valueOf(this.array[this.index]);
   }

   public String tojstring() {
      return this.array[this.index].tojstring();
   }

   public final LuaValue getValue() {
      return this.array[this.index];
   }

   public final void setValue(LuaValue value) {
      this.array[this.index] = value;
   }

   public final void close() {
      LuaValue[] old = this.array;
      this.array = new LuaValue[]{old[this.index]};
      old[this.index] = null;
      this.index = 0;
   }
}
