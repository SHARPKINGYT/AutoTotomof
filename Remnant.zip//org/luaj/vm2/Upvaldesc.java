package org.luaj.vm2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Upvaldesc {
   public LuaString name;
   public final boolean instack;
   public final short idx;

   public Upvaldesc(LuaString name, boolean instack, int idx) {
      this.name = name;
      this.instack = instack;
      this.idx = (short)idx;
   }

   public String toString() {
      short var10000 = this.idx;
      return var10000 + (this.instack ? " instack " : " closed ") + String.valueOf(this.name);
   }
}
