package org.luaj.vm2;

import java.lang.ref.WeakReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class WeakTable implements Metatable {
   private boolean weakkeys;
   private boolean weakvalues;
   private LuaValue backing;

   public static LuaTable make(boolean weakkeys, boolean weakvalues) {
      LuaString mode;
      if (weakkeys && weakvalues) {
         mode = LuaString.valueOf("kv");
      } else if (weakkeys) {
         mode = LuaString.valueOf("k");
      } else {
         if (!weakvalues) {
            return LuaTable.tableOf();
         }

         mode = LuaString.valueOf("v");
      }

      LuaTable table = LuaTable.tableOf();
      LuaTable mt = LuaTable.tableOf(new LuaValue[]{LuaValue.MODE, mode});
      table.setmetatable(mt);
      return table;
   }

   public WeakTable(boolean weakkeys, boolean weakvalues, LuaValue backing) {
      this.weakkeys = weakkeys;
      this.weakvalues = weakvalues;
      this.backing = backing;
   }

   public boolean useWeakKeys() {
      return this.weakkeys;
   }

   public boolean useWeakValues() {
      return this.weakvalues;
   }

   public LuaValue toLuaValue() {
      return this.backing;
   }

   public LuaTable.Slot entry(LuaValue key, LuaValue value) {
      value = value.strongvalue();
      if (value == null) {
         return null;
      } else if (this.weakkeys && !key.isnumber() && !key.isstring() && !key.isboolean()) {
         return (LuaTable.Slot)(this.weakvalues && !value.isnumber() && !value.isstring() && !value.isboolean() ? new WeakTable.WeakKeyAndValueSlot(key, value, (LuaTable.Slot)null) : new WeakTable.WeakKeySlot(key, value, (LuaTable.Slot)null));
      } else {
         return (LuaTable.Slot)(this.weakvalues && !value.isnumber() && !value.isstring() && !value.isboolean() ? new WeakTable.WeakValueSlot(key, value, (LuaTable.Slot)null) : LuaTable.defaultEntry(key, value));
      }
   }

   protected static LuaValue weaken(LuaValue value) {
      switch(value.type()) {
      case 5:
      case 6:
      case 8:
         return new WeakTable.WeakValue(value);
      case 7:
         return new WeakTable.WeakUserdata(value);
      default:
         return value;
      }
   }

   protected static LuaValue strengthen(Object ref) {
      if (ref instanceof WeakReference) {
         ref = ((WeakReference)ref).get();
      }

      return ref instanceof WeakTable.WeakValue ? ((WeakTable.WeakValue)ref).strongvalue() : (LuaValue)ref;
   }

   public LuaValue wrap(LuaValue value) {
      return this.weakvalues ? weaken(value) : value;
   }

   public LuaValue arrayget(LuaValue[] array, int index) {
      LuaValue value = array[index];
      if (value != null) {
         value = strengthen(value);
         if (value == null) {
            array[index] = null;
         }
      }

      return value;
   }

   @Environment(EnvType.CLIENT)
   static class WeakKeyAndValueSlot extends WeakTable.WeakSlot {
      private final int keyhash;

      protected WeakKeyAndValueSlot(LuaValue key, LuaValue value, LuaTable.Slot next) {
         super(WeakTable.weaken(key), WeakTable.weaken(value), next);
         this.keyhash = key.hashCode();
      }

      protected WeakKeyAndValueSlot(WeakTable.WeakKeyAndValueSlot copyFrom, LuaTable.Slot next) {
         super(copyFrom.key, copyFrom.value, next);
         this.keyhash = copyFrom.keyhash;
      }

      public int keyindex(int hashMask) {
         return LuaTable.hashmod(this.keyhash, hashMask);
      }

      public LuaTable.Slot set(LuaValue value) {
         this.value = WeakTable.weaken(value);
         return this;
      }

      public LuaValue strongkey() {
         return WeakTable.strengthen(this.key);
      }

      public LuaValue strongvalue() {
         return WeakTable.strengthen(this.value);
      }

      protected WeakTable.WeakSlot copy(LuaTable.Slot next) {
         return new WeakTable.WeakKeyAndValueSlot(this, next);
      }
   }

   @Environment(EnvType.CLIENT)
   static class WeakKeySlot extends WeakTable.WeakSlot {
      private final int keyhash;

      protected WeakKeySlot(LuaValue key, LuaValue value, LuaTable.Slot next) {
         super(WeakTable.weaken(key), value, next);
         this.keyhash = key.hashCode();
      }

      protected WeakKeySlot(WeakTable.WeakKeySlot copyFrom, LuaTable.Slot next) {
         super(copyFrom.key, copyFrom.value, next);
         this.keyhash = copyFrom.keyhash;
      }

      public int keyindex(int mask) {
         return LuaTable.hashmod(this.keyhash, mask);
      }

      public LuaTable.Slot set(LuaValue value) {
         this.value = value;
         return this;
      }

      public LuaValue strongkey() {
         return WeakTable.strengthen(this.key);
      }

      protected WeakTable.WeakSlot copy(LuaTable.Slot rest) {
         return new WeakTable.WeakKeySlot(this, rest);
      }
   }

   @Environment(EnvType.CLIENT)
   static class WeakValueSlot extends WeakTable.WeakSlot {
      protected WeakValueSlot(LuaValue key, LuaValue value, LuaTable.Slot next) {
         super(key, WeakTable.weaken(value), next);
      }

      protected WeakValueSlot(WeakTable.WeakValueSlot copyFrom, LuaTable.Slot next) {
         super(copyFrom.key, copyFrom.value, next);
      }

      public int keyindex(int mask) {
         return LuaTable.hashSlot(this.strongkey(), mask);
      }

      public LuaTable.Slot set(LuaValue value) {
         this.value = WeakTable.weaken(value);
         return this;
      }

      public LuaValue strongvalue() {
         return WeakTable.strengthen(this.value);
      }

      protected WeakTable.WeakSlot copy(LuaTable.Slot next) {
         return new WeakTable.WeakValueSlot(this, next);
      }
   }

   @Environment(EnvType.CLIENT)
   static class WeakValue extends LuaValue {
      WeakReference ref;

      protected WeakValue(LuaValue value) {
         this.ref = new WeakReference(value);
      }

      public int type() {
         this.illegal("type", "weak value");
         return 0;
      }

      public String typename() {
         this.illegal("typename", "weak value");
         return null;
      }

      public String toString() {
         return "weak<" + String.valueOf(this.ref.get()) + ">";
      }

      public LuaValue strongvalue() {
         Object o = this.ref.get();
         return (LuaValue)o;
      }

      public boolean raweq(LuaValue rhs) {
         Object o = this.ref.get();
         return o != null && rhs.raweq((LuaValue)o);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class WeakUserdata extends WeakTable.WeakValue {
      private final WeakReference ob;
      private final LuaValue mt;

      private WeakUserdata(LuaValue value) {
         super(value);
         this.ob = new WeakReference(value.touserdata());
         this.mt = value.getmetatable();
      }

      public LuaValue strongvalue() {
         Object u = this.ref.get();
         if (u != null) {
            return (LuaValue)u;
         } else {
            Object o = this.ob.get();
            if (o != null) {
               LuaValue ud = LuaValue.userdataOf(o, this.mt);
               this.ref = new WeakReference(ud);
               return ud;
            } else {
               return null;
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   public abstract static class WeakSlot implements LuaTable.Slot {
      protected Object key;
      protected Object value;
      protected LuaTable.Slot next;

      protected WeakSlot(Object key, Object value, LuaTable.Slot next) {
         this.key = key;
         this.value = value;
         this.next = next;
      }

      public abstract int keyindex(int var1);

      public abstract LuaTable.Slot set(LuaValue var1);

      public LuaTable.StrongSlot first() {
         LuaValue key = this.strongkey();
         LuaValue value = this.strongvalue();
         if (key != null && value != null) {
            return new LuaTable.NormalEntry(key, value);
         } else {
            this.key = null;
            this.value = null;
            return null;
         }
      }

      public LuaTable.StrongSlot find(LuaValue key) {
         LuaTable.StrongSlot first = this.first();
         return first != null ? first.find(key) : null;
      }

      public boolean keyeq(LuaValue key) {
         LuaTable.StrongSlot first = this.first();
         return first != null && first.keyeq(key);
      }

      public LuaTable.Slot rest() {
         return this.next;
      }

      public int arraykey(int max) {
         return 0;
      }

      public LuaTable.Slot set(LuaTable.StrongSlot target, LuaValue value) {
         LuaValue key = this.strongkey();
         if (key != null && target.find(key) != null) {
            return this.set(value);
         } else if (key != null) {
            this.next = this.next.set(target, value);
            return this;
         } else {
            return this.next.set(target, value);
         }
      }

      public LuaTable.Slot add(LuaTable.Slot entry) {
         this.next = this.next != null ? this.next.add(entry) : entry;
         return (LuaTable.Slot)(this.strongkey() != null && this.strongvalue() != null ? this : this.next);
      }

      public LuaTable.Slot remove(LuaTable.StrongSlot target) {
         LuaValue key = this.strongkey();
         if (key == null) {
            return this.next.remove(target);
         } else if (target.keyeq(key)) {
            this.value = null;
            return this;
         } else {
            this.next = this.next.remove(target);
            return this;
         }
      }

      public LuaTable.Slot relink(LuaTable.Slot rest) {
         if (this.strongkey() != null && this.strongvalue() != null) {
            return rest == null && this.next == null ? this : this.copy(rest);
         } else {
            return rest;
         }
      }

      public LuaValue strongkey() {
         return (LuaValue)this.key;
      }

      public LuaValue strongvalue() {
         return (LuaValue)this.value;
      }

      protected abstract WeakTable.WeakSlot copy(LuaTable.Slot var1);
   }
}
