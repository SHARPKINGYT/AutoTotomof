package org.luaj.vm2.ast;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Block extends Stat {
   public List<Stat> stats = new ArrayList();
   public NameScope scope;

   public void add(Stat s) {
      if (s != null) {
         this.stats.add(s);
      }
   }

   public void accept(Visitor visitor) {
      visitor.visit(this);
   }
}
