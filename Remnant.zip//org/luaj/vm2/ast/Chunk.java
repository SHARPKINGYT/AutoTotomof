package org.luaj.vm2.ast;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Chunk extends SyntaxElement {
   public final Block block;

   public Chunk(Block b) {
      this.block = b;
   }

   public void accept(Visitor visitor) {
      visitor.visit(this);
   }
}
