package org.luaj.vm2.ast;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;

@Environment(EnvType.CLIENT)
public abstract class Exp extends SyntaxElement {
   public abstract void accept(Visitor var1);

   public static Exp constant(LuaValue value) {
      return new Exp.Constant(value);
   }

   public static Exp numberconstant(String token) {
      return new Exp.Constant(LuaValue.valueOf(token).tonumber());
   }

   public static Exp varargs() {
      return new Exp.VarargsExp();
   }

   public static Exp tableconstructor(TableConstructor tc) {
      return tc;
   }

   public static Exp unaryexp(int op, Exp rhs) {
      if (rhs instanceof Exp.BinopExp) {
         Exp.BinopExp b = (Exp.BinopExp)rhs;
         if (precedence(op) > precedence(b.op)) {
            return binaryexp(unaryexp(op, b.lhs), b.op, b.rhs);
         }
      }

      return new Exp.UnopExp(op, rhs);
   }

   public static Exp binaryexp(Exp lhs, int op, Exp rhs) {
      if (lhs instanceof Exp.UnopExp) {
         Exp.UnopExp u = (Exp.UnopExp)lhs;
         if (precedence(op) > precedence(u.op)) {
            return unaryexp(u.op, binaryexp(u.rhs, op, rhs));
         }
      }

      Exp.BinopExp b;
      if (lhs instanceof Exp.BinopExp) {
         b = (Exp.BinopExp)lhs;
         if (precedence(op) > precedence(b.op) || precedence(op) == precedence(b.op) && isrightassoc(op)) {
            return binaryexp(b.lhs, b.op, binaryexp(b.rhs, op, rhs));
         }
      }

      if (rhs instanceof Exp.BinopExp) {
         b = (Exp.BinopExp)rhs;
         if (precedence(op) > precedence(b.op) || precedence(op) == precedence(b.op) && !isrightassoc(op)) {
            return binaryexp(binaryexp(lhs, op, b.lhs), b.op, b.rhs);
         }
      }

      return new Exp.BinopExp(lhs, op, rhs);
   }

   static boolean isrightassoc(int op) {
      switch(op) {
      case 18:
      case 22:
         return true;
      default:
         return false;
      }
   }

   static int precedence(int op) {
      switch(op) {
      case 13:
      case 14:
         return 4;
      case 15:
      case 16:
      case 17:
         return 5;
      case 18:
         return 7;
      case 19:
      case 20:
      case 21:
         return 6;
      case 22:
         return 3;
      case 23:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      default:
         throw new IllegalStateException("precedence of bad op " + op);
      case 24:
      case 25:
      case 26:
      case 61:
      case 62:
      case 63:
         return 2;
      case 59:
         return 0;
      case 60:
         return 1;
      }
   }

   public static Exp anonymousfunction(FuncBody funcbody) {
      return new Exp.AnonFuncDef(funcbody);
   }

   public static Exp.NameExp nameprefix(String name) {
      return new Exp.NameExp(name);
   }

   public static Exp.ParensExp parensprefix(Exp exp) {
      return new Exp.ParensExp(exp);
   }

   public static Exp.IndexExp indexop(Exp.PrimaryExp lhs, Exp exp) {
      return new Exp.IndexExp(lhs, exp);
   }

   public static Exp.FieldExp fieldop(Exp.PrimaryExp lhs, String name) {
      return new Exp.FieldExp(lhs, name);
   }

   public static Exp.FuncCall functionop(Exp.PrimaryExp lhs, FuncArgs args) {
      return new Exp.FuncCall(lhs, args);
   }

   public static Exp.MethodCall methodop(Exp.PrimaryExp lhs, String name, FuncArgs args) {
      return new Exp.MethodCall(lhs, name, args);
   }

   public boolean isvarexp() {
      return false;
   }

   public boolean isfunccall() {
      return false;
   }

   public boolean isvarargexp() {
      return false;
   }

   @Environment(EnvType.CLIENT)
   public static class Constant extends Exp {
      public final LuaValue value;

      public Constant(LuaValue value) {
         this.value = value;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static class VarargsExp extends Exp {
      public void accept(Visitor visitor) {
         visitor.visit(this);
      }

      public boolean isvarargexp() {
         return true;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class BinopExp extends Exp {
      public final Exp lhs;
      public final Exp rhs;
      public final int op;

      public BinopExp(Exp lhs, int op, Exp rhs) {
         this.lhs = lhs;
         this.op = op;
         this.rhs = rhs;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static class UnopExp extends Exp {
      public final int op;
      public final Exp rhs;

      public UnopExp(int op, Exp rhs) {
         this.op = op;
         this.rhs = rhs;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static class AnonFuncDef extends Exp {
      public final FuncBody body;

      public AnonFuncDef(FuncBody funcbody) {
         this.body = funcbody;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static class NameExp extends Exp.VarExp {
      public final Name name;

      public NameExp(String name) {
         this.name = new Name(name);
      }

      public void markHasAssignment() {
         this.name.variable.hasassignments = true;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static class ParensExp extends Exp.PrimaryExp {
      public final Exp exp;

      public ParensExp(Exp exp) {
         this.exp = exp;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static class IndexExp extends Exp.VarExp {
      public final Exp.PrimaryExp lhs;
      public final Exp exp;

      public IndexExp(Exp.PrimaryExp lhs, Exp exp) {
         this.lhs = lhs;
         this.exp = exp;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public abstract static class PrimaryExp extends Exp {
      public boolean isvarexp() {
         return false;
      }

      public boolean isfunccall() {
         return false;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class FieldExp extends Exp.VarExp {
      public final Exp.PrimaryExp lhs;
      public final Name name;

      public FieldExp(Exp.PrimaryExp lhs, String name) {
         this.lhs = lhs;
         this.name = new Name(name);
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static class FuncCall extends Exp.PrimaryExp {
      public final Exp.PrimaryExp lhs;
      public final FuncArgs args;

      public FuncCall(Exp.PrimaryExp lhs, FuncArgs args) {
         this.lhs = lhs;
         this.args = args;
      }

      public boolean isfunccall() {
         return true;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }

      public boolean isvarargexp() {
         return true;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class MethodCall extends Exp.FuncCall {
      public final String name;

      public MethodCall(Exp.PrimaryExp lhs, String name, FuncArgs args) {
         super(lhs, args);
         this.name = new String(name);
      }

      public boolean isfunccall() {
         return true;
      }

      public void accept(Visitor visitor) {
         visitor.visit(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public abstract static class VarExp extends Exp.PrimaryExp {
      public boolean isvarexp() {
         return true;
      }

      public void markHasAssignment() {
      }
   }
}
