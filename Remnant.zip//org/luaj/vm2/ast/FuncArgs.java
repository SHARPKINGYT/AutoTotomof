package org.luaj.vm2.ast;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaString;

@Environment(EnvType.CLIENT)
public class FuncArgs extends SyntaxElement {
   public final List<Exp> exps;

   public static FuncArgs explist(List<Exp> explist) {
      return new FuncArgs(explist);
   }

   public static FuncArgs tableconstructor(TableConstructor table) {
      return new FuncArgs(table);
   }

   public static FuncArgs string(LuaString string) {
      return new FuncArgs(string);
   }

   public FuncArgs(List<Exp> exps) {
      this.exps = exps;
   }

   public FuncArgs(LuaString string) {
      this.exps = new ArrayList();
      this.exps.add(Exp.constant(string));
   }

   public FuncArgs(TableConstructor table) {
      this.exps = new ArrayList();
      this.exps.add(table);
   }

   public void accept(Visitor visitor) {
      visitor.visit(this);
   }
}
