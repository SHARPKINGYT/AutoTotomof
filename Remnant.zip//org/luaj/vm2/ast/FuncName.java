package org.luaj.vm2.ast;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class FuncName extends SyntaxElement {
   public final Name name;
   public List<String> dots;
   public String method;

   public FuncName(String name) {
      this.name = new Name(name);
   }

   public void adddot(String dot) {
      if (this.dots == null) {
         this.dots = new ArrayList();
      }

      this.dots.add(dot);
   }
}
