package org.luaj.vm2.ast;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Name {
   public final String name;
   public Variable variable;

   public Name(String name) {
      this.name = name;
   }
}
