package org.luaj.vm2.ast;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;

@Environment(EnvType.CLIENT)
public class NameResolver extends Visitor {
   private NameScope scope = null;

   private void pushScope() {
      this.scope = new NameScope(this.scope);
   }

   private void popScope() {
      this.scope = this.scope.outerScope;
   }

   public void visit(NameScope scope) {
   }

   public void visit(Block block) {
      this.pushScope();
      block.scope = this.scope;
      super.visit(block);
      this.popScope();
   }

   public void visit(FuncBody body) {
      this.pushScope();
      ++this.scope.functionNestingCount;
      body.scope = this.scope;
      super.visit(body);
      this.popScope();
   }

   public void visit(Stat.LocalFuncDef stat) {
      this.defineLocalVar(stat.name);
      super.visit(stat);
   }

   public void visit(Stat.NumericFor stat) {
      this.pushScope();
      stat.scope = this.scope;
      this.defineLocalVar(stat.name);
      super.visit(stat);
      this.popScope();
   }

   public void visit(Stat.GenericFor stat) {
      this.pushScope();
      stat.scope = this.scope;
      this.defineLocalVars(stat.names);
      super.visit(stat);
      this.popScope();
   }

   public void visit(Exp.NameExp exp) {
      exp.name.variable = this.resolveNameReference(exp.name);
      super.visit(exp);
   }

   public void visit(Stat.FuncDef stat) {
      stat.name.name.variable = this.resolveNameReference(stat.name.name);
      stat.name.name.variable.hasassignments = true;
      super.visit(stat);
   }

   public void visit(Stat.Assign stat) {
      super.visit(stat);
      int i = 0;

      for(int n = stat.vars.size(); i < n; ++i) {
         Exp.VarExp v = (Exp.VarExp)stat.vars.get(i);
         v.markHasAssignment();
      }

   }

   public void visit(Stat.LocalAssign stat) {
      this.visitExps(stat.values);
      this.defineLocalVars(stat.names);
      int n = stat.names.size();
      int m = stat.values != null ? stat.values.size() : 0;
      boolean isvarlist = m > 0 && m < n && ((Exp)stat.values.get(m - 1)).isvarargexp();

      int i;
      for(i = 0; i < n && i < (isvarlist ? m - 1 : m); ++i) {
         if (stat.values.get(i) instanceof Exp.Constant) {
            ((Name)stat.names.get(i)).variable.initialValue = ((Exp.Constant)stat.values.get(i)).value;
         }
      }

      if (!isvarlist) {
         for(i = m; i < n; ++i) {
            ((Name)stat.names.get(i)).variable.initialValue = LuaValue.NIL;
         }
      }

   }

   public void visit(ParList pars) {
      if (pars.names != null) {
         this.defineLocalVars(pars.names);
      }

      if (pars.isvararg) {
         this.scope.define("arg");
      }

      super.visit(pars);
   }

   protected void defineLocalVars(List<Name> names) {
      int i = 0;

      for(int n = names.size(); i < n; ++i) {
         this.defineLocalVar((Name)names.get(i));
      }

   }

   protected void defineLocalVar(Name name) {
      name.variable = this.scope.define(name.name);
   }

   protected Variable resolveNameReference(Name name) {
      Variable v = this.scope.find(name.name);
      if (v.isLocal() && this.scope.functionNestingCount != v.definingScope.functionNestingCount) {
         v.isupvalue = true;
      }

      return v;
   }
}
