package org.luaj.vm2.ast;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ParList extends SyntaxElement {
   public static final List<Name> EMPTY_NAMELIST = new ArrayList();
   public static final ParList EMPTY_PARLIST;
   public final List<Name> names;
   public final boolean isvararg;

   public ParList(List<Name> names, boolean isvararg) {
      this.names = names;
      this.isvararg = isvararg;
   }

   public void accept(Visitor visitor) {
      visitor.visit(this);
   }

   static {
      EMPTY_PARLIST = new ParList(EMPTY_NAMELIST, false);
   }
}
