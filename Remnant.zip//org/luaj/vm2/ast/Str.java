package org.luaj.vm2.ast;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaString;

@Environment(EnvType.CLIENT)
public class Str {
   private Str() {
   }

   public static LuaString quoteString(String image) {
      String s = image.substring(1, image.length() - 1);
      byte[] bytes = unquote(s);
      return LuaString.valueUsing(bytes);
   }

   public static LuaString charString(String image) {
      String s = image.substring(1, image.length() - 1);
      byte[] bytes = unquote(s);
      return LuaString.valueUsing(bytes);
   }

   public static LuaString longString(String image) {
      int i = image.indexOf(91, image.indexOf(91) + 1) + 1;
      String s = image.substring(i, image.length() - i);
      byte[] b = iso88591bytes(s);
      return LuaString.valueUsing(b);
   }

   public static byte[] iso88591bytes(String s) {
      try {
         return s.getBytes("ISO8859-1");
      } catch (UnsupportedEncodingException var2) {
         throw new IllegalStateException("ISO8859-1 not supported");
      }
   }

   public static byte[] unquote(String s) {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      char[] c = s.toCharArray();
      int n = c.length;

      for(int i = 0; i < n; ++i) {
         if (c[i] == '\\' && i < n) {
            ++i;
            switch(c[i]) {
            case '"':
               baos.write(34);
               break;
            case '#':
            case '$':
            case '%':
            case '&':
            case '(':
            case ')':
            case '*':
            case '+':
            case ',':
            case '-':
            case '.':
            case '/':
            case ':':
            case ';':
            case '<':
            case '=':
            case '>':
            case '?':
            case '@':
            case 'A':
            case 'B':
            case 'C':
            case 'D':
            case 'E':
            case 'F':
            case 'G':
            case 'H':
            case 'I':
            case 'J':
            case 'K':
            case 'L':
            case 'M':
            case 'N':
            case 'O':
            case 'P':
            case 'Q':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
            case 'V':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
            case '[':
            case ']':
            case '^':
            case '_':
            case '`':
            case 'c':
            case 'd':
            case 'e':
            case 'g':
            case 'h':
            case 'i':
            case 'j':
            case 'k':
            case 'l':
            case 'm':
            case 'o':
            case 'p':
            case 'q':
            case 's':
            case 'u':
            default:
               baos.write((byte)c[i]);
               break;
            case '\'':
               baos.write(39);
               break;
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
               int d = c[i++] - 48;

               for(int j = 0; i < n && j < 2 && c[i] >= '0' && c[i] <= '9'; ++j) {
                  d = d * 10 + (c[i] - 48);
                  ++i;
               }

               baos.write((byte)d);
               --i;
               break;
            case '\\':
               baos.write(92);
               break;
            case 'a':
               baos.write(7);
               break;
            case 'b':
               baos.write(8);
               break;
            case 'f':
               baos.write(12);
               break;
            case 'n':
               baos.write(10);
               break;
            case 'r':
               baos.write(13);
               break;
            case 't':
               baos.write(9);
               break;
            case 'v':
               baos.write(11);
            }
         } else {
            baos.write((byte)c[i]);
         }
      }

      return baos.toByteArray();
   }
}
