package org.luaj.vm2.ast;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TableConstructor extends Exp {
   public List<TableField> fields;

   public void accept(Visitor visitor) {
      visitor.visit(this);
   }
}
