package org.luaj.vm2.ast;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;

@Environment(EnvType.CLIENT)
public class Variable {
   public final String name;
   public final NameScope definingScope;
   public boolean isupvalue;
   public boolean hasassignments;
   public LuaValue initialValue;

   public Variable(String name) {
      this.name = name;
      this.definingScope = null;
   }

   public Variable(String name, NameScope definingScope) {
      this.name = name;
      this.definingScope = definingScope;
   }

   public boolean isLocal() {
      return this.definingScope != null;
   }

   public boolean isConstant() {
      return !this.hasassignments && this.initialValue != null;
   }
}
