package org.luaj.vm2.ast;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class Visitor {
   public void visit(Chunk chunk) {
      chunk.block.accept(this);
   }

   public void visit(Block block) {
      this.visit(block.scope);
      if (block.stats != null) {
         int i = 0;

         for(int n = block.stats.size(); i < n; ++i) {
            ((Stat)block.stats.get(i)).accept(this);
         }
      }

   }

   public void visit(Stat.Assign stat) {
      this.visitVars(stat.vars);
      this.visitExps(stat.exps);
   }

   public void visit(Stat.Break breakstat) {
   }

   public void visit(Stat.FuncCallStat stat) {
      stat.funccall.accept(this);
   }

   public void visit(Stat.FuncDef stat) {
      stat.body.accept(this);
   }

   public void visit(Stat.GenericFor stat) {
      this.visit(stat.scope);
      this.visitNames(stat.names);
      this.visitExps(stat.exps);
      stat.block.accept(this);
   }

   public void visit(Stat.IfThenElse stat) {
      stat.ifexp.accept(this);
      stat.ifblock.accept(this);
      if (stat.elseifblocks != null) {
         int i = 0;

         for(int n = stat.elseifblocks.size(); i < n; ++i) {
            ((Exp)stat.elseifexps.get(i)).accept(this);
            ((Block)stat.elseifblocks.get(i)).accept(this);
         }
      }

      if (stat.elseblock != null) {
         this.visit(stat.elseblock);
      }

   }

   public void visit(Stat.LocalAssign stat) {
      this.visitNames(stat.names);
      this.visitExps(stat.values);
   }

   public void visit(Stat.LocalFuncDef stat) {
      this.visit(stat.name);
      stat.body.accept(this);
   }

   public void visit(Stat.NumericFor stat) {
      this.visit(stat.scope);
      this.visit(stat.name);
      stat.initial.accept(this);
      stat.limit.accept(this);
      if (stat.step != null) {
         stat.step.accept(this);
      }

      stat.block.accept(this);
   }

   public void visit(Stat.RepeatUntil stat) {
      stat.block.accept(this);
      stat.exp.accept(this);
   }

   public void visit(Stat.Return stat) {
      this.visitExps(stat.values);
   }

   public void visit(Stat.WhileDo stat) {
      stat.exp.accept(this);
      stat.block.accept(this);
   }

   public void visit(FuncBody body) {
      this.visit(body.scope);
      body.parlist.accept(this);
      body.block.accept(this);
   }

   public void visit(FuncArgs args) {
      this.visitExps(args.exps);
   }

   public void visit(TableField field) {
      if (field.name != null) {
      }

      this.visit(field.name);
      if (field.index != null) {
         field.index.accept(this);
      }

      field.rhs.accept(this);
   }

   public void visit(Exp.AnonFuncDef exp) {
      exp.body.accept(this);
   }

   public void visit(Exp.BinopExp exp) {
      exp.lhs.accept(this);
      exp.rhs.accept(this);
   }

   public void visit(Exp.Constant exp) {
   }

   public void visit(Exp.FieldExp exp) {
      exp.lhs.accept(this);
      this.visit(exp.name);
   }

   public void visit(Exp.FuncCall exp) {
      exp.lhs.accept(this);
      exp.args.accept(this);
   }

   public void visit(Exp.IndexExp exp) {
      exp.lhs.accept(this);
      exp.exp.accept(this);
   }

   public void visit(Exp.MethodCall exp) {
      exp.lhs.accept(this);
      this.visit(exp.name);
      exp.args.accept(this);
   }

   public void visit(Exp.NameExp exp) {
      this.visit(exp.name);
   }

   public void visit(Exp.ParensExp exp) {
      exp.exp.accept(this);
   }

   public void visit(Exp.UnopExp exp) {
      exp.rhs.accept(this);
   }

   public void visit(Exp.VarargsExp exp) {
   }

   public void visit(ParList pars) {
      this.visitNames(pars.names);
   }

   public void visit(TableConstructor table) {
      if (table.fields != null) {
         int i = 0;

         for(int n = table.fields.size(); i < n; ++i) {
            ((TableField)table.fields.get(i)).accept(this);
         }
      }

   }

   public void visitVars(List<Exp.VarExp> vars) {
      if (vars != null) {
         int i = 0;

         for(int n = vars.size(); i < n; ++i) {
            ((Exp.VarExp)vars.get(i)).accept(this);
         }
      }

   }

   public void visitExps(List<Exp> exps) {
      if (exps != null) {
         int i = 0;

         for(int n = exps.size(); i < n; ++i) {
            ((Exp)exps.get(i)).accept(this);
         }
      }

   }

   public void visitNames(List<Name> names) {
      if (names != null) {
         int i = 0;

         for(int n = names.size(); i < n; ++i) {
            this.visit((Name)names.get(i));
         }
      }

   }

   public void visit(Name name) {
   }

   public void visit(String name) {
   }

   public void visit(NameScope scope) {
   }

   public void visit(Stat.Goto gotostat) {
   }

   public void visit(Stat.Label label) {
   }
}
