package org.luaj.vm2.compiler;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
class InstructionPtr {
   final int[] code;
   final int idx;

   InstructionPtr(int[] code, int idx) {
      this.code = code;
      this.idx = idx;
   }

   int get() {
      return this.code[this.idx];
   }

   void set(int value) {
      this.code[this.idx] = value;
   }
}
