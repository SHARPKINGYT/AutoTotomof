package org.luaj.vm2.compiler;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class IntPtr {
   int i;

   IntPtr() {
   }

   IntPtr(int value) {
      this.i = value;
   }
}
