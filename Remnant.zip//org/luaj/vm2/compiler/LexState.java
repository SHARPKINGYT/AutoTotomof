package org.luaj.vm2.compiler;

import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LocVars;
import org.luaj.vm2.Lua;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Prototype;
import org.luaj.vm2.lib.MathLib;

@Environment(EnvType.CLIENT)
public class LexState extends Constants {
   protected static final String RESERVED_LOCAL_VAR_FOR_CONTROL = "(for control)";
   protected static final String RESERVED_LOCAL_VAR_FOR_STATE = "(for state)";
   protected static final String RESERVED_LOCAL_VAR_FOR_GENERATOR = "(for generator)";
   protected static final String RESERVED_LOCAL_VAR_FOR_STEP = "(for step)";
   protected static final String RESERVED_LOCAL_VAR_FOR_LIMIT = "(for limit)";
   protected static final String RESERVED_LOCAL_VAR_FOR_INDEX = "(for index)";
   protected static final String[] RESERVED_LOCAL_VAR_KEYWORDS = new String[]{"(for control)", "(for generator)", "(for index)", "(for limit)", "(for state)", "(for step)"};
   private static final Hashtable RESERVED_LOCAL_VAR_KEYWORDS_TABLE = new Hashtable();
   private static final int EOZ = -1;
   private static final int MAX_INT = 2147483645;
   private static final int UCHAR_MAX = 255;
   private static final int LUAI_MAXCCALLS = 200;
   private static final int LUA_COMPAT_LSTR = 1;
   private static final boolean LUA_COMPAT_VARARG = true;
   static final int NO_JUMP = -1;
   static final int OPR_ADD = 0;
   static final int OPR_SUB = 1;
   static final int OPR_MUL = 2;
   static final int OPR_DIV = 3;
   static final int OPR_MOD = 4;
   static final int OPR_POW = 5;
   static final int OPR_CONCAT = 6;
   static final int OPR_NE = 7;
   static final int OPR_EQ = 8;
   static final int OPR_LT = 9;
   static final int OPR_LE = 10;
   static final int OPR_GT = 11;
   static final int OPR_GE = 12;
   static final int OPR_AND = 13;
   static final int OPR_OR = 14;
   static final int OPR_NOBINOPR = 15;
   static final int OPR_MINUS = 0;
   static final int OPR_NOT = 1;
   static final int OPR_LEN = 2;
   static final int OPR_NOUNOPR = 3;
   static final int VVOID = 0;
   static final int VNIL = 1;
   static final int VTRUE = 2;
   static final int VFALSE = 3;
   static final int VK = 4;
   static final int VKNUM = 5;
   static final int VNONRELOC = 6;
   static final int VLOCAL = 7;
   static final int VUPVAL = 8;
   static final int VINDEXED = 9;
   static final int VJMP = 10;
   static final int VRELOCABLE = 11;
   static final int VCALL = 12;
   static final int VVARARG = 13;
   int current;
   int linenumber;
   int lastline;
   final LexState.Token t = new LexState.Token();
   final LexState.Token lookahead = new LexState.Token();
   FuncState fs;
   LuaC.CompileState L;
   InputStream z;
   char[] buff;
   int nbuff;
   LexState.Dyndata dyd = new LexState.Dyndata();
   LuaString source;
   LuaString envn;
   byte decpoint;
   static final String[] luaX_tokens;
   static final int TK_AND = 257;
   static final int TK_BREAK = 258;
   static final int TK_DO = 259;
   static final int TK_ELSE = 260;
   static final int TK_ELSEIF = 261;
   static final int TK_END = 262;
   static final int TK_FALSE = 263;
   static final int TK_FOR = 264;
   static final int TK_FUNCTION = 265;
   static final int TK_GOTO = 266;
   static final int TK_IF = 267;
   static final int TK_IN = 268;
   static final int TK_LOCAL = 269;
   static final int TK_NIL = 270;
   static final int TK_NOT = 271;
   static final int TK_OR = 272;
   static final int TK_REPEAT = 273;
   static final int TK_RETURN = 274;
   static final int TK_THEN = 275;
   static final int TK_TRUE = 276;
   static final int TK_UNTIL = 277;
   static final int TK_WHILE = 278;
   static final int TK_CONCAT = 279;
   static final int TK_DOTS = 280;
   static final int TK_EQ = 281;
   static final int TK_GE = 282;
   static final int TK_LE = 283;
   static final int TK_NE = 284;
   static final int TK_DBCOLON = 285;
   static final int TK_EOS = 286;
   static final int TK_NUMBER = 287;
   static final int TK_NAME = 288;
   static final int TK_STRING = 289;
   static final int FIRST_RESERVED = 257;
   static final int NUM_RESERVED = 22;
   static final Hashtable RESERVED;
   static LexState.Priority[] priority;
   static final int UNARY_PRIORITY = 8;

   private static final String LUA_QS(String s) {
      return "'" + s + "'";
   }

   private static final String LUA_QL(Object o) {
      return LUA_QS(String.valueOf(o));
   }

   public static boolean isReservedKeyword(String varName) {
      return RESERVED_LOCAL_VAR_KEYWORDS_TABLE.containsKey(varName);
   }

   private boolean isalnum(int c) {
      return c >= 48 && c <= 57 || c >= 97 && c <= 122 || c >= 65 && c <= 90 || c == 95;
   }

   private boolean isalpha(int c) {
      return c >= 97 && c <= 122 || c >= 65 && c <= 90;
   }

   private boolean isdigit(int c) {
      return c >= 48 && c <= 57;
   }

   private boolean isxdigit(int c) {
      return c >= 48 && c <= 57 || c >= 97 && c <= 102 || c >= 65 && c <= 70;
   }

   private boolean isspace(int c) {
      return c <= 32;
   }

   public LexState(LuaC.CompileState state, InputStream stream) {
      this.z = stream;
      this.buff = new char[32];
      this.L = state;
   }

   void nextChar() {
      try {
         this.current = this.z.read();
      } catch (IOException var2) {
         var2.printStackTrace();
         this.current = -1;
      }

   }

   boolean currIsNewline() {
      return this.current == 10 || this.current == 13;
   }

   void save_and_next() {
      this.save(this.current);
      this.nextChar();
   }

   void save(int c) {
      if (this.buff == null || this.nbuff + 1 > this.buff.length) {
         this.buff = realloc(this.buff, this.nbuff * 2 + 1);
      }

      this.buff[this.nbuff++] = (char)c;
   }

   String token2str(int token) {
      if (token < 257) {
         return iscntrl(token) ? this.L.pushfstring("char(" + token + ")") : this.L.pushfstring(String.valueOf((char)token));
      } else {
         return luaX_tokens[token - 257];
      }
   }

   private static boolean iscntrl(int token) {
      return token < 32;
   }

   String txtToken(int token) {
      switch(token) {
      case 287:
      case 288:
      case 289:
         return new String(this.buff, 0, this.nbuff);
      default:
         return this.token2str(token);
      }
   }

   void lexerror(String msg, int token) {
      String cid = Lua.chunkid(this.source.tojstring());
      this.L.pushfstring(cid + ":" + this.linenumber + ": " + msg);
      if (token != 0) {
         this.L.pushfstring("syntax error: " + msg + " near " + this.txtToken(token));
      }

      throw new LuaError(cid + ":" + this.linenumber + ": " + msg);
   }

   void syntaxerror(String msg) {
      this.lexerror(msg, this.t.token);
   }

   LuaString newstring(String s) {
      return this.L.newTString(s);
   }

   LuaString newstring(char[] chars, int offset, int len) {
      return this.L.newTString(new String(chars, offset, len));
   }

   void inclinenumber() {
      int old = this.current;
      _assert(this.currIsNewline());
      this.nextChar();
      if (this.currIsNewline() && this.current != old) {
         this.nextChar();
      }

      if (++this.linenumber >= 2147483645) {
         this.syntaxerror("chunk has too many lines");
      }

   }

   void setinput(LuaC.CompileState L, int firstByte, InputStream z, LuaString source) {
      this.decpoint = 46;
      this.L = L;
      this.lookahead.token = 286;
      this.z = z;
      this.fs = null;
      this.linenumber = 1;
      this.lastline = 1;
      this.source = source;
      this.envn = LuaValue.ENV;
      this.nbuff = 0;
      this.current = firstByte;
      this.skipShebang();
   }

   private void skipShebang() {
      if (this.current == 35) {
         while(!this.currIsNewline() && this.current != -1) {
            this.nextChar();
         }
      }

   }

   boolean check_next(String set) {
      if (set.indexOf(this.current) < 0) {
         return false;
      } else {
         this.save_and_next();
         return true;
      }
   }

   void buffreplace(char from, char to) {
      int n = this.nbuff;
      char[] p = this.buff;

      while(true) {
         --n;
         if (n < 0) {
            return;
         }

         if (p[n] == from) {
            p[n] = to;
         }
      }
   }

   LuaValue strx2number(String str, LexState.SemInfo seminfo) {
      char[] c = str.toCharArray();

      int s;
      for(s = 0; s < c.length && this.isspace(c[s]); ++s) {
      }

      double sgn = 1.0D;
      if (s < c.length && c[s] == '-') {
         sgn = -1.0D;
         ++s;
      }

      if (s + 2 >= c.length) {
         return LuaValue.ZERO;
      } else if (c[s++] != '0') {
         return LuaValue.ZERO;
      } else if (c[s] != 'x' && c[s] != 'X') {
         return LuaValue.ZERO;
      } else {
         ++s;
         double m = 0.0D;

         int e;
         for(e = 0; s < c.length && this.isxdigit(c[s]); m = m * 16.0D + (double)this.hexvalue(c[s++])) {
         }

         if (s < c.length && c[s] == '.') {
            ++s;

            while(s < c.length && this.isxdigit(c[s])) {
               m = m * 16.0D + (double)this.hexvalue(c[s++]);
               e -= 4;
            }
         }

         if (s < c.length && (c[s] == 'p' || c[s] == 'P')) {
            ++s;
            int exp1 = 0;
            boolean neg1 = false;
            if (s < c.length && c[s] == '-') {
               neg1 = true;
               ++s;
            }

            while(s < c.length && this.isdigit(c[s])) {
               exp1 = exp1 * 10 + c[s++] - 48;
            }

            if (neg1) {
               exp1 = -exp1;
            }

            e += exp1;
         }

         return LuaValue.valueOf(sgn * m * MathLib.dpow_d(2.0D, (double)e));
      }
   }

   boolean str2d(String str, LexState.SemInfo seminfo) {
      if (str.indexOf(110) < 0 && str.indexOf(78) < 0) {
         if (str.indexOf(120) < 0 && str.indexOf(88) < 0) {
            seminfo.r = LuaValue.valueOf(Double.parseDouble(str.trim()));
         } else {
            seminfo.r = this.strx2number(str, seminfo);
         }
      } else {
         seminfo.r = LuaValue.ZERO;
      }

      return true;
   }

   void read_numeral(LexState.SemInfo seminfo) {
      String expo = "Ee";
      int first = this.current;
      _assert(this.isdigit(this.current));
      this.save_and_next();
      if (first == 48 && this.check_next("Xx")) {
         expo = "Pp";
      }

      while(true) {
         if (this.check_next(expo)) {
            this.check_next("+-");
         }

         if (!this.isxdigit(this.current) && this.current != 46) {
            this.save(0);
            String str = new String(this.buff, 0, this.nbuff);
            this.str2d(str, seminfo);
            return;
         }

         this.save_and_next();
      }
   }

   int skip_sep() {
      int count = 0;
      int s = this.current;
      _assert(s == 91 || s == 93);
      this.save_and_next();

      while(this.current == 61) {
         this.save_and_next();
         ++count;
      }

      return this.current == s ? count : -count - 1;
   }

   void read_long_string(LexState.SemInfo seminfo, int sep) {
      int cont = 0;
      this.save_and_next();
      if (this.currIsNewline()) {
         this.inclinenumber();
      }

      boolean endloop = false;

      while(!endloop) {
         switch(this.current) {
         case -1:
            this.lexerror(seminfo != null ? "unfinished long string" : "unfinished long comment", 286);
            break;
         case 10:
         case 13:
            this.save(10);
            this.inclinenumber();
            if (seminfo == null) {
               this.nbuff = 0;
            }
            break;
         case 91:
            if (this.skip_sep() == sep) {
               this.save_and_next();
               ++cont;
               if (sep == 0) {
                  this.lexerror("nesting of [[...]] is deprecated", 91);
               }
            }
            break;
         case 93:
            if (this.skip_sep() == sep) {
               this.save_and_next();
               endloop = true;
            }
            break;
         default:
            if (seminfo != null) {
               this.save_and_next();
            } else {
               this.nextChar();
            }
         }
      }

      if (seminfo != null) {
         seminfo.ts = this.L.newTString(LuaString.valueOf(this.buff, 2 + sep, this.nbuff - 2 * (2 + sep)));
      }

   }

   int hexvalue(int c) {
      return c <= 57 ? c - 48 : (c <= 70 ? c + 10 - 65 : c + 10 - 97);
   }

   int readhexaesc() {
      this.nextChar();
      int c1 = this.current;
      this.nextChar();
      int c2 = this.current;
      if (!this.isxdigit(c1) || !this.isxdigit(c2)) {
         this.lexerror("hexadecimal digit expected 'x" + (char)c1 + (char)c2, 289);
      }

      return (this.hexvalue(c1) << 4) + this.hexvalue(c2);
   }

   void read_string(int del, LexState.SemInfo seminfo) {
      this.save_and_next();

      while(true) {
         while(true) {
            while(this.current != del) {
               switch(this.current) {
               case -1:
                  this.lexerror("unfinished string", 286);
                  break;
               case 10:
               case 13:
                  this.lexerror("unfinished string", 289);
                  break;
               case 92:
                  this.nextChar();
                  int c;
                  switch(this.current) {
                  case -1:
                     continue;
                  case 10:
                  case 13:
                     this.save(10);
                     this.inclinenumber();
                     continue;
                  case 97:
                     c = 7;
                     break;
                  case 98:
                     c = 8;
                     break;
                  case 102:
                     c = 12;
                     break;
                  case 110:
                     c = 10;
                     break;
                  case 114:
                     c = 13;
                     break;
                  case 116:
                     c = 9;
                     break;
                  case 118:
                     c = 11;
                     break;
                  case 120:
                     c = this.readhexaesc();
                     break;
                  case 122:
                     this.nextChar();

                     while(this.isspace(this.current)) {
                        if (this.currIsNewline()) {
                           this.inclinenumber();
                        } else {
                           this.nextChar();
                        }
                     }
                     continue;
                  default:
                     if (!this.isdigit(this.current)) {
                        this.save_and_next();
                        continue;
                     }

                     int i = 0;
                     c = 0;

                     do {
                        c = 10 * c + (this.current - 48);
                        this.nextChar();
                        ++i;
                     } while(i < 3 && this.isdigit(this.current));

                     if (c > 255) {
                        this.lexerror("escape sequence too large", 289);
                     }

                     this.save(c);
                     continue;
                  }

                  this.save(c);
                  this.nextChar();
                  break;
               default:
                  this.save_and_next();
               }
            }

            this.save_and_next();
            seminfo.ts = this.L.newTString(LuaString.valueOf((char[])this.buff, 1, this.nbuff - 2));
            return;
         }
      }
   }

   int llex(LexState.SemInfo seminfo) {
      this.nbuff = 0;

      label109:
      while(true) {
         int sep;
         switch(this.current) {
         case -1:
            return 286;
         case 10:
         case 13:
            this.inclinenumber();
            break;
         case 34:
         case 39:
            this.read_string(this.current, seminfo);
            return 289;
         case 45:
            this.nextChar();
            if (this.current != 45) {
               return 45;
            }

            this.nextChar();
            if (this.current == 91) {
               sep = this.skip_sep();
               this.nbuff = 0;
               if (sep >= 0) {
                  this.read_long_string((LexState.SemInfo)null, sep);
                  this.nbuff = 0;
                  break;
               }
            }

            while(true) {
               if (this.currIsNewline() || this.current == -1) {
                  continue label109;
               }

               this.nextChar();
            }
         case 46:
            this.save_and_next();
            if (this.check_next(".")) {
               if (this.check_next(".")) {
                  return 280;
               }

               return 279;
            }

            if (!this.isdigit(this.current)) {
               return 46;
            }

            this.read_numeral(seminfo);
            return 287;
         case 48:
         case 49:
         case 50:
         case 51:
         case 52:
         case 53:
         case 54:
         case 55:
         case 56:
         case 57:
            this.read_numeral(seminfo);
            return 287;
         case 58:
            this.nextChar();
            if (this.current != 58) {
               return 58;
            }

            this.nextChar();
            return 285;
         case 60:
            this.nextChar();
            if (this.current != 61) {
               return 60;
            }

            this.nextChar();
            return 283;
         case 62:
            this.nextChar();
            if (this.current != 61) {
               return 62;
            }

            this.nextChar();
            return 282;
         case 91:
            sep = this.skip_sep();
            if (sep >= 0) {
               this.read_long_string(seminfo, sep);
               return 289;
            }

            if (sep == -1) {
               return 91;
            }

            this.lexerror("invalid long string delimiter", 289);
         case 61:
            this.nextChar();
            if (this.current != 61) {
               return 61;
            }

            this.nextChar();
            return 281;
         case 126:
            this.nextChar();
            if (this.current != 61) {
               return 126;
            }

            this.nextChar();
            return 284;
         default:
            if (!this.isspace(this.current)) {
               if (this.isdigit(this.current)) {
                  this.read_numeral(seminfo);
                  return 287;
               }

               if (!this.isalpha(this.current) && this.current != 95) {
                  sep = this.current;
                  this.nextChar();
                  return sep;
               }

               do {
                  do {
                     this.save_and_next();
                  } while(this.isalnum(this.current));
               } while(this.current == 95);

               LuaString ts = this.newstring(this.buff, 0, this.nbuff);
               if (RESERVED.containsKey(ts)) {
                  return (Integer)RESERVED.get(ts);
               }

               seminfo.ts = ts;
               return 288;
            }

            _assert(!this.currIsNewline());
            this.nextChar();
         }
      }
   }

   void next() {
      this.lastline = this.linenumber;
      if (this.lookahead.token != 286) {
         this.t.set(this.lookahead);
         this.lookahead.token = 286;
      } else {
         this.t.token = this.llex(this.t.seminfo);
      }

   }

   void lookahead() {
      _assert(this.lookahead.token == 286);
      this.lookahead.token = this.llex(this.lookahead.seminfo);
   }

   static final boolean vkisvar(int k) {
      return 7 <= k && k <= 9;
   }

   static final boolean vkisinreg(int k) {
      return k == 6 || k == 7;
   }

   boolean hasmultret(int k) {
      return k == 12 || k == 13;
   }

   void anchor_token() {
      _assert(this.fs != null || this.t.token == 286);
      if (this.t.token == 288 || this.t.token == 289) {
         LuaString ts = this.t.seminfo.ts;
         this.L.cachedLuaString(this.t.seminfo.ts);
      }

   }

   void semerror(String msg) {
      this.t.token = 0;
      this.syntaxerror(msg);
   }

   void error_expected(int token) {
      LuaC.CompileState var10001 = this.L;
      String var10002 = this.token2str(token);
      this.syntaxerror(var10001.pushfstring(LUA_QS(var10002) + " expected"));
   }

   boolean testnext(int c) {
      if (this.t.token == c) {
         this.next();
         return true;
      } else {
         return false;
      }
   }

   void check(int c) {
      if (this.t.token != c) {
         this.error_expected(c);
      }

   }

   void checknext(int c) {
      this.check(c);
      this.next();
   }

   void check_condition(boolean c, String msg) {
      if (!c) {
         this.syntaxerror(msg);
      }

   }

   void check_match(int what, int who, int where) {
      if (!this.testnext(what)) {
         if (where == this.linenumber) {
            this.error_expected(what);
         } else {
            LuaC.CompileState var10001 = this.L;
            String var10002 = LUA_QS(this.token2str(what));
            this.syntaxerror(var10001.pushfstring(var10002 + " expected (to close " + LUA_QS(this.token2str(who)) + " at line " + where + ")"));
         }
      }

   }

   LuaString str_checkname() {
      this.check(288);
      LuaString ts = this.t.seminfo.ts;
      this.next();
      return ts;
   }

   void codestring(LexState.expdesc e, LuaString s) {
      e.init(4, this.fs.stringK(s));
   }

   void checkname(LexState.expdesc e) {
      this.codestring(e, this.str_checkname());
   }

   int registerlocalvar(LuaString varname) {
      FuncState fs = this.fs;
      Prototype f = fs.f;
      if (f.locvars == null || fs.nlocvars + 1 > f.locvars.length) {
         f.locvars = realloc(f.locvars, fs.nlocvars * 2 + 1);
      }

      f.locvars[fs.nlocvars] = new LocVars(varname, 0, 0);
      short var10002 = fs.nlocvars;
      fs.nlocvars = (short)(var10002 + 1);
      return var10002;
   }

   void new_localvar(LuaString name) {
      int reg = this.registerlocalvar(name);
      this.fs.checklimit(this.dyd.n_actvar + 1, 200, "local variables");
      if (this.dyd.actvar == null || this.dyd.n_actvar + 1 > this.dyd.actvar.length) {
         this.dyd.actvar = realloc(this.dyd.actvar, Math.max(1, this.dyd.n_actvar * 2));
      }

      this.dyd.actvar[this.dyd.n_actvar++] = new LexState.Vardesc(reg);
   }

   void new_localvarliteral(String v) {
      LuaString ts = this.newstring(v);
      this.new_localvar(ts);
   }

   void adjustlocalvars(int nvars) {
      FuncState fs = this.fs;

      for(fs.nactvar = (short)(fs.nactvar + nvars); nvars > 0; --nvars) {
         fs.getlocvar(fs.nactvar - nvars).startpc = fs.pc;
      }

   }

   void removevars(int tolevel) {
      for(FuncState fs = this.fs; fs.nactvar > tolevel; fs.getlocvar(--fs.nactvar).endpc = fs.pc) {
      }

   }

   void singlevar(LexState.expdesc var) {
      LuaString varname = this.str_checkname();
      FuncState fs = this.fs;
      if (FuncState.singlevaraux(fs, varname, var, 1) == 0) {
         LexState.expdesc key = new LexState.expdesc();
         FuncState.singlevaraux(fs, this.envn, var, 1);
         _assert(var.k == 7 || var.k == 8);
         this.codestring(key, varname);
         fs.indexed(var, key);
      }

   }

   void adjust_assign(int nvars, int nexps, LexState.expdesc e) {
      FuncState fs = this.fs;
      int extra = nvars - nexps;
      if (this.hasmultret(e.k)) {
         ++extra;
         if (extra < 0) {
            extra = 0;
         }

         fs.setreturns(e, extra);
         if (extra > 1) {
            fs.reserveregs(extra - 1);
         }
      } else {
         if (e.k != 0) {
            fs.exp2nextreg(e);
         }

         if (extra > 0) {
            int reg = fs.freereg;
            fs.reserveregs(extra);
            fs.nil(reg, extra);
         }
      }

   }

   void enterlevel() {
      if (++this.L.nCcalls > 200) {
         this.lexerror("chunk has too many syntax levels", 0);
      }

   }

   void leavelevel() {
      --this.L.nCcalls;
   }

   void closegoto(int g, LexState.Labeldesc label) {
      FuncState fs = this.fs;
      LexState.Labeldesc[] gl = this.dyd.gt;
      LexState.Labeldesc gt = gl[g];
      _assert(gt.name.eq_b(label.name));
      if (gt.nactvar < label.nactvar) {
         LuaString vname = fs.getlocvar(gt.nactvar).varname;
         LuaC.CompileState var10000 = this.L;
         String var10001 = String.valueOf(gt.name);
         String msg = var10000.pushfstring("<goto " + var10001 + "> at line " + gt.line + " jumps into the scope of local '" + vname.tojstring() + "'");
         this.semerror(msg);
      }

      fs.patchlist(gt.pc, label.pc);
      System.arraycopy(gl, g + 1, gl, g, this.dyd.n_gt - g - 1);
      gl[--this.dyd.n_gt] = null;
   }

   boolean findlabel(int g) {
      FuncState.BlockCnt bl = this.fs.bl;
      LexState.Dyndata dyd = this.dyd;
      LexState.Labeldesc gt = dyd.gt[g];

      for(int i = bl.firstlabel; i < dyd.n_label; ++i) {
         LexState.Labeldesc lb = dyd.label[i];
         if (lb.name.eq_b(gt.name)) {
            if (gt.nactvar > lb.nactvar && (bl.upval || dyd.n_label > bl.firstlabel)) {
               this.fs.patchclose(gt.pc, lb.nactvar);
            }

            this.closegoto(g, lb);
            return true;
         }
      }

      return false;
   }

   int newlabelentry(LexState.Labeldesc[] l, int index, LuaString name, int line, int pc) {
      l[index] = new LexState.Labeldesc(name, pc, line, this.fs.nactvar);
      return index;
   }

   void findgotos(LexState.Labeldesc lb) {
      LexState.Labeldesc[] gl = this.dyd.gt;
      int i = this.fs.bl.firstgoto;

      while(i < this.dyd.n_gt) {
         if (gl[i].name.eq_b(lb.name)) {
            this.closegoto(i, lb);
         } else {
            ++i;
         }
      }

   }

   void breaklabel() {
      LuaString n = LuaString.valueOf("break");
      int l = this.newlabelentry(this.dyd.label = grow(this.dyd.label, this.dyd.n_label + 1), this.dyd.n_label++, n, 0, this.fs.pc);
      this.findgotos(this.dyd.label[l]);
   }

   void undefgoto(LexState.Labeldesc gt) {
      String msg = this.L.pushfstring(isReservedKeyword(gt.name.tojstring()) ? "<" + String.valueOf(gt.name) + "> at line " + gt.line + " not inside a loop" : "no visible label '" + String.valueOf(gt.name) + "' for <goto> at line " + gt.line);
      this.semerror(msg);
   }

   Prototype addprototype() {
      Prototype f = this.fs.f;
      if (f.p == null || this.fs.np >= f.p.length) {
         f.p = realloc(f.p, Math.max(1, this.fs.np * 2));
      }

      Prototype clp;
      f.p[this.fs.np++] = clp = new Prototype();
      return clp;
   }

   void codeclosure(LexState.expdesc v) {
      FuncState fs = this.fs.prev;
      v.init(11, fs.codeABx(37, 0, fs.np - 1));
      fs.exp2nextreg(v);
   }

   void open_func(FuncState fs, FuncState.BlockCnt bl) {
      fs.prev = this.fs;
      fs.ls = this;
      this.fs = fs;
      fs.pc = 0;
      fs.lasttarget = -1;
      fs.jpc = new IntPtr(-1);
      fs.freereg = 0;
      fs.nk = 0;
      fs.np = 0;
      fs.nups = 0;
      fs.nlocvars = 0;
      fs.nactvar = 0;
      fs.firstlocal = this.dyd.n_actvar;
      fs.bl = null;
      fs.f.source = this.source;
      fs.f.maxstacksize = 2;
      fs.enterblock(bl, false);
   }

   void close_func() {
      FuncState fs = this.fs;
      Prototype f = fs.f;
      fs.ret(0, 0);
      fs.leaveblock();
      f.code = realloc(f.code, fs.pc);
      f.lineinfo = realloc(f.lineinfo, fs.pc);
      f.k = realloc(f.k, fs.nk);
      f.p = realloc(f.p, fs.np);
      f.locvars = realloc(f.locvars, fs.nlocvars);
      f.upvalues = realloc(f.upvalues, fs.nups);
      _assert(fs.bl == null);
      this.fs = fs.prev;
   }

   void fieldsel(LexState.expdesc v) {
      FuncState fs = this.fs;
      LexState.expdesc key = new LexState.expdesc();
      fs.exp2anyregup(v);
      this.next();
      this.checkname(key);
      fs.indexed(v, key);
   }

   void yindex(LexState.expdesc v) {
      this.next();
      this.expr(v);
      this.fs.exp2val(v);
      this.checknext(93);
   }

   void recfield(LexState.ConsControl cc) {
      FuncState fs = this.fs;
      int reg = this.fs.freereg;
      LexState.expdesc key = new LexState.expdesc();
      LexState.expdesc val = new LexState.expdesc();
      if (this.t.token == 288) {
         fs.checklimit(cc.nh, 2147483645, "items in a constructor");
         this.checkname(key);
      } else {
         this.yindex(key);
      }

      ++cc.nh;
      this.checknext(61);
      int rkkey = fs.exp2RK(key);
      this.expr(val);
      fs.codeABC(10, cc.t.u.info, rkkey, fs.exp2RK(val));
      fs.freereg = (short)reg;
   }

   void listfield(LexState.ConsControl cc) {
      this.expr(cc.v);
      this.fs.checklimit(cc.na, 2147483645, "items in a constructor");
      ++cc.na;
      ++cc.tostore;
   }

   void constructor(LexState.expdesc t) {
      FuncState fs = this.fs;
      int line = this.linenumber;
      int pc = fs.codeABC(11, 0, 0, 0);
      LexState.ConsControl cc = new LexState.ConsControl();
      cc.na = cc.nh = cc.tostore = 0;
      cc.t = t;
      t.init(11, pc);
      cc.v.init(0, 0);
      fs.exp2nextreg(t);
      this.checknext(123);

      do {
         _assert(cc.v.k == 0 || cc.tostore > 0);
         if (this.t.token == 125) {
            break;
         }

         fs.closelistfield(cc);
         switch(this.t.token) {
         case 91:
            this.recfield(cc);
            break;
         case 288:
            this.lookahead();
            if (this.lookahead.token != 61) {
               this.listfield(cc);
            } else {
               this.recfield(cc);
            }
            break;
         default:
            this.listfield(cc);
         }
      } while(this.testnext(44) || this.testnext(59));

      this.check_match(125, 123, line);
      fs.lastlistfield(cc);
      InstructionPtr i = new InstructionPtr(fs.f.code, pc);
      SETARG_B(i, luaO_int2fb(cc.na));
      SETARG_C(i, luaO_int2fb(cc.nh));
   }

   static int luaO_int2fb(int x) {
      int e;
      for(e = 0; x >= 16; ++e) {
         x = x + 1 >> 1;
      }

      return x < 8 ? x : e + 1 << 3 | x - 8;
   }

   void parlist() {
      FuncState fs = this.fs;
      Prototype f = fs.f;
      int nparams = 0;
      f.is_vararg = 0;
      if (this.t.token != 41) {
         do {
            switch(this.t.token) {
            case 280:
               this.next();
               f.is_vararg = 1;
               break;
            case 288:
               this.new_localvar(this.str_checkname());
               ++nparams;
               break;
            default:
               this.syntaxerror("<name> or " + LUA_QL("...") + " expected");
            }
         } while(f.is_vararg == 0 && this.testnext(44));
      }

      this.adjustlocalvars(nparams);
      f.numparams = fs.nactvar;
      fs.reserveregs(fs.nactvar);
   }

   void body(LexState.expdesc e, boolean needself, int line) {
      FuncState new_fs = new FuncState();
      FuncState.BlockCnt bl = new FuncState.BlockCnt();
      new_fs.f = this.addprototype();
      new_fs.f.linedefined = line;
      this.open_func(new_fs, bl);
      this.checknext(40);
      if (needself) {
         this.new_localvarliteral("self");
         this.adjustlocalvars(1);
      }

      this.parlist();
      this.checknext(41);
      this.statlist();
      new_fs.f.lastlinedefined = this.linenumber;
      this.check_match(262, 265, line);
      this.codeclosure(e);
      this.close_func();
   }

   int explist(LexState.expdesc v) {
      int n = 1;
      this.expr(v);

      while(this.testnext(44)) {
         this.fs.exp2nextreg(v);
         this.expr(v);
         ++n;
      }

      return n;
   }

   void funcargs(LexState.expdesc f, int line) {
      FuncState fs = this.fs;
      LexState.expdesc args = new LexState.expdesc();
      switch(this.t.token) {
      case 40:
         this.next();
         if (this.t.token == 41) {
            args.k = 0;
         } else {
            this.explist(args);
            fs.setmultret(args);
         }

         this.check_match(41, 40, line);
         break;
      case 123:
         this.constructor(args);
         break;
      case 289:
         this.codestring(args, this.t.seminfo.ts);
         this.next();
         break;
      default:
         this.syntaxerror("function arguments expected");
         return;
      }

      _assert(f.k == 6);
      int base = f.u.info;
      int nparams;
      if (this.hasmultret(args.k)) {
         nparams = -1;
      } else {
         if (args.k != 0) {
            fs.exp2nextreg(args);
         }

         nparams = fs.freereg - (base + 1);
      }

      f.init(12, fs.codeABC(29, base, nparams + 1, 2));
      fs.fixline(line);
      fs.freereg = (short)(base + 1);
   }

   void primaryexp(LexState.expdesc v) {
      switch(this.t.token) {
      case 40:
         int line = this.linenumber;
         this.next();
         this.expr(v);
         this.check_match(41, 40, line);
         this.fs.dischargevars(v);
         return;
      case 288:
         this.singlevar(v);
         return;
      default:
         this.syntaxerror("unexpected symbol " + this.t.token + " (" + (char)this.t.token + ")");
      }
   }

   void suffixedexp(LexState.expdesc v) {
      int line = this.linenumber;
      this.primaryexp(v);

      while(true) {
         LexState.expdesc key;
         switch(this.t.token) {
         case 40:
         case 123:
         case 289:
            this.fs.exp2nextreg(v);
            this.funcargs(v, line);
            break;
         case 46:
            this.fieldsel(v);
            break;
         case 58:
            key = new LexState.expdesc();
            this.next();
            this.checkname(key);
            this.fs.self(v, key);
            this.funcargs(v, line);
            break;
         case 91:
            key = new LexState.expdesc();
            this.fs.exp2anyregup(v);
            this.yindex(key);
            this.fs.indexed(v, key);
            break;
         default:
            return;
         }
      }
   }

   void simpleexp(LexState.expdesc v) {
      switch(this.t.token) {
      case 123:
         this.constructor(v);
         return;
      case 263:
         v.init(3, 0);
         break;
      case 265:
         this.next();
         this.body(v, false, this.linenumber);
         return;
      case 270:
         v.init(1, 0);
         break;
      case 276:
         v.init(2, 0);
         break;
      case 280:
         FuncState fs = this.fs;
         this.check_condition(fs.f.is_vararg != 0, "cannot use " + LUA_QL("...") + " outside a vararg function");
         v.init(13, fs.codeABC(38, 0, 1, 0));
         break;
      case 287:
         v.init(5, 0);
         v.u.setNval(this.t.seminfo.r);
         break;
      case 289:
         this.codestring(v, this.t.seminfo.ts);
         break;
      default:
         this.suffixedexp(v);
         return;
      }

      this.next();
   }

   int getunopr(int op) {
      switch(op) {
      case 35:
         return 2;
      case 45:
         return 0;
      case 271:
         return 1;
      default:
         return 3;
      }
   }

   int getbinopr(int op) {
      switch(op) {
      case 37:
         return 4;
      case 42:
         return 2;
      case 43:
         return 0;
      case 45:
         return 1;
      case 47:
         return 3;
      case 60:
         return 9;
      case 62:
         return 11;
      case 94:
         return 5;
      case 257:
         return 13;
      case 272:
         return 14;
      case 279:
         return 6;
      case 281:
         return 8;
      case 282:
         return 12;
      case 283:
         return 10;
      case 284:
         return 7;
      default:
         return 15;
      }
   }

   int subexpr(LexState.expdesc v, int limit) {
      this.enterlevel();
      int uop = this.getunopr(this.t.token);
      if (uop != 3) {
         int line = this.linenumber;
         this.next();
         this.subexpr(v, 8);
         this.fs.prefix(uop, v, line);
      } else {
         this.simpleexp(v);
      }

      int op;
      int nextop;
      for(op = this.getbinopr(this.t.token); op != 15 && priority[op].left > limit; op = nextop) {
         LexState.expdesc v2 = new LexState.expdesc();
         int line = this.linenumber;
         this.next();
         this.fs.infix(op, v);
         nextop = this.subexpr(v2, priority[op].right);
         this.fs.posfix(op, v, v2, line);
      }

      this.leavelevel();
      return op;
   }

   void expr(LexState.expdesc v) {
      this.subexpr(v, 0);
   }

   boolean block_follow(boolean withuntil) {
      switch(this.t.token) {
      case 260:
      case 261:
      case 262:
      case 286:
         return true;
      case 277:
         return withuntil;
      default:
         return false;
      }
   }

   void block() {
      FuncState fs = this.fs;
      FuncState.BlockCnt bl = new FuncState.BlockCnt();
      fs.enterblock(bl, false);
      this.statlist();
      fs.leaveblock();
   }

   void check_conflict(LexState.LHS_assign lh, LexState.expdesc v) {
      FuncState fs = this.fs;
      short extra = fs.freereg;

      boolean conflict;
      for(conflict = false; lh != null; lh = lh.prev) {
         if (lh.v.k == 9) {
            if (lh.v.u.ind_vt == v.k && lh.v.u.ind_t == v.u.info) {
               conflict = true;
               lh.v.u.ind_vt = 7;
               lh.v.u.ind_t = extra;
            }

            if (v.k == 7 && lh.v.u.ind_idx == v.u.info) {
               conflict = true;
               lh.v.u.ind_idx = extra;
            }
         }
      }

      if (conflict) {
         int op = v.k == 7 ? 0 : 5;
         fs.codeABC(op, extra, v.u.info, 0);
         fs.reserveregs(1);
      }

   }

   void assignment(LexState.LHS_assign lh, int nvars) {
      LexState.expdesc e = new LexState.expdesc();
      this.check_condition(7 <= lh.v.k && lh.v.k <= 9, "syntax error");
      if (this.testnext(44)) {
         LexState.LHS_assign nv = new LexState.LHS_assign();
         nv.prev = lh;
         this.suffixedexp(nv.v);
         if (nv.v.k != 9) {
            this.check_conflict(lh, nv.v);
         }

         this.assignment(nv, nvars + 1);
      } else {
         this.checknext(61);
         int nexps = this.explist(e);
         if (nexps == nvars) {
            this.fs.setoneret(e);
            this.fs.storevar(lh.v, e);
            return;
         }

         this.adjust_assign(nvars, nexps, e);
         if (nexps > nvars) {
            FuncState var10000 = this.fs;
            var10000.freereg = (short)(var10000.freereg - (nexps - nvars));
         }
      }

      e.init(6, this.fs.freereg - 1);
      this.fs.storevar(lh.v, e);
   }

   int cond() {
      LexState.expdesc v = new LexState.expdesc();
      this.expr(v);
      if (v.k == 1) {
         v.k = 3;
      }

      this.fs.goiftrue(v);
      return v.f.i;
   }

   void gotostat(int pc) {
      int line = this.linenumber;
      LuaString label;
      if (this.testnext(266)) {
         label = this.str_checkname();
      } else {
         this.next();
         label = LuaString.valueOf("break");
      }

      int g = this.newlabelentry(this.dyd.gt = grow(this.dyd.gt, this.dyd.n_gt + 1), this.dyd.n_gt++, label, line, pc);
      this.findlabel(g);
   }

   void skipnoopstat() {
      while(this.t.token == 59 || this.t.token == 285) {
         this.statement();
      }

   }

   void labelstat(LuaString label, int line) {
      this.fs.checkrepeated(this.dyd.label, this.dyd.n_label, label);
      this.checknext(285);
      int l = this.newlabelentry(this.dyd.label = grow(this.dyd.label, this.dyd.n_label + 1), this.dyd.n_label++, label, line, this.fs.pc);
      this.skipnoopstat();
      if (this.block_follow(false)) {
         this.dyd.label[l].nactvar = this.fs.bl.nactvar;
      }

      this.findgotos(this.dyd.label[l]);
   }

   void whilestat(int line) {
      FuncState fs = this.fs;
      FuncState.BlockCnt bl = new FuncState.BlockCnt();
      this.next();
      int whileinit = fs.getlabel();
      int condexit = this.cond();
      fs.enterblock(bl, true);
      this.checknext(259);
      this.block();
      fs.patchlist(fs.jump(), whileinit);
      this.check_match(262, 278, line);
      fs.leaveblock();
      fs.patchtohere(condexit);
   }

   void repeatstat(int line) {
      FuncState fs = this.fs;
      int repeat_init = fs.getlabel();
      FuncState.BlockCnt bl1 = new FuncState.BlockCnt();
      FuncState.BlockCnt bl2 = new FuncState.BlockCnt();
      fs.enterblock(bl1, true);
      fs.enterblock(bl2, false);
      this.next();
      this.statlist();
      this.check_match(277, 273, line);
      int condexit = this.cond();
      if (bl2.upval) {
         fs.patchclose(condexit, bl2.nactvar);
      }

      fs.leaveblock();
      fs.patchlist(condexit, repeat_init);
      fs.leaveblock();
   }

   int exp1() {
      LexState.expdesc e = new LexState.expdesc();
      this.expr(e);
      int k = e.k;
      this.fs.exp2nextreg(e);
      return k;
   }

   void forbody(int base, int line, int nvars, boolean isnum) {
      FuncState.BlockCnt bl = new FuncState.BlockCnt();
      FuncState fs = this.fs;
      this.adjustlocalvars(3);
      this.checknext(259);
      int prep = isnum ? fs.codeAsBx(33, base, -1) : fs.jump();
      fs.enterblock(bl, false);
      this.adjustlocalvars(nvars);
      fs.reserveregs(nvars);
      this.block();
      fs.leaveblock();
      fs.patchtohere(prep);
      int endfor;
      if (isnum) {
         endfor = fs.codeAsBx(32, base, -1);
      } else {
         fs.codeABC(34, base, 0, nvars);
         fs.fixline(line);
         endfor = fs.codeAsBx(35, base + 2, -1);
      }

      fs.patchlist(endfor, prep + 1);
      fs.fixline(line);
   }

   void fornum(LuaString varname, int line) {
      FuncState fs = this.fs;
      int base = fs.freereg;
      this.new_localvarliteral("(for index)");
      this.new_localvarliteral("(for limit)");
      this.new_localvarliteral("(for step)");
      this.new_localvar(varname);
      this.checknext(61);
      this.exp1();
      this.checknext(44);
      this.exp1();
      if (this.testnext(44)) {
         this.exp1();
      } else {
         fs.codeABx(1, fs.freereg, fs.numberK(LuaInteger.valueOf(1)));
         fs.reserveregs(1);
      }

      this.forbody(base, line, 1, true);
   }

   void forlist(LuaString indexname) {
      FuncState fs = this.fs;
      LexState.expdesc e = new LexState.expdesc();
      int nvars = 4;
      int base = fs.freereg;
      this.new_localvarliteral("(for generator)");
      this.new_localvarliteral("(for state)");
      this.new_localvarliteral("(for control)");
      this.new_localvar(indexname);

      while(this.testnext(44)) {
         this.new_localvar(this.str_checkname());
         ++nvars;
      }

      this.checknext(268);
      int line = this.linenumber;
      this.adjust_assign(3, this.explist(e), e);
      fs.checkstack(3);
      this.forbody(base, line, nvars - 3, false);
   }

   void forstat(int line) {
      FuncState fs = this.fs;
      FuncState.BlockCnt bl = new FuncState.BlockCnt();
      fs.enterblock(bl, true);
      this.next();
      LuaString varname = this.str_checkname();
      switch(this.t.token) {
      case 44:
      case 268:
         this.forlist(varname);
         break;
      case 61:
         this.fornum(varname, line);
         break;
      default:
         String var10001 = LUA_QL("=");
         this.syntaxerror(var10001 + " or " + LUA_QL("in") + " expected");
      }

      this.check_match(262, 264, line);
      fs.leaveblock();
   }

   void test_then_block(IntPtr escapelist) {
      LexState.expdesc v = new LexState.expdesc();
      FuncState.BlockCnt bl = new FuncState.BlockCnt();
      this.next();
      this.expr(v);
      this.checknext(275);
      int jf;
      if (this.t.token != 266 && this.t.token != 258) {
         this.fs.goiftrue(v);
         this.fs.enterblock(bl, false);
         jf = v.f.i;
      } else {
         this.fs.goiffalse(v);
         this.fs.enterblock(bl, false);
         this.gotostat(v.t.i);
         this.skipnoopstat();
         if (this.block_follow(false)) {
            this.fs.leaveblock();
            return;
         }

         jf = this.fs.jump();
      }

      this.statlist();
      this.fs.leaveblock();
      if (this.t.token == 260 || this.t.token == 261) {
         this.fs.concat(escapelist, this.fs.jump());
      }

      this.fs.patchtohere(jf);
   }

   void ifstat(int line) {
      IntPtr escapelist = new IntPtr(-1);
      this.test_then_block(escapelist);

      while(this.t.token == 261) {
         this.test_then_block(escapelist);
      }

      if (this.testnext(260)) {
         this.block();
      }

      this.check_match(262, 267, line);
      this.fs.patchtohere(escapelist.i);
   }

   void localfunc() {
      LexState.expdesc b = new LexState.expdesc();
      FuncState fs = this.fs;
      this.new_localvar(this.str_checkname());
      this.adjustlocalvars(1);
      this.body(b, false, this.linenumber);
      fs.getlocvar(fs.nactvar - 1).startpc = fs.pc;
   }

   void localstat() {
      int nvars = 0;
      LexState.expdesc e = new LexState.expdesc();

      do {
         this.new_localvar(this.str_checkname());
         ++nvars;
      } while(this.testnext(44));

      int nexps;
      if (this.testnext(61)) {
         nexps = this.explist(e);
      } else {
         e.k = 0;
         nexps = 0;
      }

      this.adjust_assign(nvars, nexps, e);
      this.adjustlocalvars(nvars);
   }

   boolean funcname(LexState.expdesc v) {
      boolean ismethod = false;
      this.singlevar(v);

      while(this.t.token == 46) {
         this.fieldsel(v);
      }

      if (this.t.token == 58) {
         ismethod = true;
         this.fieldsel(v);
      }

      return ismethod;
   }

   void funcstat(int line) {
      LexState.expdesc v = new LexState.expdesc();
      LexState.expdesc b = new LexState.expdesc();
      this.next();
      boolean needself = this.funcname(v);
      this.body(b, needself, line);
      this.fs.storevar(v, b);
      this.fs.fixline(line);
   }

   void exprstat() {
      FuncState fs = this.fs;
      LexState.LHS_assign v = new LexState.LHS_assign();
      this.suffixedexp(v.v);
      if (this.t.token != 61 && this.t.token != 44) {
         this.check_condition(v.v.k == 12, "syntax error");
         SETARG_C(fs.getcodePtr(v.v), 1);
      } else {
         v.prev = null;
         this.assignment(v, 1);
      }

   }

   void retstat() {
      FuncState fs = this.fs;
      LexState.expdesc e = new LexState.expdesc();
      int first;
      int nret;
      if (!this.block_follow(true) && this.t.token != 59) {
         nret = this.explist(e);
         if (this.hasmultret(e.k)) {
            fs.setmultret(e);
            if (e.k == 12 && nret == 1) {
               SET_OPCODE(fs.getcodePtr(e), 30);
               _assert(Lua.GETARG_A(fs.getcode(e)) == fs.nactvar);
            }

            first = fs.nactvar;
            nret = -1;
         } else if (nret == 1) {
            first = fs.exp2anyreg(e);
         } else {
            fs.exp2nextreg(e);
            first = fs.nactvar;
            _assert(nret == fs.freereg - first);
         }
      } else {
         nret = 0;
         first = 0;
      }

      fs.ret(first, nret);
      this.testnext(59);
   }

   void statement() {
      int line = this.linenumber;
      this.enterlevel();
      switch(this.t.token) {
      case 59:
         this.next();
         break;
      case 258:
      case 266:
         this.gotostat(this.fs.jump());
         break;
      case 259:
         this.next();
         this.block();
         this.check_match(262, 259, line);
         break;
      case 264:
         this.forstat(line);
         break;
      case 265:
         this.funcstat(line);
         break;
      case 267:
         this.ifstat(line);
         break;
      case 269:
         this.next();
         if (this.testnext(265)) {
            this.localfunc();
         } else {
            this.localstat();
         }
         break;
      case 273:
         this.repeatstat(line);
         break;
      case 274:
         this.next();
         this.retstat();
         break;
      case 278:
         this.whilestat(line);
         break;
      case 285:
         this.next();
         this.labelstat(this.str_checkname(), line);
         break;
      default:
         this.exprstat();
      }

      _assert(this.fs.f.maxstacksize >= this.fs.freereg && this.fs.freereg >= this.fs.nactvar);
      this.fs.freereg = this.fs.nactvar;
      this.leavelevel();
   }

   void statlist() {
      while(!this.block_follow(true)) {
         if (this.t.token == 274) {
            this.statement();
            return;
         }

         this.statement();
      }

   }

   public void mainfunc(FuncState funcstate) {
      FuncState.BlockCnt bl = new FuncState.BlockCnt();
      this.open_func(funcstate, bl);
      this.fs.f.is_vararg = 1;
      LexState.expdesc v = new LexState.expdesc();
      v.init(7, 0);
      this.fs.newupvalue(this.envn, v);
      this.next();
      this.statlist();
      this.check(286);
      this.close_func();
   }

   static {
      int i;
      for(i = 0; i < RESERVED_LOCAL_VAR_KEYWORDS.length; ++i) {
         RESERVED_LOCAL_VAR_KEYWORDS_TABLE.put(RESERVED_LOCAL_VAR_KEYWORDS[i], Boolean.TRUE);
      }

      luaX_tokens = new String[]{"and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while", "..", "...", "==", ">=", "<=", "~=", "::", "<eos>", "<number>", "<name>", "<string>", "<eof>"};
      RESERVED = new Hashtable();

      for(i = 0; i < 22; ++i) {
         LuaString ts = LuaValue.valueOf(luaX_tokens[i]);
         RESERVED.put(ts, new Integer(257 + i));
      }

      priority = new LexState.Priority[]{new LexState.Priority(6, 6), new LexState.Priority(6, 6), new LexState.Priority(7, 7), new LexState.Priority(7, 7), new LexState.Priority(7, 7), new LexState.Priority(10, 9), new LexState.Priority(5, 4), new LexState.Priority(3, 3), new LexState.Priority(3, 3), new LexState.Priority(3, 3), new LexState.Priority(3, 3), new LexState.Priority(3, 3), new LexState.Priority(3, 3), new LexState.Priority(2, 2), new LexState.Priority(1, 1)};
   }

   @Environment(EnvType.CLIENT)
   private static class Token {
      int token;
      final LexState.SemInfo seminfo = new LexState.SemInfo();

      public void set(LexState.Token other) {
         this.token = other.token;
         this.seminfo.r = other.seminfo.r;
         this.seminfo.ts = other.seminfo.ts;
      }
   }

   @Environment(EnvType.CLIENT)
   static class Dyndata {
      LexState.Vardesc[] actvar;
      int n_actvar = 0;
      LexState.Labeldesc[] gt;
      int n_gt = 0;
      LexState.Labeldesc[] label;
      int n_label = 0;
   }

   @Environment(EnvType.CLIENT)
   private static class SemInfo {
      LuaValue r;
      LuaString ts;
   }

   @Environment(EnvType.CLIENT)
   static class expdesc {
      int k;
      final LexState.expdesc.U u = new LexState.expdesc.U();
      final IntPtr t = new IntPtr();
      final IntPtr f = new IntPtr();

      void init(int k, int i) {
         this.f.i = -1;
         this.t.i = -1;
         this.k = k;
         this.u.info = i;
      }

      boolean hasjumps() {
         return this.t.i != this.f.i;
      }

      boolean isnumeral() {
         return this.k == 5 && this.t.i == -1 && this.f.i == -1;
      }

      public void setvalue(LexState.expdesc other) {
         this.f.i = other.f.i;
         this.k = other.k;
         this.t.i = other.t.i;
         this.u._nval = other.u._nval;
         this.u.ind_idx = other.u.ind_idx;
         this.u.ind_t = other.u.ind_t;
         this.u.ind_vt = other.u.ind_vt;
         this.u.info = other.u.info;
      }

      @Environment(EnvType.CLIENT)
      static class U {
         short ind_idx;
         short ind_t;
         short ind_vt;
         private LuaValue _nval;
         int info;

         public void setNval(LuaValue r) {
            this._nval = r;
         }

         public LuaValue nval() {
            return (LuaValue)(this._nval == null ? LuaInteger.valueOf(this.info) : this._nval);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static class Vardesc {
      final short idx;

      Vardesc(int idx) {
         this.idx = (short)idx;
      }
   }

   @Environment(EnvType.CLIENT)
   static class Labeldesc {
      LuaString name;
      int pc;
      int line;
      short nactvar;

      public Labeldesc(LuaString name, int pc, int line, short nactvar) {
         this.name = name;
         this.pc = pc;
         this.line = line;
         this.nactvar = nactvar;
      }
   }

   @Environment(EnvType.CLIENT)
   static class ConsControl {
      LexState.expdesc v = new LexState.expdesc();
      LexState.expdesc t;
      int nh;
      int na;
      int tostore;
   }

   @Environment(EnvType.CLIENT)
   static class Priority {
      final byte left;
      final byte right;

      public Priority(int i, int j) {
         this.left = (byte)i;
         this.right = (byte)j;
      }
   }

   @Environment(EnvType.CLIENT)
   static class LHS_assign {
      LexState.LHS_assign prev;
      LexState.expdesc v = new LexState.expdesc();
   }
}
