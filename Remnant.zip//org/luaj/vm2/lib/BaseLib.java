package org.luaj.vm2.lib;

import java.io.IOException;
import java.io.InputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaThread;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public class BaseLib extends TwoArgFunction implements ResourceFinder {
   Globals globals;

   public LuaValue call(LuaValue modname, LuaValue env) {
      this.globals = env.checkglobals();
      this.globals.finder = this;
      this.globals.baselib = this;
      env.set("_G", env);
      env.set("_VERSION", "Luaj-jse 3.0.1");
      env.set((String)"assert", (LuaValue)(new BaseLib._assert()));
      env.set((String)"collectgarbage", (LuaValue)(new BaseLib.collectgarbage()));
      env.set((String)"dofile", (LuaValue)(new BaseLib.dofile()));
      env.set((String)"error", (LuaValue)(new BaseLib.error()));
      env.set((String)"getmetatable", (LuaValue)(new BaseLib.getmetatable()));
      env.set((String)"load", (LuaValue)(new BaseLib.load()));
      env.set((String)"loadfile", (LuaValue)(new BaseLib.loadfile()));
      env.set((String)"pcall", (LuaValue)(new BaseLib.pcall()));
      env.set((String)"print", (LuaValue)(new BaseLib.print(this)));
      env.set((String)"rawequal", (LuaValue)(new BaseLib.rawequal()));
      env.set((String)"rawget", (LuaValue)(new BaseLib.rawget()));
      env.set((String)"rawlen", (LuaValue)(new BaseLib.rawlen()));
      env.set((String)"rawset", (LuaValue)(new BaseLib.rawset()));
      env.set((String)"select", (LuaValue)(new BaseLib.select()));
      env.set((String)"setmetatable", (LuaValue)(new BaseLib.setmetatable()));
      env.set((String)"tonumber", (LuaValue)(new BaseLib.tonumber()));
      env.set((String)"tostring", (LuaValue)(new BaseLib.tostring()));
      env.set((String)"type", (LuaValue)(new BaseLib.type()));
      env.set((String)"xpcall", (LuaValue)(new BaseLib.xpcall()));
      BaseLib.next next;
      env.set((String)"next", (LuaValue)(next = new BaseLib.next()));
      env.set((String)"pairs", (LuaValue)(new BaseLib.pairs(next)));
      env.set((String)"ipairs", (LuaValue)(new BaseLib.ipairs()));
      return env;
   }

   public InputStream findResource(String filename) {
      return this.getClass().getResourceAsStream(filename.startsWith("/") ? filename : "/" + filename);
   }

   public Varargs loadFile(String filename, String mode, LuaValue env) {
      InputStream is = this.globals.finder.findResource(filename);
      if (is == null) {
         return varargsOf(NIL, valueOf("cannot open " + filename + ": No such file or directory"));
      } else {
         Varargs var5;
         try {
            var5 = this.loadStream(is, "@" + filename, mode, env);
         } finally {
            try {
               is.close();
            } catch (Exception var12) {
               var12.printStackTrace();
            }

         }

         return var5;
      }
   }

   public Varargs loadStream(InputStream is, String chunkname, String mode, LuaValue env) {
      try {
         return (Varargs)(is == null ? varargsOf(NIL, valueOf("not found: " + chunkname)) : this.globals.load(is, chunkname, mode, env));
      } catch (Exception var6) {
         return varargsOf(NIL, valueOf(var6.getMessage()));
      }
   }

   @Environment(EnvType.CLIENT)
   static final class _assert extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         if (!args.arg1().toboolean()) {
            error(args.narg() > 1 ? args.optjstring(2, "assertion failed!") : "assertion failed!");
         }

         return args;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class collectgarbage extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         String s = args.optjstring(1, "collect");
         if ("collect".equals(s)) {
            System.gc();
            return ZERO;
         } else if ("count".equals(s)) {
            Runtime rt = Runtime.getRuntime();
            long used = rt.totalMemory() - rt.freeMemory();
            return varargsOf(valueOf((double)used / 1024.0D), valueOf((double)(used % 1024L)));
         } else if ("step".equals(s)) {
            System.gc();
            return LuaValue.TRUE;
         } else {
            this.argerror("gc op");
            return NIL;
         }
      }
   }

   @Environment(EnvType.CLIENT)
   final class dofile extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         args.argcheck(args.isstring(1) || args.isnil(1), 1, "filename must be string or nil");
         String filename = args.isstring(1) ? args.tojstring(1) : null;
         Varargs v = filename == null ? BaseLib.this.loadStream(BaseLib.this.globals.STDIN, "=stdin", "bt", BaseLib.this.globals) : BaseLib.this.loadFile(args.checkjstring(1), "bt", BaseLib.this.globals);
         return (Varargs)(v.isnil(1) ? error(v.tojstring(2)) : v.arg1().invoke());
      }
   }

   @Environment(EnvType.CLIENT)
   static final class error extends TwoArgFunction {
      public LuaValue call(LuaValue arg1, LuaValue arg2) {
         throw arg1.isnil() ? new LuaError((String)null, arg2.optint(1)) : (arg1.isstring() ? new LuaError(arg1.tojstring(), arg2.optint(1)) : new LuaError(arg1));
      }
   }

   @Environment(EnvType.CLIENT)
   static final class getmetatable extends LibFunction {
      public LuaValue call() {
         return argerror(1, "value");
      }

      public LuaValue call(LuaValue arg) {
         LuaValue mt = arg.getmetatable();
         return mt != null ? mt.rawget((LuaValue)METATABLE).optvalue(mt) : NIL;
      }
   }

   @Environment(EnvType.CLIENT)
   final class load extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaValue ld = args.arg1();
         args.argcheck(ld.isstring() || ld.isfunction(), 1, "ld must be string or function");
         String source = args.optjstring(2, ld.isstring() ? ld.tojstring() : "=(load)");
         String mode = args.optjstring(3, "bt");
         LuaValue env = args.optvalue(4, BaseLib.this.globals);
         return BaseLib.this.loadStream((InputStream)(ld.isstring() ? ld.strvalue().toInputStream() : new BaseLib.StringInputStream(ld.checkfunction())), source, mode, env);
      }
   }

   @Environment(EnvType.CLIENT)
   final class loadfile extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         args.argcheck(args.isstring(1) || args.isnil(1), 1, "filename must be string or nil");
         String filename = args.isstring(1) ? args.tojstring(1) : null;
         String mode = args.optjstring(2, "bt");
         LuaValue env = args.optvalue(3, BaseLib.this.globals);
         return filename == null ? BaseLib.this.loadStream(BaseLib.this.globals.STDIN, "=stdin", mode, env) : BaseLib.this.loadFile(filename, mode, env);
      }
   }

   @Environment(EnvType.CLIENT)
   final class pcall extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaValue func = args.checkvalue(1);
         if (BaseLib.this.globals != null && BaseLib.this.globals.debuglib != null) {
            BaseLib.this.globals.debuglib.onCall(this);
         }

         Varargs var5;
         try {
            Varargs var3 = varargsOf(TRUE, func.invoke(args.subargs(2)));
            return var3;
         } catch (LuaError var10) {
            LuaValue m = var10.getMessageObject();
            var5 = varargsOf(FALSE, m != null ? m : NIL);
         } catch (Exception var11) {
            String mx = var11.getMessage();
            var5 = varargsOf(FALSE, valueOf(mx != null ? mx : var11.toString()));
            return var5;
         } finally {
            if (BaseLib.this.globals != null && BaseLib.this.globals.debuglib != null) {
               BaseLib.this.globals.debuglib.onReturn();
            }

         }

         return var5;
      }
   }

   @Environment(EnvType.CLIENT)
   final class print extends VarArgFunction {
      final BaseLib baselib;

      print(BaseLib baselib) {
         this.baselib = baselib;
      }

      public Varargs invoke(Varargs args) {
         LuaValue tostring = BaseLib.this.globals.get("tostring");
         int i = 1;

         for(int n = args.narg(); i <= n; ++i) {
            if (i > 1) {
               BaseLib.this.globals.STDOUT.print('\t');
            }

            LuaString s = tostring.call(args.arg(i)).strvalue();
            BaseLib.this.globals.STDOUT.print(s.tojstring());
         }

         BaseLib.this.globals.STDOUT.println();
         return NONE;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class rawequal extends LibFunction {
      public LuaValue call() {
         return argerror(1, "value");
      }

      public LuaValue call(LuaValue arg) {
         return argerror(2, "value");
      }

      public LuaValue call(LuaValue arg1, LuaValue arg2) {
         return valueOf(arg1.raweq(arg2));
      }
   }

   @Environment(EnvType.CLIENT)
   static final class rawget extends LibFunction {
      public LuaValue call() {
         return argerror(1, "value");
      }

      public LuaValue call(LuaValue arg) {
         return argerror(2, "value");
      }

      public LuaValue call(LuaValue arg1, LuaValue arg2) {
         return arg1.checktable().rawget(arg2);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class rawlen extends LibFunction {
      public LuaValue call(LuaValue arg) {
         return valueOf(arg.rawlen());
      }
   }

   @Environment(EnvType.CLIENT)
   static final class rawset extends LibFunction {
      public LuaValue call(LuaValue table) {
         return argerror(2, "value");
      }

      public LuaValue call(LuaValue table, LuaValue index) {
         return argerror(3, "value");
      }

      public LuaValue call(LuaValue table, LuaValue index, LuaValue value) {
         LuaTable t = table.checktable();
         t.rawset(index.checknotnil(), value);
         return t;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class select extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         int n = args.narg() - 1;
         if (args.arg1().equals(valueOf("#"))) {
            return valueOf(n);
         } else {
            int i = args.checkint(1);
            if (i == 0 || i < -n) {
               argerror(1, "index out of range");
            }

            return args.subargs(i < 0 ? n + i + 2 : i + 1);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class setmetatable extends LibFunction {
      public LuaValue call(LuaValue table) {
         return argerror(2, "value");
      }

      public LuaValue call(LuaValue table, LuaValue metatable) {
         LuaValue mt0 = table.checktable().getmetatable();
         if (mt0 != null && !mt0.rawget((LuaValue)METATABLE).isnil()) {
            error("cannot change a protected metatable");
         }

         return table.setmetatable(metatable.isnil() ? null : metatable.checktable());
      }
   }

   @Environment(EnvType.CLIENT)
   static final class tonumber extends LibFunction {
      public LuaValue call(LuaValue e) {
         return e.tonumber();
      }

      public LuaValue call(LuaValue e, LuaValue base) {
         if (base.isnil()) {
            return e.tonumber();
         } else {
            int b = base.checkint();
            if (b < 2 || b > 36) {
               argerror(2, "base out of range");
            }

            return e.checkstring().tonumber(b);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class tostring extends LibFunction {
      public LuaValue call(LuaValue arg) {
         LuaValue h = arg.metatag(TOSTRING);
         if (!h.isnil()) {
            return h.call(arg);
         } else {
            LuaValue v = arg.tostring();
            return (LuaValue)(!v.isnil() ? v : valueOf(arg.tojstring()));
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class type extends LibFunction {
      public LuaValue call(LuaValue arg) {
         return valueOf(arg.typename());
      }
   }

   @Environment(EnvType.CLIENT)
   final class xpcall extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaThread t = BaseLib.this.globals.running;
         LuaValue preverror = t.errorfunc;
         t.errorfunc = args.checkvalue(2);

         Varargs var6;
         try {
            if (BaseLib.this.globals != null && BaseLib.this.globals.debuglib != null) {
               BaseLib.this.globals.debuglib.onCall(this);
            }

            try {
               Object e;
               try {
                  e = varargsOf(TRUE, args.arg1().invoke(args.subargs(3)));
                  return (Varargs)e;
               } catch (LuaError var17) {
                  e = var17;
                  LuaValue mx = var17.getMessageObject();
                  var6 = varargsOf(FALSE, mx != null ? mx : NIL);
               } catch (Exception var18) {
                  e = var18;
                  String m = var18.getMessage();
                  var6 = varargsOf(FALSE, valueOf(m != null ? m : var18.toString()));
                  return var6;
               }
            } finally {
               if (BaseLib.this.globals != null && BaseLib.this.globals.debuglib != null) {
                  BaseLib.this.globals.debuglib.onReturn();
               }

            }
         } finally {
            t.errorfunc = preverror;
         }

         return var6;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class next extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         return args.checktable(1).next(args.arg(2));
      }
   }

   @Environment(EnvType.CLIENT)
   static final class pairs extends VarArgFunction {
      final BaseLib.next next;

      pairs(BaseLib.next next) {
         this.next = next;
      }

      public Varargs invoke(Varargs args) {
         return varargsOf(this.next, args.checktable(1), NIL);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class ipairs extends VarArgFunction {
      BaseLib.inext inext = new BaseLib.inext();

      public Varargs invoke(Varargs args) {
         return varargsOf(this.inext, args.checktable(1), ZERO);
      }
   }

   @Environment(EnvType.CLIENT)
   private static class StringInputStream extends InputStream {
      final LuaValue func;
      byte[] bytes;
      int offset;
      int remaining = 0;

      StringInputStream(LuaValue func) {
         this.func = func;
      }

      public int read() throws IOException {
         if (this.remaining <= 0) {
            LuaValue s = this.func.call();
            if (s.isnil()) {
               return -1;
            }

            LuaString ls = s.strvalue();
            this.bytes = ls.m_bytes;
            this.offset = ls.m_offset;
            this.remaining = ls.m_length;
            if (this.remaining <= 0) {
               return -1;
            }
         }

         --this.remaining;
         return this.bytes[this.offset++];
      }
   }

   @Environment(EnvType.CLIENT)
   static final class inext extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         return args.checktable(1).inext(args.arg(2));
      }
   }
}
