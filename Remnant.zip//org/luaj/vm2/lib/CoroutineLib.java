package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaThread;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public class CoroutineLib extends TwoArgFunction {
   static int coroutine_count = 0;
   Globals globals;

   public LuaValue call(LuaValue modname, LuaValue env) {
      this.globals = env.checkglobals();
      LuaTable coroutine = new LuaTable();
      coroutine.set("create", new CoroutineLib.create());
      coroutine.set("resume", new CoroutineLib.resume(this));
      coroutine.set("running", new CoroutineLib.running());
      coroutine.set("status", new CoroutineLib.status());
      coroutine.set("yield", new CoroutineLib.Yield());
      coroutine.set("wrap", new CoroutineLib.wrap());
      env.set((String)"coroutine", (LuaValue)coroutine);
      env.get("package").get("loaded").set((String)"coroutine", (LuaValue)coroutine);
      return coroutine;
   }

   @Environment(EnvType.CLIENT)
   final class create extends LibFunction {
      public LuaValue call(LuaValue f) {
         return new LuaThread(CoroutineLib.this.globals, f.checkfunction());
      }
   }

   @Environment(EnvType.CLIENT)
   final class resume extends VarArgFunction {
      resume(final CoroutineLib this$0) {
      }

      public Varargs invoke(Varargs args) {
         LuaThread t = args.checkthread(1);
         return t.resume(args.subargs(2));
      }
   }

   @Environment(EnvType.CLIENT)
   final class running extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaThread r = CoroutineLib.this.globals.running;
         return varargsOf(r, valueOf(r.isMainThread()));
      }
   }

   @Environment(EnvType.CLIENT)
   static final class status extends LibFunction {
      public LuaValue call(LuaValue t) {
         LuaThread lt = t.checkthread();
         return valueOf(lt.getStatus());
      }
   }

   @Environment(EnvType.CLIENT)
   final class Yield extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         return CoroutineLib.this.globals.yield(args);
      }
   }

   @Environment(EnvType.CLIENT)
   final class wrap extends LibFunction {
      public LuaValue call(LuaValue f) {
         LuaValue func = f.checkfunction();
         LuaThread thread = new LuaThread(CoroutineLib.this.globals, func);
         return CoroutineLib.this.new wrapper(CoroutineLib.this, thread);
      }
   }

   @Environment(EnvType.CLIENT)
   final class wrapper extends VarArgFunction {
      final LuaThread luathread;

      wrapper(final CoroutineLib this$0, LuaThread luathread) {
         this.luathread = luathread;
      }

      public Varargs invoke(Varargs args) {
         Varargs result = this.luathread.resume(args);
         return (Varargs)(result.arg1().toboolean() ? result.subargs(2) : error(result.arg(2).tojstring()));
      }
   }
}
