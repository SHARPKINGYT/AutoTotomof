package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.Lua;
import org.luaj.vm2.LuaBoolean;
import org.luaj.vm2.LuaClosure;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaNil;
import org.luaj.vm2.LuaNumber;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaThread;
import org.luaj.vm2.LuaUserdata;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Print;
import org.luaj.vm2.Prototype;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public class DebugLib extends TwoArgFunction {
   public static boolean CALLS;
   public static boolean TRACE;
   private static final LuaString LUA;
   private static final LuaString QMARK;
   private static final LuaString CALL;
   private static final LuaString LINE;
   private static final LuaString COUNT;
   private static final LuaString RETURN;
   private static final LuaString FUNC;
   private static final LuaString ISTAILCALL;
   private static final LuaString ISVARARG;
   private static final LuaString NUPS;
   private static final LuaString NPARAMS;
   private static final LuaString NAME;
   private static final LuaString NAMEWHAT;
   private static final LuaString WHAT;
   private static final LuaString SOURCE;
   private static final LuaString SHORT_SRC;
   private static final LuaString LINEDEFINED;
   private static final LuaString LASTLINEDEFINED;
   private static final LuaString CURRENTLINE;
   private static final LuaString ACTIVELINES;
   Globals globals;

   public LuaValue call(LuaValue modname, LuaValue env) {
      this.globals = env.checkglobals();
      this.globals.debuglib = this;
      LuaTable debug = new LuaTable();
      debug.set("debug", new DebugLib.debug());
      debug.set("gethook", new DebugLib.gethook());
      debug.set("getinfo", new DebugLib.getinfo());
      debug.set("getlocal", new DebugLib.getlocal());
      debug.set("getmetatable", new DebugLib.getmetatable(this));
      debug.set("getregistry", new DebugLib.getregistry());
      debug.set("getupvalue", new DebugLib.getupvalue());
      debug.set("getuservalue", new DebugLib.getuservalue());
      debug.set("sethook", new DebugLib.sethook());
      debug.set("setlocal", new DebugLib.setlocal());
      debug.set("setmetatable", new DebugLib.setmetatable(this));
      debug.set("setupvalue", new DebugLib.setupvalue(this));
      debug.set("setuservalue", new DebugLib.setuservalue(this));
      debug.set("traceback", new DebugLib.traceback());
      debug.set("upvalueid", new DebugLib.upvalueid(this));
      debug.set("upvaluejoin", new DebugLib.upvaluejoin(this));
      env.set((String)"debug", (LuaValue)debug);
      env.get("package").get("loaded").set((String)"debug", (LuaValue)debug);
      return debug;
   }

   public void onCall(LuaFunction f) {
      LuaThread.State s = this.globals.running.state;
      if (!s.inhook) {
         this.callstack().onCall(f);
         if (s.hookcall) {
            this.callHook(s, CALL, NIL);
         }

      }
   }

   public void onCall(LuaClosure c, Varargs varargs, LuaValue[] stack) {
      LuaThread.State s = this.globals.running.state;
      if (!s.inhook) {
         this.callstack().onCall(c, varargs, stack);
         if (s.hookcall) {
            this.callHook(s, CALL, NIL);
         }

      }
   }

   public void onInstruction(int pc, Varargs v, int top) {
      LuaThread.State s = this.globals.running.state;
      if (!s.inhook) {
         this.callstack().onInstruction(pc, v, top);
         if (s.hookfunc != null) {
            if (s.hookcount > 0 && ++s.bytecodes % s.hookcount == 0) {
               this.callHook(s, COUNT, NIL);
            }

            if (s.hookline) {
               int newline = this.callstack().currentline();
               if (newline != s.lastline) {
                  s.lastline = newline;
                  this.callHook(s, LINE, LuaValue.valueOf(newline));
               }
            }

         }
      }
   }

   public void onReturn() {
      LuaThread.State s = this.globals.running.state;
      if (!s.inhook) {
         this.callstack().onReturn();
         if (s.hookrtrn) {
            this.callHook(s, RETURN, NIL);
         }

      }
   }

   public String traceback(int level) {
      return this.callstack().traceback(level);
   }

   void callHook(LuaThread.State s, LuaValue type, LuaValue arg) {
      if (!s.inhook && s.hookfunc != null) {
         s.inhook = true;

         try {
            s.hookfunc.call(type, arg);
         } catch (LuaError var9) {
            throw var9;
         } catch (RuntimeException var10) {
            throw new LuaError(var10);
         } finally {
            s.inhook = false;
         }

      }
   }

   DebugLib.CallStack callstack() {
      return this.callstack(this.globals.running);
   }

   DebugLib.CallStack callstack(LuaThread t) {
      if (t.callstack == null) {
         t.callstack = new DebugLib.CallStack();
      }

      return (DebugLib.CallStack)t.callstack;
   }

   static LuaString findupvalue(LuaClosure c, int up) {
      if (c.upValues != null && up > 0 && up <= c.upValues.length) {
         return c.p.upvalues != null && up <= c.p.upvalues.length ? c.p.upvalues[up - 1].name : LuaString.valueOf("." + up);
      } else {
         return null;
      }
   }

   static void lua_assert(boolean x) {
      if (!x) {
         throw new RuntimeException("lua_assert failed");
      }
   }

   static DebugLib.NameWhat getfuncname(DebugLib.CallFrame frame) {
      if (!frame.f.isclosure()) {
         return new DebugLib.NameWhat(frame.f.classnamestub(), "Java");
      } else {
         Prototype p = frame.f.checkclosure().p;
         int pc = frame.pc;
         int i = p.code[pc];
         LuaString tm;
         switch(Lua.GET_OPCODE(i)) {
         case 6:
         case 7:
         case 12:
            tm = LuaValue.INDEX;
            break;
         case 8:
         case 10:
            tm = LuaValue.NEWINDEX;
            break;
         case 9:
         case 11:
         case 20:
         case 23:
         case 27:
         case 28:
         case 31:
         case 32:
         case 33:
         default:
            return null;
         case 13:
            tm = LuaValue.ADD;
            break;
         case 14:
            tm = LuaValue.SUB;
            break;
         case 15:
            tm = LuaValue.MUL;
            break;
         case 16:
            tm = LuaValue.DIV;
            break;
         case 17:
            tm = LuaValue.MOD;
            break;
         case 18:
            tm = LuaValue.POW;
            break;
         case 19:
            tm = LuaValue.UNM;
            break;
         case 21:
            tm = LuaValue.LEN;
            break;
         case 22:
            tm = LuaValue.CONCAT;
            break;
         case 24:
            tm = LuaValue.EQ;
            break;
         case 25:
            tm = LuaValue.LT;
            break;
         case 26:
            tm = LuaValue.LE;
            break;
         case 29:
         case 30:
            return getobjname(p, pc, Lua.GETARG_A(i));
         case 34:
            return new DebugLib.NameWhat("(for iterator)", "(for iterator");
         }

         return new DebugLib.NameWhat(tm.tojstring(), "metamethod");
      }
   }

   public static DebugLib.NameWhat getobjname(Prototype p, int lastpc, int reg) {
      LuaString name = p.getlocalname(reg + 1, lastpc);
      if (name != null) {
         return new DebugLib.NameWhat(name.tojstring(), "local");
      } else {
         int pc = findsetreg(p, lastpc, reg);
         if (pc != -1) {
            int i = p.code[pc];
            int b;
            int b;
            switch(Lua.GET_OPCODE(i)) {
            case 0:
               b = Lua.GETARG_A(i);
               b = Lua.GETARG_B(i);
               if (b < b) {
                  return getobjname(p, pc, b);
               }
               break;
            case 1:
            case 2:
               b = Lua.GET_OPCODE(i) == 1 ? Lua.GETARG_Bx(i) : Lua.GETARG_Ax(p.code[pc + 1]);
               if (p.k[b].isstring()) {
                  name = p.k[b].strvalue();
                  return new DebugLib.NameWhat(name.tojstring(), "constant");
               }
            case 3:
            case 4:
            case 8:
            case 9:
            case 10:
            case 11:
            default:
               break;
            case 5:
               b = Lua.GETARG_B(i);
               name = b < p.upvalues.length ? p.upvalues[b].name : QMARK;
               return new DebugLib.NameWhat(name.tojstring(), "upvalue");
            case 6:
            case 7:
               b = Lua.GETARG_C(i);
               b = Lua.GETARG_B(i);
               LuaString vn = Lua.GET_OPCODE(i) == 7 ? p.getlocalname(b + 1, pc) : (b < p.upvalues.length ? p.upvalues[b].name : QMARK);
               name = kname(p, b);
               return new DebugLib.NameWhat(name.tojstring(), vn != null && vn.eq_b(ENV) ? "global" : "field");
            case 12:
               b = Lua.GETARG_C(i);
               name = kname(p, b);
               return new DebugLib.NameWhat(name.tojstring(), "method");
            }
         }

         return null;
      }
   }

   static LuaString kname(Prototype p, int c) {
      return Lua.ISK(c) && p.k[Lua.INDEXK(c)].isstring() ? p.k[Lua.INDEXK(c)].strvalue() : QMARK;
   }

   static int findsetreg(Prototype p, int lastpc, int reg) {
      int setreg = -1;

      for(int pc = 0; pc < lastpc; ++pc) {
         int i = p.code[pc];
         int op = Lua.GET_OPCODE(i);
         int a = Lua.GETARG_A(i);
         int b;
         switch(op) {
         case 4:
            b = Lua.GETARG_B(i);
            if (a <= reg && reg <= a + b) {
               setreg = pc;
            }
            break;
         case 23:
            b = Lua.GETARG_sBx(i);
            int dest = pc + 1 + b;
            if (pc < dest && dest <= lastpc) {
               pc += b;
            }
            break;
         case 27:
            if (reg == a) {
               setreg = pc;
            }
            break;
         case 29:
         case 30:
            if (reg >= a) {
               setreg = pc;
            }
            break;
         case 34:
            if (reg >= a + 2) {
               setreg = pc;
            }
            break;
         default:
            if (Lua.testAMode(op) && reg == a) {
               setreg = pc;
            }
         }
      }

      return setreg;
   }

   static {
      try {
         CALLS = null != System.getProperty("CALLS");
      } catch (Exception var2) {
      }

      try {
         TRACE = null != System.getProperty("TRACE");
      } catch (Exception var1) {
      }

      LUA = valueOf("Lua");
      QMARK = valueOf("?");
      CALL = valueOf("call");
      LINE = valueOf("line");
      COUNT = valueOf("count");
      RETURN = valueOf("return");
      FUNC = valueOf("func");
      ISTAILCALL = valueOf("istailcall");
      ISVARARG = valueOf("isvararg");
      NUPS = valueOf("nups");
      NPARAMS = valueOf("nparams");
      NAME = valueOf("name");
      NAMEWHAT = valueOf("namewhat");
      WHAT = valueOf("what");
      SOURCE = valueOf("source");
      SHORT_SRC = valueOf("short_src");
      LINEDEFINED = valueOf("linedefined");
      LASTLINEDEFINED = valueOf("lastlinedefined");
      CURRENTLINE = valueOf("currentline");
      ACTIVELINES = valueOf("activelines");
   }

   @Environment(EnvType.CLIENT)
   static final class debug extends ZeroArgFunction {
      public LuaValue call() {
         return NONE;
      }
   }

   @Environment(EnvType.CLIENT)
   final class gethook extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaThread t = args.narg() > 0 ? args.checkthread(1) : DebugLib.this.globals.running;
         LuaThread.State s = t.state;
         LuaValue var10000 = s.hookfunc != null ? s.hookfunc : NIL;
         String var10001 = s.hookcall ? "c" : "";
         return varargsOf(var10000, valueOf(var10001 + (s.hookline ? "l" : "") + (s.hookrtrn ? "r" : "")), valueOf(s.hookcount));
      }
   }

   @Environment(EnvType.CLIENT)
   final class getinfo extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         int a = 1;
         LuaThread thread = args.isthread(a) ? args.checkthread(a++) : DebugLib.this.globals.running;
         LuaValue func = args.arg(a++);
         String what = args.optjstring(a++, "flnStu");
         DebugLib.CallStack callstack = DebugLib.this.callstack(thread);
         DebugLib.CallFrame frame;
         if (((LuaValue)func).isnumber()) {
            frame = callstack.getCallFrame(((LuaValue)func).toint());
            if (frame == null) {
               return NONE;
            }

            func = frame.f;
         } else {
            if (!((LuaValue)func).isfunction()) {
               return argerror(a - 2, "function or level");
            }

            frame = callstack.findCallFrame((LuaValue)func);
         }

         DebugLib.DebugInfo ar = callstack.auxgetinfo(what, (LuaFunction)func, frame);
         LuaTable info = new LuaTable();
         if (what.indexOf(83) >= 0) {
            info.set(DebugLib.WHAT, DebugLib.LUA);
            info.set(DebugLib.SOURCE, valueOf(ar.source));
            info.set(DebugLib.SHORT_SRC, valueOf(ar.short_src));
            info.set(DebugLib.LINEDEFINED, valueOf(ar.linedefined));
            info.set(DebugLib.LASTLINEDEFINED, valueOf(ar.lastlinedefined));
         }

         if (what.indexOf(108) >= 0) {
            info.set(DebugLib.CURRENTLINE, valueOf(ar.currentline));
         }

         if (what.indexOf(117) >= 0) {
            info.set(DebugLib.NUPS, valueOf(ar.nups));
            info.set(DebugLib.NPARAMS, valueOf(ar.nparams));
            info.set(DebugLib.ISVARARG, ar.isvararg ? ONE : ZERO);
         }

         if (what.indexOf(110) >= 0) {
            info.set(DebugLib.NAME, LuaValue.valueOf(ar.name != null ? ar.name : "?"));
            info.set(DebugLib.NAMEWHAT, LuaValue.valueOf(ar.namewhat));
         }

         if (what.indexOf(116) >= 0) {
            info.set(DebugLib.ISTAILCALL, ZERO);
         }

         if (what.indexOf(76) >= 0) {
            LuaTable lines = new LuaTable();
            info.set(DebugLib.ACTIVELINES, lines);

            DebugLib.CallFrame cf;
            for(int l = 1; (cf = callstack.getCallFrame(l)) != null; ++l) {
               if (cf.f == func) {
                  lines.insert(-1, valueOf(cf.currentline()));
               }
            }
         }

         if (what.indexOf(102) >= 0 && func != null) {
            info.set(DebugLib.FUNC, (LuaValue)func);
         }

         return info;
      }
   }

   @Environment(EnvType.CLIENT)
   final class getlocal extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         int a = 1;
         LuaThread thread = args.isthread(a) ? args.checkthread(a++) : DebugLib.this.globals.running;
         int level = args.checkint(a++);
         int local = args.checkint(a++);
         DebugLib.CallFrame f = DebugLib.this.callstack(thread).getCallFrame(level);
         return (Varargs)(f != null ? f.getLocal(local) : NONE);
      }
   }

   @Environment(EnvType.CLIENT)
   final class getmetatable extends LibFunction {
      getmetatable(final DebugLib this$0) {
      }

      public LuaValue call(LuaValue v) {
         LuaValue mt = v.getmetatable();
         return mt != null ? mt : NIL;
      }
   }

   @Environment(EnvType.CLIENT)
   final class getregistry extends ZeroArgFunction {
      public LuaValue call() {
         return DebugLib.this.globals;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class getupvalue extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaValue func = args.checkfunction(1);
         int up = args.checkint(2);
         if (func instanceof LuaClosure) {
            LuaClosure c = (LuaClosure)func;
            LuaString name = DebugLib.findupvalue(c, up);
            if (name != null) {
               return varargsOf(name, c.upValues[up - 1].getValue());
            }
         }

         return NIL;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class getuservalue extends LibFunction {
      public LuaValue call(LuaValue u) {
         return u.isuserdata() ? u : NIL;
      }
   }

   @Environment(EnvType.CLIENT)
   final class sethook extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         int a = 1;
         LuaThread t = args.isthread(a) ? args.checkthread(a++) : DebugLib.this.globals.running;
         LuaValue func = args.optfunction(a++, (LuaFunction)null);
         String str = args.optjstring(a++, "");
         int count = args.optint(a++, 0);
         boolean call = false;
         boolean line = false;
         boolean rtrn = false;

         for(int i = 0; i < str.length(); ++i) {
            switch(str.charAt(i)) {
            case 'c':
               call = true;
               break;
            case 'l':
               line = true;
               break;
            case 'r':
               rtrn = true;
            }
         }

         LuaThread.State s = t.state;
         s.hookfunc = func;
         s.hookcall = call;
         s.hookline = line;
         s.hookcount = count;
         s.hookrtrn = rtrn;
         return NONE;
      }
   }

   @Environment(EnvType.CLIENT)
   final class setlocal extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         int a = 1;
         LuaThread thread = args.isthread(a) ? args.checkthread(a++) : DebugLib.this.globals.running;
         int level = args.checkint(a++);
         int local = args.checkint(a++);
         LuaValue value = args.arg(a++);
         DebugLib.CallFrame f = DebugLib.this.callstack(thread).getCallFrame(level);
         return (Varargs)(f != null ? f.setLocal(local, value) : NONE);
      }
   }

   @Environment(EnvType.CLIENT)
   final class setmetatable extends TwoArgFunction {
      setmetatable(final DebugLib this$0) {
      }

      public LuaValue call(LuaValue value, LuaValue table) {
         LuaValue mt = table.opttable((LuaTable)null);
         switch(value.type()) {
         case 0:
            LuaNil.s_metatable = mt;
            break;
         case 1:
            LuaBoolean.s_metatable = mt;
            break;
         case 2:
         case 5:
         case 7:
         default:
            value.setmetatable(mt);
            break;
         case 3:
            LuaNumber.s_metatable = mt;
            break;
         case 4:
            LuaString.s_metatable = mt;
            break;
         case 6:
            LuaFunction.s_metatable = mt;
            break;
         case 8:
            LuaThread.s_metatable = mt;
         }

         return value;
      }
   }

   @Environment(EnvType.CLIENT)
   final class setupvalue extends VarArgFunction {
      setupvalue(final DebugLib this$0) {
      }

      public Varargs invoke(Varargs args) {
         LuaValue func = args.checkfunction(1);
         int up = args.checkint(2);
         LuaValue value = args.arg(3);
         if (func instanceof LuaClosure) {
            LuaClosure c = (LuaClosure)func;
            LuaString name = DebugLib.findupvalue(c, up);
            if (name != null) {
               c.upValues[up - 1].setValue(value);
               return name;
            }
         }

         return NIL;
      }
   }

   @Environment(EnvType.CLIENT)
   final class setuservalue extends VarArgFunction {
      setuservalue(final DebugLib this$0) {
      }

      public Varargs invoke(Varargs args) {
         Object o = args.checkuserdata(1);
         LuaValue v = args.checkvalue(2);
         LuaUserdata u = (LuaUserdata)args.arg1();
         u.m_instance = v.checkuserdata();
         u.m_metatable = v.getmetatable();
         return NONE;
      }
   }

   @Environment(EnvType.CLIENT)
   final class traceback extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         int a = 1;
         LuaThread thread = args.isthread(a) ? args.checkthread(a++) : DebugLib.this.globals.running;
         String message = args.optjstring(a++, (String)null);
         int level = args.optint(a++, 1);
         String tb = DebugLib.this.callstack(thread).traceback(level);
         return valueOf(message != null ? message + "\n" + tb : tb);
      }
   }

   @Environment(EnvType.CLIENT)
   final class upvalueid extends VarArgFunction {
      upvalueid(final DebugLib this$0) {
      }

      public Varargs invoke(Varargs args) {
         LuaValue func = args.checkfunction(1);
         int up = args.checkint(2);
         if (func instanceof LuaClosure) {
            LuaClosure c = (LuaClosure)func;
            if (c.upValues != null && up > 0 && up <= c.upValues.length) {
               return valueOf(c.upValues[up - 1].hashCode());
            }
         }

         return NIL;
      }
   }

   @Environment(EnvType.CLIENT)
   final class upvaluejoin extends VarArgFunction {
      upvaluejoin(final DebugLib this$0) {
      }

      public Varargs invoke(Varargs args) {
         LuaClosure f1 = args.checkclosure(1);
         int n1 = args.checkint(2);
         LuaClosure f2 = args.checkclosure(3);
         int n2 = args.checkint(4);
         if (n1 < 1 || n1 > f1.upValues.length) {
            this.argerror("index out of range");
         }

         if (n2 < 1 || n2 > f2.upValues.length) {
            this.argerror("index out of range");
         }

         f1.upValues[n1 - 1] = f2.upValues[n2 - 1];
         return NONE;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class CallStack {
      static final DebugLib.CallFrame[] EMPTY = new DebugLib.CallFrame[0];
      DebugLib.CallFrame[] frame;
      int calls;

      CallStack() {
         this.frame = EMPTY;
         this.calls = 0;
      }

      synchronized int currentline() {
         return this.calls > 0 ? this.frame[this.calls - 1].currentline() : -1;
      }

      private synchronized DebugLib.CallFrame pushcall() {
         if (this.calls >= this.frame.length) {
            int n = Math.max(4, this.frame.length * 3 / 2);
            DebugLib.CallFrame[] f = new DebugLib.CallFrame[n];
            System.arraycopy(this.frame, 0, f, 0, this.frame.length);

            int i;
            for(i = this.frame.length; i < n; ++i) {
               f[i] = new DebugLib.CallFrame();
            }

            this.frame = f;

            for(i = 1; i < n; ++i) {
               f[i].previous = f[i - 1];
            }
         }

         return this.frame[this.calls++];
      }

      final synchronized void onCall(LuaFunction function) {
         this.pushcall().set(function);
      }

      final synchronized void onCall(LuaClosure function, Varargs varargs, LuaValue[] stack) {
         this.pushcall().set(function, varargs, stack);
      }

      final synchronized void onReturn() {
         if (this.calls > 0) {
            this.frame[--this.calls].reset();
         }

      }

      final synchronized void onInstruction(int pc, Varargs v, int top) {
         if (this.calls > 0) {
            this.frame[this.calls - 1].instr(pc, v, top);
         }

      }

      synchronized String traceback(int level) {
         StringBuffer sb = new StringBuffer();
         sb.append("stack traceback:");

         DebugLib.CallFrame c;
         while((c = this.getCallFrame(level++)) != null) {
            sb.append("\n\t");
            sb.append(c.shortsource());
            sb.append(':');
            if (c.currentline() > 0) {
               sb.append(c.currentline() + ":");
            }

            sb.append(" in ");
            DebugLib.DebugInfo ar = this.auxgetinfo("n", c.f, c);
            if (c.linedefined() == 0) {
               sb.append("main chunk");
            } else if (ar.name != null) {
               sb.append("function '");
               sb.append(ar.name);
               sb.append('\'');
            } else {
               String var5 = c.shortsource();
               sb.append("function <" + var5 + ":" + c.linedefined() + ">");
            }
         }

         sb.append("\n\t[Java]: in ?");
         return sb.toString();
      }

      synchronized DebugLib.CallFrame getCallFrame(int level) {
         return level >= 1 && level <= this.calls ? this.frame[this.calls - level] : null;
      }

      synchronized DebugLib.CallFrame findCallFrame(LuaValue func) {
         for(int i = 1; i <= this.calls; ++i) {
            if (this.frame[this.calls - i].f == func) {
               return this.frame[i];
            }
         }

         return null;
      }

      synchronized DebugLib.DebugInfo auxgetinfo(String what, LuaFunction f, DebugLib.CallFrame ci) {
         DebugLib.DebugInfo ar = new DebugLib.DebugInfo();
         int i = 0;

         for(int n = what.length(); i < n; ++i) {
            switch(what.charAt(i)) {
            case 'L':
            case 'f':
            default:
               break;
            case 'S':
               ar.funcinfo(f);
               break;
            case 'l':
               ar.currentline = ci != null && ci.f.isclosure() ? ci.currentline() : -1;
               break;
            case 'n':
               if (ci != null && ci.previous != null && ci.previous.f.isclosure()) {
                  DebugLib.NameWhat nw = DebugLib.getfuncname(ci.previous);
                  if (nw != null) {
                     ar.name = nw.name;
                     ar.namewhat = nw.namewhat;
                  }
               }

               if (ar.namewhat == null) {
                  ar.namewhat = "";
                  ar.name = null;
               }
               break;
            case 't':
               ar.istailcall = false;
               break;
            case 'u':
               if (f != null && f.isclosure()) {
                  Prototype p = f.checkclosure().p;
                  ar.nups = (short)p.upvalues.length;
                  ar.nparams = (short)p.numparams;
                  ar.isvararg = p.is_vararg != 0;
               } else {
                  ar.nups = 0;
                  ar.isvararg = true;
                  ar.nparams = 0;
               }
            }
         }

         return ar;
      }
   }

   @Environment(EnvType.CLIENT)
   static class CallFrame {
      LuaFunction f;
      int pc;
      int top;
      Varargs v;
      LuaValue[] stack;
      DebugLib.CallFrame previous;

      void set(LuaClosure function, Varargs varargs, LuaValue[] stack) {
         this.f = function;
         this.v = varargs;
         this.stack = stack;
      }

      public String shortsource() {
         return this.f.isclosure() ? this.f.checkclosure().p.shortsource() : "[Java]";
      }

      void set(LuaFunction function) {
         this.f = function;
      }

      void reset() {
         this.f = null;
         this.v = null;
         this.stack = null;
      }

      void instr(int pc, Varargs v, int top) {
         this.pc = pc;
         this.v = v;
         this.top = top;
         if (DebugLib.TRACE) {
            Print.printState(this.f.checkclosure(), pc, this.stack, top, v);
         }

      }

      Varargs getLocal(int i) {
         LuaString name = this.getlocalname(i);
         return (Varargs)(name != null ? LuaValue.varargsOf((LuaValue)name, this.stack[i - 1]) : LuaValue.NIL);
      }

      Varargs setLocal(int i, LuaValue value) {
         LuaString name = this.getlocalname(i);
         if (name != null) {
            this.stack[i - 1] = value;
            return name;
         } else {
            return LuaValue.NIL;
         }
      }

      int currentline() {
         if (!this.f.isclosure()) {
            return -1;
         } else {
            int[] li = this.f.checkclosure().p.lineinfo;
            return li != null && this.pc >= 0 && this.pc < li.length ? li[this.pc] : -1;
         }
      }

      String sourceline() {
         if (!this.f.isclosure()) {
            return this.f.tojstring();
         } else {
            String var10000 = this.f.checkclosure().p.shortsource();
            return var10000 + ":" + this.currentline();
         }
      }

      private int linedefined() {
         return this.f.isclosure() ? this.f.checkclosure().p.linedefined : -1;
      }

      LuaString getlocalname(int index) {
         return !this.f.isclosure() ? null : this.f.checkclosure().p.getlocalname(index, this.pc);
      }
   }

   @Environment(EnvType.CLIENT)
   static class NameWhat {
      final String name;
      final String namewhat;

      NameWhat(String name, String namewhat) {
         this.name = name;
         this.namewhat = namewhat;
      }
   }

   @Environment(EnvType.CLIENT)
   static class DebugInfo {
      String name;
      String namewhat;
      String what;
      String source;
      int currentline;
      int linedefined;
      int lastlinedefined;
      short nups;
      short nparams;
      boolean isvararg;
      boolean istailcall;
      String short_src;
      DebugLib.CallFrame cf;

      public void funcinfo(LuaFunction f) {
         if (f.isclosure()) {
            Prototype p = f.checkclosure().p;
            this.source = p.source != null ? p.source.tojstring() : "=?";
            this.linedefined = p.linedefined;
            this.lastlinedefined = p.lastlinedefined;
            this.what = this.linedefined == 0 ? "main" : "Lua";
            this.short_src = p.shortsource();
         } else {
            this.source = "=[Java]";
            this.linedefined = -1;
            this.lastlinedefined = -1;
            this.what = "Java";
            this.short_src = f.name();
         }

      }
   }
}
