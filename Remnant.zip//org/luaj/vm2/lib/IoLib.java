package org.luaj.vm2.lib;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public abstract class IoLib extends TwoArgFunction {
   protected static final int FTYPE_STDIN = 0;
   protected static final int FTYPE_STDOUT = 1;
   protected static final int FTYPE_STDERR = 2;
   protected static final int FTYPE_NAMED = 3;
   private IoLib.File infile = null;
   private IoLib.File outfile = null;
   private IoLib.File errfile = null;
   private static final LuaValue STDIN = valueOf("stdin");
   private static final LuaValue STDOUT = valueOf("stdout");
   private static final LuaValue STDERR = valueOf("stderr");
   private static final LuaValue FILE = valueOf("file");
   private static final LuaValue CLOSED_FILE = valueOf("closed file");
   private static final int IO_CLOSE = 0;
   private static final int IO_FLUSH = 1;
   private static final int IO_INPUT = 2;
   private static final int IO_LINES = 3;
   private static final int IO_OPEN = 4;
   private static final int IO_OUTPUT = 5;
   private static final int IO_POPEN = 6;
   private static final int IO_READ = 7;
   private static final int IO_TMPFILE = 8;
   private static final int IO_TYPE = 9;
   private static final int IO_WRITE = 10;
   private static final int FILE_CLOSE = 11;
   private static final int FILE_FLUSH = 12;
   private static final int FILE_LINES = 13;
   private static final int FILE_READ = 14;
   private static final int FILE_SEEK = 15;
   private static final int FILE_SETVBUF = 16;
   private static final int FILE_WRITE = 17;
   private static final int IO_INDEX = 18;
   private static final int LINES_ITER = 19;
   public static final String[] IO_NAMES = new String[]{"close", "flush", "input", "lines", "open", "output", "popen", "read", "tmpfile", "type", "write"};
   public static final String[] FILE_NAMES = new String[]{"close", "flush", "lines", "read", "seek", "setvbuf", "write"};
   LuaTable filemethods;
   protected Globals globals;

   protected abstract IoLib.File wrapStdin() throws IOException;

   protected abstract IoLib.File wrapStdout() throws IOException;

   protected abstract IoLib.File wrapStderr() throws IOException;

   protected abstract IoLib.File openFile(String var1, boolean var2, boolean var3, boolean var4, boolean var5) throws IOException;

   protected abstract IoLib.File tmpFile() throws IOException;

   protected abstract IoLib.File openProgram(String var1, String var2) throws IOException;

   public LuaValue call(LuaValue modname, LuaValue env) {
      this.globals = env.checkglobals();
      LuaTable t = new LuaTable();
      this.bind(t, IoLib.IoLibV.class, IO_NAMES);
      this.filemethods = new LuaTable();
      this.bind(this.filemethods, IoLib.IoLibV.class, FILE_NAMES, 11);
      LuaTable mt = new LuaTable();
      this.bind(mt, IoLib.IoLibV.class, new String[]{"__index"}, 18);
      t.setmetatable(mt);
      this.setLibInstance(t);
      this.setLibInstance(this.filemethods);
      this.setLibInstance(mt);
      env.set((String)"io", (LuaValue)t);
      env.get("package").get("loaded").set((String)"io", (LuaValue)t);
      return t;
   }

   private void setLibInstance(LuaTable t) {
      LuaValue[] k = t.keys();
      int i = 0;

      for(int n = k.length; i < n; ++i) {
         ((IoLib.IoLibV)t.get(k[i])).iolib = this;
      }

   }

   private IoLib.File input() {
      return this.infile != null ? this.infile : (this.infile = this.ioopenfile(0, "-", "r"));
   }

   public Varargs _io_flush() throws IOException {
      checkopen(this.output());
      this.outfile.flush();
      return LuaValue.TRUE;
   }

   public Varargs _io_tmpfile() throws IOException {
      return this.tmpFile();
   }

   public Varargs _io_close(LuaValue file) throws IOException {
      IoLib.File f = file.isnil() ? this.output() : checkfile(file);
      checkopen(f);
      return ioclose(f);
   }

   public Varargs _io_input(LuaValue file) {
      this.infile = file.isnil() ? this.input() : (file.isstring() ? this.ioopenfile(3, file.checkjstring(), "r") : checkfile(file));
      return this.infile;
   }

   public Varargs _io_output(LuaValue filename) {
      this.outfile = filename.isnil() ? this.output() : (filename.isstring() ? this.ioopenfile(3, filename.checkjstring(), "w") : checkfile(filename));
      return this.outfile;
   }

   public Varargs _io_type(LuaValue obj) {
      IoLib.File f = optfile(obj);
      return f != null ? (f.isclosed() ? CLOSED_FILE : FILE) : NIL;
   }

   public Varargs _io_popen(String prog, String mode) throws IOException {
      return this.openProgram(prog, mode);
   }

   public Varargs _io_open(String filename, String mode) throws IOException {
      return this.rawopenfile(3, filename, mode);
   }

   public Varargs _io_lines(String filename) {
      this.infile = filename == null ? this.input() : this.ioopenfile(3, filename, "r");
      checkopen(this.infile);
      return this.lines(this.infile);
   }

   public Varargs _io_read(Varargs args) throws IOException {
      checkopen(this.input());
      return this.ioread(this.infile, args);
   }

   public Varargs _io_write(Varargs args) throws IOException {
      checkopen(this.output());
      return iowrite(this.outfile, args);
   }

   public Varargs _file_close(LuaValue file) throws IOException {
      return ioclose(checkfile(file));
   }

   public Varargs _file_flush(LuaValue file) throws IOException {
      checkfile(file).flush();
      return LuaValue.TRUE;
   }

   public Varargs _file_setvbuf(LuaValue file, String mode, int size) {
      checkfile(file).setvbuf(mode, size);
      return LuaValue.TRUE;
   }

   public Varargs _file_lines(LuaValue file) {
      return this.lines(checkfile(file));
   }

   public Varargs _file_read(LuaValue file, Varargs subargs) throws IOException {
      return this.ioread(checkfile(file), subargs);
   }

   public Varargs _file_seek(LuaValue file, String whence, int offset) throws IOException {
      return valueOf(checkfile(file).seek(whence, offset));
   }

   public Varargs _file_write(LuaValue file, Varargs subargs) throws IOException {
      return iowrite(checkfile(file), subargs);
   }

   public Varargs _io_index(LuaValue v) {
      return (Varargs)(v.equals(STDOUT) ? this.output() : (v.equals(STDIN) ? this.input() : (v.equals(STDERR) ? this.errput() : NIL)));
   }

   public Varargs _lines_iter(LuaValue file) throws IOException {
      return freadline(checkfile(file));
   }

   private IoLib.File output() {
      return this.outfile != null ? this.outfile : (this.outfile = this.ioopenfile(1, "-", "w"));
   }

   private IoLib.File errput() {
      return this.errfile != null ? this.errfile : (this.errfile = this.ioopenfile(2, "-", "w"));
   }

   private IoLib.File ioopenfile(int filetype, String filename, String mode) {
      try {
         return this.rawopenfile(filetype, filename, mode);
      } catch (Exception var5) {
         error("io error: " + var5.getMessage());
         return null;
      }
   }

   private static Varargs ioclose(IoLib.File f) throws IOException {
      if (f.isstdfile()) {
         return errorresult("cannot close standard file");
      } else {
         f.close();
         return successresult();
      }
   }

   private static Varargs successresult() {
      return LuaValue.TRUE;
   }

   private static Varargs errorresult(Exception ioe) {
      String s = ioe.getMessage();
      String var10000 = s != null ? s : ioe.toString();
      return errorresult("io error: " + var10000);
   }

   private static Varargs errorresult(String errortext) {
      return varargsOf(NIL, valueOf(errortext));
   }

   private Varargs lines(IoLib.File f) {
      try {
         return new IoLib.IoLibV(f, "lnext", 19, this);
      } catch (Exception var3) {
         return error("lines: " + String.valueOf(var3));
      }
   }

   private static Varargs iowrite(IoLib.File f, Varargs args) throws IOException {
      int i = 1;

      for(int n = args.narg(); i <= n; ++i) {
         f.write(args.checkstring(i));
      }

      return f;
   }

   private Varargs ioread(IoLib.File f, Varargs args) throws IOException {
      int n = args.narg();
      LuaValue[] v = new LuaValue[n];
      int i = 0;

      while(i < n) {
         LuaValue vi;
         LuaValue ai;
         label34:
         switch((ai = args.arg(i + 1)).type()) {
         case 3:
            vi = freadbytes(f, ai.toint());
            break;
         case 4:
            LuaString fmt = ai.checkstring();
            if (fmt.m_length == 2 && fmt.m_bytes[fmt.m_offset] == 42) {
               switch(fmt.m_bytes[fmt.m_offset + 1]) {
               case 97:
                  vi = freadall(f);
                  break label34;
               case 108:
                  vi = freadline(f);
                  break label34;
               case 110:
                  vi = freadnumber(f);
                  break label34;
               }
            }
         default:
            return argerror(i + 1, "(invalid format)");
         }

         if ((v[i++] = vi).isnil()) {
            break;
         }
      }

      return (Varargs)(i == 0 ? NIL : varargsOf(v, 0, i));
   }

   private static IoLib.File checkfile(LuaValue val) {
      IoLib.File f = optfile(val);
      if (f == null) {
         argerror(1, "file");
      }

      checkopen(f);
      return f;
   }

   private static IoLib.File optfile(LuaValue val) {
      return val instanceof IoLib.File ? (IoLib.File)val : null;
   }

   private static IoLib.File checkopen(IoLib.File file) {
      if (file.isclosed()) {
         error("attempt to use a closed file");
      }

      return file;
   }

   private IoLib.File rawopenfile(int filetype, String filename, String mode) throws IOException {
      switch(filetype) {
      case 0:
         return this.wrapStdin();
      case 1:
         return this.wrapStdout();
      case 2:
         return this.wrapStderr();
      default:
         boolean isreadmode = mode.startsWith("r");
         boolean isappend = mode.startsWith("a");
         boolean isupdate = mode.indexOf("+") > 0;
         boolean isbinary = mode.endsWith("b");
         return this.openFile(filename, isreadmode, isappend, isupdate, isbinary);
      }
   }

   public static LuaValue freadbytes(IoLib.File f, int count) throws IOException {
      byte[] b = new byte[count];
      int r;
      return (LuaValue)((r = f.read(b, 0, b.length)) < 0 ? NIL : LuaString.valueUsing(b, 0, r));
   }

   public static LuaValue freaduntil(IoLib.File f, boolean lineonly) throws IOException {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();

      int c;
      try {
         if (lineonly) {
            while((c = f.read()) > 0) {
               switch(c) {
               case 10:
                  return (LuaValue)(c < 0 && baos.size() == 0 ? NIL : LuaString.valueUsing(baos.toByteArray()));
               case 13:
                  break;
               default:
                  baos.write(c);
               }
            }
         } else {
            while((c = f.read()) > 0) {
               baos.write(c);
            }
         }
      } catch (EOFException var5) {
         c = -1;
      }

      return (LuaValue)(c < 0 && baos.size() == 0 ? NIL : LuaString.valueUsing(baos.toByteArray()));
   }

   public static LuaValue freadline(IoLib.File f) throws IOException {
      return freaduntil(f, true);
   }

   public static LuaValue freadall(IoLib.File f) throws IOException {
      int n = f.remaining();
      return n >= 0 ? freadbytes(f, n) : freaduntil(f, false);
   }

   public static LuaValue freadnumber(IoLib.File f) throws IOException {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      freadchars(f, " \t\r\n", (ByteArrayOutputStream)null);
      freadchars(f, "-+", baos);
      freadchars(f, "0123456789", baos);
      freadchars(f, ".", baos);
      freadchars(f, "0123456789", baos);
      String s = baos.toString();
      return (LuaValue)(s.length() > 0 ? valueOf(Double.parseDouble(s)) : NIL);
   }

   private static void freadchars(IoLib.File f, String chars, ByteArrayOutputStream baos) throws IOException {
      while(true) {
         int c = f.peek();
         if (chars.indexOf(c) < 0) {
            return;
         }

         f.read();
         if (baos != null) {
            baos.write(c);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   protected abstract class File extends LuaValue {
      public abstract void write(LuaString var1) throws IOException;

      public abstract void flush() throws IOException;

      public abstract boolean isstdfile();

      public abstract void close() throws IOException;

      public abstract boolean isclosed();

      public abstract int seek(String var1, int var2) throws IOException;

      public abstract void setvbuf(String var1, int var2);

      public abstract int remaining() throws IOException;

      public abstract int peek() throws IOException, EOFException;

      public abstract int read() throws IOException, EOFException;

      public abstract int read(byte[] var1, int var2, int var3) throws IOException;

      public LuaValue get(LuaValue key) {
         return IoLib.this.filemethods.get(key);
      }

      public int type() {
         return 7;
      }

      public String typename() {
         return "userdata";
      }

      public String tojstring() {
         return "file: " + Integer.toHexString(this.hashCode());
      }
   }

   @Environment(EnvType.CLIENT)
   static final class IoLibV extends VarArgFunction {
      private IoLib.File f;
      public IoLib iolib;

      public IoLibV() {
      }

      public IoLibV(IoLib.File f, String name, int opcode, IoLib iolib) {
         this.f = f;
         this.name = name;
         this.opcode = opcode;
         this.iolib = iolib;
      }

      public Varargs invoke(Varargs args) {
         try {
            switch(this.opcode) {
            case 0:
               return this.iolib._io_close(args.arg1());
            case 1:
               return this.iolib._io_flush();
            case 2:
               return this.iolib._io_input(args.arg1());
            case 3:
               return this.iolib._io_lines(args.isvalue(1) ? args.checkjstring(1) : null);
            case 4:
               return this.iolib._io_open(args.checkjstring(1), args.optjstring(2, "r"));
            case 5:
               return this.iolib._io_output(args.arg1());
            case 6:
               return this.iolib._io_popen(args.checkjstring(1), args.optjstring(2, "r"));
            case 7:
               return this.iolib._io_read(args);
            case 8:
               return this.iolib._io_tmpfile();
            case 9:
               return this.iolib._io_type(args.arg1());
            case 10:
               return this.iolib._io_write(args);
            case 11:
               return this.iolib._file_close(args.arg1());
            case 12:
               return this.iolib._file_flush(args.arg1());
            case 13:
               return this.iolib._file_lines(args.arg1());
            case 14:
               return this.iolib._file_read(args.arg1(), args.subargs(2));
            case 15:
               return this.iolib._file_seek(args.arg1(), args.optjstring(2, "cur"), args.optint(3, 0));
            case 16:
               return this.iolib._file_setvbuf(args.arg1(), args.checkjstring(2), args.optint(3, 1024));
            case 17:
               return this.iolib._file_write(args.arg1(), args.subargs(2));
            case 18:
               return this.iolib._io_index(args.arg(2));
            case 19:
               return this.iolib._lines_iter(this.f);
            }
         } catch (IOException var3) {
            return IoLib.errorresult((Exception)var3);
         }

         return NONE;
      }
   }
}
