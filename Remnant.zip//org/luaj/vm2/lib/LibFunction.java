package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public abstract class LibFunction extends LuaFunction {
   protected int opcode;
   protected String name;

   protected LibFunction() {
   }

   public String tojstring() {
      return this.name != null ? this.name : super.tojstring();
   }

   protected void bind(LuaValue env, Class factory, String[] names) {
      this.bind(env, factory, names, 0);
   }

   protected void bind(LuaValue env, Class factory, String[] names, int firstopcode) {
      try {
         int i = 0;

         for(int n = names.length; i < n; ++i) {
            LibFunction f = (LibFunction)factory.newInstance();
            f.opcode = firstopcode + i;
            f.name = names[i];
            env.set((String)f.name, (LuaValue)f);
         }

      } catch (Exception var8) {
         throw new LuaError("bind failed: " + String.valueOf(var8));
      }
   }

   protected static LuaValue[] newupe() {
      return new LuaValue[1];
   }

   protected static LuaValue[] newupn() {
      return new LuaValue[]{NIL};
   }

   protected static LuaValue[] newupl(LuaValue v) {
      return new LuaValue[]{v};
   }

   public LuaValue call() {
      return argerror(1, "value");
   }

   public LuaValue call(LuaValue a) {
      return this.call();
   }

   public LuaValue call(LuaValue a, LuaValue b) {
      return this.call(a);
   }

   public LuaValue call(LuaValue a, LuaValue b, LuaValue c) {
      return this.call(a, b);
   }

   public LuaValue call(LuaValue a, LuaValue b, LuaValue c, LuaValue d) {
      return this.call(a, b, c);
   }

   public Varargs invoke(Varargs args) {
      switch(args.narg()) {
      case 0:
         return this.call();
      case 1:
         return this.call(args.arg1());
      case 2:
         return this.call(args.arg1(), args.arg(2));
      case 3:
         return this.call(args.arg1(), args.arg(2), args.arg(3));
      default:
         return this.call(args.arg1(), args.arg(2), args.arg(3), args.arg(4));
      }
   }
}
