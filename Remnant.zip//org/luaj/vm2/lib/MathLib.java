package org.luaj.vm2.lib;

import com.chorus.api.system.prot.MathProt;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaDouble;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public class MathLib extends TwoArgFunction {
   public static MathLib MATHLIB = null;

   public MathLib() {
      MATHLIB = this;
   }

   public LuaValue call(LuaValue modname, LuaValue env) {
      LuaTable math = new LuaTable(0, 30);
      math.set("abs", new MathLib.abs());
      math.set("ceil", new MathLib.ceil());
      math.set("cos", new MathLib.cos());
      math.set("deg", new MathLib.deg());
      math.set("exp", new MathLib.exp(this));
      math.set("floor", new MathLib.floor());
      math.set("fmod", new MathLib.fmod());
      math.set("frexp", new MathLib.frexp());
      math.set("huge", LuaDouble.POSINF);
      math.set("ldexp", new MathLib.ldexp());
      math.set("max", new MathLib.max());
      math.set("min", new MathLib.min());
      math.set("modf", new MathLib.modf());
      math.set("pi", MathProt.PI());
      math.set("pow", new MathLib.pow());
      MathLib.random r;
      math.set("random", r = new MathLib.random());
      math.set("randomseed", new MathLib.randomseed(r));
      math.set("rad", new MathLib.rad());
      math.set("sin", new MathLib.sin());
      math.set("sqrt", new MathLib.sqrt());
      math.set("tan", new MathLib.tan());
      env.set((String)"math", (LuaValue)math);
      env.get("package").get("loaded").set((String)"math", (LuaValue)math);
      return math;
   }

   public static LuaValue dpow(double a, double b) {
      return LuaDouble.valueOf(MATHLIB != null ? MATHLIB.dpow_lib(a, b) : dpow_default(a, b));
   }

   public static double dpow_d(double a, double b) {
      return MATHLIB != null ? MATHLIB.dpow_lib(a, b) : dpow_default(a, b);
   }

   public double dpow_lib(double a, double b) {
      return dpow_default(a, b);
   }

   protected static double dpow_default(double a, double b) {
      if (b < 0.0D) {
         return 1.0D / dpow_default(a, -b);
      } else {
         double p = 1.0D;
         int whole = (int)b;

         for(double v = a; whole > 0; v *= v) {
            if ((whole & 1) != 0) {
               p *= v;
            }

            whole >>= 1;
         }

         if ((b -= (double)whole) > 0.0D) {
            for(int frac = (int)(65536.0D * b); (frac & '\uffff') != 0; frac <<= 1) {
               a = Math.sqrt(a);
               if ((frac & '耀') != 0) {
                  p *= a;
               }
            }
         }

         return p;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class abs extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.abs(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class ceil extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.ceil(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class cos extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.cos(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class deg extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.toDegrees(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class exp extends MathLib.UnaryOp {
      final MathLib mathlib;

      exp(MathLib mathlib) {
         this.mathlib = mathlib;
      }

      protected double call(double d) {
         return this.mathlib.dpow_lib(MathProt.E(), d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class floor extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.floor(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class fmod extends MathLib.BinaryOp {
      protected double call(double x, double y) {
         double q = x / y;
         return x - y * (q >= 0.0D ? Math.floor(q) : Math.ceil(q));
      }
   }

   @Environment(EnvType.CLIENT)
   static class frexp extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         double x = args.checkdouble(1);
         if (x == 0.0D) {
            return varargsOf(ZERO, ZERO);
         } else {
            long bits = Double.doubleToLongBits(x);
            double m = (double)((bits & 4503599627370495L) + 4503599627370496L) * (bits >= 0L ? 1.1102230246251565E-16D : -1.1102230246251565E-16D);
            double e = (double)(((int)(bits >> 52) & 2047) - 1022);
            return varargsOf(valueOf(m), valueOf(e));
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class ldexp extends MathLib.BinaryOp {
      protected double call(double x, double y) {
         return x * Double.longBitsToDouble((long)y + 1023L << 52);
      }
   }

   @Environment(EnvType.CLIENT)
   static class max extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         double m = args.checkdouble(1);
         int i = 2;

         for(int n = args.narg(); i <= n; ++i) {
            m = Math.max(m, args.checkdouble(i));
         }

         return valueOf(m);
      }
   }

   @Environment(EnvType.CLIENT)
   static class min extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         double m = args.checkdouble(1);
         int i = 2;

         for(int n = args.narg(); i <= n; ++i) {
            m = Math.min(m, args.checkdouble(i));
         }

         return valueOf(m);
      }
   }

   @Environment(EnvType.CLIENT)
   static class modf extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         double x = args.checkdouble(1);
         double intPart = x > 0.0D ? Math.floor(x) : Math.ceil(x);
         double fracPart = x - intPart;
         return varargsOf(valueOf(intPart), valueOf(fracPart));
      }
   }

   @Environment(EnvType.CLIENT)
   static final class pow extends MathLib.BinaryOp {
      protected double call(double x, double y) {
         return MathLib.dpow_default(x, y);
      }
   }

   @Environment(EnvType.CLIENT)
   static class random extends LibFunction {
      Random random = new Random();

      public LuaValue call() {
         return valueOf(this.random.nextDouble());
      }

      public LuaValue call(LuaValue a) {
         int m = a.checkint();
         if (m < 1) {
            argerror(1, "interval is empty");
         }

         return valueOf(1 + this.random.nextInt(m));
      }

      public LuaValue call(LuaValue a, LuaValue b) {
         int m = a.checkint();
         int n = b.checkint();
         if (n < m) {
            argerror(2, "interval is empty");
         }

         return valueOf(m + this.random.nextInt(n + 1 - m));
      }
   }

   @Environment(EnvType.CLIENT)
   static class randomseed extends OneArgFunction {
      final MathLib.random random;

      randomseed(MathLib.random random) {
         this.random = random;
      }

      public LuaValue call(LuaValue arg) {
         long seed = arg.checklong();
         this.random.random = new Random(seed);
         return NONE;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class rad extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.toRadians(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class sin extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.sin(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class sqrt extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.sqrt(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class tan extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.tan(d);
      }
   }

   @Environment(EnvType.CLIENT)
   protected abstract static class BinaryOp extends TwoArgFunction {
      public LuaValue call(LuaValue x, LuaValue y) {
         return valueOf(this.call(x.checkdouble(), y.checkdouble()));
      }

      protected abstract double call(double var1, double var3);
   }

   @Environment(EnvType.CLIENT)
   protected abstract static class UnaryOp extends OneArgFunction {
      public LuaValue call(LuaValue arg) {
         return valueOf(this.call(arg.checkdouble()));
      }

      protected abstract double call(double var1);
   }
}
