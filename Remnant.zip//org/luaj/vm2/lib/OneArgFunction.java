package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public abstract class OneArgFunction extends LibFunction {
   public abstract LuaValue call(LuaValue var1);

   public final LuaValue call() {
      return this.call(NIL);
   }

   public final LuaValue call(LuaValue arg1, LuaValue arg2) {
      return this.call(arg1);
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
      return this.call(arg1);
   }

   public Varargs invoke(Varargs varargs) {
      return this.call(varargs.arg1());
   }
}
