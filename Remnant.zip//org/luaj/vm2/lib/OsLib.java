package org.luaj.vm2.lib;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Buffer;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public class OsLib extends TwoArgFunction {
   public static String TMP_PREFIX = ".luaj";
   public static String TMP_SUFFIX = "tmp";
   private static final int CLOCK = 0;
   private static final int DATE = 1;
   private static final int DIFFTIME = 2;
   private static final int EXECUTE = 3;
   private static final int EXIT = 4;
   private static final int GETENV = 5;
   private static final int REMOVE = 6;
   private static final int RENAME = 7;
   private static final int SETLOCALE = 8;
   private static final int TIME = 9;
   private static final int TMPNAME = 10;
   private static final String[] NAMES = new String[]{"clock", "date", "difftime", "execute", "exit", "getenv", "remove", "rename", "setlocale", "time", "tmpname"};
   private static final long t0 = System.currentTimeMillis();
   private static long tmpnames;
   protected Globals globals;
   private static final String[] WeekdayNameAbbrev;
   private static final String[] WeekdayName;
   private static final String[] MonthNameAbbrev;
   private static final String[] MonthName;

   public LuaValue call(LuaValue modname, LuaValue env) {
      this.globals = env.checkglobals();
      LuaTable os = new LuaTable();

      for(int i = 0; i < NAMES.length; ++i) {
         os.set(NAMES[i], new OsLib.OsLibFunc(i, NAMES[i]));
      }

      env.set((String)"os", (LuaValue)os);
      env.get("package").get("loaded").set((String)"os", (LuaValue)os);
      return os;
   }

   protected double clock() {
      return (double)(System.currentTimeMillis() - t0) / 1000.0D;
   }

   protected double difftime(double t2, double t1) {
      return t2 - t1;
   }

   public String date(String format, double time) {
      Calendar d = Calendar.getInstance();
      d.setTime(new Date((long)(time * 1000.0D)));
      if (format.startsWith("!")) {
         time -= (double)this.timeZoneOffset(d);
         d.setTime(new Date((long)(time * 1000.0D)));
         format = format.substring(1);
      }

      byte[] fmt = format.getBytes();
      int n = fmt.length;
      Buffer result = new Buffer(n);
      int i = 0;

      while(i < n) {
         byte c;
         switch(c = fmt[i++]) {
         case 10:
            result.append("\n");
            break;
         case 37:
            if (i < n) {
               int a;
               switch(c = fmt[i++]) {
               case 37:
                  result.append((byte)37);
                  break;
               case 38:
               case 39:
               case 40:
               case 41:
               case 42:
               case 43:
               case 44:
               case 45:
               case 46:
               case 47:
               case 48:
               case 49:
               case 50:
               case 51:
               case 52:
               case 53:
               case 54:
               case 55:
               case 56:
               case 57:
               case 58:
               case 59:
               case 60:
               case 61:
               case 62:
               case 63:
               case 64:
               case 67:
               case 68:
               case 69:
               case 70:
               case 71:
               case 74:
               case 75:
               case 76:
               case 78:
               case 79:
               case 80:
               case 81:
               case 82:
               case 84:
               case 86:
               case 90:
               case 91:
               case 92:
               case 93:
               case 94:
               case 95:
               case 96:
               case 101:
               case 102:
               case 103:
               case 104:
               case 105:
               case 107:
               case 108:
               case 110:
               case 111:
               case 113:
               case 114:
               case 115:
               case 116:
               case 117:
               case 118:
               default:
                  LuaValue.argerror(1, "invalid conversion specifier '%" + c + "'");
                  break;
               case 65:
                  result.append(WeekdayName[d.get(7) - 1]);
                  break;
               case 66:
                  result.append(MonthName[d.get(2)]);
                  break;
               case 72:
                  result.append(String.valueOf(100 + d.get(11)).substring(1));
                  break;
               case 73:
                  result.append(String.valueOf(100 + d.get(11) % 12).substring(1));
                  break;
               case 77:
                  result.append(String.valueOf(100 + d.get(12)).substring(1));
                  break;
               case 83:
                  result.append(String.valueOf(100 + d.get(13)).substring(1));
                  break;
               case 85:
                  result.append(String.valueOf(this.weekNumber(d, 0)));
                  break;
               case 87:
                  result.append(String.valueOf(this.weekNumber(d, 1)));
                  break;
               case 88:
                  result.append(this.date("%H:%M:%S", time));
                  break;
               case 89:
                  result.append(String.valueOf(d.get(1)));
                  break;
               case 97:
                  result.append(WeekdayNameAbbrev[d.get(7) - 1]);
                  break;
               case 98:
                  result.append(MonthNameAbbrev[d.get(2)]);
                  break;
               case 99:
                  result.append(this.date("%a %b %d %H:%M:%S %Y", time));
                  break;
               case 100:
                  result.append(String.valueOf(100 + d.get(5)).substring(1));
                  break;
               case 106:
                  Calendar y0 = this.beginningOfYear(d);
                  a = (int)((d.getTime().getTime() - y0.getTime().getTime()) / 86400000L);
                  result.append(String.valueOf(1001 + a).substring(1));
                  break;
               case 109:
                  result.append(String.valueOf(101 + d.get(2)).substring(1));
                  break;
               case 112:
                  result.append(d.get(11) < 12 ? "AM" : "PM");
                  break;
               case 119:
                  result.append(String.valueOf((d.get(7) + 6) % 7));
                  break;
               case 120:
                  result.append(this.date("%m/%d/%y", time));
                  break;
               case 121:
                  result.append(String.valueOf(d.get(1)).substring(2));
                  break;
               case 122:
                  int tzo = this.timeZoneOffset(d) / 60;
                  a = Math.abs(tzo);
                  String h = String.valueOf(100 + a / 60).substring(1);
                  String m = String.valueOf(100 + a % 60).substring(1);
                  result.append((tzo >= 0 ? "+" : "-") + h + m);
               }
            }
            break;
         default:
            result.append(c);
         }
      }

      return result.tojstring();
   }

   private Calendar beginningOfYear(Calendar d) {
      Calendar y0 = Calendar.getInstance();
      y0.setTime(d.getTime());
      y0.set(2, 0);
      y0.set(5, 1);
      y0.set(11, 0);
      y0.set(12, 0);
      y0.set(13, 0);
      y0.set(14, 0);
      return y0;
   }

   private int weekNumber(Calendar d, int startDay) {
      Calendar y0 = this.beginningOfYear(d);
      y0.set(5, 1 + (startDay + 8 - y0.get(7)) % 7);
      if (y0.after(d)) {
         y0.set(1, y0.get(1) - 1);
         y0.set(5, 1 + (startDay + 8 - y0.get(7)) % 7);
      }

      long dt = d.getTime().getTime() - y0.getTime().getTime();
      return 1 + (int)(dt / 604800000L);
   }

   private int timeZoneOffset(Calendar d) {
      int localStandarTimeMillis = (d.get(11) * 3600 + d.get(12) * 60 + d.get(13)) * 1000;
      return d.getTimeZone().getOffset(1, d.get(1), d.get(2), d.get(5), d.get(7), localStandarTimeMillis) / 1000;
   }

   private boolean isDaylightSavingsTime(Calendar d) {
      return this.timeZoneOffset(d) != d.getTimeZone().getRawOffset() / 1000;
   }

   protected Varargs execute(String command) {
      return varargsOf(NIL, valueOf("exit"), ONE);
   }

   protected void exit(int code) {
      System.exit(code);
   }

   protected String getenv(String varname) {
      return System.getProperty(varname);
   }

   protected void remove(String filename) throws IOException {
      throw new IOException("not implemented");
   }

   protected void rename(String oldname, String newname) throws IOException {
      throw new IOException("not implemented");
   }

   protected String setlocale(String locale, String category) {
      return "C";
   }

   protected double time(LuaTable table) {
      Date d;
      if (table == null) {
         d = new Date();
      } else {
         Calendar c = Calendar.getInstance();
         c.set(1, table.get("year").checkint());
         c.set(2, table.get("month").checkint() - 1);
         c.set(5, table.get("day").checkint());
         c.set(11, table.get("hour").optint(12));
         c.set(12, table.get("min").optint(0));
         c.set(13, table.get("sec").optint(0));
         c.set(14, 0);
         d = c.getTime();
      }

      return (double)d.getTime() / 1000.0D;
   }

   protected String tmpname() {
      Class var1 = OsLib.class;
      synchronized(OsLib.class) {
         String var10000 = TMP_PREFIX;
         return var10000 + tmpnames++ + TMP_SUFFIX;
      }
   }

   static {
      tmpnames = t0;
      WeekdayNameAbbrev = new String[]{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
      WeekdayName = new String[]{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
      MonthNameAbbrev = new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
      MonthName = new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
   }

   @Environment(EnvType.CLIENT)
   class OsLibFunc extends VarArgFunction {
      public OsLibFunc(int opcode, String name) {
         this.opcode = opcode;
         this.name = name;
      }

      public Varargs invoke(Varargs args) {
         try {
            String s;
            switch(this.opcode) {
            case 0:
               return valueOf(OsLib.this.clock());
            case 1:
               s = args.optjstring(1, "%c");
               double t = args.isnumber(2) ? args.todouble(2) : OsLib.this.time((LuaTable)null);
               if (s.equals("*t")) {
                  Calendar d = Calendar.getInstance();
                  d.setTime(new Date((long)(t * 1000.0D)));
                  LuaTable tbl = LuaValue.tableOf();
                  tbl.set("year", LuaValue.valueOf(d.get(1)));
                  tbl.set("month", LuaValue.valueOf(d.get(2) + 1));
                  tbl.set("day", LuaValue.valueOf(d.get(5)));
                  tbl.set("hour", LuaValue.valueOf(d.get(11)));
                  tbl.set("min", LuaValue.valueOf(d.get(12)));
                  tbl.set("sec", LuaValue.valueOf(d.get(13)));
                  tbl.set("wday", LuaValue.valueOf(d.get(7)));
                  tbl.set("yday", LuaValue.valueOf(d.get(6)));
                  tbl.set("isdst", LuaValue.valueOf(OsLib.this.isDaylightSavingsTime(d)));
                  return tbl;
               }

               return valueOf(OsLib.this.date(s, t == -1.0D ? OsLib.this.time((LuaTable)null) : t));
            case 2:
               return valueOf(OsLib.this.difftime(args.checkdouble(1), args.checkdouble(2)));
            case 3:
               return OsLib.this.execute(args.optjstring(1, (String)null));
            case 4:
               OsLib.this.exit(args.optint(1, 0));
               return NONE;
            case 5:
               s = OsLib.this.getenv(args.checkjstring(1));
               return (Varargs)(s != null ? valueOf(s) : NIL);
            case 6:
               OsLib.this.remove(args.checkjstring(1));
               return LuaValue.TRUE;
            case 7:
               OsLib.this.rename(args.checkjstring(1), args.checkjstring(2));
               return LuaValue.TRUE;
            case 8:
               s = OsLib.this.setlocale(args.optjstring(1, (String)null), args.optjstring(2, "all"));
               return (Varargs)(s != null ? valueOf(s) : NIL);
            case 9:
               return valueOf(OsLib.this.time(args.opttable(1, (LuaTable)null)));
            case 10:
               return valueOf(OsLib.this.tmpname());
            default:
               return NONE;
            }
         } catch (IOException var7) {
            return varargsOf(NIL, valueOf(var7.getMessage()));
         }
      }
   }
}
