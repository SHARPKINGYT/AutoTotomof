package org.luaj.vm2.lib;

import java.io.IOException;
import java.io.InputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public class PackageLib extends TwoArgFunction {
   public static String DEFAULT_LUA_PATH;
   private static final LuaString _LOADED;
   private static final LuaString _LOADLIB;
   private static final LuaString _PRELOAD;
   private static final LuaString _PATH;
   private static final LuaString _SEARCHPATH;
   private static final LuaString _SEARCHERS;
   Globals globals;
   LuaTable package_;
   public PackageLib.preload_searcher preload_searcher;
   public PackageLib.lua_searcher lua_searcher;
   public PackageLib.java_searcher java_searcher;
   private static final LuaString _SENTINEL;
   private static final String FILE_SEP;

   public LuaValue call(LuaValue modname, LuaValue env) {
      this.globals = env.checkglobals();
      this.globals.set("require", new PackageLib.require());
      this.package_ = new LuaTable();
      this.package_.set(_LOADED, new LuaTable());
      this.package_.set(_PRELOAD, new LuaTable());
      this.package_.set(_PATH, LuaValue.valueOf(DEFAULT_LUA_PATH));
      this.package_.set(_LOADLIB, new PackageLib.loadlib());
      this.package_.set(_SEARCHPATH, new PackageLib.searchpath());
      LuaTable searchers = new LuaTable();
      searchers.set(1, this.preload_searcher = new PackageLib.preload_searcher());
      searchers.set(2, this.lua_searcher = new PackageLib.lua_searcher());
      searchers.set(3, this.java_searcher = new PackageLib.java_searcher());
      this.package_.set(_SEARCHERS, searchers);
      this.package_.get(_LOADED).set((String)"package", (LuaValue)this.package_);
      env.set((String)"package", (LuaValue)this.package_);
      this.globals.package_ = this;
      return env;
   }

   public void setIsLoaded(String name, LuaTable value) {
      this.package_.get(_LOADED).set((String)name, (LuaValue)value);
   }

   public void setLuaPath(String newLuaPath) {
      this.package_.set(_PATH, LuaValue.valueOf(newLuaPath));
   }

   public String tojstring() {
      return "package";
   }

   public static final String toClassname(String filename) {
      int n = filename.length();
      int j = n;
      if (filename.endsWith(".lua")) {
         j = n - 4;
      }

      for(int k = 0; k < j; ++k) {
         char c = filename.charAt(k);
         if (!isClassnamePart(c) || c == '/' || c == '\\') {
            StringBuffer sb = new StringBuffer(j);

            for(int i = 0; i < j; ++i) {
               c = filename.charAt(i);
               sb.append((char)(isClassnamePart(c) ? c : (c != '/' && c != '\\' ? '_' : '.')));
            }

            return sb.toString();
         }
      }

      return n == j ? filename : filename.substring(0, j);
   }

   private static final boolean isClassnamePart(char c) {
      if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < '0' || c > '9')) {
         switch(c) {
         case '$':
         case '.':
         case '_':
            return true;
         default:
            return false;
         }
      } else {
         return true;
      }
   }

   static {
      try {
         DEFAULT_LUA_PATH = System.getProperty("luaj.package.path");
      } catch (Exception var1) {
         System.out.println(var1.toString());
      }

      if (DEFAULT_LUA_PATH == null) {
         DEFAULT_LUA_PATH = "?.lua";
      }

      _LOADED = valueOf("loaded");
      _LOADLIB = valueOf("loadlib");
      _PRELOAD = valueOf("preload");
      _PATH = valueOf("path");
      _SEARCHPATH = valueOf("searchpath");
      _SEARCHERS = valueOf("searchers");
      _SENTINEL = valueOf("\u0001");
      FILE_SEP = System.getProperty("file.separator");
   }

   @Environment(EnvType.CLIENT)
   public class require extends OneArgFunction {
      public LuaValue call(LuaValue arg) {
         LuaString name = arg.checkstring();
         LuaValue loaded = PackageLib.this.package_.get(PackageLib._LOADED);
         LuaValue result = loaded.get((LuaValue)name);
         if (result.toboolean()) {
            if (result == PackageLib._SENTINEL) {
               error("loop or previous error loading module '" + String.valueOf(name) + "'");
            }

            return result;
         } else {
            LuaTable tbl = PackageLib.this.package_.get(PackageLib._SEARCHERS).checktable();
            StringBuffer sb = new StringBuffer();
            Varargs loader = null;
            int i = 1;

            while(true) {
               LuaValue searcher = tbl.get(i);
               if (searcher.isnil()) {
                  String var10000 = String.valueOf(name);
                  error("module '" + var10000 + "' not found: " + String.valueOf(name) + String.valueOf(sb));
               }

               loader = searcher.invoke((Varargs)name);
               if (loader.isfunction(1)) {
                  loaded.set((LuaValue)name, (LuaValue)PackageLib._SENTINEL);
                  LuaValue resultx = loader.arg1().call(name, loader.arg(2));
                  if (!((LuaValue)resultx).isnil()) {
                     loaded.set((LuaValue)name, (LuaValue)resultx);
                  } else if ((resultx = loaded.get((LuaValue)name)) == PackageLib._SENTINEL) {
                     loaded.set((LuaValue)name, (LuaValue)(resultx = LuaValue.TRUE));
                  }

                  return (LuaValue)resultx;
               }

               if (loader.isstring(1)) {
                  sb.append(loader.tojstring(1));
               }

               ++i;
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   public static class loadlib extends VarArgFunction {
      public Varargs loadlib(Varargs args) {
         args.checkstring(1);
         return varargsOf(NIL, valueOf("dynamic libraries not enabled"), valueOf("absent"));
      }
   }

   @Environment(EnvType.CLIENT)
   public class searchpath extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         String name = args.checkjstring(1);
         String path = args.checkjstring(2);
         String sep = args.optjstring(3, ".");
         String rep = args.optjstring(4, PackageLib.FILE_SEP);
         int e = -1;
         int n = path.length();
         StringBuffer sb = null;

         String filename;
         for(name = name.replace(sep.charAt(0), rep.charAt(0)); e < n; sb.append("\n\t" + filename)) {
            int b = e + 1;
            e = path.indexOf(59, b);
            if (e < 0) {
               e = path.length();
            }

            String template = path.substring(b, e);
            int q = template.indexOf(63);
            filename = template;
            if (q >= 0) {
               filename = template.substring(0, q) + name + template.substring(q + 1);
            }

            InputStream is = PackageLib.this.globals.finder.findResource(filename);
            if (is != null) {
               try {
                  is.close();
               } catch (IOException var15) {
               }

               return valueOf(filename);
            }

            if (sb == null) {
               sb = new StringBuffer();
            }
         }

         return varargsOf(NIL, valueOf(sb.toString()));
      }
   }

   @Environment(EnvType.CLIENT)
   public class preload_searcher extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString name = args.checkstring(1);
         LuaValue val = PackageLib.this.package_.get(PackageLib._PRELOAD).get((LuaValue)name);
         return (Varargs)(val.isnil() ? valueOf("\n\tno field package.preload['" + String.valueOf(name) + "']") : val);
      }
   }

   @Environment(EnvType.CLIENT)
   public class lua_searcher extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString name = args.checkstring(1);
         InputStream is = null;
         LuaValue path = PackageLib.this.package_.get(PackageLib._PATH);
         if (!path.isstring()) {
            return valueOf("package.path is not a string");
         } else {
            Varargs vx = PackageLib.this.package_.get(PackageLib._SEARCHPATH).invoke(varargsOf(name, path));
            if (!vx.isstring(1)) {
               return vx.arg(2).tostring();
            } else {
               LuaString filename = vx.arg1().strvalue();
               Varargs v = PackageLib.this.globals.loadfile(filename.tojstring());
               if (v.arg1().isfunction()) {
                  return LuaValue.varargsOf((LuaValue)v.arg1(), filename);
               } else {
                  LuaValue var10000 = NIL;
                  String var10001 = String.valueOf(filename);
                  return varargsOf(var10000, valueOf("'" + var10001 + "': " + v.arg(2).tojstring()));
               }
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   public class java_searcher extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         String name = args.checkjstring(1);
         String classname = PackageLib.toClassname(name);
         Class c = null;
         LuaValue v = null;

         try {
            c = Class.forName(classname);
            v = (LuaValue)c.newInstance();
            if (v.isfunction()) {
               ((LuaFunction)v).initupvalue1(PackageLib.this.globals);
            }

            return varargsOf(v, PackageLib.this.globals);
         } catch (ClassNotFoundException var7) {
            return valueOf("\n\tno class '" + classname + "'");
         } catch (Exception var8) {
            return valueOf("\n\tjava load failed on '" + classname + "', " + String.valueOf(var8));
         }
      }
   }
}
