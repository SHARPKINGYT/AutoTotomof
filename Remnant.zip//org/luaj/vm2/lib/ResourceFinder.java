package org.luaj.vm2.lib;

import java.io.InputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface ResourceFinder {
   InputStream findResource(String var1);
}
