package org.luaj.vm2.lib;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Buffer;
import org.luaj.vm2.LuaClosure;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.compiler.DumpState;

@Environment(EnvType.CLIENT)
public class StringLib extends TwoArgFunction {
   private static final String FLAGS = "-+ #0";
   private static final int L_ESC = 37;
   private static final LuaString SPECIALS = valueOf("^$*+?.([%-");
   private static final int MAX_CAPTURES = 32;
   private static final int CAP_UNFINISHED = -1;
   private static final int CAP_POSITION = -2;
   private static final byte MASK_ALPHA = 1;
   private static final byte MASK_LOWERCASE = 2;
   private static final byte MASK_UPPERCASE = 4;
   private static final byte MASK_DIGIT = 8;
   private static final byte MASK_PUNCT = 16;
   private static final byte MASK_SPACE = 32;
   private static final byte MASK_CONTROL = 64;
   private static final byte MASK_HEXDIGIT = -128;
   private static final byte[] CHAR_TABLE = new byte[256];

   public LuaValue call(LuaValue modname, LuaValue env) {
      LuaTable string = new LuaTable();
      string.set("byte", new StringLib.byte_());
      string.set("char", new StringLib.char_());
      string.set("dump", new StringLib.dump());
      string.set("find", new StringLib.find());
      string.set("format", new StringLib.format());
      string.set("gmatch", new StringLib.gmatch());
      string.set("gsub", new StringLib.gsub());
      string.set("len", new StringLib.len());
      string.set("lower", new StringLib.lower());
      string.set("match", new StringLib.match());
      string.set("rep", new StringLib.rep());
      string.set("reverse", new StringLib.reverse());
      string.set("sub", new StringLib.sub());
      string.set("upper", new StringLib.upper());
      LuaTable mt = LuaValue.tableOf(new LuaValue[]{INDEX, string});
      env.set((String)"string", (LuaValue)string);
      env.get("package").get("loaded").set((String)"string", (LuaValue)string);
      if (LuaString.s_metatable == null) {
         LuaString.s_metatable = mt;
      }

      return string;
   }

   private static void addquoted(Buffer buf, LuaString s) {
      buf.append((byte)34);
      int i = 0;

      for(int n = s.length(); i < n; ++i) {
         int c;
         switch(c = s.luaByte(i)) {
         case 10:
         case 34:
         case 92:
            buf.append((byte)92);
            buf.append((byte)c);
            break;
         default:
            if (c > 31 && c != 127) {
               buf.append((byte)c);
            } else {
               buf.append((byte)92);
               if (i + 1 != n && s.luaByte(i + 1) >= 48 && s.luaByte(i + 1) <= 57) {
                  buf.append((byte)48);
                  buf.append((byte)((char)(48 + c / 10)));
                  buf.append((byte)((char)(48 + c % 10)));
               } else {
                  buf.append(Integer.toString(c));
               }
            }
         }
      }

      buf.append((byte)34);
   }

   static Varargs str_find_aux(Varargs args, boolean find) {
      LuaString s = args.checkstring(1);
      LuaString pat = args.checkstring(2);
      int init = args.optint(3, 1);
      if (init > 0) {
         init = Math.min(init - 1, s.length());
      } else if (init < 0) {
         init = Math.max(0, s.length() + init);
      }

      boolean fastMatch = find && (args.arg(4).toboolean() || pat.indexOfAny(SPECIALS) == -1);
      if (fastMatch) {
         int result = s.indexOf(pat, init);
         if (result != -1) {
            return varargsOf(valueOf(result + 1), valueOf(result + pat.length()));
         }
      } else {
         StringLib.MatchState ms = new StringLib.MatchState(args, s, pat);
         boolean anchor = false;
         int poff = 0;
         if (pat.luaByte(0) == 94) {
            anchor = true;
            poff = 1;
         }

         int soff = init;

         do {
            ms.reset();
            int res;
            if ((res = ms.match(soff, poff)) != -1) {
               if (find) {
                  return varargsOf(valueOf(soff + 1), valueOf(res), ms.push_captures(false, soff, res));
               }

               return ms.push_captures(true, soff, res);
            }
         } while(soff++ < s.length() && !anchor);
      }

      return NIL;
   }

   private static int posrelat(int pos, int len) {
      return pos >= 0 ? pos : len + pos + 1;
   }

   static {
      byte[] var10000;
      for(int i = 0; i < 256; ++i) {
         char c = (char)i;
         CHAR_TABLE[i] = (byte)((Character.isDigit(c) ? 8 : 0) | (Character.isLowerCase(c) ? 2 : 0) | (Character.isUpperCase(c) ? 4 : 0) | (c >= ' ' && c != 127 ? 0 : 64));
         if (c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F' || c >= '0' && c <= '9') {
            var10000 = CHAR_TABLE;
            var10000[i] |= -128;
         }

         if (c >= '!' && c <= '/' || c >= ':' && c <= '@') {
            var10000 = CHAR_TABLE;
            var10000[i] = (byte)(var10000[i] | 16);
         }

         if ((CHAR_TABLE[i] & 6) != 0) {
            var10000 = CHAR_TABLE;
            var10000[i] = (byte)(var10000[i] | 1);
         }
      }

      CHAR_TABLE[32] = 32;
      var10000 = CHAR_TABLE;
      var10000[13] = (byte)(var10000[13] | 32);
      var10000 = CHAR_TABLE;
      var10000[10] = (byte)(var10000[10] | 32);
      var10000 = CHAR_TABLE;
      var10000[9] = (byte)(var10000[9] | 32);
      var10000 = CHAR_TABLE;
      var10000[12] = (byte)(var10000[12] | 32);
      var10000 = CHAR_TABLE;
      var10000[12] = (byte)(var10000[12] | 32);
   }

   @Environment(EnvType.CLIENT)
   static final class byte_ extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString s = args.checkstring(1);
         int l = s.m_length;
         int posi = StringLib.posrelat(args.optint(2, 1), l);
         int pose = StringLib.posrelat(args.optint(3, posi), l);
         if (posi <= 0) {
            posi = 1;
         }

         if (pose > l) {
            pose = l;
         }

         if (posi > pose) {
            return NONE;
         } else {
            int n = pose - posi + 1;
            if (posi + n <= pose) {
               error("string slice too long");
            }

            LuaValue[] v = new LuaValue[n];

            for(int i = 0; i < n; ++i) {
               v[i] = valueOf(s.luaByte(posi + i - 1));
            }

            return varargsOf(v);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class char_ extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         int n = args.narg();
         byte[] bytes = new byte[n];
         int i = 0;

         for(int a = 1; i < n; ++a) {
            int c = args.checkint(a);
            if (c < 0 || c >= 256) {
               argerror(a, "invalid value");
            }

            bytes[i] = (byte)c;
            ++i;
         }

         return LuaString.valueUsing(bytes);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class dump extends OneArgFunction {
      public LuaValue call(LuaValue arg) {
         LuaValue f = arg.checkfunction();
         ByteArrayOutputStream baos = new ByteArrayOutputStream();

         try {
            DumpState.dump(((LuaClosure)f).p, baos, true);
            return LuaString.valueUsing(baos.toByteArray());
         } catch (IOException var5) {
            return error(var5.getMessage());
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class find extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         return StringLib.str_find_aux(args, true);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class format extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString fmt = args.checkstring(1);
         int n = fmt.length();
         Buffer result = new Buffer(n);
         int arg = 1;
         int i = 0;

         while(true) {
            while(true) {
               label36:
               do {
                  while(i < n) {
                     int c;
                     switch(c = fmt.luaByte(i++)) {
                     case 10:
                        result.append("\n");
                        break;
                     case 37:
                        continue label36;
                     default:
                        result.append((byte)c);
                     }
                  }

                  return result.tostring();
               } while(i >= n);

               if (fmt.luaByte(i) == 37) {
                  ++i;
                  result.append((byte)37);
               } else {
                  ++arg;
                  StringLib.FormatDesc fdsc = new StringLib.FormatDesc(args, fmt, i);
                  i += fdsc.length;
                  switch(fdsc.conversion) {
                  case 69:
                  case 71:
                  case 101:
                  case 102:
                  case 103:
                     fdsc.format(result, args.checkdouble(arg));
                     break;
                  case 70:
                  case 72:
                  case 73:
                  case 74:
                  case 75:
                  case 76:
                  case 77:
                  case 78:
                  case 79:
                  case 80:
                  case 81:
                  case 82:
                  case 83:
                  case 84:
                  case 85:
                  case 86:
                  case 87:
                  case 89:
                  case 90:
                  case 91:
                  case 92:
                  case 93:
                  case 94:
                  case 95:
                  case 96:
                  case 97:
                  case 98:
                  case 104:
                  case 106:
                  case 107:
                  case 108:
                  case 109:
                  case 110:
                  case 112:
                  case 114:
                  case 116:
                  case 118:
                  case 119:
                  default:
                     error("invalid option '%" + (char)fdsc.conversion + "' to 'format'");
                     break;
                  case 88:
                  case 111:
                  case 117:
                  case 120:
                     fdsc.format(result, args.checklong(arg));
                     break;
                  case 99:
                     fdsc.format(result, (byte)args.checkint(arg));
                     break;
                  case 100:
                  case 105:
                     fdsc.format(result, (long)args.checkint(arg));
                     break;
                  case 113:
                     StringLib.addquoted(result, args.checkstring(arg));
                     break;
                  case 115:
                     LuaString s = args.checkstring(arg);
                     if (fdsc.precision == -1 && s.length() >= 100) {
                        result.append(s);
                     } else {
                        fdsc.format(result, s);
                     }
                  }
               }
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class gmatch extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString src = args.checkstring(1);
         LuaString pat = args.checkstring(2);
         return new StringLib.GMatchAux(args, src, pat);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class gsub extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString src = args.checkstring(1);
         int srclen = src.length();
         LuaString p = args.checkstring(2);
         LuaValue repl = args.arg(3);
         int max_s = args.optint(4, srclen + 1);
         boolean anchor = p.length() > 0 && p.charAt(0) == 94;
         Buffer lbuf = new Buffer(srclen);
         StringLib.MatchState ms = new StringLib.MatchState(args, src, p);
         int soffset = 0;
         int n = 0;

         while(n < max_s) {
            ms.reset();
            int res = ms.match(soffset, anchor ? 1 : 0);
            if (res != -1) {
               ++n;
               ms.add_value(lbuf, soffset, res, repl);
            }

            if (res != -1 && res > soffset) {
               soffset = res;
            } else {
               if (soffset >= srclen) {
                  break;
               }

               lbuf.append((byte)src.luaByte(soffset++));
            }

            if (anchor) {
               break;
            }
         }

         lbuf.append(src.substring(soffset, srclen));
         return varargsOf(lbuf.tostring(), valueOf(n));
      }
   }

   @Environment(EnvType.CLIENT)
   static final class len extends OneArgFunction {
      public LuaValue call(LuaValue arg) {
         return arg.checkstring().len();
      }
   }

   @Environment(EnvType.CLIENT)
   static final class lower extends OneArgFunction {
      public LuaValue call(LuaValue arg) {
         return valueOf(arg.checkjstring().toLowerCase());
      }
   }

   @Environment(EnvType.CLIENT)
   static final class match extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         return StringLib.str_find_aux(args, false);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class rep extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString s = args.checkstring(1);
         int n = args.checkint(2);
         byte[] bytes = new byte[s.length() * n];
         int len = s.length();

         for(int offset = 0; offset < bytes.length; offset += len) {
            s.copyInto(0, bytes, offset, len);
         }

         return LuaString.valueUsing(bytes);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class reverse extends OneArgFunction {
      public LuaValue call(LuaValue arg) {
         LuaString s = arg.checkstring();
         int n = s.length();
         byte[] b = new byte[n];
         int i = 0;

         for(int j = n - 1; i < n; --j) {
            b[j] = (byte)s.luaByte(i);
            ++i;
         }

         return LuaString.valueUsing(b);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class sub extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaString s = args.checkstring(1);
         int l = s.length();
         int start = StringLib.posrelat(args.checkint(2), l);
         int end = StringLib.posrelat(args.optint(3, -1), l);
         if (start < 1) {
            start = 1;
         }

         if (end > l) {
            end = l;
         }

         return start <= end ? s.substring(start - 1, end) : EMPTYSTRING;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class upper extends OneArgFunction {
      public LuaValue call(LuaValue arg) {
         return valueOf(arg.checkjstring().toUpperCase());
      }
   }

   @Environment(EnvType.CLIENT)
   static class MatchState {
      final LuaString s;
      final LuaString p;
      final Varargs args;
      int level;
      int[] cinit;
      int[] clen;

      MatchState(Varargs args, LuaString s, LuaString pattern) {
         this.s = s;
         this.p = pattern;
         this.args = args;
         this.level = 0;
         this.cinit = new int[32];
         this.clen = new int[32];
      }

      void reset() {
         this.level = 0;
      }

      private void add_s(Buffer lbuf, LuaString news, int soff, int e) {
         int l = news.length();

         for(int i = 0; i < l; ++i) {
            byte b = (byte)news.luaByte(i);
            if (b != 37) {
               lbuf.append(b);
            } else {
               ++i;
               b = (byte)news.luaByte(i);
               if (!Character.isDigit((char)b)) {
                  lbuf.append(b);
               } else if (b == 48) {
                  lbuf.append(this.s.substring(soff, e));
               } else {
                  lbuf.append(this.push_onecapture(b - 49, soff, e).strvalue());
               }
            }
         }

      }

      public void add_value(Buffer lbuf, int soffset, int end, LuaValue repl) {
         Object repl;
         switch(repl.type()) {
         case 3:
         case 4:
            this.add_s(lbuf, repl.strvalue(), soffset, end);
            return;
         case 5:
            repl = repl.get(this.push_onecapture(0, soffset, end));
            break;
         case 6:
            repl = repl.invoke(this.push_captures(true, soffset, end)).arg1();
            break;
         default:
            LuaValue.error("bad argument: string/function/table expected");
            return;
         }

         if (!((LuaValue)repl).toboolean()) {
            repl = this.s.substring(soffset, end);
         } else if (!((LuaValue)repl).isstring()) {
            LuaValue.error("invalid replacement value (a " + ((LuaValue)repl).typename() + ")");
         }

         lbuf.append(((LuaValue)repl).strvalue());
      }

      Varargs push_captures(boolean wholeMatch, int soff, int end) {
         int nlevels = this.level == 0 && wholeMatch ? 1 : this.level;
         switch(nlevels) {
         case 0:
            return LuaValue.NONE;
         case 1:
            return this.push_onecapture(0, soff, end);
         default:
            LuaValue[] v = new LuaValue[nlevels];

            for(int i = 0; i < nlevels; ++i) {
               v[i] = this.push_onecapture(i, soff, end);
            }

            return LuaValue.varargsOf(v);
         }
      }

      private LuaValue push_onecapture(int i, int soff, int end) {
         if (i >= this.level) {
            return (LuaValue)(i == 0 ? this.s.substring(soff, end) : LuaValue.error("invalid capture index"));
         } else {
            int l = this.clen[i];
            if (l == -1) {
               return LuaValue.error("unfinished capture");
            } else if (l == -2) {
               return LuaValue.valueOf(this.cinit[i] + 1);
            } else {
               int begin = this.cinit[i];
               return this.s.substring(begin, begin + l);
            }
         }
      }

      private int check_capture(int l) {
         l -= 49;
         if (l < 0 || l >= this.level || this.clen[l] == -1) {
            LuaValue.error("invalid capture index");
         }

         return l;
      }

      private int capture_to_close() {
         int level = this.level;
         --level;

         while(level >= 0) {
            if (this.clen[level] == -1) {
               return level;
            }

            --level;
         }

         LuaValue.error("invalid pattern capture");
         return 0;
      }

      int classend(int poffset) {
         switch(this.p.luaByte(poffset++)) {
         case 37:
            if (poffset == this.p.length()) {
               LuaValue.error("malformed pattern (ends with %)");
            }

            return poffset + 1;
         case 91:
            if (this.p.luaByte(poffset) == 94) {
               ++poffset;
            }

            do {
               if (poffset == this.p.length()) {
                  LuaValue.error("malformed pattern (missing ])");
               }

               if (this.p.luaByte(poffset++) == 37 && poffset != this.p.length()) {
                  ++poffset;
               }
            } while(this.p.luaByte(poffset) != 93);

            return poffset + 1;
         default:
            return poffset;
         }
      }

      static boolean match_class(int c, int cl) {
         char lcl = Character.toLowerCase((char)cl);
         int cdata = StringLib.CHAR_TABLE[c];
         boolean res;
         switch(lcl) {
         case 'a':
            res = (cdata & 1) != 0;
            break;
         case 'b':
         case 'e':
         case 'f':
         case 'g':
         case 'h':
         case 'i':
         case 'j':
         case 'k':
         case 'm':
         case 'n':
         case 'o':
         case 'q':
         case 'r':
         case 't':
         case 'v':
         case 'y':
         default:
            return cl == c;
         case 'c':
            res = (cdata & 64) != 0;
            break;
         case 'd':
            res = (cdata & 8) != 0;
            break;
         case 'l':
            res = (cdata & 2) != 0;
            break;
         case 'p':
            res = (cdata & 16) != 0;
            break;
         case 's':
            res = (cdata & 32) != 0;
            break;
         case 'u':
            res = (cdata & 4) != 0;
            break;
         case 'w':
            res = (cdata & 9) != 0;
            break;
         case 'x':
            res = (cdata & -128) != 0;
            break;
         case 'z':
            res = c == 0;
         }

         return lcl == cl ? res : !res;
      }

      boolean matchbracketclass(int c, int poff, int ec) {
         boolean sig = true;
         if (this.p.luaByte(poff + 1) == 94) {
            sig = false;
            ++poff;
         }

         do {
            while(true) {
               ++poff;
               if (poff >= ec) {
                  return !sig;
               }

               if (this.p.luaByte(poff) == 37) {
                  ++poff;
                  break;
               }

               if (this.p.luaByte(poff + 1) == 45 && poff + 2 < ec) {
                  poff += 2;
                  if (this.p.luaByte(poff - 2) <= c && c <= this.p.luaByte(poff)) {
                     return sig;
                  }
               } else if (this.p.luaByte(poff) == c) {
                  return sig;
               }
            }
         } while(!match_class(c, this.p.luaByte(poff)));

         return sig;
      }

      boolean singlematch(int c, int poff, int ep) {
         switch(this.p.luaByte(poff)) {
         case 37:
            return match_class(c, this.p.luaByte(poff + 1));
         case 46:
            return true;
         case 91:
            return this.matchbracketclass(c, poff, ep - 1);
         default:
            return this.p.luaByte(poff) == c;
         }
      }

      int match(int soffset, int poffset) {
         while(poffset != this.p.length()) {
            int ep;
            switch(this.p.luaByte(poffset)) {
            case 37:
               if (poffset + 1 == this.p.length()) {
                  LuaValue.error("malformed pattern (ends with '%')");
               }

               switch(this.p.luaByte(poffset + 1)) {
               case 98:
                  soffset = this.matchbalance(soffset, poffset + 2);
                  if (soffset == -1) {
                     return -1;
                  }

                  poffset += 4;
                  continue;
               case 102:
                  poffset += 2;
                  if (this.p.luaByte(poffset) != 91) {
                     LuaValue.error("Missing [ after %f in pattern");
                  }

                  ep = this.classend(poffset);
                  int previous = soffset == 0 ? -1 : this.s.luaByte(soffset - 1);
                  if (!this.matchbracketclass(previous, poffset, ep - 1) && !this.matchbracketclass(this.s.luaByte(soffset), poffset, ep - 1)) {
                     poffset = ep;
                     continue;
                  }

                  return -1;
               default:
                  ep = this.p.luaByte(poffset + 1);
                  if (Character.isDigit((char)ep)) {
                     soffset = this.match_capture(soffset, ep);
                     if (soffset == -1) {
                        return -1;
                     }

                     return this.match(soffset, poffset + 2);
                  }
               }
            case 36:
               if (poffset + 1 == this.p.length()) {
                  return soffset == this.s.length() ? soffset : -1;
               }
            case 38:
            case 39:
            default:
               break;
            case 40:
               ++poffset;
               if (poffset < this.p.length() && this.p.luaByte(poffset) == 41) {
                  return this.start_capture(soffset, poffset + 1, -2);
               }

               return this.start_capture(soffset, poffset, -1);
            case 41:
               return this.end_capture(soffset, poffset + 1);
            }

            ep = this.classend(poffset);
            boolean m = soffset < this.s.length() && this.singlematch(this.s.luaByte(soffset), poffset, ep);
            int pc = ep < this.p.length() ? this.p.luaByte(ep) : 0;
            switch(pc) {
            case 42:
               return this.max_expand(soffset, poffset, ep);
            case 43:
               return m ? this.max_expand(soffset + 1, poffset, ep) : -1;
            case 45:
               return this.min_expand(soffset, poffset, ep);
            case 63:
               int res;
               if (m && (res = this.match(soffset + 1, ep + 1)) != -1) {
                  return res;
               }

               poffset = ep + 1;
               break;
            default:
               if (!m) {
                  return -1;
               }

               ++soffset;
               poffset = ep;
            }
         }

         return soffset;
      }

      int max_expand(int soff, int poff, int ep) {
         int i;
         for(i = 0; soff + i < this.s.length() && this.singlematch(this.s.luaByte(soff + i), poff, ep); ++i) {
         }

         while(i >= 0) {
            int res = this.match(soff + i, ep + 1);
            if (res != -1) {
               return res;
            }

            --i;
         }

         return -1;
      }

      int min_expand(int soff, int poff, int ep) {
         while(true) {
            int res = this.match(soff, ep + 1);
            if (res != -1) {
               return res;
            }

            if (soff >= this.s.length() || !this.singlematch(this.s.luaByte(soff), poff, ep)) {
               return -1;
            }

            ++soff;
         }
      }

      int start_capture(int soff, int poff, int what) {
         int level = this.level;
         if (level >= 32) {
            LuaValue.error("too many captures");
         }

         this.cinit[level] = soff;
         this.clen[level] = what;
         this.level = level + 1;
         int res;
         if ((res = this.match(soff, poff)) == -1) {
            --this.level;
         }

         return res;
      }

      int end_capture(int soff, int poff) {
         int l = this.capture_to_close();
         this.clen[l] = soff - this.cinit[l];
         int res;
         if ((res = this.match(soff, poff)) == -1) {
            this.clen[l] = -1;
         }

         return res;
      }

      int match_capture(int soff, int l) {
         l = this.check_capture(l);
         int len = this.clen[l];
         return this.s.length() - soff >= len && LuaString.equals(this.s, this.cinit[l], this.s, soff, len) ? soff + len : -1;
      }

      int matchbalance(int soff, int poff) {
         int plen = this.p.length();
         if (poff == plen || poff + 1 == plen) {
            LuaValue.error("unbalanced pattern");
         }

         int slen = this.s.length();
         if (soff >= slen) {
            return -1;
         } else {
            int b = this.p.luaByte(poff);
            if (this.s.luaByte(soff) != b) {
               return -1;
            } else {
               int e = this.p.luaByte(poff + 1);
               int cont = 1;

               while(true) {
                  ++soff;
                  if (soff >= slen) {
                     return -1;
                  }

                  if (this.s.luaByte(soff) == e) {
                     --cont;
                     if (cont == 0) {
                        return soff + 1;
                     }
                  } else if (this.s.luaByte(soff) == b) {
                     ++cont;
                  }
               }
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static class GMatchAux extends VarArgFunction {
      private final int srclen;
      private final StringLib.MatchState ms;
      private int soffset;

      public GMatchAux(Varargs args, LuaString src, LuaString pat) {
         this.srclen = src.length();
         this.ms = new StringLib.MatchState(args, src, pat);
         this.soffset = 0;
      }

      public Varargs invoke(Varargs args) {
         while(this.soffset < this.srclen) {
            this.ms.reset();
            int res = this.ms.match(this.soffset, 0);
            if (res >= 0) {
               int soff = this.soffset;
               this.soffset = res;
               return this.ms.push_captures(true, soff, res);
            }

            ++this.soffset;
         }

         return NIL;
      }
   }

   @Environment(EnvType.CLIENT)
   static class FormatDesc {
      private boolean leftAdjust;
      private boolean zeroPad;
      private boolean explicitPlus;
      private boolean space;
      private boolean alternateForm;
      private static final int MAX_FLAGS = 5;
      private int width;
      private int precision;
      public final int conversion;
      public final int length;
      public final String src;

      public FormatDesc(Varargs args, LuaString strfrmt, int start) {
         int p = start;
         int n = strfrmt.length();
         int c = 0;
         boolean moreFlags = true;

         while(moreFlags) {
            switch(c = p < n ? strfrmt.luaByte(p++) : 0) {
            case 32:
               this.space = true;
               break;
            case 35:
               this.alternateForm = true;
               break;
            case 43:
               this.explicitPlus = true;
               break;
            case 45:
               this.leftAdjust = true;
               break;
            case 48:
               this.zeroPad = true;
               break;
            default:
               moreFlags = false;
            }
         }

         if (p - start > 5) {
            LuaValue.error("invalid format (repeated flags)");
         }

         this.width = -1;
         if (Character.isDigit((char)c)) {
            this.width = c - 48;
            c = p < n ? strfrmt.luaByte(p++) : 0;
            if (Character.isDigit((char)c)) {
               this.width = this.width * 10 + (c - 48);
               c = p < n ? strfrmt.luaByte(p++) : 0;
            }
         }

         this.precision = -1;
         if (c == 46) {
            c = p < n ? strfrmt.luaByte(p++) : 0;
            if (Character.isDigit((char)c)) {
               this.precision = c - 48;
               c = p < n ? strfrmt.luaByte(p++) : 0;
               if (Character.isDigit((char)c)) {
                  this.precision = this.precision * 10 + (c - 48);
                  c = p < n ? strfrmt.luaByte(p++) : 0;
               }
            }
         }

         if (Character.isDigit((char)c)) {
            LuaValue.error("invalid format (width or precision too long)");
         }

         this.zeroPad &= !this.leftAdjust;
         this.conversion = c;
         this.length = p - start;
         this.src = strfrmt.substring(start - 1, p).tojstring();
      }

      public void format(Buffer buf, byte c) {
         buf.append(c);
      }

      public void format(Buffer buf, long number) {
         String digits;
         if (number == 0L && this.precision == 0) {
            digits = "";
         } else {
            byte radix;
            switch(this.conversion) {
            case 88:
            case 120:
               radix = 16;
               break;
            case 111:
               radix = 8;
               break;
            default:
               radix = 10;
            }

            digits = Long.toString(number, radix);
            if (this.conversion == 88) {
               digits = digits.toUpperCase();
            }
         }

         int minwidth = digits.length();
         int ndigits = minwidth;
         if (number < 0L) {
            ndigits = minwidth - 1;
         } else if (this.explicitPlus || this.space) {
            ++minwidth;
         }

         int nzeros;
         if (this.precision > ndigits) {
            nzeros = this.precision - ndigits;
         } else if (this.precision == -1 && this.zeroPad && this.width > minwidth) {
            nzeros = this.width - minwidth;
         } else {
            nzeros = 0;
         }

         minwidth += nzeros;
         int nspaces = this.width > minwidth ? this.width - minwidth : 0;
         if (!this.leftAdjust) {
            pad(buf, ' ', nspaces);
         }

         if (number < 0L) {
            if (nzeros > 0) {
               buf.append((byte)45);
               digits = digits.substring(1);
            }
         } else if (this.explicitPlus) {
            buf.append((byte)43);
         } else if (this.space) {
            buf.append((byte)32);
         }

         if (nzeros > 0) {
            pad(buf, '0', nzeros);
         }

         buf.append(digits);
         if (this.leftAdjust) {
            pad(buf, ' ', nspaces);
         }

      }

      public void format(Buffer buf, double x) {
         String out;
         try {
            out = String.format(this.src, x);
         } catch (Throwable var6) {
            out = String.valueOf(x);
         }

         buf.append(out);
      }

      public void format(Buffer buf, LuaString s) {
         int nullindex = s.indexOf((byte)0, 0);
         if (nullindex != -1) {
            s = s.substring(0, nullindex);
         }

         buf.append(s);
      }

      public static final void pad(Buffer buf, char c, int n) {
         byte b = (byte)c;

         while(n-- > 0) {
            buf.append(b);
         }

      }
   }
}
