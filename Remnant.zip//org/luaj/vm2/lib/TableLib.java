package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public class TableLib extends TwoArgFunction {
   public LuaValue call(LuaValue modname, LuaValue env) {
      LuaTable table = new LuaTable();
      table.set("concat", new TableLib.concat());
      table.set("insert", new TableLib.insert());
      table.set("pack", new TableLib.pack());
      table.set("remove", new TableLib.remove());
      table.set("sort", new TableLib.sort());
      table.set("unpack", new TableLib.unpack());
      env.set((String)"table", (LuaValue)table);
      env.get("package").get("loaded").set((String)"table", (LuaValue)table);
      return NIL;
   }

   @Environment(EnvType.CLIENT)
   static class concat extends TableLib.TableLibFunction {
      public LuaValue call(LuaValue list) {
         return list.checktable().concat(EMPTYSTRING, 1, list.length());
      }

      public LuaValue call(LuaValue list, LuaValue sep) {
         return list.checktable().concat(sep.checkstring(), 1, list.length());
      }

      public LuaValue call(LuaValue list, LuaValue sep, LuaValue i) {
         return list.checktable().concat(sep.checkstring(), i.checkint(), list.length());
      }

      public LuaValue call(LuaValue list, LuaValue sep, LuaValue i, LuaValue j) {
         return list.checktable().concat(sep.checkstring(), i.checkint(), j.checkint());
      }
   }

   @Environment(EnvType.CLIENT)
   static class insert extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         switch(args.narg()) {
         case 0:
         case 1:
            return argerror(2, "value expected");
         case 2:
            LuaTable table = args.arg1().checktable();
            table.insert(table.length() + 1, args.arg(2));
            return NONE;
         default:
            args.arg1().checktable().insert(args.checkint(2), args.arg(3));
            return NONE;
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static class pack extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaValue t = tableOf(args, 1);
         t.set("n", args.narg());
         return t;
      }
   }

   @Environment(EnvType.CLIENT)
   static class remove extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         return args.arg1().checktable().remove(args.optint(2, 0));
      }
   }

   @Environment(EnvType.CLIENT)
   static class sort extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         args.arg1().checktable().sort((LuaValue)(args.arg(2).isnil() ? NIL : args.arg(2).checkfunction()));
         return NONE;
      }
   }

   @Environment(EnvType.CLIENT)
   static class unpack extends VarArgFunction {
      public Varargs invoke(Varargs args) {
         LuaTable t = args.checktable(1);
         switch(args.narg()) {
         case 1:
            return t.unpack();
         case 2:
            return t.unpack(args.checkint(2));
         default:
            return t.unpack(args.checkint(2), args.checkint(3));
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static class TableLibFunction extends LibFunction {
      public LuaValue call() {
         return argerror(1, "table expected, got no value");
      }
   }
}
