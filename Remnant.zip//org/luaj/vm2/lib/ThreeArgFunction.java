package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public abstract class ThreeArgFunction extends LibFunction {
   public abstract LuaValue call(LuaValue var1, LuaValue var2, LuaValue var3);

   public final LuaValue call() {
      return this.call(NIL, NIL, NIL);
   }

   public final LuaValue call(LuaValue arg) {
      return this.call(arg, NIL, NIL);
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2) {
      return this.call(arg1, arg2, NIL);
   }

   public Varargs invoke(Varargs varargs) {
      return this.call(varargs.arg1(), varargs.arg(2), varargs.arg(3));
   }
}
