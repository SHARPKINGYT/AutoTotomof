package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public abstract class VarArgFunction extends LibFunction {
   public LuaValue call() {
      return this.invoke(NONE).arg1();
   }

   public LuaValue call(LuaValue arg) {
      return this.invoke(arg).arg1();
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2) {
      return this.invoke(varargsOf(arg1, arg2)).arg1();
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
      return this.invoke(varargsOf(arg1, arg2, arg3)).arg1();
   }

   public Varargs invoke(Varargs args) {
      return this.onInvoke(args).eval();
   }

   public Varargs onInvoke(Varargs args) {
      return this.invoke(args);
   }
}
