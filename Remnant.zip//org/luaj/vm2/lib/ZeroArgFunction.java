package org.luaj.vm2.lib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
public abstract class ZeroArgFunction extends LibFunction {
   public abstract LuaValue call();

   public LuaValue call(LuaValue arg) {
      return this.call();
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2) {
      return this.call();
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
      return this.call();
   }

   public Varargs invoke(Varargs varargs) {
      return this.call();
   }
}
