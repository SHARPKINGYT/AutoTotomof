package org.luaj.vm2.lib.jse;

import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaDouble;
import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaValue;

@Environment(EnvType.CLIENT)
public class CoerceJavaToLua {
   static final Map COERCIONS = new HashMap();
   static final CoerceJavaToLua.Coercion instanceCoercion;
   static final CoerceJavaToLua.Coercion arrayCoercion;
   static final CoerceJavaToLua.Coercion luaCoercion;

   public static LuaValue coerce(Object o) {
      if (o == null) {
         return LuaValue.NIL;
      } else {
         Class clazz = o.getClass();
         CoerceJavaToLua.Coercion c = (CoerceJavaToLua.Coercion)COERCIONS.get(clazz);
         if (c == null) {
            c = clazz.isArray() ? arrayCoercion : (o instanceof LuaValue ? luaCoercion : instanceCoercion);
            COERCIONS.put(clazz, c);
         }

         return c.coerce(o);
      }
   }

   static {
      CoerceJavaToLua.Coercion boolCoercion = new CoerceJavaToLua.BoolCoercion();
      CoerceJavaToLua.Coercion intCoercion = new CoerceJavaToLua.IntCoercion();
      CoerceJavaToLua.Coercion charCoercion = new CoerceJavaToLua.CharCoercion();
      CoerceJavaToLua.Coercion doubleCoercion = new CoerceJavaToLua.DoubleCoercion();
      CoerceJavaToLua.Coercion stringCoercion = new CoerceJavaToLua.StringCoercion();
      CoerceJavaToLua.Coercion bytesCoercion = new CoerceJavaToLua.BytesCoercion();
      CoerceJavaToLua.Coercion classCoercion = new CoerceJavaToLua.ClassCoercion();
      COERCIONS.put(Boolean.class, boolCoercion);
      COERCIONS.put(Byte.class, intCoercion);
      COERCIONS.put(Character.class, charCoercion);
      COERCIONS.put(Short.class, intCoercion);
      COERCIONS.put(Integer.class, intCoercion);
      COERCIONS.put(Long.class, doubleCoercion);
      COERCIONS.put(Float.class, doubleCoercion);
      COERCIONS.put(Double.class, doubleCoercion);
      COERCIONS.put(String.class, stringCoercion);
      COERCIONS.put(byte[].class, bytesCoercion);
      COERCIONS.put(Class.class, classCoercion);
      instanceCoercion = new CoerceJavaToLua.InstanceCoercion();
      arrayCoercion = new CoerceJavaToLua.ArrayCoercion();
      luaCoercion = new CoerceJavaToLua.LuaCoercion();
   }

   @Environment(EnvType.CLIENT)
   interface Coercion {
      LuaValue coerce(Object var1);
   }

   @Environment(EnvType.CLIENT)
   private static final class BoolCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         Boolean b = (Boolean)javaValue;
         return b ? LuaValue.TRUE : LuaValue.FALSE;
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class IntCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         Number n = (Number)javaValue;
         return LuaInteger.valueOf(n.intValue());
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class CharCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         Character c = (Character)javaValue;
         return LuaInteger.valueOf(c);
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class DoubleCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         Number n = (Number)javaValue;
         return LuaDouble.valueOf(n.doubleValue());
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class StringCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         return LuaString.valueOf(javaValue.toString());
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class BytesCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         return LuaValue.valueOf((byte[])javaValue);
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class ClassCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         return JavaClass.forClass((Class)javaValue);
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class InstanceCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         return new JavaInstance(javaValue);
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class ArrayCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         return new JavaArray(javaValue);
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class LuaCoercion implements CoerceJavaToLua.Coercion {
      public LuaValue coerce(Object javaValue) {
         return (LuaValue)javaValue;
      }
   }
}
