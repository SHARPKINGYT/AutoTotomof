package org.luaj.vm2.lib.jse;

import java.lang.reflect.Array;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaValue;

@Environment(EnvType.CLIENT)
public class CoerceLuaToJava {
   static int SCORE_NULL_VALUE = 16;
   static int SCORE_WRONG_TYPE = 256;
   static int SCORE_UNCOERCIBLE = 65536;
   static final Map COERCIONS = Collections.synchronizedMap(new HashMap());

   public static Object coerce(LuaValue value, Class clazz) {
      return getCoercion(clazz).coerce(value);
   }

   static final int inheritanceLevels(Class baseclass, Class subclass) {
      if (subclass == null) {
         return SCORE_UNCOERCIBLE;
      } else if (baseclass == subclass) {
         return 0;
      } else {
         int min = Math.min(SCORE_UNCOERCIBLE, inheritanceLevels(baseclass, subclass.getSuperclass()) + 1);
         Class[] ifaces = subclass.getInterfaces();

         for(int i = 0; i < ifaces.length; ++i) {
            min = Math.min(min, inheritanceLevels(baseclass, ifaces[i]) + 1);
         }

         return min;
      }
   }

   static CoerceLuaToJava.Coercion getCoercion(Class c) {
      CoerceLuaToJava.Coercion co = (CoerceLuaToJava.Coercion)COERCIONS.get(c);
      if (co != null) {
         return co;
      } else {
         Object co;
         if (c.isArray()) {
            Class typ = c.getComponentType();
            co = new CoerceLuaToJava.ArrayCoercion(c.getComponentType());
         } else {
            co = new CoerceLuaToJava.ObjectCoercion(c);
         }

         COERCIONS.put(c, co);
         return (CoerceLuaToJava.Coercion)co;
      }
   }

   static {
      CoerceLuaToJava.Coercion boolCoercion = new CoerceLuaToJava.BoolCoercion();
      CoerceLuaToJava.Coercion byteCoercion = new CoerceLuaToJava.NumericCoercion(0);
      CoerceLuaToJava.Coercion charCoercion = new CoerceLuaToJava.NumericCoercion(1);
      CoerceLuaToJava.Coercion shortCoercion = new CoerceLuaToJava.NumericCoercion(2);
      CoerceLuaToJava.Coercion intCoercion = new CoerceLuaToJava.NumericCoercion(3);
      CoerceLuaToJava.Coercion longCoercion = new CoerceLuaToJava.NumericCoercion(4);
      CoerceLuaToJava.Coercion floatCoercion = new CoerceLuaToJava.NumericCoercion(5);
      CoerceLuaToJava.Coercion doubleCoercion = new CoerceLuaToJava.NumericCoercion(6);
      CoerceLuaToJava.Coercion stringCoercion = new CoerceLuaToJava.StringCoercion(0);
      CoerceLuaToJava.Coercion bytesCoercion = new CoerceLuaToJava.StringCoercion(1);
      COERCIONS.put(Boolean.TYPE, boolCoercion);
      COERCIONS.put(Boolean.class, boolCoercion);
      COERCIONS.put(Byte.TYPE, byteCoercion);
      COERCIONS.put(Byte.class, byteCoercion);
      COERCIONS.put(Character.TYPE, charCoercion);
      COERCIONS.put(Character.class, charCoercion);
      COERCIONS.put(Short.TYPE, shortCoercion);
      COERCIONS.put(Short.class, shortCoercion);
      COERCIONS.put(Integer.TYPE, intCoercion);
      COERCIONS.put(Integer.class, intCoercion);
      COERCIONS.put(Long.TYPE, longCoercion);
      COERCIONS.put(Long.class, longCoercion);
      COERCIONS.put(Float.TYPE, floatCoercion);
      COERCIONS.put(Float.class, floatCoercion);
      COERCIONS.put(Double.TYPE, doubleCoercion);
      COERCIONS.put(Double.class, doubleCoercion);
      COERCIONS.put(String.class, stringCoercion);
      COERCIONS.put(byte[].class, bytesCoercion);
   }

   @Environment(EnvType.CLIENT)
   interface Coercion {
      int score(LuaValue var1);

      Object coerce(LuaValue var1);
   }

   @Environment(EnvType.CLIENT)
   static final class ArrayCoercion implements CoerceLuaToJava.Coercion {
      final Class componentType;
      final CoerceLuaToJava.Coercion componentCoercion;

      public ArrayCoercion(Class componentType) {
         this.componentType = componentType;
         this.componentCoercion = CoerceLuaToJava.getCoercion(componentType);
      }

      public String toString() {
         return "ArrayCoercion(" + this.componentType.getName() + ")";
      }

      public int score(LuaValue value) {
         switch(value.type()) {
         case 0:
            return CoerceLuaToJava.SCORE_NULL_VALUE;
         case 5:
            return value.length() == 0 ? 0 : this.componentCoercion.score(value.get(1));
         case 7:
            return CoerceLuaToJava.inheritanceLevels(this.componentType, value.touserdata().getClass().getComponentType());
         default:
            return CoerceLuaToJava.SCORE_UNCOERCIBLE;
         }
      }

      public Object coerce(LuaValue value) {
         switch(value.type()) {
         case 0:
            return null;
         case 5:
            int n = value.length();
            Object a = Array.newInstance(this.componentType, n);

            for(int i = 0; i < n; ++i) {
               Array.set(a, i, this.componentCoercion.coerce(value.get(i + 1)));
            }

            return a;
         case 7:
            return value.touserdata();
         default:
            return null;
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class ObjectCoercion implements CoerceLuaToJava.Coercion {
      final Class targetType;

      ObjectCoercion(Class targetType) {
         this.targetType = targetType;
      }

      public String toString() {
         return "ObjectCoercion(" + this.targetType.getName() + ")";
      }

      public int score(LuaValue value) {
         switch(value.type()) {
         case 0:
            return CoerceLuaToJava.SCORE_NULL_VALUE;
         case 1:
            return CoerceLuaToJava.inheritanceLevels(this.targetType, Boolean.class);
         case 2:
         case 5:
         case 6:
         default:
            return CoerceLuaToJava.inheritanceLevels(this.targetType, value.getClass());
         case 3:
            return CoerceLuaToJava.inheritanceLevels(this.targetType, value.isint() ? Integer.class : Double.class);
         case 4:
            return CoerceLuaToJava.inheritanceLevels(this.targetType, String.class);
         case 7:
            return CoerceLuaToJava.inheritanceLevels(this.targetType, value.touserdata().getClass());
         }
      }

      public Object coerce(LuaValue value) {
         switch(value.type()) {
         case 0:
            return null;
         case 1:
            return value.toboolean() ? Boolean.TRUE : Boolean.FALSE;
         case 2:
         case 5:
         case 6:
         default:
            return value;
         case 3:
            return value.isint() ? new Integer(value.toint()) : new Double(value.todouble());
         case 4:
            return value.tojstring();
         case 7:
            return value.optuserdata(this.targetType, (Object)null);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class BoolCoercion implements CoerceLuaToJava.Coercion {
      public String toString() {
         return "BoolCoercion()";
      }

      public int score(LuaValue value) {
         switch(value.type()) {
         case 1:
            return 0;
         default:
            return 1;
         }
      }

      public Object coerce(LuaValue value) {
         return value.toboolean() ? Boolean.TRUE : Boolean.FALSE;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class NumericCoercion implements CoerceLuaToJava.Coercion {
      static final int TARGET_TYPE_BYTE = 0;
      static final int TARGET_TYPE_CHAR = 1;
      static final int TARGET_TYPE_SHORT = 2;
      static final int TARGET_TYPE_INT = 3;
      static final int TARGET_TYPE_LONG = 4;
      static final int TARGET_TYPE_FLOAT = 5;
      static final int TARGET_TYPE_DOUBLE = 6;
      static final String[] TYPE_NAMES = new String[]{"byte", "char", "short", "int", "long", "float", "double"};
      final int targetType;

      public String toString() {
         String var10000 = TYPE_NAMES[this.targetType];
         return "NumericCoercion(" + var10000 + ")";
      }

      NumericCoercion(int targetType) {
         this.targetType = targetType;
      }

      public int score(LuaValue value) {
         int fromStringPenalty = 0;
         if (value.type() == 4) {
            value = value.tonumber();
            if (value.isnil()) {
               return CoerceLuaToJava.SCORE_UNCOERCIBLE;
            }

            fromStringPenalty = 4;
         }

         if (value.isint()) {
            int i;
            switch(this.targetType) {
            case 0:
               i = value.toint();
               return fromStringPenalty + (i == (byte)i ? 0 : CoerceLuaToJava.SCORE_WRONG_TYPE);
            case 1:
               i = value.toint();
               return fromStringPenalty + (i == (byte)i ? 1 : (i == (char)i ? 0 : CoerceLuaToJava.SCORE_WRONG_TYPE));
            case 2:
               i = value.toint();
               return fromStringPenalty + (i == (byte)i ? 1 : (i == (short)i ? 0 : CoerceLuaToJava.SCORE_WRONG_TYPE));
            case 3:
               i = value.toint();
               return fromStringPenalty + (i == (byte)i ? 2 : (i != (char)i && i != (short)i ? 0 : 1));
            case 4:
               return fromStringPenalty + 1;
            case 5:
               return fromStringPenalty + 1;
            case 6:
               return fromStringPenalty + 2;
            default:
               return CoerceLuaToJava.SCORE_WRONG_TYPE;
            }
         } else if (value.isnumber()) {
            double d;
            switch(this.targetType) {
            case 0:
               return CoerceLuaToJava.SCORE_WRONG_TYPE;
            case 1:
               return CoerceLuaToJava.SCORE_WRONG_TYPE;
            case 2:
               return CoerceLuaToJava.SCORE_WRONG_TYPE;
            case 3:
               return CoerceLuaToJava.SCORE_WRONG_TYPE;
            case 4:
               d = value.todouble();
               return fromStringPenalty + (d == (double)((long)d) ? 0 : CoerceLuaToJava.SCORE_WRONG_TYPE);
            case 5:
               d = value.todouble();
               return fromStringPenalty + (d == (double)((float)d) ? 0 : CoerceLuaToJava.SCORE_WRONG_TYPE);
            case 6:
               d = value.todouble();
               return fromStringPenalty + (d != (double)((long)d) && d != (double)((float)d) ? 0 : 1);
            default:
               return CoerceLuaToJava.SCORE_WRONG_TYPE;
            }
         } else {
            return CoerceLuaToJava.SCORE_UNCOERCIBLE;
         }
      }

      public Object coerce(LuaValue value) {
         switch(this.targetType) {
         case 0:
            return new Byte((byte)value.toint());
         case 1:
            return new Character((char)value.toint());
         case 2:
            return new Short((short)value.toint());
         case 3:
            return new Integer(value.toint());
         case 4:
            return new Long((long)value.todouble());
         case 5:
            return new Float((float)value.todouble());
         case 6:
            return new Double(value.todouble());
         default:
            return null;
         }
      }
   }

   @Environment(EnvType.CLIENT)
   static final class StringCoercion implements CoerceLuaToJava.Coercion {
      public static final int TARGET_TYPE_STRING = 0;
      public static final int TARGET_TYPE_BYTES = 1;
      final int targetType;

      public StringCoercion(int targetType) {
         this.targetType = targetType;
      }

      public String toString() {
         return "StringCoercion(" + (this.targetType == 0 ? "String" : "byte[]") + ")";
      }

      public int score(LuaValue value) {
         switch(value.type()) {
         case 0:
            return CoerceLuaToJava.SCORE_NULL_VALUE;
         case 4:
            return value.checkstring().isValidUtf8() ? (this.targetType == 0 ? 0 : 1) : (this.targetType == 1 ? 0 : CoerceLuaToJava.SCORE_WRONG_TYPE);
         default:
            return this.targetType == 0 ? CoerceLuaToJava.SCORE_WRONG_TYPE : CoerceLuaToJava.SCORE_UNCOERCIBLE;
         }
      }

      public Object coerce(LuaValue value) {
         if (value.isnil()) {
            return null;
         } else if (this.targetType == 0) {
            return value.tojstring();
         } else {
            LuaString s = value.checkstring();
            byte[] b = new byte[s.m_length];
            s.copyInto(0, b, 0, b.length);
            return b;
         }
      }
   }
}
