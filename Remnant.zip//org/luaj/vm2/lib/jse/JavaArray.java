package org.luaj.vm2.lib.jse;

import java.lang.reflect.Array;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaUserdata;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.OneArgFunction;

@Environment(EnvType.CLIENT)
class JavaArray extends LuaUserdata {
   static final LuaValue LENGTH = valueOf("length");
   static final LuaTable array_metatable = new LuaTable();

   JavaArray(Object instance) {
      super(instance);
      this.setmetatable(array_metatable);
   }

   public LuaValue get(LuaValue key) {
      if (key.equals(LENGTH)) {
         return valueOf(Array.getLength(this.m_instance));
      } else if (!key.isint()) {
         return super.get(key);
      } else {
         int i = key.toint() - 1;
         return i >= 0 && i < Array.getLength(this.m_instance) ? CoerceJavaToLua.coerce(Array.get(this.m_instance, key.toint() - 1)) : NIL;
      }
   }

   public void set(LuaValue key, LuaValue value) {
      if (key.isint()) {
         int i = key.toint() - 1;
         if (i >= 0 && i < Array.getLength(this.m_instance)) {
            Array.set(this.m_instance, i, CoerceLuaToJava.coerce(value, this.m_instance.getClass().getComponentType()));
         } else if (this.m_metatable == null || !settable(this, key, value)) {
            error("array index out of bounds");
         }
      } else {
         super.set(key, value);
      }

   }

   static {
      array_metatable.rawset(LuaValue.LEN, new JavaArray.LenFunction());
   }

   @Environment(EnvType.CLIENT)
   private static final class LenFunction extends OneArgFunction {
      public LuaValue call(LuaValue u) {
         return LuaValue.valueOf(Array.getLength(((LuaUserdata)u).m_instance));
      }
   }
}
