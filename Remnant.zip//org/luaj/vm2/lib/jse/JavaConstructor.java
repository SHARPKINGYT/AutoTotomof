package org.luaj.vm2.lib.jse;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;

@Environment(EnvType.CLIENT)
class JavaConstructor extends JavaMember {
   static final Map constructors = Collections.synchronizedMap(new HashMap());
   final Constructor constructor;

   static JavaConstructor forConstructor(Constructor c) {
      JavaConstructor j = (JavaConstructor)constructors.get(c);
      if (j == null) {
         constructors.put(c, j = new JavaConstructor(c));
      }

      return j;
   }

   public static LuaValue forConstructors(JavaConstructor[] array) {
      return new JavaConstructor.Overload(array);
   }

   private JavaConstructor(Constructor c) {
      super(c.getParameterTypes(), c.getModifiers());
      this.constructor = c;
   }

   public Varargs invoke(Varargs args) {
      Object[] a = this.convertArgs(args);

      try {
         return CoerceJavaToLua.coerce(this.constructor.newInstance(a));
      } catch (InvocationTargetException var4) {
         throw new LuaError(var4.getTargetException());
      } catch (Exception var5) {
         return LuaValue.error("coercion error " + String.valueOf(var5));
      }
   }

   @Environment(EnvType.CLIENT)
   static class Overload extends VarArgFunction {
      final JavaConstructor[] constructors;

      public Overload(JavaConstructor[] c) {
         this.constructors = c;
      }

      public Varargs invoke(Varargs args) {
         JavaConstructor best = null;
         int score = CoerceLuaToJava.SCORE_UNCOERCIBLE;

         for(int i = 0; i < this.constructors.length; ++i) {
            int s = this.constructors[i].score(args);
            if (s < score) {
               score = s;
               best = this.constructors[i];
               if (s == 0) {
                  break;
               }
            }
         }

         if (best == null) {
            LuaValue.error("no coercible public method");
         }

         return best.invoke(args);
      }
   }
}
