package org.luaj.vm2.lib.jse;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaUserdata;
import org.luaj.vm2.LuaValue;

@Environment(EnvType.CLIENT)
class JavaInstance extends LuaUserdata {
   JavaClass jclass;

   JavaInstance(Object instance) {
      super(instance);
   }

   public LuaValue get(LuaValue key) {
      if (this.jclass == null) {
         this.jclass = JavaClass.forClass(this.m_instance.getClass());
      }

      Field f = this.jclass.getField(key);
      if (f != null) {
         try {
            return CoerceJavaToLua.coerce(f.get(Modifier.isStatic(f.getModifiers()) ? null : this.m_instance));
         } catch (Exception var5) {
            throw new LuaError(var5);
         }
      } else {
         LuaValue m = this.jclass.getMethod(key);
         if (m != null) {
            return m;
         } else {
            Class c = this.jclass.getInnerClass(key);
            return (LuaValue)(c != null ? JavaClass.forClass(c) : super.get(key));
         }
      }
   }

   public void set(LuaValue key, LuaValue value) {
      if (this.jclass == null) {
         this.jclass = JavaClass.forClass(this.m_instance.getClass());
      }

      Field f = this.jclass.getField(key);
      if (f != null) {
         try {
            f.set(Modifier.isStatic(f.getModifiers()) ? null : this.m_instance, CoerceLuaToJava.coerce(value, f.getType()));
         } catch (Exception var5) {
            throw new LuaError(var5);
         }
      } else {
         super.set(key, value);
      }
   }
}
