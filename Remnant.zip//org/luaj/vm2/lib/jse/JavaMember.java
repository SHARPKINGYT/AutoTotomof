package org.luaj.vm2.lib.jse;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;

@Environment(EnvType.CLIENT)
abstract class JavaMember extends VarArgFunction {
   static final int METHOD_MODIFIERS_VARARGS = 128;
   final CoerceLuaToJava.Coercion[] fixedargs;
   final CoerceLuaToJava.Coercion varargs;

   protected JavaMember(Class[] params, int modifiers) {
      boolean isvarargs = (modifiers & 128) != 0;
      this.fixedargs = new CoerceLuaToJava.Coercion[isvarargs ? params.length - 1 : params.length];

      for(int i = 0; i < this.fixedargs.length; ++i) {
         this.fixedargs[i] = CoerceLuaToJava.getCoercion(params[i]);
      }

      this.varargs = isvarargs ? CoerceLuaToJava.getCoercion(params[params.length - 1]) : null;
   }

   int score(Varargs args) {
      int n = args.narg();
      int s = n > this.fixedargs.length ? CoerceLuaToJava.SCORE_WRONG_TYPE * (n - this.fixedargs.length) : 0;

      int k;
      for(k = 0; k < this.fixedargs.length; ++k) {
         s += this.fixedargs[k].score(args.arg(k + 1));
      }

      if (this.varargs != null) {
         for(k = this.fixedargs.length; k < n; ++k) {
            s += this.varargs.score(args.arg(k + 1));
         }
      }

      return s;
   }

   protected Object[] convertArgs(Varargs args) {
      Object[] a;
      int n;
      if (this.varargs == null) {
         a = new Object[this.fixedargs.length];

         for(n = 0; n < a.length; ++n) {
            a[n] = this.fixedargs[n].coerce(args.arg(n + 1));
         }
      } else {
         n = Math.max(this.fixedargs.length, args.narg());
         a = new Object[n];

         int i;
         for(i = 0; i < this.fixedargs.length; ++i) {
            a[i] = this.fixedargs[i].coerce(args.arg(i + 1));
         }

         for(i = this.fixedargs.length; i < n; ++i) {
            a[i] = this.varargs.coerce(args.arg(i + 1));
         }
      }

      return a;
   }
}
