package org.luaj.vm2.lib.jse;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

@Environment(EnvType.CLIENT)
class JavaMethod extends JavaMember {
   static final Map methods = Collections.synchronizedMap(new HashMap());
   final Method method;

   static JavaMethod forMethod(Method m) {
      JavaMethod j = (JavaMethod)methods.get(m);
      if (j == null) {
         methods.put(m, j = new JavaMethod(m));
      }

      return j;
   }

   static LuaFunction forMethods(JavaMethod[] m) {
      return new JavaMethod.Overload(m);
   }

   private JavaMethod(Method m) {
      super(m.getParameterTypes(), m.getModifiers());
      this.method = m;

      try {
         if (!m.isAccessible()) {
            m.setAccessible(true);
         }
      } catch (SecurityException var3) {
      }

   }

   public LuaValue call() {
      return error("method cannot be called without instance");
   }

   public LuaValue call(LuaValue arg) {
      return this.invokeMethod(arg.checkuserdata(), LuaValue.NONE);
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2) {
      return this.invokeMethod(arg1.checkuserdata(), arg2);
   }

   public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
      return this.invokeMethod(arg1.checkuserdata(), LuaValue.varargsOf((LuaValue)arg2, arg3));
   }

   public Varargs invoke(Varargs args) {
      return this.invokeMethod(args.checkuserdata(1), args.subargs(2));
   }

   LuaValue invokeMethod(Object instance, Varargs args) {
      Object[] a = this.convertArgs(args);

      try {
         return CoerceJavaToLua.coerce(this.method.invoke(instance, a));
      } catch (InvocationTargetException var5) {
         throw new LuaError(var5.getTargetException());
      } catch (Exception var6) {
         return LuaValue.error("coercion error " + String.valueOf(var6));
      }
   }

   @Environment(EnvType.CLIENT)
   static class Overload extends LuaFunction {
      final JavaMethod[] methods;

      Overload(JavaMethod[] methods) {
         this.methods = methods;
      }

      public LuaValue call() {
         return error("method cannot be called without instance");
      }

      public LuaValue call(LuaValue arg) {
         return this.invokeBestMethod(arg.checkuserdata(), LuaValue.NONE);
      }

      public LuaValue call(LuaValue arg1, LuaValue arg2) {
         return this.invokeBestMethod(arg1.checkuserdata(), arg2);
      }

      public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
         return this.invokeBestMethod(arg1.checkuserdata(), LuaValue.varargsOf((LuaValue)arg2, arg3));
      }

      public Varargs invoke(Varargs args) {
         return this.invokeBestMethod(args.checkuserdata(1), args.subargs(2));
      }

      private LuaValue invokeBestMethod(Object instance, Varargs args) {
         JavaMethod best = null;
         int score = CoerceLuaToJava.SCORE_UNCOERCIBLE;

         for(int i = 0; i < this.methods.length; ++i) {
            int s = this.methods[i].score(args);
            if (s < score) {
               score = s;
               best = this.methods[i];
               if (s == 0) {
                  break;
               }
            }
         }

         if (best == null) {
            LuaValue.error("no coercible public method");
         }

         return best.invokeMethod(instance, args);
      }
   }
}
