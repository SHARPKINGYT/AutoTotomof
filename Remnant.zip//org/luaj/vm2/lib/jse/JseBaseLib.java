package org.luaj.vm2.lib.jse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.BaseLib;

@Environment(EnvType.CLIENT)
public class JseBaseLib extends BaseLib {
   public LuaValue call(LuaValue modname, LuaValue env) {
      super.call(modname, env);
      env.checkglobals().STDIN = System.in;
      return env;
   }

   public InputStream findResource(String filename) {
      File f = new File(filename);
      if (!f.exists()) {
         return super.findResource(filename);
      } else {
         try {
            return new FileInputStream(f);
         } catch (IOException var4) {
            return null;
         }
      }
   }
}
