package org.luaj.vm2.lib.jse;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.lib.IoLib;

@Environment(EnvType.CLIENT)
public class JseIoLib extends IoLib {
   protected IoLib.File wrapStdin() throws IOException {
      return new JseIoLib.StdinFile();
   }

   protected IoLib.File wrapStdout() throws IOException {
      return new JseIoLib.StdoutFile(1);
   }

   protected IoLib.File wrapStderr() throws IOException {
      return new JseIoLib.StdoutFile(2);
   }

   protected IoLib.File openFile(String filename, boolean readMode, boolean appendMode, boolean updateMode, boolean binaryMode) throws IOException {
      RandomAccessFile f = new RandomAccessFile(filename, readMode ? "r" : "rw");
      if (appendMode) {
         f.seek(f.length());
      } else if (!readMode) {
         f.setLength(0L);
      }

      return new JseIoLib.FileImpl(this, f);
   }

   protected IoLib.File openProgram(String prog, String mode) throws IOException {
      Process p = Runtime.getRuntime().exec(prog);
      return "w".equals(mode) ? new JseIoLib.FileImpl(this, p.getOutputStream()) : new JseIoLib.FileImpl(this, p.getInputStream());
   }

   protected IoLib.File tmpFile() throws IOException {
      java.io.File f = java.io.File.createTempFile(".luaj", "bin");
      f.deleteOnExit();
      return new JseIoLib.FileImpl(this, new RandomAccessFile(f, "rw"));
   }

   private static void notimplemented() {
      throw new LuaError("not implemented");
   }

   @Environment(EnvType.CLIENT)
   private final class StdinFile extends IoLib.File {
      private StdinFile() {
         super();
      }

      public String tojstring() {
         return "file (" + this.hashCode() + ")";
      }

      public void write(LuaString string) throws IOException {
      }

      public void flush() throws IOException {
      }

      public boolean isstdfile() {
         return true;
      }

      public void close() throws IOException {
      }

      public boolean isclosed() {
         return false;
      }

      public int seek(String option, int bytecount) throws IOException {
         return 0;
      }

      public void setvbuf(String mode, int size) {
      }

      public int remaining() throws IOException {
         return 0;
      }

      public int peek() throws IOException, EOFException {
         JseIoLib.this.globals.STDIN.mark(1);
         int c = JseIoLib.this.globals.STDIN.read();
         JseIoLib.this.globals.STDIN.reset();
         return c;
      }

      public int read() throws IOException, EOFException {
         return JseIoLib.this.globals.STDIN.read();
      }

      public int read(byte[] bytes, int offset, int length) throws IOException {
         return JseIoLib.this.globals.STDIN.read(bytes, offset, length);
      }
   }

   @Environment(EnvType.CLIENT)
   private final class StdoutFile extends IoLib.File {
      private final int file_type;

      private StdoutFile(int file_type) {
         super();
         this.file_type = file_type;
      }

      public String tojstring() {
         return "file (" + this.hashCode() + ")";
      }

      private final PrintStream getPrintStream() {
         return this.file_type == 2 ? JseIoLib.this.globals.STDERR : JseIoLib.this.globals.STDOUT;
      }

      public void write(LuaString string) throws IOException {
         this.getPrintStream().write(string.m_bytes, string.m_offset, string.m_length);
      }

      public void flush() throws IOException {
         this.getPrintStream().flush();
      }

      public boolean isstdfile() {
         return true;
      }

      public void close() throws IOException {
      }

      public boolean isclosed() {
         return false;
      }

      public int seek(String option, int bytecount) throws IOException {
         return 0;
      }

      public void setvbuf(String mode, int size) {
      }

      public int remaining() throws IOException {
         return 0;
      }

      public int peek() throws IOException, EOFException {
         return 0;
      }

      public int read() throws IOException, EOFException {
         return 0;
      }

      public int read(byte[] bytes, int offset, int length) throws IOException {
         return 0;
      }
   }

   @Environment(EnvType.CLIENT)
   private final class FileImpl extends IoLib.File {
      private final RandomAccessFile file;
      private final InputStream is;
      private final OutputStream os;
      private boolean closed;
      private boolean nobuffer;

      private FileImpl(final JseIoLib param1, RandomAccessFile file, InputStream is, OutputStream os) {
         super();
         this.closed = false;
         this.nobuffer = false;
         this.file = file;
         this.is = (InputStream)(is != null ? (is.markSupported() ? is : new BufferedInputStream(is)) : null);
         this.os = os;
      }

      private FileImpl(final JseIoLib param1, RandomAccessFile f) {
         this(var1, f, (InputStream)null, (OutputStream)null);
      }

      private FileImpl(final JseIoLib param1, InputStream i) {
         this(var1, (RandomAccessFile)null, i, (OutputStream)null);
      }

      private FileImpl(final JseIoLib param1, OutputStream o) {
         this(var1, (RandomAccessFile)null, (InputStream)null, o);
      }

      public String tojstring() {
         return "file (" + this.hashCode() + ")";
      }

      public boolean isstdfile() {
         return this.file == null;
      }

      public void close() throws IOException {
         this.closed = true;
         if (this.file != null) {
            this.file.close();
         }

      }

      public void flush() throws IOException {
         if (this.os != null) {
            this.os.flush();
         }

      }

      public void write(LuaString s) throws IOException {
         if (this.os != null) {
            this.os.write(s.m_bytes, s.m_offset, s.m_length);
         } else if (this.file != null) {
            this.file.write(s.m_bytes, s.m_offset, s.m_length);
         } else {
            JseIoLib.notimplemented();
         }

         if (this.nobuffer) {
            this.flush();
         }

      }

      public boolean isclosed() {
         return this.closed;
      }

      public int seek(String option, int pos) throws IOException {
         if (this.file != null) {
            if ("set".equals(option)) {
               this.file.seek((long)pos);
            } else if ("end".equals(option)) {
               this.file.seek(this.file.length() + (long)pos);
            } else {
               this.file.seek(this.file.getFilePointer() + (long)pos);
            }

            return (int)this.file.getFilePointer();
         } else {
            JseIoLib.notimplemented();
            return 0;
         }
      }

      public void setvbuf(String mode, int size) {
         this.nobuffer = "no".equals(mode);
      }

      public int remaining() throws IOException {
         return this.file != null ? (int)(this.file.length() - this.file.getFilePointer()) : -1;
      }

      public int peek() throws IOException {
         if (this.is != null) {
            this.is.mark(1);
            int cx = this.is.read();
            this.is.reset();
            return cx;
         } else if (this.file != null) {
            long fp = this.file.getFilePointer();
            int c = this.file.read();
            this.file.seek(fp);
            return c;
         } else {
            JseIoLib.notimplemented();
            return 0;
         }
      }

      public int read() throws IOException {
         if (this.is != null) {
            return this.is.read();
         } else if (this.file != null) {
            return this.file.read();
         } else {
            JseIoLib.notimplemented();
            return 0;
         }
      }

      public int read(byte[] bytes, int offset, int length) throws IOException {
         if (this.file != null) {
            return this.file.read(bytes, offset, length);
         } else if (this.is != null) {
            return this.is.read(bytes, offset, length);
         } else {
            JseIoLib.notimplemented();
            return length;
         }
      }
   }
}
