package org.luaj.vm2.lib.jse;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.MathLib;

@Environment(EnvType.CLIENT)
public class JseMathLib extends MathLib {
   public LuaValue call(LuaValue modname, LuaValue env) {
      super.call(modname, env);
      LuaValue math = env.get("math");
      math.set((String)"acos", (LuaValue)(new JseMathLib.acos()));
      math.set((String)"asin", (LuaValue)(new JseMathLib.asin()));
      math.set((String)"atan", (LuaValue)(new JseMathLib.atan()));
      math.set((String)"atan2", (LuaValue)(new JseMathLib.atan2()));
      math.set((String)"cosh", (LuaValue)(new JseMathLib.cosh()));
      math.set((String)"exp", (LuaValue)(new JseMathLib.exp()));
      math.set((String)"log", (LuaValue)(new JseMathLib.log()));
      math.set((String)"pow", (LuaValue)(new JseMathLib.pow()));
      math.set((String)"sinh", (LuaValue)(new JseMathLib.sinh()));
      math.set((String)"tanh", (LuaValue)(new JseMathLib.tanh()));
      return math;
   }

   public double dpow_lib(double a, double b) {
      return Math.pow(a, b);
   }

   @Environment(EnvType.CLIENT)
   static final class acos extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.acos(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class asin extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.asin(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class atan extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.atan(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class atan2 extends MathLib.BinaryOp {
      protected double call(double y, double x) {
         return Math.atan2(y, x);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class cosh extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.cosh(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class exp extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.exp(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class log extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.log(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class pow extends MathLib.BinaryOp {
      protected double call(double x, double y) {
         return Math.pow(x, y);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class sinh extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.sinh(d);
      }
   }

   @Environment(EnvType.CLIENT)
   static final class tanh extends MathLib.UnaryOp {
      protected double call(double d) {
         return Math.tanh(d);
      }
   }
}
