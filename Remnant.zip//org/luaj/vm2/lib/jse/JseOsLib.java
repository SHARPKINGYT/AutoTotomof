package org.luaj.vm2.lib.jse;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.OsLib;

@Environment(EnvType.CLIENT)
public class JseOsLib extends OsLib {
   public static int EXEC_IOEXCEPTION = 1;
   public static int EXEC_INTERRUPTED = -2;
   public static int EXEC_ERROR = -3;

   protected String getenv(String varname) {
      String s = System.getenv(varname);
      return s != null ? s : System.getProperty(varname);
   }

   protected Varargs execute(String command) {
      int exitValue;
      try {
         exitValue = (new JseProcess(command, (InputStream)null, this.globals.STDOUT, this.globals.STDERR)).waitFor();
      } catch (IOException var4) {
         exitValue = EXEC_IOEXCEPTION;
      } catch (InterruptedException var5) {
         exitValue = EXEC_INTERRUPTED;
      } catch (Throwable var6) {
         exitValue = EXEC_ERROR;
      }

      return exitValue == 0 ? varargsOf(TRUE, valueOf("exit"), ZERO) : varargsOf(NIL, valueOf("signal"), valueOf(exitValue));
   }

   protected void remove(String filename) throws IOException {
      File f = new File(filename);
      if (!f.exists()) {
         throw new IOException("No such file or directory");
      } else if (!f.delete()) {
         throw new IOException("Failed to delete");
      }
   }

   protected void rename(String oldname, String newname) throws IOException {
      File f = new File(oldname);
      if (!f.exists()) {
         throw new IOException("No such file or directory");
      } else if (!f.renameTo(new File(newname))) {
         throw new IOException("Failed to delete");
      }
   }

   protected String tmpname() {
      try {
         File f = File.createTempFile(TMP_PREFIX, TMP_SUFFIX);
         return f.getName();
      } catch (IOException var2) {
         return super.tmpname();
      }
   }
}
