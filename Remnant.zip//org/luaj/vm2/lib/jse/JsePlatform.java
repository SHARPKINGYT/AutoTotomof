package org.luaj.vm2.lib.jse;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LoadState;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.compiler.LuaC;
import org.luaj.vm2.lib.Bit32Lib;
import org.luaj.vm2.lib.CoroutineLib;
import org.luaj.vm2.lib.DebugLib;
import org.luaj.vm2.lib.PackageLib;
import org.luaj.vm2.lib.StringLib;
import org.luaj.vm2.lib.TableLib;

@Environment(EnvType.CLIENT)
public class JsePlatform {
   public static Globals standardGlobals() {
      Globals globals = new Globals();
      globals.load(new JseBaseLib());
      globals.load(new PackageLib());
      globals.load(new Bit32Lib());
      globals.load(new TableLib());
      globals.load(new StringLib());
      globals.load(new CoroutineLib());
      globals.load(new JseMathLib());
      globals.load(new JseIoLib());
      globals.load(new JseOsLib());
      globals.load(new LuajavaLib());
      LoadState.install(globals);
      LuaC.install(globals);
      return globals;
   }

   public static Globals debugGlobals() {
      Globals globals = standardGlobals();
      globals.load(new DebugLib());
      return globals;
   }

   public static void luaMain(LuaValue mainChunk, String[] args) {
      Globals g = standardGlobals();
      int n = args.length;
      LuaValue[] vargs = new LuaValue[args.length];

      for(int i = 0; i < n; ++i) {
         vargs[i] = LuaValue.valueOf(args[i]);
      }

      LuaValue arg = LuaValue.listOf(vargs);
      arg.set("n", n);
      g.set("arg", arg);
      mainChunk.initupvalue1(g);
      mainChunk.invoke(LuaValue.varargsOf(vargs));
   }
}
