package org.luaj.vm2.lib.jse;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class JseProcess {
   final Process process;
   final Thread input;
   final Thread output;
   final Thread error;

   public JseProcess(String[] cmd, InputStream stdin, OutputStream stdout, OutputStream stderr) throws IOException {
      this(Runtime.getRuntime().exec(cmd), stdin, stdout, stderr);
   }

   public JseProcess(String cmd, InputStream stdin, OutputStream stdout, OutputStream stderr) throws IOException {
      this(Runtime.getRuntime().exec(cmd), stdin, stdout, stderr);
   }

   private JseProcess(Process process, InputStream stdin, OutputStream stdout, OutputStream stderr) {
      this.process = process;
      this.input = stdin == null ? null : this.copyBytes(stdin, process.getOutputStream(), (InputStream)null, process.getOutputStream());
      this.output = stdout == null ? null : this.copyBytes(process.getInputStream(), stdout, process.getInputStream(), (OutputStream)null);
      this.error = stderr == null ? null : this.copyBytes(process.getErrorStream(), stderr, process.getErrorStream(), (OutputStream)null);
   }

   public int exitValue() {
      return this.process.exitValue();
   }

   public int waitFor() throws InterruptedException {
      int r = this.process.waitFor();
      if (this.input != null) {
         this.input.join();
      }

      if (this.output != null) {
         this.output.join();
      }

      if (this.error != null) {
         this.error.join();
      }

      this.process.destroy();
      return r;
   }

   private Thread copyBytes(InputStream input, OutputStream output, InputStream ownedInput, OutputStream ownedOutput) {
      Thread t = new JseProcess.CopyThread(output, ownedOutput, ownedInput, input);
      t.start();
      return t;
   }

   @Environment(EnvType.CLIENT)
   private static final class CopyThread extends Thread {
      private final OutputStream output;
      private final OutputStream ownedOutput;
      private final InputStream ownedInput;
      private final InputStream input;

      private CopyThread(OutputStream output, OutputStream ownedOutput, InputStream ownedInput, InputStream input) {
         this.output = output;
         this.ownedOutput = ownedOutput;
         this.ownedInput = ownedInput;
         this.input = input;
      }

      public void run() {
         try {
            byte[] buf = new byte[1024];

            int r;
            try {
               while((r = this.input.read(buf)) >= 0) {
                  this.output.write(buf, 0, r);
               }
            } finally {
               if (this.ownedInput != null) {
                  this.ownedInput.close();
               }

               if (this.ownedOutput != null) {
                  this.ownedOutput.close();
               }

            }
         } catch (IOException var7) {
            var7.printStackTrace();
         }

      }
   }
}
