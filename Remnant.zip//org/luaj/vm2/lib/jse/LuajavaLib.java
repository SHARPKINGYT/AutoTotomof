package org.luaj.vm2.lib.jse;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;

@Environment(EnvType.CLIENT)
public class LuajavaLib extends VarArgFunction {
   static final int INIT = 0;
   static final int BINDCLASS = 1;
   static final int NEWINSTANCE = 2;
   static final int NEW = 3;
   static final int CREATEPROXY = 4;
   static final int LOADLIB = 5;
   static final String[] NAMES = new String[]{"bindClass", "newInstance", "new", "createProxy", "loadLib"};
   static final int METHOD_MODIFIERS_VARARGS = 128;

   public Varargs invoke(Varargs args) {
      try {
         Object proxy;
         LuaValue env;
         LuaTable lobj;
         switch(this.opcode) {
         case 0:
            env = args.arg(2);
            lobj = new LuaTable();
            this.bind(lobj, this.getClass(), NAMES, 1);
            env.set((String)"luajava", (LuaValue)lobj);
            if (!env.get("package").isnil()) {
               env.get("package").get("loaded").set((String)"luajava", (LuaValue)lobj);
            }

            return lobj;
         case 1:
            Class clazz = this.classForName(args.checkjstring(1));
            return JavaClass.forClass(clazz);
         case 2:
         case 3:
            env = args.checkvalue(1);
            Class clazz = this.opcode == 2 ? this.classForName(env.tojstring()) : (Class)env.checkuserdata(Class.class);
            Varargs consargs = args.subargs(2);
            return JavaClass.forClass(clazz).getConstructor().invoke(consargs);
         case 4:
            int niface = args.narg() - 1;
            if (niface <= 0) {
               throw new LuaError("no interfaces");
            }

            lobj = args.checktable(niface + 1);
            Class[] ifaces = new Class[niface];

            for(int i = 0; i < niface; ++i) {
               ifaces[i] = this.classForName(args.checkjstring(i + 1));
            }

            InvocationHandler handler = new LuajavaLib.ProxyInvocationHandler(lobj);
            proxy = Proxy.newProxyInstance(this.getClass().getClassLoader(), ifaces, handler);
            return LuaValue.userdataOf(proxy);
         case 5:
            String classname = args.checkjstring(1);
            String methodname = args.checkjstring(2);
            Class clazz = this.classForName(classname);
            Method method = clazz.getMethod(methodname);
            proxy = method.invoke(clazz);
            if (proxy instanceof LuaValue) {
               return (LuaValue)proxy;
            }

            return NIL;
         default:
            throw new LuaError("not yet supported: " + String.valueOf(this));
         }
      } catch (LuaError var7) {
         throw var7;
      } catch (InvocationTargetException var8) {
         throw new LuaError(var8.getTargetException());
      } catch (Exception var9) {
         throw new LuaError(var9);
      }
   }

   protected Class classForName(String name) throws ClassNotFoundException {
      return Class.forName(name, true, ClassLoader.getSystemClassLoader());
   }

   @Environment(EnvType.CLIENT)
   private static final class ProxyInvocationHandler implements InvocationHandler {
      private final LuaValue lobj;

      private ProxyInvocationHandler(LuaValue lobj) {
         this.lobj = lobj;
      }

      public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
         String name = method.getName();
         LuaValue func = this.lobj.get(name);
         if (func.isnil()) {
            return null;
         } else {
            boolean isvarargs = (method.getModifiers() & 128) != 0;
            int n = args != null ? args.length : 0;
            LuaValue[] v;
            if (isvarargs) {
               --n;
               Object o = args[n];
               int m = Array.getLength(o);
               v = new LuaValue[n + m];

               int i;
               for(i = 0; i < n; ++i) {
                  v[i] = CoerceJavaToLua.coerce(args[i]);
               }

               for(i = 0; i < m; ++i) {
                  v[i + n] = CoerceJavaToLua.coerce(Array.get(o, i));
               }
            } else {
               v = new LuaValue[n];

               for(int i = 0; i < n; ++i) {
                  v[i] = CoerceJavaToLua.coerce(args[i]);
               }
            }

            LuaValue result = func.invoke(v).arg1();
            return CoerceLuaToJava.coerce(result, method.getReturnType());
         }
      }
   }
}
