package org.luaj.vm2.luajc;

import java.util.Vector;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Lua;
import org.luaj.vm2.Prototype;

@Environment(EnvType.CLIENT)
public class BasicBlock {
   int pc0;
   int pc1;
   BasicBlock[] prev;
   BasicBlock[] next;
   boolean islive;

   public BasicBlock(Prototype p, int pc0) {
      this.pc0 = this.pc1 = pc0;
   }

   public String toString() {
      StringBuffer sb = new StringBuffer();
      int var10001 = this.pc0 + 1;
      sb.append(var10001 + "-" + (this.pc1 + 1) + (this.prev != null ? "  prv: " + this.str(this.prev, 1) : "") + (this.next != null ? "  nxt: " + this.str(this.next, 0) : "") + "\n");
      return sb.toString();
   }

   private String str(BasicBlock[] b, int p) {
      if (b == null) {
         return "";
      } else {
         StringBuffer sb = new StringBuffer();
         sb.append("(");
         int i = 0;

         for(int n = b.length; i < n; ++i) {
            if (i > 0) {
               sb.append(",");
            }

            sb.append(String.valueOf(p == 1 ? b[i].pc1 + 1 : b[i].pc0 + 1));
         }

         sb.append(")");
         return sb.toString();
      }
   }

   public static BasicBlock[] findBasicBlocks(Prototype p) {
      int n = p.code.length;
      boolean[] isbeg = new boolean[n];
      boolean[] isend = new boolean[n];
      isbeg[0] = true;
      BasicBlock.BranchVisitor bv = new BasicBlock.MarkAndMergeVisitor(isbeg, isend);
      visitBranches(p, bv);
      visitBranches(p, bv);
      BasicBlock[] blocks = new BasicBlock[n];

      for(int i = 0; i < n; ++i) {
         isbeg[i] = true;
         BasicBlock b = new BasicBlock(p, i);

         for(blocks[i] = b; !isend[i] && i + 1 < n && !isbeg[i + 1]; blocks[b.pc1 = i] = b) {
            ++i;
         }
      }

      int[] nnext = new int[n];
      int[] nprev = new int[n];
      visitBranches(p, new BasicBlock.CountPrevNextVistor(isbeg, nnext, nprev));
      visitBranches(p, new BasicBlock.AllocAndXRefVisitor(isbeg, nnext, nprev, blocks));
      return blocks;
   }

   public static void visitBranches(Prototype p, BasicBlock.BranchVisitor visitor) {
      int[] code = p.code;
      int n = code.length;

      for(int i = 0; i < n; ++i) {
         int ins = code[i];
         int sbx;
         int j;
         switch(Lua.GET_OPCODE(ins)) {
         case 3:
            if (0 != Lua.GETARG_C(ins)) {
               if (Lua.GET_OPCODE(code[i + 1]) == 23) {
                  throw new IllegalArgumentException("OP_LOADBOOL followed by jump at " + i);
               }

               visitor.visitBranch(i, i + 2);
               break;
            }
         case 4:
         case 5:
         case 6:
         case 7:
         case 8:
         case 9:
         case 10:
         case 11:
         case 12:
         case 13:
         case 14:
         case 15:
         case 16:
         case 17:
         case 18:
         case 19:
         case 20:
         case 21:
         case 22:
         case 29:
         case 34:
         default:
            if (i + 1 < n && visitor.isbeg[i + 1]) {
               visitor.visitBranch(i, i + 1);
            }
            break;
         case 23:
         case 33:
            sbx = Lua.GETARG_sBx(ins);
            j = i + sbx + 1;
            visitor.visitBranch(i, j);
            break;
         case 24:
         case 25:
         case 26:
         case 27:
         case 28:
            if (Lua.GET_OPCODE(code[i + 1]) != 23) {
               throw new IllegalArgumentException("test not followed by jump at " + i);
            }

            sbx = Lua.GETARG_sBx(code[i + 1]);
            ++i;
            j = i + sbx + 1;
            visitor.visitBranch(i, j);
            visitor.visitBranch(i, i + 1);
            break;
         case 30:
         case 31:
            visitor.visitReturn(i);
            break;
         case 32:
         case 35:
            sbx = Lua.GETARG_sBx(ins);
            j = i + sbx + 1;
            visitor.visitBranch(i, j);
            visitor.visitBranch(i, i + 1);
         }
      }

   }

   public static BasicBlock[] findLiveBlocks(BasicBlock[] blocks) {
      Vector next = new Vector();
      next.addElement(blocks[0]);

      while(true) {
         BasicBlock b;
         int i;
         do {
            if (next.isEmpty()) {
               Vector list = new Vector();

               for(i = 0; i < blocks.length; i = blocks[i].pc1 + 1) {
                  if (blocks[i].islive) {
                     list.addElement(blocks[i]);
                  }
               }

               BasicBlock[] array = new BasicBlock[list.size()];
               list.copyInto(array);
               return array;
            }

            b = (BasicBlock)next.elementAt(0);
            next.removeElementAt(0);
         } while(b.islive);

         b.islive = true;
         i = 0;

         for(int n = b.next != null ? b.next.length : 0; i < n; ++i) {
            if (!b.next[i].islive) {
               next.addElement(b.next[i]);
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class MarkAndMergeVisitor extends BasicBlock.BranchVisitor {
      private final boolean[] isend;

      private MarkAndMergeVisitor(boolean[] isbeg, boolean[] isend) {
         super(isbeg);
         this.isend = isend;
      }

      public void visitBranch(int pc0, int pc1) {
         this.isend[pc0] = true;
         this.isbeg[pc1] = true;
      }

      public void visitReturn(int pc) {
         this.isend[pc] = true;
      }
   }

   @Environment(EnvType.CLIENT)
   public abstract static class BranchVisitor {
      final boolean[] isbeg;

      public BranchVisitor(boolean[] isbeg) {
         this.isbeg = isbeg;
      }

      public void visitBranch(int frompc, int topc) {
      }

      public void visitReturn(int atpc) {
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class CountPrevNextVistor extends BasicBlock.BranchVisitor {
      private final int[] nnext;
      private final int[] nprev;

      private CountPrevNextVistor(boolean[] isbeg, int[] nnext, int[] nprev) {
         super(isbeg);
         this.nnext = nnext;
         this.nprev = nprev;
      }

      public void visitBranch(int pc0, int pc1) {
         int var10002 = this.nnext[pc0]++;
         var10002 = this.nprev[pc1]++;
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class AllocAndXRefVisitor extends BasicBlock.BranchVisitor {
      private final int[] nnext;
      private final int[] nprev;
      private final BasicBlock[] blocks;

      private AllocAndXRefVisitor(boolean[] isbeg, int[] nnext, int[] nprev, BasicBlock[] blocks) {
         super(isbeg);
         this.nnext = nnext;
         this.nprev = nprev;
         this.blocks = blocks;
      }

      public void visitBranch(int pc0, int pc1) {
         if (this.blocks[pc0].next == null) {
            this.blocks[pc0].next = new BasicBlock[this.nnext[pc0]];
         }

         if (this.blocks[pc1].prev == null) {
            this.blocks[pc1].prev = new BasicBlock[this.nprev[pc1]];
         }

         this.blocks[pc0].next[--this.nnext[pc0]] = this.blocks[pc1];
         this.blocks[pc1].prev[--this.nprev[pc1]] = this.blocks[pc0];
      }
   }
}
