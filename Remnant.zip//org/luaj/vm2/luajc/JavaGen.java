package org.luaj.vm2.luajc;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LocVars;
import org.luaj.vm2.Lua;
import org.luaj.vm2.Prototype;
import org.luaj.vm2.Upvaldesc;

@Environment(EnvType.CLIENT)
public class JavaGen {
   public final String classname;
   public final byte[] bytecode;
   public final JavaGen[] inners;

   public JavaGen(Prototype p, String classname, String filename, boolean genmain) {
      this(new ProtoInfo(p, classname), classname, filename, genmain);
   }

   private JavaGen(ProtoInfo pi, String classname, String filename, boolean genmain) {
      this.classname = classname;
      JavaBuilder builder = new JavaBuilder(pi, classname, filename);
      this.scanInstructions(pi, classname, builder);

      int n;
      for(n = 0; n < pi.prototype.locvars.length; ++n) {
         LocVars l = pi.prototype.locvars[n];
         builder.setVarStartEnd(n, l.startpc, l.endpc, l.varname.tojstring());
      }

      this.bytecode = builder.completeClass(genmain);
      if (pi.subprotos != null) {
         n = pi.subprotos.length;
         this.inners = new JavaGen[n];

         for(int i = 0; i < n; ++i) {
            this.inners[i] = new JavaGen(pi.subprotos[i], pi.subprotos[i].name, filename, false);
         }
      } else {
         this.inners = null;
      }

   }

   private void scanInstructions(ProtoInfo pi, String classname, JavaBuilder builder) {
      Prototype p = pi.prototype;
      int vresultbase = -1;

      for(int bi = 0; bi < pi.blocklist.length; ++bi) {
         BasicBlock b0 = pi.blocklist[bi];

         int pc;
         for(pc = 0; pc < p.maxstacksize; ++pc) {
            int pc = b0.pc0;
            boolean c = pi.isUpvalueCreate(pc, pc);
            if (c && pi.vars[pc][pc].isPhiVar()) {
               builder.convertToUpvalue(pc, pc);
            }
         }

         for(pc = b0.pc0; pc <= b0.pc1; ++pc) {
            int line;
            int ins = p.code[pc];
            line = pc < p.lineinfo.length ? p.lineinfo[pc] : -1;
            int o = Lua.GET_OPCODE(ins);
            int a = Lua.GETARG_A(ins);
            int b = Lua.GETARG_B(ins);
            int bx = Lua.GETARG_Bx(ins);
            int sbx = Lua.GETARG_sBx(ins);
            int c = Lua.GETARG_C(ins);
            int k;
            int i;
            int i;
            label234:
            switch(o) {
            case 0:
               builder.loadLocal(pc, b);
               builder.storeLocal(pc, a);
               break;
            case 1:
               builder.loadConstant(p.k[bx]);
               builder.storeLocal(pc, a);
            case 2:
            default:
               break;
            case 3:
               builder.loadBoolean(b != 0);
               builder.storeLocal(pc, a);
               if (c != 0) {
                  builder.addBranch(pc, 1, pc + 2);
               }
               break;
            case 4:
               builder.loadNil();

               while(true) {
                  if (b < 0) {
                     break label234;
                  }

                  if (b > 0) {
                     builder.dup();
                  }

                  builder.storeLocal(pc, a);
                  ++a;
                  --b;
               }
            case 5:
               builder.loadUpvalue(b);
               builder.storeLocal(pc, a);
               break;
            case 6:
               builder.loadUpvalue(b);
               this.loadLocalOrConstant(p, builder, pc, c);
               builder.getTable();
               builder.storeLocal(pc, a);
               break;
            case 7:
               builder.loadLocal(pc, b);
               this.loadLocalOrConstant(p, builder, pc, c);
               builder.getTable();
               builder.storeLocal(pc, a);
               break;
            case 8:
               builder.loadUpvalue(a);
               this.loadLocalOrConstant(p, builder, pc, b);
               this.loadLocalOrConstant(p, builder, pc, c);
               builder.setTable();
               break;
            case 9:
               builder.storeUpvalue(pc, b, a);
               break;
            case 10:
               builder.loadLocal(pc, a);
               this.loadLocalOrConstant(p, builder, pc, b);
               this.loadLocalOrConstant(p, builder, pc, c);
               builder.setTable();
               break;
            case 11:
               builder.newTable(b, c);
               builder.storeLocal(pc, a);
               break;
            case 12:
               builder.loadLocal(pc, b);
               builder.dup();
               builder.storeLocal(pc, a + 1);
               this.loadLocalOrConstant(p, builder, pc, c);
               builder.getTable();
               builder.storeLocal(pc, a);
               break;
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
               this.loadLocalOrConstant(p, builder, pc, b);
               this.loadLocalOrConstant(p, builder, pc, c);
               builder.binaryop(o);
               builder.storeLocal(pc, a);
               break;
            case 19:
            case 20:
            case 21:
               builder.loadLocal(pc, b);
               builder.unaryop(o);
               builder.storeLocal(pc, a);
               break;
            case 22:
               for(k = b; k <= c; ++k) {
                  builder.loadLocal(pc, k);
               }

               if (c > b + 1) {
                  builder.tobuffer();
                  k = c;

                  while(true) {
                     --k;
                     if (k < b) {
                        builder.tovalue();
                        break;
                     }

                     builder.concatbuffer();
                  }
               } else {
                  builder.concatvalue();
               }

               builder.storeLocal(pc, a);
               break;
            case 23:
               if (a > 0) {
                  for(k = a - 1; k < pi.openups.length; ++k) {
                     builder.closeUpvalue(pc, k);
                  }
               }

               builder.addBranch(pc, 1, pc + 1 + sbx);
               break;
            case 24:
            case 25:
            case 26:
               this.loadLocalOrConstant(p, builder, pc, b);
               this.loadLocalOrConstant(p, builder, pc, c);
               builder.compareop(o);
               builder.addBranch(pc, a != 0 ? 3 : 2, pc + 2);
               break;
            case 27:
               builder.loadLocal(pc, a);
               builder.toBoolean();
               builder.addBranch(pc, c != 0 ? 3 : 2, pc + 2);
               break;
            case 28:
               builder.loadLocal(pc, b);
               builder.toBoolean();
               builder.addBranch(pc, c != 0 ? 3 : 2, pc + 2);
               builder.loadLocal(pc, b);
               builder.storeLocal(pc, a);
               break;
            case 29:
               builder.loadLocal(pc, a);
               k = b - 1;
               label225:
               switch(k) {
               case -1:
                  this.loadVarargResults(builder, pc, a + 1, vresultbase);
                  k = -1;
                  break;
               case 0:
               case 1:
               case 2:
               case 3:
                  i = 1;

                  while(true) {
                     if (i >= b) {
                        break label225;
                     }

                     builder.loadLocal(pc, a + i);
                     ++i;
                  }
               default:
                  builder.newVarargs(pc, a + 1, b - 1);
                  k = -1;
               }

               boolean useinvoke = k < 0 || c < 1 || c > 2;
               if (useinvoke) {
                  builder.invoke(k);
               } else {
                  builder.call(k);
               }

               switch(c) {
               case 0:
                  vresultbase = a;
                  builder.storeVarresult();
                  break label234;
               case 1:
                  builder.pop();
                  break label234;
               case 2:
                  if (useinvoke) {
                     builder.arg(1);
                  }

                  builder.storeLocal(pc, a);
                  break label234;
               default:
                  i = 1;

                  while(true) {
                     if (i >= c) {
                        break label234;
                     }

                     if (i + 1 < c) {
                        builder.dup();
                     }

                     builder.arg(i);
                     builder.storeLocal(pc, a + i - 1);
                     ++i;
                  }
               }
            case 30:
               builder.loadLocal(pc, a);
               switch(b) {
               case 0:
                  this.loadVarargResults(builder, pc, a + 1, vresultbase);
                  break;
               case 1:
                  builder.loadNone();
                  break;
               case 2:
                  builder.loadLocal(pc, a + 1);
                  break;
               default:
                  builder.newVarargs(pc, a + 1, b - 1);
               }

               builder.newTailcallVarargs();
               builder.areturn();
               break;
            case 31:
               if (c == 1) {
                  builder.loadNone();
               } else {
                  switch(b) {
                  case 0:
                     this.loadVarargResults(builder, pc, a, vresultbase);
                     break;
                  case 1:
                     builder.loadNone();
                     break;
                  case 2:
                     builder.loadLocal(pc, a);
                     break;
                  default:
                     builder.newVarargs(pc, a, b - 1);
                  }
               }

               builder.areturn();
               break;
            case 32:
               builder.loadLocal(pc, a);
               builder.loadLocal(pc, a + 2);
               builder.binaryop(13);
               builder.dup();
               builder.dup();
               builder.storeLocal(pc, a);
               builder.storeLocal(pc, a + 3);
               builder.loadLocal(pc, a + 1);
               builder.loadLocal(pc, a + 2);
               builder.testForLoop();
               builder.addBranch(pc, 2, pc + 1 + sbx);
               break;
            case 33:
               builder.loadLocal(pc, a);
               builder.loadLocal(pc, a + 2);
               builder.binaryop(14);
               builder.storeLocal(pc, a);
               builder.addBranch(pc, 1, pc + 1 + sbx);
               break;
            case 34:
               builder.loadLocal(pc, a);
               builder.loadLocal(pc, a + 1);
               builder.loadLocal(pc, a + 2);
               builder.invoke(2);
               k = 1;

               while(true) {
                  if (k > c) {
                     break label234;
                  }

                  if (k < c) {
                     builder.dup();
                  }

                  builder.arg(k);
                  builder.storeLocal(pc, a + 2 + k);
                  ++k;
               }
            case 35:
               builder.loadLocal(pc, a + 1);
               builder.dup();
               builder.storeLocal(pc, a);
               builder.isNil();
               builder.addBranch(pc, 3, pc + 1 + sbx);
               break;
            case 36:
               k = (c - 1) * 50 + 1;
               builder.loadLocal(pc, a);
               if (b == 0) {
                  i = vresultbase - (a + 1);
                  if (i > 0) {
                     builder.setlistStack(pc, a + 1, k, i);
                     k += i;
                  }

                  builder.setlistVarargs(k, vresultbase);
               } else {
                  builder.setlistStack(pc, a + 1, k, b);
                  builder.pop();
               }
               break;
            case 37:
               Prototype newp = p.p[bx];
               i = newp.upvalues.length;
               String protoname = pi.subprotos[bx].name;
               builder.closureCreate(protoname);
               if (i > 0) {
                  builder.dup();
               }

               builder.storeLocal(pc, a);
               int up = 0;

               while(true) {
                  if (up >= i) {
                     break label234;
                  }

                  if (up + 1 < i) {
                     builder.dup();
                  }

                  Upvaldesc u = newp.upvalues[up];
                  if (u.instack) {
                     builder.closureInitUpvalueFromLocal(protoname, up, pc, u.idx);
                  } else {
                     builder.closureInitUpvalueFromUpvalue(protoname, up, u.idx);
                  }

                  ++up;
               }
            case 38:
               if (b == 0) {
                  builder.loadVarargs();
                  builder.storeVarresult();
                  vresultbase = a;
               } else {
                  for(i = 1; i < b; ++i) {
                     builder.loadVarargs(i);
                     builder.storeLocal(pc, a);
                     ++a;
                  }
               }
            }

            builder.onEndOfLuaInstruction(pc, line);
         }
      }

   }

   private void loadVarargResults(JavaBuilder builder, int pc, int a, int vresultbase) {
      if (vresultbase <= a) {
         builder.loadVarresult();
         builder.subargs(a + 1 - vresultbase);
      } else if (vresultbase == a) {
         builder.loadVarresult();
      } else {
         builder.newVarargsVarresult(pc, a, vresultbase - a);
      }

   }

   private void loadLocalOrConstant(Prototype p, JavaBuilder builder, int pc, int borc) {
      if (borc <= 255) {
         builder.loadLocal(pc, borc);
      } else {
         builder.loadConstant(p.k[borc & 255]);
      }

   }
}
