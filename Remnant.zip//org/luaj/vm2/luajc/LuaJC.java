package org.luaj.vm2.luajc;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Hashtable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Prototype;

@Environment(EnvType.CLIENT)
public class LuaJC implements Globals.Loader {
   public static final LuaJC instance = new LuaJC();

   public static final void install(Globals G) {
      G.loader = instance;
   }

   protected LuaJC() {
   }

   public Hashtable compileAll(InputStream script, String chunkname, String filename, Globals globals, boolean genmain) throws IOException {
      String classname = toStandardJavaClassName(chunkname);
      Prototype p = globals.loadPrototype(script, classname, "bt");
      return this.compileProtoAndSubProtos(p, classname, filename, genmain);
   }

   public Hashtable compileAll(Reader script, String chunkname, String filename, Globals globals, boolean genmain) throws IOException {
      String classname = toStandardJavaClassName(chunkname);
      Prototype p = globals.compilePrototype(script, classname);
      return this.compileProtoAndSubProtos(p, classname, filename, genmain);
   }

   private Hashtable compileProtoAndSubProtos(Prototype p, String classname, String filename, boolean genmain) throws IOException {
      String luaname = toStandardLuaFileName(filename);
      Hashtable h = new Hashtable();
      JavaGen gen = new JavaGen(p, classname, luaname, genmain);
      this.insert(h, gen);
      return h;
   }

   private void insert(Hashtable h, JavaGen gen) {
      h.put(gen.classname, gen.bytecode);
      int i = 0;

      for(int n = gen.inners != null ? gen.inners.length : 0; i < n; ++i) {
         this.insert(h, gen.inners[i]);
      }

   }

   public LuaFunction load(Prototype p, String name, LuaValue globals) throws IOException {
      String luaname = toStandardLuaFileName(name);
      String classname = toStandardJavaClassName(luaname);
      JavaLoader loader = new JavaLoader();
      return loader.load(p, classname, luaname, globals);
   }

   private static String toStandardJavaClassName(String luachunkname) {
      String stub = toStub(luachunkname);
      StringBuffer classname = new StringBuffer();
      int i = 0;

      for(int n = stub.length(); i < n; ++i) {
         char c = stub.charAt(i);
         classname.append((i != 0 || !Character.isJavaIdentifierStart(c)) && (i <= 0 || !Character.isJavaIdentifierPart(c)) ? '_' : c);
      }

      return classname.toString();
   }

   private static String toStandardLuaFileName(String luachunkname) {
      String stub = toStub(luachunkname);
      String filename = stub.replace('.', '/') + ".lua";
      return filename.startsWith("@") ? filename.substring(1) : filename;
   }

   private static String toStub(String s) {
      String stub = s.endsWith(".lua") ? s.substring(0, s.length() - 4) : s;
      return stub;
   }
}
