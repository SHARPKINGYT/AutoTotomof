package org.luaj.vm2.luajc;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Hashtable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Lua;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.Print;
import org.luaj.vm2.Prototype;
import org.luaj.vm2.Upvaldesc;

@Environment(EnvType.CLIENT)
public class ProtoInfo {
   public final String name;
   public final Prototype prototype;
   public final ProtoInfo[] subprotos;
   public final BasicBlock[] blocks;
   public final BasicBlock[] blocklist;
   public final VarInfo[] params;
   public final VarInfo[][] vars;
   public final UpvalInfo[] upvals;
   public final UpvalInfo[][] openups;

   public ProtoInfo(Prototype p, String name) {
      this(p, name, (UpvalInfo[])null);
   }

   private ProtoInfo(Prototype p, String name, UpvalInfo[] u) {
      this.name = name;
      this.prototype = p;
      this.upvals = u != null ? u : new UpvalInfo[]{new UpvalInfo(this)};
      this.subprotos = p.p != null && p.p.length > 0 ? new ProtoInfo[p.p.length] : null;
      this.blocks = BasicBlock.findBasicBlocks(p);
      this.blocklist = BasicBlock.findLiveBlocks(this.blocks);
      this.params = new VarInfo[p.maxstacksize];

      for(int slot = 0; slot < p.maxstacksize; ++slot) {
         VarInfo v = VarInfo.PARAM(slot);
         this.params[slot] = v;
      }

      this.vars = this.findVariables();
      this.replaceTrivialPhiVariables();
      this.openups = new UpvalInfo[p.maxstacksize][];
      this.findUpvalues();
   }

   public String toString() {
      StringBuffer sb = new StringBuffer();
      sb.append("proto '" + this.name + "'\n");
      int i = 0;

      int n;
      for(n = this.upvals != null ? this.upvals.length : 0; i < n; ++i) {
         sb.append(" up[" + i + "]: " + String.valueOf(this.upvals[i]) + "\n");
      }

      for(i = 0; i < this.blocklist.length; ++i) {
         BasicBlock b = this.blocklist[i];
         int pc0 = b.pc0;
         sb.append("  block " + b.toString());
         this.appendOpenUps(sb, -1);

         for(int pc = pc0; pc <= b.pc1; ++pc) {
            this.appendOpenUps(sb, pc);
            sb.append("     ");

            for(int j = 0; j < this.prototype.maxstacksize; ++j) {
               VarInfo v = this.vars[j][pc];
               String u = v == null ? "" : (v.upvalue != null ? (!v.upvalue.rw ? "[C] " : (v.allocupvalue && v.pc == pc ? "[*] " : "[]  ")) : "    ");
               String s = v == null ? "null   " : String.valueOf(v);
               sb.append(s + u);
            }

            sb.append("  ");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintStream ops = Print.ps;
            Print.ps = new PrintStream(baos);

            try {
               Print.printOpCode(this.prototype, pc);
            } finally {
               Print.ps.close();
               Print.ps = ops;
            }

            sb.append(baos.toString());
            sb.append("\n");
         }
      }

      i = 0;

      for(n = this.subprotos != null ? this.subprotos.length : 0; i < n; ++i) {
         sb.append(this.subprotos[i].toString());
      }

      return sb.toString();
   }

   private void appendOpenUps(StringBuffer sb, int pc) {
      for(int j = 0; j < this.prototype.maxstacksize; ++j) {
         VarInfo v = pc < 0 ? this.params[j] : this.vars[j][pc];
         if (v != null && v.pc == pc && v.allocupvalue) {
            sb.append("    open: " + String.valueOf(v.upvalue) + "\n");
         }
      }

   }

   private VarInfo[][] findVariables() {
      int n = this.prototype.code.length;
      int m = this.prototype.maxstacksize;
      VarInfo[][] v = new VarInfo[m][];

      int bi;
      for(bi = 0; bi < v.length; ++bi) {
         v[bi] = new VarInfo[n];
      }

      for(bi = 0; bi < this.blocklist.length; ++bi) {
         BasicBlock b0 = this.blocklist[bi];
         int nprev = b0.prev != null ? b0.prev.length : 0;

         int pc;
         int b;
         for(pc = 0; pc < m; ++pc) {
            VarInfo var = null;
            if (nprev == 0) {
               var = this.params[pc];
            } else if (nprev == 1) {
               var = v[pc][b0.prev[0].pc1];
            } else {
               for(b = 0; b < nprev; ++b) {
                  BasicBlock bp = b0.prev[b];
                  if (v[pc][bp.pc1] == VarInfo.INVALID) {
                     var = VarInfo.INVALID;
                  }
               }
            }

            if (var == null) {
               var = VarInfo.PHI(this, pc, b0.pc0);
            }

            v[pc][b0.pc0] = var;
         }

         label246:
         for(pc = b0.pc0; pc <= b0.pc1; ++pc) {
            if (pc > b0.pc0) {
               propogateVars(v, pc - 1, pc);
            }

            int ins = this.prototype.code[pc];
            int op = Lua.GET_OPCODE(ins);
            int j;
            int c;
            int a;
            switch(op) {
            case 0:
            case 19:
            case 20:
            case 21:
            case 28:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               v[b][pc].isreferenced = true;
               v[a][pc] = new VarInfo(a, pc);
               break;
            case 1:
            case 3:
            case 5:
            case 11:
               a = Lua.GETARG_A(ins);
               v[a][pc] = new VarInfo(a, pc);
               break;
            case 2:
            default:
               throw new IllegalStateException("unhandled opcode: " + ins);
            case 4:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);

               while(true) {
                  if (b-- < 0) {
                     continue label246;
                  }

                  v[a][pc] = new VarInfo(a, pc);
                  ++a;
               }
            case 6:
               a = Lua.GETARG_A(ins);
               c = Lua.GETARG_C(ins);
               if (!Lua.ISK(c)) {
                  v[c][pc].isreferenced = true;
               }

               v[a][pc] = new VarInfo(a, pc);
               break;
            case 7:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               c = Lua.GETARG_C(ins);
               v[b][pc].isreferenced = true;
               if (!Lua.ISK(c)) {
                  v[c][pc].isreferenced = true;
               }

               v[a][pc] = new VarInfo(a, pc);
               break;
            case 8:
               b = Lua.GETARG_B(ins);
               c = Lua.GETARG_C(ins);
               if (!Lua.ISK(b)) {
                  v[b][pc].isreferenced = true;
               }

               if (!Lua.ISK(c)) {
                  v[c][pc].isreferenced = true;
               }
               break;
            case 9:
            case 27:
               a = Lua.GETARG_A(ins);
               v[a][pc].isreferenced = true;
               break;
            case 10:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               c = Lua.GETARG_C(ins);
               v[a][pc].isreferenced = true;
               if (!Lua.ISK(b)) {
                  v[b][pc].isreferenced = true;
               }

               if (!Lua.ISK(c)) {
                  v[c][pc].isreferenced = true;
               }
               break;
            case 12:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               c = Lua.GETARG_C(ins);
               v[b][pc].isreferenced = true;
               if (!Lua.ISK(c)) {
                  v[c][pc].isreferenced = true;
               }

               v[a][pc] = new VarInfo(a, pc);
               v[a + 1][pc] = new VarInfo(a + 1, pc);
               break;
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               c = Lua.GETARG_C(ins);
               if (!Lua.ISK(b)) {
                  v[b][pc].isreferenced = true;
               }

               if (!Lua.ISK(c)) {
                  v[c][pc].isreferenced = true;
               }

               v[a][pc] = new VarInfo(a, pc);
               break;
            case 22:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);

               for(c = Lua.GETARG_C(ins); b <= c; ++b) {
                  v[b][pc].isreferenced = true;
               }

               v[a][pc] = new VarInfo(a, pc);
               break;
            case 23:
               a = Lua.GETARG_A(ins);
               if (a > 0) {
                  --a;

                  while(a < m) {
                     v[a][pc] = VarInfo.INVALID;
                     ++a;
                  }
               }
               break;
            case 24:
            case 25:
            case 26:
               b = Lua.GETARG_B(ins);
               c = Lua.GETARG_C(ins);
               if (!Lua.ISK(b)) {
                  v[b][pc].isreferenced = true;
               }

               if (!Lua.ISK(c)) {
                  v[c][pc].isreferenced = true;
               }
               break;
            case 29:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               c = Lua.GETARG_C(ins);
               v[a][pc].isreferenced = true;
               v[a][pc].isreferenced = true;

               for(j = 1; j <= b - 1; ++j) {
                  v[a + j][pc].isreferenced = true;
               }

               for(j = 0; j <= c - 2; ++a) {
                  v[a][pc] = new VarInfo(a, pc);
                  ++j;
               }

               while(true) {
                  if (a >= m) {
                     continue label246;
                  }

                  v[a][pc] = VarInfo.INVALID;
                  ++a;
               }
            case 30:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               v[a][pc].isreferenced = true;
               j = 1;

               while(true) {
                  if (j > b - 1) {
                     continue label246;
                  }

                  v[a + j][pc].isreferenced = true;
                  ++j;
               }
            case 31:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               j = 0;

               while(true) {
                  if (j > b - 2) {
                     continue label246;
                  }

                  v[a + j][pc].isreferenced = true;
                  ++j;
               }
            case 32:
               a = Lua.GETARG_A(ins);
               v[a][pc].isreferenced = true;
               v[a + 2][pc].isreferenced = true;
               v[a][pc] = new VarInfo(a, pc);
               v[a][pc].isreferenced = true;
               v[a + 1][pc].isreferenced = true;
               v[a + 3][pc] = new VarInfo(a + 3, pc);
               break;
            case 33:
               a = Lua.GETARG_A(ins);
               v[a + 2][pc].isreferenced = true;
               v[a][pc] = new VarInfo(a, pc);
               break;
            case 34:
               a = Lua.GETARG_A(ins);
               c = Lua.GETARG_C(ins);
               v[a++][pc].isreferenced = true;
               v[a++][pc].isreferenced = true;
               v[a++][pc].isreferenced = true;

               for(j = 0; j < c; ++a) {
                  v[a][pc] = new VarInfo(a, pc);
                  ++j;
               }

               while(true) {
                  if (a >= m) {
                     continue label246;
                  }

                  v[a][pc] = VarInfo.INVALID;
                  ++a;
               }
            case 35:
               a = Lua.GETARG_A(ins);
               v[a + 1][pc].isreferenced = true;
               v[a][pc] = new VarInfo(a, pc);
               break;
            case 36:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);
               v[a][pc].isreferenced = true;
               j = 1;

               while(true) {
                  if (j > b) {
                     continue label246;
                  }

                  v[a + j][pc].isreferenced = true;
                  ++j;
               }
            case 37:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_Bx(ins);
               Upvaldesc[] upvalues = this.prototype.p[b].upvalues;
               int k = 0;

               for(int nups = upvalues.length; k < nups; ++k) {
                  if (upvalues[k].instack) {
                     v[upvalues[k].idx][pc].isreferenced = true;
                  }
               }

               v[a][pc] = new VarInfo(a, pc);
               break;
            case 38:
               a = Lua.GETARG_A(ins);
               b = Lua.GETARG_B(ins);

               for(j = 1; j < b; ++a) {
                  v[a][pc] = new VarInfo(a, pc);
                  ++j;
               }

               if (b == 0) {
                  while(a < m) {
                     v[a][pc] = VarInfo.INVALID;
                     ++a;
                  }
               }
            }
         }
      }

      return v;
   }

   private static void propogateVars(VarInfo[][] v, int pcfrom, int pcto) {
      int j = 0;

      for(int m = v.length; j < m; ++j) {
         v[j][pcto] = v[j][pcfrom];
      }

   }

   private void replaceTrivialPhiVariables() {
      for(int i = 0; i < this.blocklist.length; ++i) {
         BasicBlock b0 = this.blocklist[i];

         for(int slot = 0; slot < this.prototype.maxstacksize; ++slot) {
            VarInfo vold = this.vars[slot][b0.pc0];
            VarInfo vnew = vold.resolvePhiVariableValues();
            if (vnew != null) {
               this.substituteVariable(slot, vold, vnew);
            }
         }
      }

   }

   private void substituteVariable(int slot, VarInfo vold, VarInfo vnew) {
      int i = 0;

      for(int n = this.prototype.code.length; i < n; ++i) {
         this.replaceAll(this.vars[slot], this.vars[slot].length, vold, vnew);
      }

   }

   private void replaceAll(VarInfo[] v, int n, VarInfo vold, VarInfo vnew) {
      for(int i = 0; i < n; ++i) {
         if (v[i] == vold) {
            v[i] = vnew;
         }
      }

   }

   private void findUpvalues() {
      int[] code = this.prototype.code;
      int n = code.length;
      String[] names = this.findInnerprotoNames();

      int pc;
      for(pc = 0; pc < n; ++pc) {
         if (Lua.GET_OPCODE(code[pc]) == 37) {
            int bx = Lua.GETARG_Bx(code[pc]);
            Prototype newp = this.prototype.p[bx];
            UpvalInfo[] newu = new UpvalInfo[newp.upvalues.length];
            String newname = this.name + "$" + names[bx];

            for(int j = 0; j < newp.upvalues.length; ++j) {
               Upvaldesc u = newp.upvalues[j];
               newu[j] = u.instack ? this.findOpenUp(pc, u.idx) : this.upvals[u.idx];
            }

            this.subprotos[bx] = new ProtoInfo(newp, newname, newu);
         }
      }

      for(pc = 0; pc < n; ++pc) {
         if (Lua.GET_OPCODE(code[pc]) == 9) {
            this.upvals[Lua.GETARG_B(code[pc])].rw = true;
         }
      }

   }

   private UpvalInfo findOpenUp(int pc, int slot) {
      if (this.openups[slot] == null) {
         this.openups[slot] = new UpvalInfo[this.prototype.code.length];
      }

      if (this.openups[slot][pc] != null) {
         return this.openups[slot][pc];
      } else {
         UpvalInfo u = new UpvalInfo(this, pc, slot);
         int i = 0;

         for(int n = this.prototype.code.length; i < n; ++i) {
            if (this.vars[slot][i] != null && this.vars[slot][i].upvalue == u) {
               this.openups[slot][i] = u;
            }
         }

         return u;
      }
   }

   public boolean isUpvalueAssign(int pc, int slot) {
      VarInfo v = pc < 0 ? this.params[slot] : this.vars[slot][pc];
      return v != null && v.upvalue != null && v.upvalue.rw;
   }

   public boolean isUpvalueCreate(int pc, int slot) {
      VarInfo v = pc < 0 ? this.params[slot] : this.vars[slot][pc];
      return v != null && v.upvalue != null && v.upvalue.rw && v.allocupvalue && pc == v.pc;
   }

   public boolean isUpvalueRefer(int pc, int slot) {
      if (pc > 0 && this.vars[slot][pc] != null && this.vars[slot][pc].pc == pc && this.vars[slot][pc - 1] != null) {
         --pc;
      }

      VarInfo v = pc < 0 ? this.params[slot] : this.vars[slot][pc];
      return v != null && v.upvalue != null && v.upvalue.rw;
   }

   public boolean isInitialValueUsed(int slot) {
      VarInfo v = this.params[slot];
      return v.isreferenced;
   }

   public boolean isReadWriteUpvalue(UpvalInfo u) {
      return u.rw;
   }

   private String[] findInnerprotoNames() {
      if (this.prototype.p.length <= 0) {
         return null;
      } else {
         String[] names = new String[this.prototype.p.length];
         Hashtable used = new Hashtable();
         int[] code = this.prototype.code;
         int n = code.length;

         for(int pc = 0; pc < n; ++pc) {
            if (Lua.GET_OPCODE(code[pc]) == 37) {
               int bx = Lua.GETARG_Bx(code[pc]);
               String name = null;
               int i = code[pc + 1];
               int b;
               LuaString s;
               switch(Lua.GET_OPCODE(i)) {
               case 8:
               case 10:
                  b = Lua.GETARG_B(i);
                  if (Lua.ISK(b)) {
                     name = this.prototype.k[b & 255].tojstring();
                  }
                  break;
               case 9:
                  b = Lua.GETARG_B(i);
                  s = this.prototype.upvalues[b].name;
                  if (s != null) {
                     name = s.tojstring();
                  }
                  break;
               default:
                  b = Lua.GETARG_A(code[pc]);
                  s = this.prototype.getlocalname(b + 1, pc + 1);
                  if (s != null) {
                     name = s.tojstring();
                  }
               }

               name = name != null ? toJavaClassPart(name) : String.valueOf(bx);
               if (used.containsKey(name)) {
                  String basename = name;
                  int var12 = 1;

                  do {
                     name = basename + "$" + var12++;
                  } while(used.containsKey(name));
               }

               used.put(name, Boolean.TRUE);
               names[bx] = name;
            }
         }

         return names;
      }
   }

   private static String toJavaClassPart(String s) {
      int n = s.length();
      StringBuffer sb = new StringBuffer(n);

      for(int i = 0; i < n; ++i) {
         sb.append(Character.isJavaIdentifierPart(s.charAt(i)) ? s.charAt(i) : '_');
      }

      return sb.toString();
   }
}
