package org.luaj.vm2.luajc;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Lua;

@Environment(EnvType.CLIENT)
public class UpvalInfo {
   ProtoInfo pi;
   int slot;
   int nvars;
   VarInfo[] var;
   boolean rw;

   public UpvalInfo(ProtoInfo pi) {
      this.pi = pi;
      this.slot = 0;
      this.nvars = 1;
      this.var = new VarInfo[]{VarInfo.PARAM(0)};
      this.rw = false;
   }

   public UpvalInfo(ProtoInfo pi, int pc, int slot) {
      this.pi = pi;
      this.slot = slot;
      this.nvars = 0;
      this.var = null;
      this.includeVarAndPosteriorVars(pi.vars[slot][pc]);

      for(int i = 0; i < this.nvars; ++i) {
         this.var[i].allocupvalue = this.testIsAllocUpvalue(this.var[i]);
      }

      this.rw = this.nvars > 1;
   }

   private boolean includeVarAndPosteriorVars(VarInfo var) {
      if (var != null && var != VarInfo.INVALID) {
         if (var.upvalue == this) {
            return true;
         } else {
            var.upvalue = this;
            this.appendVar(var);
            if (this.isLoopVariable(var)) {
               return false;
            } else {
               boolean loopDetected = this.includePosteriorVarsCheckLoops(var);
               if (loopDetected) {
                  this.includePriorVarsIgnoreLoops(var);
               }

               return loopDetected;
            }
         }
      } else {
         return false;
      }
   }

   private boolean isLoopVariable(VarInfo var) {
      if (var.pc >= 0) {
         switch(Lua.GET_OPCODE(this.pi.prototype.code[var.pc])) {
         case 32:
         case 35:
            return true;
         }
      }

      return false;
   }

   private boolean includePosteriorVarsCheckLoops(VarInfo prior) {
      boolean loopDetected = false;
      int i = 0;

      for(int n = this.pi.blocklist.length; i < n; ++i) {
         BasicBlock b = this.pi.blocklist[i];
         VarInfo v = this.pi.vars[this.slot][b.pc1];
         int pc;
         if (v == prior) {
            pc = 0;

            for(int m = b.next != null ? b.next.length : 0; pc < m; ++pc) {
               BasicBlock b1 = b.next[pc];
               VarInfo v1 = this.pi.vars[this.slot][b1.pc0];
               if (v1 != prior) {
                  loopDetected |= this.includeVarAndPosteriorVars(v1);
                  if (v1.isPhiVar()) {
                     this.includePriorVarsIgnoreLoops(v1);
                  }
               }
            }
         } else {
            for(pc = b.pc1 - 1; pc >= b.pc0; --pc) {
               if (this.pi.vars[this.slot][pc] == prior) {
                  loopDetected |= this.includeVarAndPosteriorVars(this.pi.vars[this.slot][pc + 1]);
                  break;
               }
            }
         }
      }

      return loopDetected;
   }

   private void includePriorVarsIgnoreLoops(VarInfo poster) {
      int i = 0;

      for(int n = this.pi.blocklist.length; i < n; ++i) {
         BasicBlock b = this.pi.blocklist[i];
         VarInfo v = this.pi.vars[this.slot][b.pc0];
         int pc;
         if (v == poster) {
            pc = 0;

            for(int m = b.prev != null ? b.prev.length : 0; pc < m; ++pc) {
               BasicBlock b0 = b.prev[pc];
               VarInfo v0 = this.pi.vars[this.slot][b0.pc1];
               if (v0 != poster) {
                  this.includeVarAndPosteriorVars(v0);
               }
            }
         } else {
            for(pc = b.pc0 + 1; pc <= b.pc1; ++pc) {
               if (this.pi.vars[this.slot][pc] == poster) {
                  this.includeVarAndPosteriorVars(this.pi.vars[this.slot][pc - 1]);
                  break;
               }
            }
         }
      }

   }

   private void appendVar(VarInfo v) {
      if (this.nvars == 0) {
         this.var = new VarInfo[1];
      } else if (this.nvars + 1 >= this.var.length) {
         VarInfo[] s = this.var;
         this.var = new VarInfo[this.nvars * 2 + 1];
         System.arraycopy(s, 0, this.var, 0, this.nvars);
      }

      this.var[this.nvars++] = v;
   }

   public String toString() {
      StringBuffer sb = new StringBuffer();
      sb.append(this.pi.name);

      for(int i = 0; i < this.nvars; ++i) {
         sb.append(i > 0 ? "," : " ");
         sb.append(String.valueOf(this.var[i]));
      }

      if (this.rw) {
         sb.append("(rw)");
      }

      return sb.toString();
   }

   private boolean testIsAllocUpvalue(VarInfo v) {
      if (v.pc < 0) {
         return true;
      } else {
         BasicBlock b = this.pi.blocks[v.pc];
         if (v.pc > b.pc0) {
            return this.pi.vars[this.slot][v.pc - 1].upvalue != this;
         } else {
            if (b.prev == null) {
               v = this.pi.params[this.slot];
               if (v != null && v.upvalue != this) {
                  return true;
               }
            } else {
               int i = 0;

               for(int n = b.prev.length; i < n; ++i) {
                  v = this.pi.vars[this.slot][b.prev[i].pc1];
                  if (v != null && v.upvalue != this) {
                     return true;
                  }
               }
            }

            return false;
         }
      }
   }
}
