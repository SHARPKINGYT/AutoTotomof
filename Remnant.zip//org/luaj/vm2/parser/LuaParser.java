package org.luaj.vm2.parser;

import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.ast.Block;
import org.luaj.vm2.ast.Chunk;
import org.luaj.vm2.ast.Exp;
import org.luaj.vm2.ast.FuncArgs;
import org.luaj.vm2.ast.FuncBody;
import org.luaj.vm2.ast.FuncName;
import org.luaj.vm2.ast.Name;
import org.luaj.vm2.ast.ParList;
import org.luaj.vm2.ast.Stat;
import org.luaj.vm2.ast.Str;
import org.luaj.vm2.ast.SyntaxElement;
import org.luaj.vm2.ast.TableConstructor;
import org.luaj.vm2.ast.TableField;

@Environment(EnvType.CLIENT)
public class LuaParser implements LuaParserConstants {
   public LuaParserTokenManager token_source;
   SimpleCharStream jj_input_stream;
   public Token token;
   public Token jj_nt;
   private int jj_ntk;
   private Token jj_scanpos;
   private Token jj_lastpos;
   private int jj_la;
   private int jj_gen;
   private final int[] jj_la1;
   private static int[] jj_la1_0;
   private static int[] jj_la1_1;
   private static int[] jj_la1_2;
   private final LuaParser.JJCalls[] jj_2_rtns;
   private boolean jj_rescan;
   private int jj_gc;
   private final LuaParser.LookaheadSuccess jj_ls;
   private List jj_expentries;
   private int[] jj_expentry;
   private int jj_kind;
   private int[] jj_lasttokens;
   private int jj_endpos;

   public static void main(String[] args) throws ParseException {
      LuaParser parser = new LuaParser(System.in);
      parser.Chunk();
   }

   private static Exp.VarExp assertvarexp(Exp.PrimaryExp pe) throws ParseException {
      if (!pe.isvarexp()) {
         throw new ParseException("expected variable");
      } else {
         return (Exp.VarExp)pe;
      }
   }

   private static Exp.FuncCall assertfunccall(Exp.PrimaryExp pe) throws ParseException {
      if (!pe.isfunccall()) {
         throw new ParseException("expected function call");
      } else {
         return (Exp.FuncCall)pe;
      }
   }

   public SimpleCharStream getCharStream() {
      return this.jj_input_stream;
   }

   private long LineInfo() {
      return (long)this.jj_input_stream.getBeginLine() << 32 | (long)this.jj_input_stream.getBeginColumn();
   }

   private void L(SyntaxElement e, long startinfo) {
      e.beginLine = (int)(startinfo >> 32);
      e.beginColumn = (short)((int)startinfo);
      e.endLine = this.token.endLine;
      e.endColumn = (short)this.token.endColumn;
   }

   private void L(SyntaxElement e, Token starttoken) {
      e.beginLine = starttoken.beginLine;
      e.beginColumn = (short)starttoken.beginColumn;
      e.endLine = this.token.endLine;
      e.endColumn = (short)this.token.endColumn;
   }

   public final Chunk Chunk() throws ParseException {
      long i = this.LineInfo();
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 69:
         this.jj_consume_token(69);
         this.token_source.SwitchTo(1);
         break;
      default:
         this.jj_la1[0] = this.jj_gen;
      }

      Block b = this.Block();
      this.jj_consume_token(0);
      Chunk c = new Chunk(b);
      this.L(c, i);
      return c;
   }

   public final Block Block() throws ParseException {
      Block b = new Block();
      long i = this.LineInfo();

      while(true) {
         Stat s;
         switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
         case 30:
         case 31:
         case 36:
         case 37:
         case 38:
         case 39:
         case 41:
         case 46:
         case 50:
         case 51:
         case 65:
         case 70:
         case 75:
            s = this.Stat();
            b.add(s);
            break;
         case 32:
         case 33:
         case 34:
         case 35:
         case 40:
         case 42:
         case 43:
         case 44:
         case 45:
         case 47:
         case 48:
         case 49:
         case 52:
         case 53:
         case 54:
         case 55:
         case 56:
         case 57:
         case 58:
         case 59:
         case 60:
         case 61:
         case 62:
         case 63:
         case 64:
         case 66:
         case 67:
         case 68:
         case 69:
         case 71:
         case 72:
         case 73:
         case 74:
         default:
            this.jj_la1[1] = this.jj_gen;
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 45:
               s = this.ReturnStat();
               b.add(s);
               break;
            default:
               this.jj_la1[2] = this.jj_gen;
            }

            this.L(b, i);
            return b;
         }
      }
   }

   public final Stat Stat() throws ParseException {
      Exp e3 = null;
      List<Exp> el = null;
      long i = this.LineInfo();
      Block b;
      Exp e;
      Stat s;
      Token n;
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 30:
         this.jj_consume_token(30);
         s = Stat.breakstat();
         this.L(s, i);
         return s;
      case 31:
         this.jj_consume_token(31);
         b = this.Block();
         this.jj_consume_token(34);
         s = Stat.block(b);
         this.L(s, i);
         return s;
      case 38:
         this.jj_consume_token(38);
         n = this.jj_consume_token(51);
         s = Stat.gotostat(n.image);
         this.L(s, i);
         return s;
      case 39:
         s = this.IfThenElse();
         this.L(s, i);
         return s;
      case 46:
         this.jj_consume_token(46);
         b = this.Block();
         this.jj_consume_token(49);
         e = this.Exp();
         s = Stat.repeatuntil(b, e);
         this.L(s, i);
         return s;
      case 50:
         this.jj_consume_token(50);
         e = this.Exp();
         this.jj_consume_token(31);
         b = this.Block();
         this.jj_consume_token(34);
         s = Stat.whiledo(e, b);
         this.L(s, i);
         return s;
      case 65:
         s = this.Label();
         this.L(s, i);
         return s;
      case 70:
         this.jj_consume_token(70);
         return null;
      default:
         this.jj_la1[5] = this.jj_gen;
         if (this.jj_2_1(3)) {
            this.jj_consume_token(36);
            n = this.jj_consume_token(51);
            this.jj_consume_token(71);
            e = this.Exp();
            this.jj_consume_token(72);
            Exp e2 = this.Exp();
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 72:
               this.jj_consume_token(72);
               e3 = this.Exp();
               break;
            default:
               this.jj_la1[3] = this.jj_gen;
            }

            this.jj_consume_token(31);
            b = this.Block();
            this.jj_consume_token(34);
            s = Stat.fornumeric(n.image, e, e2, e3, b);
            this.L(s, i);
            return s;
         } else {
            FuncBody fb;
            List nl;
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 36:
               this.jj_consume_token(36);
               nl = this.NameList();
               this.jj_consume_token(40);
               el = this.ExpList();
               this.jj_consume_token(31);
               b = this.Block();
               this.jj_consume_token(34);
               s = Stat.forgeneric(nl, el, b);
               this.L(s, i);
               return s;
            case 37:
               this.jj_consume_token(37);
               FuncName fn = this.FuncName();
               fb = this.FuncBody();
               s = Stat.functiondef(fn, fb);
               this.L(s, i);
               return s;
            default:
               this.jj_la1[6] = this.jj_gen;
               if (this.jj_2_2(2)) {
                  this.jj_consume_token(41);
                  this.jj_consume_token(37);
                  n = this.jj_consume_token(51);
                  fb = this.FuncBody();
                  s = Stat.localfunctiondef(n.image, fb);
                  this.L(s, i);
                  return s;
               } else {
                  switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                  case 41:
                     this.jj_consume_token(41);
                     nl = this.NameList();
                     switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                     case 71:
                        this.jj_consume_token(71);
                        el = this.ExpList();
                        break;
                     default:
                        this.jj_la1[4] = this.jj_gen;
                     }

                     s = Stat.localassignment(nl, el);
                     this.L(s, i);
                     return s;
                  case 51:
                  case 75:
                     s = this.ExprStat();
                     this.L(s, i);
                     return s;
                  default:
                     this.jj_la1[7] = this.jj_gen;
                     this.jj_consume_token(-1);
                     throw new ParseException();
                  }
               }
            }
         }
      }
   }

   public final Stat IfThenElse() throws ParseException {
      Block b3 = null;
      List<Exp> el = null;
      List<Block> bl = null;
      this.jj_consume_token(39);
      Exp e = this.Exp();
      this.jj_consume_token(47);
      Block b = this.Block();

      while(true) {
         switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
         case 33:
            this.jj_consume_token(33);
            Exp e2 = this.Exp();
            this.jj_consume_token(47);
            Block b2 = this.Block();
            if (el == null) {
               el = new ArrayList();
            }

            if (bl == null) {
               bl = new ArrayList();
            }

            el.add(e2);
            bl.add(b2);
            break;
         default:
            this.jj_la1[8] = this.jj_gen;
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 32:
               this.jj_consume_token(32);
               b3 = this.Block();
               break;
            default:
               this.jj_la1[9] = this.jj_gen;
            }

            this.jj_consume_token(34);
            return Stat.ifthenelse(e, b, el, bl, b3);
         }
      }
   }

   public final Stat ReturnStat() throws ParseException {
      List<Exp> el = null;
      long i = this.LineInfo();
      this.jj_consume_token(45);
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 35:
      case 37:
      case 42:
      case 43:
      case 48:
      case 51:
      case 52:
      case 61:
      case 62:
      case 69:
      case 75:
      case 79:
      case 80:
      case 83:
         el = this.ExpList();
         break;
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 36:
      case 38:
      case 39:
      case 40:
      case 41:
      case 44:
      case 45:
      case 46:
      case 47:
      case 49:
      case 50:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 76:
      case 77:
      case 78:
      case 81:
      case 82:
      default:
         this.jj_la1[10] = this.jj_gen;
      }

      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 70:
         this.jj_consume_token(70);
         break;
      default:
         this.jj_la1[11] = this.jj_gen;
      }

      Stat s = Stat.returnstat(el);
      this.L(s, i);
      return s;
   }

   public final Stat Label() throws ParseException {
      this.jj_consume_token(65);
      Token n = this.jj_consume_token(51);
      this.jj_consume_token(65);
      return Stat.labelstat(n.image);
   }

   public final Stat ExprStat() throws ParseException {
      Stat s = null;
      long i = this.LineInfo();
      Exp.PrimaryExp p = this.PrimaryExp();
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 71:
      case 72:
         s = this.Assign(assertvarexp(p));
         break;
      default:
         this.jj_la1[12] = this.jj_gen;
      }

      if (s == null) {
         s = Stat.functioncall(assertfunccall(p));
      }

      this.L(s, i);
      return s;
   }

   public final Stat Assign(Exp.VarExp v0) throws ParseException {
      List<Exp.VarExp> vl = new ArrayList();
      vl.add(v0);
      long i = this.LineInfo();

      while(true) {
         switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
         case 72:
            this.jj_consume_token(72);
            Exp.VarExp ve = this.VarExp();
            vl.add(ve);
            break;
         default:
            this.jj_la1[13] = this.jj_gen;
            this.jj_consume_token(71);
            List el = this.ExpList();
            Stat s = Stat.assignment(vl, el);
            this.L(s, i);
            return s;
         }
      }
   }

   public final Exp.VarExp VarExp() throws ParseException {
      Exp.PrimaryExp p = this.PrimaryExp();
      return assertvarexp(p);
   }

   public final FuncName FuncName() throws ParseException {
      Token n = this.jj_consume_token(51);
      FuncName f = new FuncName(n.image);

      while(true) {
         switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
         case 73:
            this.jj_consume_token(73);
            n = this.jj_consume_token(51);
            f.adddot(n.image);
            break;
         default:
            this.jj_la1[14] = this.jj_gen;
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 74:
               this.jj_consume_token(74);
               n = this.jj_consume_token(51);
               f.method = n.image;
               break;
            default:
               this.jj_la1[15] = this.jj_gen;
            }

            this.L(f, n);
            return f;
         }
      }
   }

   public final Exp.PrimaryExp PrefixExp() throws ParseException {
      long i = this.LineInfo();
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 51:
         Token n = this.jj_consume_token(51);
         Exp.PrimaryExp p = Exp.nameprefix(n.image);
         this.L(p, i);
         return p;
      case 75:
         this.jj_consume_token(75);
         Exp e = this.Exp();
         this.jj_consume_token(76);
         Exp.PrimaryExp p = Exp.parensprefix(e);
         this.L(p, i);
         return p;
      default:
         this.jj_la1[16] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }
   }

   public final Exp.PrimaryExp PrimaryExp() throws ParseException {
      long i = this.LineInfo();

      Exp.PrimaryExp p;
      for(p = this.PrefixExp(); this.jj_2_3(2); p = this.PostfixOp(p)) {
      }

      this.L(p, i);
      return p;
   }

   public final Exp.PrimaryExp PostfixOp(Exp.PrimaryExp lhs) throws ParseException {
      long i = this.LineInfo();
      Token n;
      FuncArgs a;
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 61:
      case 62:
      case 75:
      case 80:
         a = this.FuncArgs();
         Exp.PrimaryExp p = Exp.functionop(lhs, a);
         this.L(p, i);
         return p;
      case 73:
         this.jj_consume_token(73);
         n = this.jj_consume_token(51);
         Exp.PrimaryExp p = Exp.fieldop(lhs, n.image);
         this.L(p, i);
         return p;
      case 74:
         this.jj_consume_token(74);
         n = this.jj_consume_token(51);
         a = this.FuncArgs();
         Exp.PrimaryExp p = Exp.methodop(lhs, n.image, a);
         this.L(p, i);
         return p;
      case 77:
         this.jj_consume_token(77);
         Exp e = this.Exp();
         this.jj_consume_token(78);
         Exp.PrimaryExp p = Exp.indexop(lhs, e);
         this.L(p, i);
         return p;
      default:
         this.jj_la1[17] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }
   }

   public final FuncArgs FuncArgs() throws ParseException {
      List<Exp> el = null;
      long i = this.LineInfo();
      FuncArgs a;
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 61:
      case 62:
         LuaString s = this.Str();
         a = FuncArgs.string(s);
         this.L(a, i);
         return a;
      case 75:
         this.jj_consume_token(75);
         switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
         case 23:
         case 24:
         case 25:
         case 26:
         case 27:
         case 35:
         case 37:
         case 42:
         case 43:
         case 48:
         case 51:
         case 52:
         case 61:
         case 62:
         case 69:
         case 75:
         case 79:
         case 80:
         case 83:
            el = this.ExpList();
            break;
         case 28:
         case 29:
         case 30:
         case 31:
         case 32:
         case 33:
         case 34:
         case 36:
         case 38:
         case 39:
         case 40:
         case 41:
         case 44:
         case 45:
         case 46:
         case 47:
         case 49:
         case 50:
         case 53:
         case 54:
         case 55:
         case 56:
         case 57:
         case 58:
         case 59:
         case 60:
         case 63:
         case 64:
         case 65:
         case 66:
         case 67:
         case 68:
         case 70:
         case 71:
         case 72:
         case 73:
         case 74:
         case 76:
         case 77:
         case 78:
         case 81:
         case 82:
         default:
            this.jj_la1[18] = this.jj_gen;
         }

         this.jj_consume_token(76);
         a = FuncArgs.explist(el);
         this.L(a, i);
         return a;
      case 80:
         TableConstructor tc = this.TableConstructor();
         a = FuncArgs.tableconstructor(tc);
         this.L(a, i);
         return a;
      default:
         this.jj_la1[19] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }
   }

   public final List<Name> NameList() throws ParseException {
      List<Name> l = new ArrayList();
      Token name = this.jj_consume_token(51);
      l.add(new Name(name.image));

      while(this.jj_2_4(2)) {
         this.jj_consume_token(72);
         name = this.jj_consume_token(51);
         l.add(new Name(name.image));
      }

      return l;
   }

   public final List<Exp> ExpList() throws ParseException {
      List<Exp> l = new ArrayList();
      Exp e = this.Exp();
      l.add(e);

      while(true) {
         switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
         case 72:
            this.jj_consume_token(72);
            e = this.Exp();
            l.add(e);
            break;
         default:
            this.jj_la1[20] = this.jj_gen;
            return l;
         }
      }
   }

   public final Exp SimpleExp() throws ParseException {
      long i = this.LineInfo();
      Exp e;
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 61:
      case 62:
         LuaString s = this.Str();
         e = Exp.constant(s);
         this.L(e, i);
         return e;
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 36:
      case 38:
      case 39:
      case 40:
      case 41:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 49:
      case 50:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 76:
      case 77:
      case 78:
      default:
         this.jj_la1[21] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      case 35:
         this.jj_consume_token(35);
         e = Exp.constant(LuaValue.FALSE);
         this.L(e, i);
         return e;
      case 37:
         FuncBody b = this.FunctionCall();
         e = Exp.anonymousfunction(b);
         this.L(e, i);
         return e;
      case 42:
         this.jj_consume_token(42);
         e = Exp.constant(LuaValue.NIL);
         this.L(e, i);
         return e;
      case 48:
         this.jj_consume_token(48);
         e = Exp.constant(LuaValue.TRUE);
         this.L(e, i);
         return e;
      case 51:
      case 75:
         Exp e = this.PrimaryExp();
         return e;
      case 52:
         Token n = this.jj_consume_token(52);
         e = Exp.numberconstant(n.image);
         this.L(e, i);
         return e;
      case 79:
         this.jj_consume_token(79);
         e = Exp.varargs();
         this.L(e, i);
         return e;
      case 80:
         TableConstructor c = this.TableConstructor();
         e = Exp.tableconstructor(c);
         this.L(e, i);
         return e;
      }
   }

   public final LuaString Str() throws ParseException {
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 23:
         this.jj_consume_token(23);
         return Str.longString(this.token.image);
      case 24:
         this.jj_consume_token(24);
         return Str.longString(this.token.image);
      case 25:
         this.jj_consume_token(25);
         return Str.longString(this.token.image);
      case 26:
         this.jj_consume_token(26);
         return Str.longString(this.token.image);
      case 27:
         this.jj_consume_token(27);
         return Str.longString(this.token.image);
      case 61:
         this.jj_consume_token(61);
         return Str.quoteString(this.token.image);
      case 62:
         this.jj_consume_token(62);
         return Str.charString(this.token.image);
      default:
         this.jj_la1[22] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }
   }

   public final Exp Exp() throws ParseException {
      long i = this.LineInfo();
      Exp e;
      Exp s;
      int op;
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 35:
      case 37:
      case 42:
      case 48:
      case 51:
      case 52:
      case 61:
      case 62:
      case 75:
      case 79:
      case 80:
         e = this.SimpleExp();
         break;
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 36:
      case 38:
      case 39:
      case 40:
      case 41:
      case 44:
      case 45:
      case 46:
      case 47:
      case 49:
      case 50:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 76:
      case 77:
      case 78:
      case 81:
      case 82:
      default:
         this.jj_la1[23] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      case 43:
      case 69:
      case 83:
         op = this.Unop();
         s = this.Exp();
         e = Exp.unaryexp(op, s);
      }

      while(this.jj_2_5(2)) {
         op = this.Binop();
         s = this.Exp();
         e = Exp.binaryexp(e, op, s);
      }

      this.L(e, i);
      return e;
   }

   public final FuncBody FunctionCall() throws ParseException {
      long i = this.LineInfo();
      this.jj_consume_token(37);
      FuncBody b = this.FuncBody();
      this.L(b, i);
      return b;
   }

   public final FuncBody FuncBody() throws ParseException {
      ParList pl = null;
      long i = this.LineInfo();
      this.jj_consume_token(75);
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 51:
      case 79:
         pl = this.ParList();
         break;
      default:
         this.jj_la1[24] = this.jj_gen;
      }

      this.jj_consume_token(76);
      Block b = this.Block();
      this.jj_consume_token(34);
      FuncBody f = new FuncBody(pl, b);
      this.L(f, i);
      return f;
   }

   public final ParList ParList() throws ParseException {
      List<Name> l = null;
      boolean v = false;
      long i = this.LineInfo();
      ParList p;
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 51:
         l = this.NameList();
         switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
         case 72:
            this.jj_consume_token(72);
            this.jj_consume_token(79);
            v = true;
            break;
         default:
            this.jj_la1[25] = this.jj_gen;
         }

         p = new ParList(l, v);
         this.L(p, i);
         return p;
      case 79:
         this.jj_consume_token(79);
         p = new ParList((List)null, true);
         this.L(p, i);
         return p;
      default:
         this.jj_la1[26] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }
   }

   public final TableConstructor TableConstructor() throws ParseException {
      TableConstructor c = new TableConstructor();
      List<TableField> l = null;
      long i = this.LineInfo();
      this.jj_consume_token(80);
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 35:
      case 37:
      case 42:
      case 43:
      case 48:
      case 51:
      case 52:
      case 61:
      case 62:
      case 69:
      case 75:
      case 77:
      case 79:
      case 80:
      case 83:
         l = this.FieldList();
         c.fields = l;
         break;
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 36:
      case 38:
      case 39:
      case 40:
      case 41:
      case 44:
      case 45:
      case 46:
      case 47:
      case 49:
      case 50:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 76:
      case 78:
      case 81:
      case 82:
      default:
         this.jj_la1[27] = this.jj_gen;
      }

      this.jj_consume_token(81);
      this.L(c, i);
      return c;
   }

   public final List<TableField> FieldList() throws ParseException {
      List<TableField> l = new ArrayList();
      TableField f = this.Field();
      l.add(f);

      while(this.jj_2_6(2)) {
         this.FieldSep();
         f = this.Field();
         l.add(f);
      }

      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 70:
      case 72:
         this.FieldSep();
         break;
      default:
         this.jj_la1[28] = this.jj_gen;
      }

      return l;
   }

   public final TableField Field() throws ParseException {
      long i = this.LineInfo();
      Exp rhs;
      TableField f;
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 77:
         this.jj_consume_token(77);
         Exp exp = this.Exp();
         this.jj_consume_token(78);
         this.jj_consume_token(71);
         rhs = this.Exp();
         f = TableField.keyedField(exp, rhs);
         this.L(f, i);
         return f;
      default:
         this.jj_la1[29] = this.jj_gen;
         if (this.jj_2_7(2)) {
            Token name = this.jj_consume_token(51);
            this.jj_consume_token(71);
            rhs = this.Exp();
            f = TableField.namedField(name.image, rhs);
            this.L(f, i);
            return f;
         } else {
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 35:
            case 37:
            case 42:
            case 43:
            case 48:
            case 51:
            case 52:
            case 61:
            case 62:
            case 69:
            case 75:
            case 79:
            case 80:
            case 83:
               rhs = this.Exp();
               f = TableField.listField(rhs);
               this.L(f, i);
               return f;
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 36:
            case 38:
            case 39:
            case 40:
            case 41:
            case 44:
            case 45:
            case 46:
            case 47:
            case 49:
            case 50:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 58:
            case 59:
            case 60:
            case 63:
            case 64:
            case 65:
            case 66:
            case 67:
            case 68:
            case 70:
            case 71:
            case 72:
            case 73:
            case 74:
            case 76:
            case 77:
            case 78:
            case 81:
            case 82:
            default:
               this.jj_la1[30] = this.jj_gen;
               this.jj_consume_token(-1);
               throw new ParseException();
            }
         }
      }
   }

   public final void FieldSep() throws ParseException {
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 70:
         this.jj_consume_token(70);
         break;
      case 72:
         this.jj_consume_token(72);
         break;
      default:
         this.jj_la1[31] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }

   }

   public final int Binop() throws ParseException {
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 29:
         this.jj_consume_token(29);
         return 60;
      case 44:
         this.jj_consume_token(44);
         return 59;
      case 82:
         this.jj_consume_token(82);
         return 13;
      case 83:
         this.jj_consume_token(83);
         return 14;
      case 84:
         this.jj_consume_token(84);
         return 15;
      case 85:
         this.jj_consume_token(85);
         return 16;
      case 86:
         this.jj_consume_token(86);
         return 18;
      case 87:
         this.jj_consume_token(87);
         return 17;
      case 88:
         this.jj_consume_token(88);
         return 22;
      case 89:
         this.jj_consume_token(89);
         return 25;
      case 90:
         this.jj_consume_token(90);
         return 26;
      case 91:
         this.jj_consume_token(91);
         return 63;
      case 92:
         this.jj_consume_token(92);
         return 62;
      case 93:
         this.jj_consume_token(93);
         return 24;
      case 94:
         this.jj_consume_token(94);
         return 61;
      default:
         this.jj_la1[32] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }
   }

   public final int Unop() throws ParseException {
      switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
      case 43:
         this.jj_consume_token(43);
         return 20;
      case 69:
         this.jj_consume_token(69);
         return 21;
      case 83:
         this.jj_consume_token(83);
         return 19;
      default:
         this.jj_la1[33] = this.jj_gen;
         this.jj_consume_token(-1);
         throw new ParseException();
      }
   }

   private boolean jj_2_1(int xla) {
      this.jj_la = xla;
      this.jj_lastpos = this.jj_scanpos = this.token;

      boolean var3;
      try {
         boolean var2 = !this.jj_3_1();
         return var2;
      } catch (LuaParser.LookaheadSuccess var7) {
         var3 = true;
      } finally {
         this.jj_save(0, xla);
      }

      return var3;
   }

   private boolean jj_2_2(int xla) {
      this.jj_la = xla;
      this.jj_lastpos = this.jj_scanpos = this.token;

      boolean var3;
      try {
         boolean var2 = !this.jj_3_2();
         return var2;
      } catch (LuaParser.LookaheadSuccess var7) {
         var3 = true;
      } finally {
         this.jj_save(1, xla);
      }

      return var3;
   }

   private boolean jj_2_3(int xla) {
      this.jj_la = xla;
      this.jj_lastpos = this.jj_scanpos = this.token;

      boolean var3;
      try {
         boolean var2 = !this.jj_3_3();
         return var2;
      } catch (LuaParser.LookaheadSuccess var7) {
         var3 = true;
      } finally {
         this.jj_save(2, xla);
      }

      return var3;
   }

   private boolean jj_2_4(int xla) {
      this.jj_la = xla;
      this.jj_lastpos = this.jj_scanpos = this.token;

      boolean var3;
      try {
         boolean var2 = !this.jj_3_4();
         return var2;
      } catch (LuaParser.LookaheadSuccess var7) {
         var3 = true;
      } finally {
         this.jj_save(3, xla);
      }

      return var3;
   }

   private boolean jj_2_5(int xla) {
      this.jj_la = xla;
      this.jj_lastpos = this.jj_scanpos = this.token;

      boolean var3;
      try {
         boolean var2 = !this.jj_3_5();
         return var2;
      } catch (LuaParser.LookaheadSuccess var7) {
         var3 = true;
      } finally {
         this.jj_save(4, xla);
      }

      return var3;
   }

   private boolean jj_2_6(int xla) {
      this.jj_la = xla;
      this.jj_lastpos = this.jj_scanpos = this.token;

      boolean var3;
      try {
         boolean var2 = !this.jj_3_6();
         return var2;
      } catch (LuaParser.LookaheadSuccess var7) {
         var3 = true;
      } finally {
         this.jj_save(5, xla);
      }

      return var3;
   }

   private boolean jj_2_7(int xla) {
      this.jj_la = xla;
      this.jj_lastpos = this.jj_scanpos = this.token;

      boolean var3;
      try {
         boolean var2 = !this.jj_3_7();
         return var2;
      } catch (LuaParser.LookaheadSuccess var7) {
         var3 = true;
      } finally {
         this.jj_save(6, xla);
      }

      return var3;
   }

   private boolean jj_3R_43() {
      return this.jj_3R_58();
   }

   private boolean jj_3R_42() {
      return this.jj_3R_57();
   }

   private boolean jj_3R_41() {
      if (this.jj_scan_token(75)) {
         return true;
      } else {
         Token xsp = this.jj_scanpos;
         if (this.jj_3R_56()) {
            this.jj_scanpos = xsp;
         }

         return this.jj_scan_token(76);
      }
   }

   private boolean jj_3R_38() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_41()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_42()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_43()) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean jj_3_3() {
      return this.jj_3R_10();
   }

   private boolean jj_3R_18() {
      return this.jj_3R_38();
   }

   private boolean jj_3R_17() {
      if (this.jj_scan_token(74)) {
         return true;
      } else {
         return this.jj_scan_token(51);
      }
   }

   private boolean jj_3R_16() {
      if (this.jj_scan_token(77)) {
         return true;
      } else {
         return this.jj_3R_12();
      }
   }

   private boolean jj_3R_35() {
      return this.jj_3R_40();
   }

   private boolean jj_3R_15() {
      if (this.jj_scan_token(73)) {
         return true;
      } else {
         return this.jj_scan_token(51);
      }
   }

   private boolean jj_3R_10() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_15()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_16()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_17()) {
               this.jj_scanpos = xsp;
               if (this.jj_3R_18()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean jj_3R_59() {
      return this.jj_scan_token(37);
   }

   private boolean jj_3_5() {
      if (this.jj_3R_11()) {
         return true;
      } else {
         return this.jj_3R_12();
      }
   }

   private boolean jj_3R_60() {
      return this.jj_3R_70();
   }

   private boolean jj_3R_55() {
      return this.jj_scan_token(69);
   }

   private boolean jj_3R_54() {
      return this.jj_scan_token(43);
   }

   private boolean jj_3R_53() {
      return this.jj_scan_token(83);
   }

   private boolean jj_3R_40() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_53()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_54()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_55()) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean jj_3R_34() {
      return this.jj_3R_39();
   }

   private boolean jj_3R_12() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_34()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_35()) {
            return true;
         }
      }

      return false;
   }

   private boolean jj_3R_73() {
      return this.jj_scan_token(75);
   }

   private boolean jj_3R_33() {
      return this.jj_scan_token(44);
   }

   private boolean jj_3R_72() {
      return this.jj_scan_token(51);
   }

   private boolean jj_3R_70() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_72()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_73()) {
            return true;
         }
      }

      return false;
   }

   private boolean jj_3_2() {
      if (this.jj_scan_token(41)) {
         return true;
      } else {
         return this.jj_scan_token(37);
      }
   }

   private boolean jj_3R_32() {
      return this.jj_scan_token(29);
   }

   private boolean jj_3R_31() {
      return this.jj_scan_token(94);
   }

   private boolean jj_3_4() {
      if (this.jj_scan_token(72)) {
         return true;
      } else {
         return this.jj_scan_token(51);
      }
   }

   private boolean jj_3R_30() {
      return this.jj_scan_token(93);
   }

   private boolean jj_3_1() {
      if (this.jj_scan_token(36)) {
         return true;
      } else if (this.jj_scan_token(51)) {
         return true;
      } else {
         return this.jj_scan_token(71);
      }
   }

   private boolean jj_3R_29() {
      return this.jj_scan_token(92);
   }

   private boolean jj_3R_28() {
      return this.jj_scan_token(91);
   }

   private boolean jj_3R_69() {
      return this.jj_scan_token(27);
   }

   private boolean jj_3R_27() {
      return this.jj_scan_token(90);
   }

   private boolean jj_3R_68() {
      return this.jj_scan_token(26);
   }

   private boolean jj_3R_26() {
      return this.jj_scan_token(89);
   }

   private boolean jj_3R_67() {
      return this.jj_scan_token(25);
   }

   private boolean jj_3R_25() {
      return this.jj_scan_token(88);
   }

   private boolean jj_3R_66() {
      return this.jj_scan_token(24);
   }

   private boolean jj_3R_24() {
      return this.jj_scan_token(87);
   }

   private boolean jj_3R_65() {
      return this.jj_scan_token(23);
   }

   private boolean jj_3R_23() {
      return this.jj_scan_token(86);
   }

   private boolean jj_3R_64() {
      return this.jj_scan_token(62);
   }

   private boolean jj_3R_22() {
      return this.jj_scan_token(85);
   }

   private boolean jj_3R_63() {
      return this.jj_scan_token(61);
   }

   private boolean jj_3R_58() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_63()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_64()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_65()) {
               this.jj_scanpos = xsp;
               if (this.jj_3R_66()) {
                  this.jj_scanpos = xsp;
                  if (this.jj_3R_67()) {
                     this.jj_scanpos = xsp;
                     if (this.jj_3R_68()) {
                        this.jj_scanpos = xsp;
                        if (this.jj_3R_69()) {
                           return true;
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private boolean jj_3R_21() {
      return this.jj_scan_token(84);
   }

   private boolean jj_3R_20() {
      return this.jj_scan_token(83);
   }

   private boolean jj_3R_19() {
      return this.jj_scan_token(82);
   }

   private boolean jj_3R_11() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_19()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_20()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_21()) {
               this.jj_scanpos = xsp;
               if (this.jj_3R_22()) {
                  this.jj_scanpos = xsp;
                  if (this.jj_3R_23()) {
                     this.jj_scanpos = xsp;
                     if (this.jj_3R_24()) {
                        this.jj_scanpos = xsp;
                        if (this.jj_3R_25()) {
                           this.jj_scanpos = xsp;
                           if (this.jj_3R_26()) {
                              this.jj_scanpos = xsp;
                              if (this.jj_3R_27()) {
                                 this.jj_scanpos = xsp;
                                 if (this.jj_3R_28()) {
                                    this.jj_scanpos = xsp;
                                    if (this.jj_3R_29()) {
                                       this.jj_scanpos = xsp;
                                       if (this.jj_3R_30()) {
                                          this.jj_scanpos = xsp;
                                          if (this.jj_3R_31()) {
                                             this.jj_scanpos = xsp;
                                             if (this.jj_3R_32()) {
                                                this.jj_scanpos = xsp;
                                                if (this.jj_3R_33()) {
                                                   return true;
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private boolean jj_3_6() {
      if (this.jj_3R_13()) {
         return true;
      } else {
         return this.jj_3R_14();
      }
   }

   private boolean jj_3R_52() {
      return this.jj_3R_60();
   }

   private boolean jj_3R_51() {
      return this.jj_3R_59();
   }

   private boolean jj_3R_50() {
      return this.jj_3R_57();
   }

   private boolean jj_3R_13() {
      Token xsp = this.jj_scanpos;
      if (this.jj_scan_token(72)) {
         this.jj_scanpos = xsp;
         if (this.jj_scan_token(70)) {
            return true;
         }
      }

      return false;
   }

   private boolean jj_3R_49() {
      return this.jj_scan_token(79);
   }

   private boolean jj_3R_48() {
      return this.jj_3R_58();
   }

   private boolean jj_3R_47() {
      return this.jj_scan_token(52);
   }

   private boolean jj_3R_46() {
      return this.jj_scan_token(35);
   }

   private boolean jj_3R_45() {
      return this.jj_scan_token(48);
   }

   private boolean jj_3R_44() {
      return this.jj_scan_token(42);
   }

   private boolean jj_3R_39() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_44()) {
         this.jj_scanpos = xsp;
         if (this.jj_3R_45()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_46()) {
               this.jj_scanpos = xsp;
               if (this.jj_3R_47()) {
                  this.jj_scanpos = xsp;
                  if (this.jj_3R_48()) {
                     this.jj_scanpos = xsp;
                     if (this.jj_3R_49()) {
                        this.jj_scanpos = xsp;
                        if (this.jj_3R_50()) {
                           this.jj_scanpos = xsp;
                           if (this.jj_3R_51()) {
                              this.jj_scanpos = xsp;
                              if (this.jj_3R_52()) {
                                 return true;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private boolean jj_3R_37() {
      return this.jj_3R_12();
   }

   private boolean jj_3_7() {
      if (this.jj_scan_token(51)) {
         return true;
      } else {
         return this.jj_scan_token(71);
      }
   }

   private boolean jj_3R_14() {
      Token xsp = this.jj_scanpos;
      if (this.jj_3R_36()) {
         this.jj_scanpos = xsp;
         if (this.jj_3_7()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_37()) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean jj_3R_36() {
      return this.jj_scan_token(77);
   }

   private boolean jj_3R_71() {
      return this.jj_3R_14();
   }

   private boolean jj_3R_61() {
      return this.jj_3R_12();
   }

   private boolean jj_3R_62() {
      return this.jj_3R_71();
   }

   private boolean jj_3R_57() {
      if (this.jj_scan_token(80)) {
         return true;
      } else {
         Token xsp = this.jj_scanpos;
         if (this.jj_3R_62()) {
            this.jj_scanpos = xsp;
         }

         return this.jj_scan_token(81);
      }
   }

   private boolean jj_3R_56() {
      return this.jj_3R_61();
   }

   private static void jj_la1_init_0() {
      jj_la1_0 = new int[]{0, -1073741824, 0, 0, 0, -1073741824, 0, 0, 0, 0, 260046848, 0, 0, 0, 0, 0, 0, 260046848, 260046848, 260046848, 0, 260046848, 260046848, 260046848, 0, 0, 0, 260046848, 0, 0, 260046848, 0, 536870912, 0};
   }

   private static void jj_la1_init_1() {
      jj_la1_1 = new int[]{0, 803568, 8192, 0, 0, 278720, 48, 524800, 2, 1, 1612254248, 0, 0, 0, 0, 0, 524288, 1610612736, 1612254248, 1610612736, 0, 1612252200, 1610612736, 1612254248, 524288, 0, 524288, 1612254248, 0, 0, 1612254248, 0, 4096, 2048};
   }

   private static void jj_la1_init_2() {
      jj_la1_2 = new int[]{32, 2114, 0, 256, 128, 66, 0, 2048, 0, 0, 624672, 64, 384, 256, 512, 1024, 2048, 77312, 624672, 67584, 256, 100352, 0, 624672, 32768, 256, 32768, 632864, 320, 8192, 624672, 320, 2147221504, 524320};
   }

   public LuaParser(InputStream stream) {
      this(stream, (String)null);
   }

   public LuaParser(InputStream stream, String encoding) {
      this.jj_la1 = new int[34];
      this.jj_2_rtns = new LuaParser.JJCalls[7];
      this.jj_rescan = false;
      this.jj_gc = 0;
      this.jj_ls = new LuaParser.LookaheadSuccess();
      this.jj_expentries = new ArrayList();
      this.jj_kind = -1;
      this.jj_lasttokens = new int[100];

      try {
         this.jj_input_stream = new SimpleCharStream(stream, encoding, 1, 1);
      } catch (UnsupportedEncodingException var4) {
         throw new RuntimeException(var4.getMessage());
      }

      this.token_source = new LuaParserTokenManager(this.jj_input_stream);
      this.token = new Token();
      this.jj_ntk = -1;
      this.jj_gen = 0;

      int i;
      for(i = 0; i < 34; ++i) {
         this.jj_la1[i] = -1;
      }

      for(i = 0; i < this.jj_2_rtns.length; ++i) {
         this.jj_2_rtns[i] = new LuaParser.JJCalls();
      }

   }

   public void ReInit(InputStream stream) {
      this.ReInit(stream, (String)null);
   }

   public void ReInit(InputStream stream, String encoding) {
      try {
         this.jj_input_stream.ReInit(stream, encoding, 1, 1);
      } catch (UnsupportedEncodingException var4) {
         throw new RuntimeException(var4.getMessage());
      }

      this.token_source.ReInit(this.jj_input_stream);
      this.token = new Token();
      this.jj_ntk = -1;
      this.jj_gen = 0;

      int i;
      for(i = 0; i < 34; ++i) {
         this.jj_la1[i] = -1;
      }

      for(i = 0; i < this.jj_2_rtns.length; ++i) {
         this.jj_2_rtns[i] = new LuaParser.JJCalls();
      }

   }

   public LuaParser(Reader stream) {
      this.jj_la1 = new int[34];
      this.jj_2_rtns = new LuaParser.JJCalls[7];
      this.jj_rescan = false;
      this.jj_gc = 0;
      this.jj_ls = new LuaParser.LookaheadSuccess();
      this.jj_expentries = new ArrayList();
      this.jj_kind = -1;
      this.jj_lasttokens = new int[100];
      this.jj_input_stream = new SimpleCharStream(stream, 1, 1);
      this.token_source = new LuaParserTokenManager(this.jj_input_stream);
      this.token = new Token();
      this.jj_ntk = -1;
      this.jj_gen = 0;

      int i;
      for(i = 0; i < 34; ++i) {
         this.jj_la1[i] = -1;
      }

      for(i = 0; i < this.jj_2_rtns.length; ++i) {
         this.jj_2_rtns[i] = new LuaParser.JJCalls();
      }

   }

   public void ReInit(Reader stream) {
      this.jj_input_stream.ReInit((Reader)stream, 1, 1);
      this.token_source.ReInit(this.jj_input_stream);
      this.token = new Token();
      this.jj_ntk = -1;
      this.jj_gen = 0;

      int i;
      for(i = 0; i < 34; ++i) {
         this.jj_la1[i] = -1;
      }

      for(i = 0; i < this.jj_2_rtns.length; ++i) {
         this.jj_2_rtns[i] = new LuaParser.JJCalls();
      }

   }

   public LuaParser(LuaParserTokenManager tm) {
      this.jj_la1 = new int[34];
      this.jj_2_rtns = new LuaParser.JJCalls[7];
      this.jj_rescan = false;
      this.jj_gc = 0;
      this.jj_ls = new LuaParser.LookaheadSuccess();
      this.jj_expentries = new ArrayList();
      this.jj_kind = -1;
      this.jj_lasttokens = new int[100];
      this.token_source = tm;
      this.token = new Token();
      this.jj_ntk = -1;
      this.jj_gen = 0;

      int i;
      for(i = 0; i < 34; ++i) {
         this.jj_la1[i] = -1;
      }

      for(i = 0; i < this.jj_2_rtns.length; ++i) {
         this.jj_2_rtns[i] = new LuaParser.JJCalls();
      }

   }

   public void ReInit(LuaParserTokenManager tm) {
      this.token_source = tm;
      this.token = new Token();
      this.jj_ntk = -1;
      this.jj_gen = 0;

      int i;
      for(i = 0; i < 34; ++i) {
         this.jj_la1[i] = -1;
      }

      for(i = 0; i < this.jj_2_rtns.length; ++i) {
         this.jj_2_rtns[i] = new LuaParser.JJCalls();
      }

   }

   private Token jj_consume_token(int kind) throws ParseException {
      Token oldToken;
      if ((oldToken = this.token).next != null) {
         this.token = this.token.next;
      } else {
         this.token = this.token.next = this.token_source.getNextToken();
      }

      this.jj_ntk = -1;
      if (this.token.kind != kind) {
         this.token = oldToken;
         this.jj_kind = kind;
         throw this.generateParseException();
      } else {
         ++this.jj_gen;
         if (++this.jj_gc > 100) {
            this.jj_gc = 0;

            for(int i = 0; i < this.jj_2_rtns.length; ++i) {
               for(LuaParser.JJCalls c = this.jj_2_rtns[i]; c != null; c = c.next) {
                  if (c.gen < this.jj_gen) {
                     c.first = null;
                  }
               }
            }
         }

         return this.token;
      }
   }

   private boolean jj_scan_token(int kind) {
      if (this.jj_scanpos == this.jj_lastpos) {
         --this.jj_la;
         if (this.jj_scanpos.next == null) {
            this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken();
         } else {
            this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next;
         }
      } else {
         this.jj_scanpos = this.jj_scanpos.next;
      }

      if (this.jj_rescan) {
         int i = 0;

         Token tok;
         for(tok = this.token; tok != null && tok != this.jj_scanpos; tok = tok.next) {
            ++i;
         }

         if (tok != null) {
            this.jj_add_error_token(kind, i);
         }
      }

      if (this.jj_scanpos.kind != kind) {
         return true;
      } else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) {
         throw this.jj_ls;
      } else {
         return false;
      }
   }

   public final Token getNextToken() {
      if (this.token.next != null) {
         this.token = this.token.next;
      } else {
         this.token = this.token.next = this.token_source.getNextToken();
      }

      this.jj_ntk = -1;
      ++this.jj_gen;
      return this.token;
   }

   public final Token getToken(int index) {
      Token t = this.token;

      for(int i = 0; i < index; ++i) {
         if (t.next != null) {
            t = t.next;
         } else {
            t = t.next = this.token_source.getNextToken();
         }
      }

      return t;
   }

   private int jj_ntk() {
      return (this.jj_nt = this.token.next) == null ? (this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind) : (this.jj_ntk = this.jj_nt.kind);
   }

   private void jj_add_error_token(int kind, int pos) {
      if (pos < 100) {
         if (pos == this.jj_endpos + 1) {
            this.jj_lasttokens[this.jj_endpos++] = kind;
         } else if (this.jj_endpos != 0) {
            this.jj_expentry = new int[this.jj_endpos];

            for(int i = 0; i < this.jj_endpos; ++i) {
               this.jj_expentry[i] = this.jj_lasttokens[i];
            }

            Iterator it = this.jj_expentries.iterator();

            label41:
            while(true) {
               int[] oldentry;
               do {
                  if (!it.hasNext()) {
                     break label41;
                  }

                  oldentry = (int[])it.next();
               } while(oldentry.length != this.jj_expentry.length);

               for(int i = 0; i < this.jj_expentry.length; ++i) {
                  if (oldentry[i] != this.jj_expentry[i]) {
                     continue label41;
                  }
               }

               this.jj_expentries.add(this.jj_expentry);
               break;
            }

            if (pos != 0) {
               this.jj_lasttokens[(this.jj_endpos = pos) - 1] = kind;
            }
         }

      }
   }

   public ParseException generateParseException() {
      this.jj_expentries.clear();
      boolean[] la1tokens = new boolean[95];
      if (this.jj_kind >= 0) {
         la1tokens[this.jj_kind] = true;
         this.jj_kind = -1;
      }

      int i;
      int j;
      for(i = 0; i < 34; ++i) {
         if (this.jj_la1[i] == this.jj_gen) {
            for(j = 0; j < 32; ++j) {
               if ((jj_la1_0[i] & 1 << j) != 0) {
                  la1tokens[j] = true;
               }

               if ((jj_la1_1[i] & 1 << j) != 0) {
                  la1tokens[32 + j] = true;
               }

               if ((jj_la1_2[i] & 1 << j) != 0) {
                  la1tokens[64 + j] = true;
               }
            }
         }
      }

      for(i = 0; i < 95; ++i) {
         if (la1tokens[i]) {
            this.jj_expentry = new int[1];
            this.jj_expentry[0] = i;
            this.jj_expentries.add(this.jj_expentry);
         }
      }

      this.jj_endpos = 0;
      this.jj_rescan_token();
      this.jj_add_error_token(0, 0);
      int[][] exptokseq = new int[this.jj_expentries.size()][];

      for(j = 0; j < this.jj_expentries.size(); ++j) {
         exptokseq[j] = (int[])this.jj_expentries.get(j);
      }

      return new ParseException(this.token, exptokseq, tokenImage);
   }

   public final void enable_tracing() {
   }

   public final void disable_tracing() {
   }

   private void jj_rescan_token() {
      this.jj_rescan = true;

      for(int i = 0; i < 7; ++i) {
         try {
            LuaParser.JJCalls p = this.jj_2_rtns[i];

            do {
               if (p.gen > this.jj_gen) {
                  this.jj_la = p.arg;
                  this.jj_lastpos = this.jj_scanpos = p.first;
                  switch(i) {
                  case 0:
                     this.jj_3_1();
                     break;
                  case 1:
                     this.jj_3_2();
                     break;
                  case 2:
                     this.jj_3_3();
                     break;
                  case 3:
                     this.jj_3_4();
                     break;
                  case 4:
                     this.jj_3_5();
                     break;
                  case 5:
                     this.jj_3_6();
                     break;
                  case 6:
                     this.jj_3_7();
                  }
               }

               p = p.next;
            } while(p != null);
         } catch (LuaParser.LookaheadSuccess var3) {
         }
      }

      this.jj_rescan = false;
   }

   private void jj_save(int index, int xla) {
      LuaParser.JJCalls p;
      for(p = this.jj_2_rtns[index]; p.gen > this.jj_gen; p = p.next) {
         if (p.next == null) {
            p = p.next = new LuaParser.JJCalls();
            break;
         }
      }

      p.gen = this.jj_gen + xla - this.jj_la;
      p.first = this.token;
      p.arg = xla;
   }

   static {
      LuaValue.valueOf(true);
      jj_la1_init_0();
      jj_la1_init_1();
      jj_la1_init_2();
   }

   @Environment(EnvType.CLIENT)
   private static final class LookaheadSuccess extends Error {
   }

   @Environment(EnvType.CLIENT)
   static final class JJCalls {
      int gen;
      Token first;
      int arg;
      LuaParser.JJCalls next;
   }
}
