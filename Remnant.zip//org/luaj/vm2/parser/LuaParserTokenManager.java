package org.luaj.vm2.parser;

import java.io.IOException;
import java.io.PrintStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LuaParserTokenManager implements LuaParserConstants {
   public PrintStream debugStream;
   static final long[] jjbitVec0 = new long[]{-2L, -1L, -1L, -1L};
   static final long[] jjbitVec2 = new long[]{0L, 0L, -1L, -1L};
   static final int[] jjnextStates = new int[]{62, 63, 65, 32, 49, 50, 51, 36, 37, 38, 26, 27, 29, 22, 36, 37, 38, 46, 36, 47, 37, 38, 49, 50, 51, 59, 49, 60, 50, 51, 20, 25, 23, 24, 33, 34, 39, 40, 45, 52, 53, 58, 0, 1, 3};
   public static final String[] jjstrLiteralImages = new String[]{"", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "return", "repeat", "then", "true", "until", "while", null, null, null, null, null, null, null, null, null, null, null, null, null, null, "::", null, null, null, "#", ";", "=", ",", ".", ":", "(", ")", "[", "]", "...", "{", "}", "+", "-", "*", "/", "^", "%", "..", "<", "<=", ">", ">=", "==", "~="};
   public static final String[] lexStateNames = new String[]{"DEFAULT", "IN_COMMENT", "IN_LC0", "IN_LC1", "IN_LC2", "IN_LC3", "IN_LCN", "IN_LS0", "IN_LS1", "IN_LS2", "IN_LS3", "IN_LSN"};
   public static final int[] jjnewLexState = new int[]{-1, -1, -1, -1, -1, -1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
   static final long[] jjtoToken = new long[]{6926536226618998785L, 2147483618L};
   static final long[] jjtoSkip = new long[]{8257598L, 0L};
   static final long[] jjtoSpecial = new long[]{8257536L, 0L};
   static final long[] jjtoMore = new long[]{268566464L, 0L};
   protected SimpleCharStream input_stream;
   private final int[] jjrounds;
   private final int[] jjstateSet;
   private final StringBuffer jjimage;
   private StringBuffer image;
   private int jjimageLen;
   private int lengthOfMatch;
   protected char curChar;
   int curLexState;
   int defaultLexState;
   int jjnewStateCnt;
   int jjround;
   int jjmatchedPos;
   int jjmatchedKind;

   public void setDebugStream(PrintStream ds) {
      this.debugStream = ds;
   }

   private int jjStopAtPos(int pos, int kind) {
      this.jjmatchedKind = kind;
      this.jjmatchedPos = pos;
      return pos + 1;
   }

   private int jjMoveStringLiteralDfa0_2() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_2(262144L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_2(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case ']':
         if ((active0 & 262144L) != 0L) {
            return this.jjStopAtPos(1, 18);
         }

         return 2;
      default:
         return 2;
      }
   }

   private int jjMoveStringLiteralDfa0_11() {
      return this.jjMoveNfa_11(6, 0);
   }

   private int jjMoveNfa_11(int startState, int curPos) {
      int startsAt = 0;
      this.jjnewStateCnt = 7;
      int i = 1;
      this.jjstateSet[0] = startState;
      int kind = Integer.MAX_VALUE;

      while(true) {
         if (++this.jjround == Integer.MAX_VALUE) {
            this.ReInitRounds();
         }

         long var14;
         if (this.curChar < '@') {
            var14 = 1L << this.curChar;

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 0:
               case 1:
                  if (this.curChar == '=') {
                     this.jjCheckNAddTwoStates(1, 2);
                  }
               case 2:
               default:
                  break;
               case 3:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 0;
                  }
                  break;
               case 4:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 3;
                  }
                  break;
               case 5:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 4;
                  }
               }
            } while(i != startsAt);
         } else if (this.curChar < 128) {
            var14 = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 2:
                  if (this.curChar == ']' && kind > 27) {
                     kind = 27;
                  }
                  break;
               case 6:
                  if (this.curChar == ']') {
                     this.jjstateSet[this.jjnewStateCnt++] = 5;
                  }
               }
            } while(i != startsAt);
         } else {
            int hiByte = this.curChar >> 8;
            int i1 = hiByte >> 6;
            long l1 = 1L << (hiByte & 63);
            int i2 = (this.curChar & 255) >> 6;
            long var11 = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               }
            } while(i != startsAt);
         }

         if (kind != Integer.MAX_VALUE) {
            this.jjmatchedKind = kind;
            this.jjmatchedPos = curPos;
            kind = Integer.MAX_VALUE;
         }

         ++curPos;
         if ((i = this.jjnewStateCnt) == (startsAt = 7 - (this.jjnewStateCnt = startsAt))) {
            return curPos;
         }

         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var13) {
            return curPos;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_10() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_10(67108864L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_10(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case '=':
         return this.jjMoveStringLiteralDfa2_10(active0, 67108864L);
      default:
         return 2;
      }
   }

   private int jjMoveStringLiteralDfa2_10(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 2;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 2;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa3_10(active0, 67108864L);
         default:
            return 3;
         }
      }
   }

   private int jjMoveStringLiteralDfa3_10(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 3;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 3;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa4_10(active0, 67108864L);
         default:
            return 4;
         }
      }
   }

   private int jjMoveStringLiteralDfa4_10(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 4;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 4;
         }

         switch(this.curChar) {
         case ']':
            if ((active0 & 67108864L) != 0L) {
               return this.jjStopAtPos(4, 26);
            }

            return 5;
         default:
            return 5;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_9() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_9(33554432L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_9(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case '=':
         return this.jjMoveStringLiteralDfa2_9(active0, 33554432L);
      default:
         return 2;
      }
   }

   private int jjMoveStringLiteralDfa2_9(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 2;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 2;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa3_9(active0, 33554432L);
         default:
            return 3;
         }
      }
   }

   private int jjMoveStringLiteralDfa3_9(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 3;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 3;
         }

         switch(this.curChar) {
         case ']':
            if ((active0 & 33554432L) != 0L) {
               return this.jjStopAtPos(3, 25);
            }

            return 4;
         default:
            return 4;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_8() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_8(16777216L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_8(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case '=':
         return this.jjMoveStringLiteralDfa2_8(active0, 16777216L);
      default:
         return 2;
      }
   }

   private int jjMoveStringLiteralDfa2_8(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 2;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 2;
         }

         switch(this.curChar) {
         case ']':
            if ((active0 & 16777216L) != 0L) {
               return this.jjStopAtPos(2, 24);
            }

            return 3;
         default:
            return 3;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_7() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_7(8388608L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_7(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case ']':
         if ((active0 & 8388608L) != 0L) {
            return this.jjStopAtPos(1, 23);
         }

         return 2;
      default:
         return 2;
      }
   }

   private final int jjStopStringLiteralDfa_0(int pos, long active0, long active1) {
      switch(pos) {
      case 0:
         if ((active0 & 30720L) == 0L && (active1 & 8192L) == 0L) {
            if ((active1 & 16810496L) != 0L) {
               return 31;
            }

            if ((active0 & 2251799276814336L) != 0L) {
               this.jjmatchedKind = 51;
               return 17;
            }

            if ((active0 & 66496L) == 0L && (active1 & 524288L) == 0L) {
               return -1;
            }

            return 7;
         }

         return 14;
      case 1:
         if ((active0 & 66496L) != 0L) {
            return 6;
         } else if ((active0 & 28672L) != 0L) {
            return 13;
         } else if ((active0 & 19243600969728L) != 0L) {
            return 17;
         } else {
            if ((active0 & 2232555675844608L) != 0L) {
               if (this.jjmatchedPos != 1) {
                  this.jjmatchedKind = 51;
                  this.jjmatchedPos = 1;
               }

               return 17;
            }

            return -1;
         }
      case 2:
         if ((active0 & 2219275100094464L) != 0L) {
            this.jjmatchedKind = 51;
            this.jjmatchedPos = 2;
            return 17;
         } else if ((active0 & 24576L) != 0L) {
            return 12;
         } else if ((active0 & 960L) != 0L) {
            return 5;
         } else {
            if ((active0 & 13280575750144L) != 0L) {
               return 17;
            }

            return -1;
         }
      case 3:
         if ((active0 & 896L) != 0L) {
            return 4;
         } else if ((active0 & 1796774872219648L) != 0L) {
            if (this.jjmatchedPos != 3) {
               this.jjmatchedKind = 51;
               this.jjmatchedPos = 3;
            }

            return 17;
         } else if ((active0 & 422500227874816L) != 0L) {
            return 17;
         } else {
            if ((active0 & 16384L) != 0L) {
               return 9;
            }

            return -1;
         }
      case 4:
         if ((active0 & 105699145154560L) != 0L) {
            this.jjmatchedKind = 51;
            this.jjmatchedPos = 4;
            return 17;
         } else if ((active0 & 768L) != 0L) {
            return 3;
         } else {
            if ((active0 & 1691084316999680L) != 0L) {
               return 17;
            }

            return -1;
         }
      case 5:
         if ((active0 & 512L) != 0L) {
            return 0;
         } else if ((active0 & 105561706201088L) != 0L) {
            return 17;
         } else {
            if ((active0 & 137438953472L) != 0L) {
               this.jjmatchedKind = 51;
               this.jjmatchedPos = 5;
               return 17;
            }

            return -1;
         }
      case 6:
         if ((active0 & 137438953472L) != 0L) {
            this.jjmatchedKind = 51;
            this.jjmatchedPos = 6;
            return 17;
         }

         return -1;
      default:
         return -1;
      }
   }

   private final int jjStartNfa_0(int pos, long active0, long active1) {
      return this.jjMoveNfa_0(this.jjStopStringLiteralDfa_0(pos, active0, active1), pos + 1);
   }

   private int jjMoveStringLiteralDfa0_0() {
      switch(this.curChar) {
      case '#':
         return this.jjStopAtPos(0, 69);
      case '$':
      case '&':
      case '\'':
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
      case '?':
      case '@':
      case 'A':
      case 'B':
      case 'C':
      case 'D':
      case 'E':
      case 'F':
      case 'G':
      case 'H':
      case 'I':
      case 'J':
      case 'K':
      case 'L':
      case 'M':
      case 'N':
      case 'O':
      case 'P':
      case 'Q':
      case 'R':
      case 'S':
      case 'T':
      case 'U':
      case 'V':
      case 'W':
      case 'X':
      case 'Y':
      case 'Z':
      case '\\':
      case '_':
      case '`':
      case 'c':
      case 'h':
      case 'j':
      case 'k':
      case 'm':
      case 'p':
      case 'q':
      case 's':
      case 'v':
      case 'x':
      case 'y':
      case 'z':
      case '|':
      default:
         return this.jjMoveNfa_0(8, 0);
      case '%':
         return this.jjStopAtPos(0, 87);
      case '(':
         return this.jjStopAtPos(0, 75);
      case ')':
         return this.jjStopAtPos(0, 76);
      case '*':
         return this.jjStopAtPos(0, 84);
      case '+':
         return this.jjStopAtPos(0, 82);
      case ',':
         return this.jjStopAtPos(0, 72);
      case '-':
         this.jjmatchedKind = 83;
         return this.jjMoveStringLiteralDfa1_0(66496L, 0L);
      case '.':
         this.jjmatchedKind = 73;
         return this.jjMoveStringLiteralDfa1_0(0L, 16809984L);
      case '/':
         return this.jjStopAtPos(0, 85);
      case ':':
         this.jjmatchedKind = 74;
         return this.jjMoveStringLiteralDfa1_0(0L, 2L);
      case ';':
         return this.jjStopAtPos(0, 70);
      case '<':
         this.jjmatchedKind = 89;
         return this.jjMoveStringLiteralDfa1_0(0L, 67108864L);
      case '=':
         this.jjmatchedKind = 71;
         return this.jjMoveStringLiteralDfa1_0(0L, 536870912L);
      case '>':
         this.jjmatchedKind = 91;
         return this.jjMoveStringLiteralDfa1_0(0L, 268435456L);
      case '[':
         this.jjmatchedKind = 77;
         return this.jjMoveStringLiteralDfa1_0(30720L, 0L);
      case ']':
         return this.jjStopAtPos(0, 78);
      case '^':
         return this.jjStopAtPos(0, 86);
      case 'a':
         return this.jjMoveStringLiteralDfa1_0(536870912L, 0L);
      case 'b':
         return this.jjMoveStringLiteralDfa1_0(1073741824L, 0L);
      case 'd':
         return this.jjMoveStringLiteralDfa1_0(2147483648L, 0L);
      case 'e':
         return this.jjMoveStringLiteralDfa1_0(30064771072L, 0L);
      case 'f':
         return this.jjMoveStringLiteralDfa1_0(240518168576L, 0L);
      case 'g':
         return this.jjMoveStringLiteralDfa1_0(274877906944L, 0L);
      case 'i':
         return this.jjMoveStringLiteralDfa1_0(1649267441664L, 0L);
      case 'l':
         return this.jjMoveStringLiteralDfa1_0(2199023255552L, 0L);
      case 'n':
         return this.jjMoveStringLiteralDfa1_0(13194139533312L, 0L);
      case 'o':
         return this.jjMoveStringLiteralDfa1_0(17592186044416L, 0L);
      case 'r':
         return this.jjMoveStringLiteralDfa1_0(105553116266496L, 0L);
      case 't':
         return this.jjMoveStringLiteralDfa1_0(422212465065984L, 0L);
      case 'u':
         return this.jjMoveStringLiteralDfa1_0(562949953421312L, 0L);
      case 'w':
         return this.jjMoveStringLiteralDfa1_0(1125899906842624L, 0L);
      case '{':
         return this.jjStopAtPos(0, 80);
      case '}':
         return this.jjStopAtPos(0, 81);
      case '~':
         return this.jjMoveStringLiteralDfa1_0(0L, 1073741824L);
      }
   }

   private int jjMoveStringLiteralDfa1_0(long active0, long active1) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var6) {
         this.jjStopStringLiteralDfa_0(0, active0, active1);
         return 1;
      }

      switch(this.curChar) {
      case '-':
         if ((active0 & 65536L) != 0L) {
            this.jjmatchedKind = 16;
            this.jjmatchedPos = 1;
         }

         return this.jjMoveStringLiteralDfa2_0(active0, 960L, active1, 0L);
      case '.':
         if ((active1 & 16777216L) != 0L) {
            this.jjmatchedKind = 88;
            this.jjmatchedPos = 1;
         }

         return this.jjMoveStringLiteralDfa2_0(active0, 0L, active1, 32768L);
      case ':':
         if ((active1 & 2L) != 0L) {
            return this.jjStopAtPos(1, 65);
         }
         break;
      case '=':
         if ((active1 & 67108864L) != 0L) {
            return this.jjStopAtPos(1, 90);
         }

         if ((active1 & 268435456L) != 0L) {
            return this.jjStopAtPos(1, 92);
         }

         if ((active1 & 536870912L) != 0L) {
            return this.jjStopAtPos(1, 93);
         }

         if ((active1 & 1073741824L) != 0L) {
            return this.jjStopAtPos(1, 94);
         }

         return this.jjMoveStringLiteralDfa2_0(active0, 28672L, active1, 0L);
      case '[':
         if ((active0 & 2048L) != 0L) {
            return this.jjStopAtPos(1, 11);
         }
         break;
      case 'a':
         return this.jjMoveStringLiteralDfa2_0(active0, 34359738368L, active1, 0L);
      case 'e':
         return this.jjMoveStringLiteralDfa2_0(active0, 105553116266496L, active1, 0L);
      case 'f':
         if ((active0 & 549755813888L) != 0L) {
            return this.jjStartNfaWithStates_0(1, 39, 17);
         }
         break;
      case 'h':
         return this.jjMoveStringLiteralDfa2_0(active0, 1266637395197952L, active1, 0L);
      case 'i':
         return this.jjMoveStringLiteralDfa2_0(active0, 4398046511104L, active1, 0L);
      case 'l':
         return this.jjMoveStringLiteralDfa2_0(active0, 12884901888L, active1, 0L);
      case 'n':
         if ((active0 & 1099511627776L) != 0L) {
            return this.jjStartNfaWithStates_0(1, 40, 17);
         }

         return this.jjMoveStringLiteralDfa2_0(active0, 562967670161408L, active1, 0L);
      case 'o':
         if ((active0 & 2147483648L) != 0L) {
            return this.jjStartNfaWithStates_0(1, 31, 17);
         }

         return this.jjMoveStringLiteralDfa2_0(active0, 11338713661440L, active1, 0L);
      case 'r':
         if ((active0 & 17592186044416L) != 0L) {
            return this.jjStartNfaWithStates_0(1, 44, 17);
         }

         return this.jjMoveStringLiteralDfa2_0(active0, 281476050452480L, active1, 0L);
      case 'u':
         return this.jjMoveStringLiteralDfa2_0(active0, 137438953472L, active1, 0L);
      }

      return this.jjStartNfa_0(0, active0, active1);
   }

   private int jjMoveStringLiteralDfa2_0(long old0, long active0, long old1, long active1) {
      if (((active0 &= old0) | (active1 &= old1)) == 0L) {
         return this.jjStartNfa_0(0, old0, old1);
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var10) {
            this.jjStopStringLiteralDfa_0(1, active0, active1);
            return 2;
         }

         switch(this.curChar) {
         case '.':
            if ((active1 & 32768L) != 0L) {
               return this.jjStopAtPos(2, 79);
            }
            break;
         case '=':
            return this.jjMoveStringLiteralDfa3_0(active0, 24576L, active1, 0L);
         case '[':
            if ((active0 & 4096L) != 0L) {
               return this.jjStopAtPos(2, 12);
            }

            return this.jjMoveStringLiteralDfa3_0(active0, 960L, active1, 0L);
         case 'c':
            return this.jjMoveStringLiteralDfa3_0(active0, 2199023255552L, active1, 0L);
         case 'd':
            if ((active0 & 536870912L) != 0L) {
               return this.jjStartNfaWithStates_0(2, 29, 17);
            }

            if ((active0 & 17179869184L) != 0L) {
               return this.jjStartNfaWithStates_0(2, 34, 17);
            }
            break;
         case 'e':
            return this.jjMoveStringLiteralDfa3_0(active0, 140738562097152L, active1, 0L);
         case 'i':
            return this.jjMoveStringLiteralDfa3_0(active0, 1125899906842624L, active1, 0L);
         case 'l':
            if ((active0 & 4398046511104L) != 0L) {
               return this.jjStartNfaWithStates_0(2, 42, 17);
            }

            return this.jjMoveStringLiteralDfa3_0(active0, 34359738368L, active1, 0L);
         case 'n':
            return this.jjMoveStringLiteralDfa3_0(active0, 137438953472L, active1, 0L);
         case 'p':
            return this.jjMoveStringLiteralDfa3_0(active0, 70368744177664L, active1, 0L);
         case 'r':
            if ((active0 & 68719476736L) != 0L) {
               return this.jjStartNfaWithStates_0(2, 36, 17);
            }
            break;
         case 's':
            return this.jjMoveStringLiteralDfa3_0(active0, 12884901888L, active1, 0L);
         case 't':
            if ((active0 & 8796093022208L) != 0L) {
               return this.jjStartNfaWithStates_0(2, 43, 17);
            }

            return this.jjMoveStringLiteralDfa3_0(active0, 598409203417088L, active1, 0L);
         case 'u':
            return this.jjMoveStringLiteralDfa3_0(active0, 281474976710656L, active1, 0L);
         }

         return this.jjStartNfa_0(1, active0, active1);
      }
   }

   private int jjMoveStringLiteralDfa3_0(long old0, long active0, long old1, long active1) {
      if (((active0 &= old0) | active1 & old1) == 0L) {
         return this.jjStartNfa_0(1, old0, old1);
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var10) {
            this.jjStopStringLiteralDfa_0(2, active0, 0L);
            return 3;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa4_0(active0, 17280L);
         case '[':
            if ((active0 & 64L) != 0L) {
               return this.jjStopAtPos(3, 6);
            }

            if ((active0 & 8192L) != 0L) {
               return this.jjStopAtPos(3, 13);
            }
            break;
         case 'a':
            return this.jjMoveStringLiteralDfa4_0(active0, 2200096997376L);
         case 'c':
            return this.jjMoveStringLiteralDfa4_0(active0, 137438953472L);
         case 'e':
            if ((active0 & 4294967296L) != 0L) {
               this.jjmatchedKind = 32;
               this.jjmatchedPos = 3;
            } else if ((active0 & 281474976710656L) != 0L) {
               return this.jjStartNfaWithStates_0(3, 48, 17);
            }

            return this.jjMoveStringLiteralDfa4_0(active0, 70377334112256L);
         case 'i':
            return this.jjMoveStringLiteralDfa4_0(active0, 562949953421312L);
         case 'l':
            return this.jjMoveStringLiteralDfa4_0(active0, 1125899906842624L);
         case 'n':
            if ((active0 & 140737488355328L) != 0L) {
               return this.jjStartNfaWithStates_0(3, 47, 17);
            }
            break;
         case 'o':
            if ((active0 & 274877906944L) != 0L) {
               return this.jjStartNfaWithStates_0(3, 38, 17);
            }
            break;
         case 's':
            return this.jjMoveStringLiteralDfa4_0(active0, 34359738368L);
         case 'u':
            return this.jjMoveStringLiteralDfa4_0(active0, 35184372088832L);
         }

         return this.jjStartNfa_0(2, active0, 0L);
      }
   }

   private int jjMoveStringLiteralDfa4_0(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return this.jjStartNfa_0(2, old0, 0L);
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            this.jjStopStringLiteralDfa_0(3, active0, 0L);
            return 4;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa5_0(active0, 768L);
         case '[':
            if ((active0 & 128L) != 0L) {
               return this.jjStopAtPos(4, 7);
            }

            if ((active0 & 16384L) != 0L) {
               return this.jjStopAtPos(4, 14);
            }
            break;
         case 'a':
            return this.jjMoveStringLiteralDfa5_0(active0, 70368744177664L);
         case 'e':
            if ((active0 & 34359738368L) != 0L) {
               return this.jjStartNfaWithStates_0(4, 35, 17);
            }

            if ((active0 & 1125899906842624L) != 0L) {
               return this.jjStartNfaWithStates_0(4, 50, 17);
            }
            break;
         case 'i':
            return this.jjMoveStringLiteralDfa5_0(active0, 8589934592L);
         case 'k':
            if ((active0 & 1073741824L) != 0L) {
               return this.jjStartNfaWithStates_0(4, 30, 17);
            }
            break;
         case 'l':
            if ((active0 & 2199023255552L) != 0L) {
               return this.jjStartNfaWithStates_0(4, 41, 17);
            }

            if ((active0 & 562949953421312L) != 0L) {
               return this.jjStartNfaWithStates_0(4, 49, 17);
            }
            break;
         case 'r':
            return this.jjMoveStringLiteralDfa5_0(active0, 35184372088832L);
         case 't':
            return this.jjMoveStringLiteralDfa5_0(active0, 137438953472L);
         }

         return this.jjStartNfa_0(3, active0, 0L);
      }
   }

   private int jjMoveStringLiteralDfa5_0(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return this.jjStartNfa_0(3, old0, 0L);
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            this.jjStopStringLiteralDfa_0(4, active0, 0L);
            return 5;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa6_0(active0, 512L);
         case '[':
            if ((active0 & 256L) != 0L) {
               return this.jjStopAtPos(5, 8);
            }
            break;
         case 'f':
            if ((active0 & 8589934592L) != 0L) {
               return this.jjStartNfaWithStates_0(5, 33, 17);
            }
            break;
         case 'i':
            return this.jjMoveStringLiteralDfa6_0(active0, 137438953472L);
         case 'n':
            if ((active0 & 35184372088832L) != 0L) {
               return this.jjStartNfaWithStates_0(5, 45, 17);
            }
            break;
         case 't':
            if ((active0 & 70368744177664L) != 0L) {
               return this.jjStartNfaWithStates_0(5, 46, 17);
            }
         }

         return this.jjStartNfa_0(4, active0, 0L);
      }
   }

   private int jjMoveStringLiteralDfa6_0(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return this.jjStartNfa_0(4, old0, 0L);
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            this.jjStopStringLiteralDfa_0(5, active0, 0L);
            return 6;
         }

         switch(this.curChar) {
         case '[':
            if ((active0 & 512L) != 0L) {
               return this.jjStopAtPos(6, 9);
            }
         default:
            return this.jjStartNfa_0(5, active0, 0L);
         case 'o':
            return this.jjMoveStringLiteralDfa7_0(active0, 137438953472L);
         }
      }
   }

   private int jjMoveStringLiteralDfa7_0(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return this.jjStartNfa_0(5, old0, 0L);
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            this.jjStopStringLiteralDfa_0(6, active0, 0L);
            return 7;
         }

         switch(this.curChar) {
         case 'n':
            if ((active0 & 137438953472L) != 0L) {
               return this.jjStartNfaWithStates_0(7, 37, 17);
            }
         default:
            return this.jjStartNfa_0(6, active0, 0L);
         }
      }
   }

   private int jjStartNfaWithStates_0(int pos, int kind, int state) {
      this.jjmatchedKind = kind;
      this.jjmatchedPos = pos;

      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var5) {
         return pos + 1;
      }

      return this.jjMoveNfa_0(state, pos + 1);
   }

   private int jjMoveNfa_0(int startState, int curPos) {
      int startsAt = 0;
      this.jjnewStateCnt = 66;
      int i = 1;
      this.jjstateSet[0] = startState;
      int kind = Integer.MAX_VALUE;

      while(true) {
         if (++this.jjround == Integer.MAX_VALUE) {
            this.ReInitRounds();
         }

         long l;
         if (this.curChar < '@') {
            l = 1L << this.curChar;

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 0:
               case 1:
                  if (this.curChar == '=') {
                     this.jjCheckNAddTwoStates(1, 2);
                  }
               case 2:
               case 6:
               case 11:
               case 15:
               case 16:
               case 19:
               case 22:
               case 32:
               case 38:
               case 40:
               case 51:
               case 53:
               default:
                  break;
               case 3:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 0;
                  }
                  break;
               case 4:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 3;
                  }
                  break;
               case 5:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 4;
                  }
                  break;
               case 7:
                  if (this.curChar == '-') {
                     this.jjstateSet[this.jjnewStateCnt++] = 6;
                  }
                  break;
               case 8:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddStates(0, 3);
                  } else if (this.curChar == '\'') {
                     this.jjCheckNAddStates(4, 6);
                  } else if (this.curChar == '"') {
                     this.jjCheckNAddStates(7, 9);
                  } else if (this.curChar == '.') {
                     this.jjCheckNAdd(31);
                  } else if (this.curChar == '-') {
                     this.jjstateSet[this.jjnewStateCnt++] = 7;
                  }

                  if (this.curChar == '0') {
                     this.jjstateSet[this.jjnewStateCnt++] = 19;
                  }
                  break;
               case 9:
               case 10:
                  if (this.curChar == '=') {
                     this.jjCheckNAddTwoStates(10, 11);
                  }
                  break;
               case 12:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 9;
                  }
                  break;
               case 13:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 12;
                  }
                  break;
               case 14:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 13;
                  }
                  break;
               case 17:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 51) {
                        kind = 51;
                     }

                     this.jjstateSet[this.jjnewStateCnt++] = 17;
                  }
                  break;
               case 18:
                  if (this.curChar == '0') {
                     this.jjstateSet[this.jjnewStateCnt++] = 19;
                  }
                  break;
               case 20:
                  if (this.curChar == '.') {
                     this.jjCheckNAdd(21);
                  }
                  break;
               case 21:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(21, 22);
                  }
                  break;
               case 23:
                  if ((43980465111040L & l) != 0L) {
                     this.jjCheckNAdd(24);
                  }
                  break;
               case 24:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAdd(24);
                  }
                  break;
               case 25:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddStates(10, 13);
                  }
                  break;
               case 26:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddTwoStates(26, 27);
                  }
                  break;
               case 27:
                  if (this.curChar == '.') {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(28, 22);
                  }
                  break;
               case 28:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(28, 22);
                  }
                  break;
               case 29:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(29, 22);
                  }
                  break;
               case 30:
                  if (this.curChar == '.') {
                     this.jjCheckNAdd(31);
                  }
                  break;
               case 31:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(31, 32);
                  }
                  break;
               case 33:
                  if ((43980465111040L & l) != 0L) {
                     this.jjCheckNAdd(34);
                  }
                  break;
               case 34:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAdd(34);
                  }
                  break;
               case 35:
                  if (this.curChar == '"') {
                     this.jjCheckNAddStates(7, 9);
                  }
                  break;
               case 36:
                  if ((-17179869185L & l) != 0L) {
                     this.jjCheckNAddStates(7, 9);
                  }
                  break;
               case 37:
                  if (this.curChar == '"' && kind > 61) {
                     kind = 61;
                  }
                  break;
               case 39:
                  this.jjCheckNAddStates(7, 9);
                  break;
               case 41:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 42;
                  }
                  break;
               case 42:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 43;
                  }
                  break;
               case 43:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 44;
                  }
                  break;
               case 44:
               case 47:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddStates(7, 9);
                  }
                  break;
               case 45:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddStates(14, 17);
                  }
                  break;
               case 46:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddStates(18, 21);
                  }
                  break;
               case 48:
                  if (this.curChar == '\'') {
                     this.jjCheckNAddStates(4, 6);
                  }
                  break;
               case 49:
                  if ((-549755813889L & l) != 0L) {
                     this.jjCheckNAddStates(4, 6);
                  }
                  break;
               case 50:
                  if (this.curChar == '\'' && kind > 62) {
                     kind = 62;
                  }
                  break;
               case 52:
                  this.jjCheckNAddStates(4, 6);
                  break;
               case 54:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 55;
                  }
                  break;
               case 55:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 56;
                  }
                  break;
               case 56:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 57;
                  }
                  break;
               case 57:
               case 60:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddStates(4, 6);
                  }
                  break;
               case 58:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddStates(22, 25);
                  }
                  break;
               case 59:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddStates(26, 29);
                  }
                  break;
               case 61:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddStates(0, 3);
                  }
                  break;
               case 62:
                  if ((287948901175001088L & l) != 0L) {
                     this.jjCheckNAddTwoStates(62, 63);
                  }
                  break;
               case 63:
                  if (this.curChar == '.') {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(64, 32);
                  }
                  break;
               case 64:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(64, 32);
                  }
                  break;
               case 65:
                  if ((287948901175001088L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(65, 32);
                  }
               }
            } while(i != startsAt);
         } else if (this.curChar < 128) {
            l = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 2:
                  if (this.curChar == '[' && kind > 10) {
                     kind = 10;
                  }
               case 3:
               case 4:
               case 5:
               case 7:
               case 9:
               case 10:
               case 12:
               case 13:
               case 14:
               case 18:
               case 20:
               case 23:
               case 24:
               case 27:
               case 30:
               case 31:
               case 33:
               case 34:
               case 35:
               case 37:
               case 45:
               case 46:
               case 47:
               case 48:
               case 50:
               default:
                  break;
               case 6:
                  if (this.curChar == '[') {
                     this.jjstateSet[this.jjnewStateCnt++] = 5;
                  }
                  break;
               case 8:
                  if ((576460745995190270L & l) != 0L) {
                     if (kind > 51) {
                        kind = 51;
                     }

                     this.jjCheckNAdd(17);
                  } else if (this.curChar == '[') {
                     this.jjstateSet[this.jjnewStateCnt++] = 14;
                  }
                  break;
               case 11:
                  if (this.curChar == '[' && kind > 15) {
                     kind = 15;
                  }
                  break;
               case 15:
                  if (this.curChar == '[') {
                     this.jjstateSet[this.jjnewStateCnt++] = 14;
                  }
                  break;
               case 16:
               case 17:
                  if ((576460745995190270L & l) != 0L) {
                     if (kind > 51) {
                        kind = 51;
                     }

                     this.jjCheckNAdd(17);
                  }
                  break;
               case 19:
                  if ((72057594054705152L & l) != 0L) {
                     this.jjAddStates(30, 31);
                  }
                  break;
               case 21:
                  if ((541165879422L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(21, 22);
                  }
                  break;
               case 22:
                  if ((281612415729696L & l) != 0L) {
                     this.jjAddStates(32, 33);
                  }
                  break;
               case 25:
                  if ((541165879422L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddStates(10, 13);
                  }
                  break;
               case 26:
                  if ((541165879422L & l) != 0L) {
                     this.jjCheckNAddTwoStates(26, 27);
                  }
                  break;
               case 28:
                  if ((541165879422L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(28, 22);
                  }
                  break;
               case 29:
                  if ((541165879422L & l) != 0L) {
                     if (kind > 52) {
                        kind = 52;
                     }

                     this.jjCheckNAddTwoStates(29, 22);
                  }
                  break;
               case 32:
                  if ((137438953504L & l) != 0L) {
                     this.jjAddStates(34, 35);
                  }
                  break;
               case 36:
                  if ((-268435457L & l) != 0L) {
                     this.jjCheckNAddStates(7, 9);
                  }
                  break;
               case 38:
                  if (this.curChar == '\\') {
                     this.jjAddStates(36, 38);
                  }
                  break;
               case 39:
                  this.jjCheckNAddStates(7, 9);
                  break;
               case 40:
                  if (this.curChar == 'u') {
                     this.jjstateSet[this.jjnewStateCnt++] = 41;
                  }
                  break;
               case 41:
                  if ((541165879422L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 42;
                  }
                  break;
               case 42:
                  if ((541165879422L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 43;
                  }
                  break;
               case 43:
                  if ((541165879422L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 44;
                  }
                  break;
               case 44:
                  if ((541165879422L & l) != 0L) {
                     this.jjCheckNAddStates(7, 9);
                  }
                  break;
               case 49:
                  if ((-268435457L & l) != 0L) {
                     this.jjCheckNAddStates(4, 6);
                  }
                  break;
               case 51:
                  if (this.curChar == '\\') {
                     this.jjAddStates(39, 41);
                  }
                  break;
               case 52:
                  this.jjCheckNAddStates(4, 6);
                  break;
               case 53:
                  if (this.curChar == 'u') {
                     this.jjstateSet[this.jjnewStateCnt++] = 54;
                  }
                  break;
               case 54:
                  if ((541165879422L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 55;
                  }
                  break;
               case 55:
                  if ((541165879422L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 56;
                  }
                  break;
               case 56:
                  if ((541165879422L & l) != 0L) {
                     this.jjstateSet[this.jjnewStateCnt++] = 57;
                  }
                  break;
               case 57:
                  if ((541165879422L & l) != 0L) {
                     this.jjCheckNAddStates(4, 6);
                  }
               }
            } while(i != startsAt);
         } else {
            int hiByte = this.curChar >> 8;
            int i1 = hiByte >> 6;
            long l1 = 1L << (hiByte & 63);
            int i2 = (this.curChar & 255) >> 6;
            long l2 = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 36:
               case 39:
                  if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
                     this.jjCheckNAddStates(7, 9);
                  }
                  break;
               case 49:
               case 52:
                  if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
                     this.jjCheckNAddStates(4, 6);
                  }
               }
            } while(i != startsAt);
         }

         if (kind != Integer.MAX_VALUE) {
            this.jjmatchedKind = kind;
            this.jjmatchedPos = curPos;
            kind = Integer.MAX_VALUE;
         }

         ++curPos;
         if ((i = this.jjnewStateCnt) == (startsAt = 66 - (this.jjnewStateCnt = startsAt))) {
            return curPos;
         }

         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var13) {
            return curPos;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_1() {
      return this.jjMoveNfa_1(4, 0);
   }

   private int jjMoveNfa_1(int startState, int curPos) {
      int startsAt = 0;
      this.jjnewStateCnt = 4;
      int i = 1;
      this.jjstateSet[0] = startState;
      int kind = Integer.MAX_VALUE;

      while(true) {
         if (++this.jjround == Integer.MAX_VALUE) {
            this.ReInitRounds();
         }

         long l;
         if (this.curChar < '@') {
            l = 1L << this.curChar;

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 0:
                  if ((-9217L & l) != 0L) {
                     kind = 17;
                     this.jjCheckNAddStates(42, 44);
                  }
                  break;
               case 1:
                  if ((9216L & l) != 0L && kind > 17) {
                     kind = 17;
                  }
                  break;
               case 2:
                  if (this.curChar == '\n' && kind > 17) {
                     kind = 17;
                  }
                  break;
               case 3:
                  if (this.curChar == '\r') {
                     this.jjstateSet[this.jjnewStateCnt++] = 2;
                  }
                  break;
               case 4:
                  if ((-9217L & l) != 0L) {
                     if (kind > 17) {
                        kind = 17;
                     }

                     this.jjCheckNAddStates(42, 44);
                  } else if ((9216L & l) != 0L && kind > 17) {
                     kind = 17;
                  }

                  if (this.curChar == '\r') {
                     this.jjstateSet[this.jjnewStateCnt++] = 2;
                  }
               }
            } while(i != startsAt);
         } else if (this.curChar < 128) {
            l = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 0:
               case 4:
                  kind = 17;
                  this.jjCheckNAddStates(42, 44);
               }
            } while(i != startsAt);
         } else {
            int hiByte = this.curChar >> 8;
            int i1 = hiByte >> 6;
            long l1 = 1L << (hiByte & 63);
            int i2 = (this.curChar & 255) >> 6;
            long l2 = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 0:
               case 4:
                  if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
                     if (kind > 17) {
                        kind = 17;
                     }

                     this.jjCheckNAddStates(42, 44);
                  }
               }
            } while(i != startsAt);
         }

         if (kind != Integer.MAX_VALUE) {
            this.jjmatchedKind = kind;
            this.jjmatchedPos = curPos;
            kind = Integer.MAX_VALUE;
         }

         ++curPos;
         if ((i = this.jjnewStateCnt) == (startsAt = 4 - (this.jjnewStateCnt = startsAt))) {
            return curPos;
         }

         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var13) {
            return curPos;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_6() {
      return this.jjMoveNfa_6(6, 0);
   }

   private int jjMoveNfa_6(int startState, int curPos) {
      int startsAt = 0;
      this.jjnewStateCnt = 7;
      int i = 1;
      this.jjstateSet[0] = startState;
      int kind = Integer.MAX_VALUE;

      while(true) {
         if (++this.jjround == Integer.MAX_VALUE) {
            this.ReInitRounds();
         }

         long var14;
         if (this.curChar < '@') {
            var14 = 1L << this.curChar;

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 0:
               case 1:
                  if (this.curChar == '=') {
                     this.jjCheckNAddTwoStates(1, 2);
                  }
               case 2:
               default:
                  break;
               case 3:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 0;
                  }
                  break;
               case 4:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 3;
                  }
                  break;
               case 5:
                  if (this.curChar == '=') {
                     this.jjstateSet[this.jjnewStateCnt++] = 4;
                  }
               }
            } while(i != startsAt);
         } else if (this.curChar < 128) {
            var14 = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               case 2:
                  if (this.curChar == ']' && kind > 22) {
                     kind = 22;
                  }
                  break;
               case 6:
                  if (this.curChar == ']') {
                     this.jjstateSet[this.jjnewStateCnt++] = 5;
                  }
               }
            } while(i != startsAt);
         } else {
            int hiByte = this.curChar >> 8;
            int i1 = hiByte >> 6;
            long l1 = 1L << (hiByte & 63);
            int i2 = (this.curChar & 255) >> 6;
            long var11 = 1L << (this.curChar & 63);

            do {
               --i;
               switch(this.jjstateSet[i]) {
               }
            } while(i != startsAt);
         }

         if (kind != Integer.MAX_VALUE) {
            this.jjmatchedKind = kind;
            this.jjmatchedPos = curPos;
            kind = Integer.MAX_VALUE;
         }

         ++curPos;
         if ((i = this.jjnewStateCnt) == (startsAt = 7 - (this.jjnewStateCnt = startsAt))) {
            return curPos;
         }

         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var13) {
            return curPos;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_5() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_5(2097152L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_5(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case '=':
         return this.jjMoveStringLiteralDfa2_5(active0, 2097152L);
      default:
         return 2;
      }
   }

   private int jjMoveStringLiteralDfa2_5(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 2;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 2;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa3_5(active0, 2097152L);
         default:
            return 3;
         }
      }
   }

   private int jjMoveStringLiteralDfa3_5(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 3;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 3;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa4_5(active0, 2097152L);
         default:
            return 4;
         }
      }
   }

   private int jjMoveStringLiteralDfa4_5(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 4;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 4;
         }

         switch(this.curChar) {
         case ']':
            if ((active0 & 2097152L) != 0L) {
               return this.jjStopAtPos(4, 21);
            }

            return 5;
         default:
            return 5;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_4() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_4(1048576L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_4(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case '=':
         return this.jjMoveStringLiteralDfa2_4(active0, 1048576L);
      default:
         return 2;
      }
   }

   private int jjMoveStringLiteralDfa2_4(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 2;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 2;
         }

         switch(this.curChar) {
         case '=':
            return this.jjMoveStringLiteralDfa3_4(active0, 1048576L);
         default:
            return 3;
         }
      }
   }

   private int jjMoveStringLiteralDfa3_4(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 3;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 3;
         }

         switch(this.curChar) {
         case ']':
            if ((active0 & 1048576L) != 0L) {
               return this.jjStopAtPos(3, 20);
            }

            return 4;
         default:
            return 4;
         }
      }
   }

   private int jjMoveStringLiteralDfa0_3() {
      switch(this.curChar) {
      case ']':
         return this.jjMoveStringLiteralDfa1_3(524288L);
      default:
         return 1;
      }
   }

   private int jjMoveStringLiteralDfa1_3(long active0) {
      try {
         this.curChar = this.input_stream.readChar();
      } catch (IOException var4) {
         return 1;
      }

      switch(this.curChar) {
      case '=':
         return this.jjMoveStringLiteralDfa2_3(active0, 524288L);
      default:
         return 2;
      }
   }

   private int jjMoveStringLiteralDfa2_3(long old0, long active0) {
      if ((active0 &= old0) == 0L) {
         return 2;
      } else {
         try {
            this.curChar = this.input_stream.readChar();
         } catch (IOException var6) {
            return 2;
         }

         switch(this.curChar) {
         case ']':
            if ((active0 & 524288L) != 0L) {
               return this.jjStopAtPos(2, 19);
            }

            return 3;
         default:
            return 3;
         }
      }
   }

   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2) {
      switch(hiByte) {
      case 0:
         return (jjbitVec2[i2] & l2) != 0L;
      default:
         return (jjbitVec0[i1] & l1) != 0L;
      }
   }

   public LuaParserTokenManager(SimpleCharStream stream) {
      this.debugStream = System.out;
      this.jjrounds = new int[66];
      this.jjstateSet = new int[132];
      this.jjimage = new StringBuffer();
      this.image = this.jjimage;
      this.curLexState = 0;
      this.defaultLexState = 0;
      this.input_stream = stream;
   }

   public LuaParserTokenManager(SimpleCharStream stream, int lexState) {
      this(stream);
      this.SwitchTo(lexState);
   }

   public void ReInit(SimpleCharStream stream) {
      this.jjmatchedPos = this.jjnewStateCnt = 0;
      this.curLexState = this.defaultLexState;
      this.input_stream = stream;
      this.ReInitRounds();
   }

   private void ReInitRounds() {
      this.jjround = -2147483647;

      for(int i = 66; i-- > 0; this.jjrounds[i] = Integer.MIN_VALUE) {
      }

   }

   public void ReInit(SimpleCharStream stream, int lexState) {
      this.ReInit(stream);
      this.SwitchTo(lexState);
   }

   public void SwitchTo(int lexState) {
      if (lexState < 12 && lexState >= 0) {
         this.curLexState = lexState;
      } else {
         throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
      }
   }

   protected Token jjFillToken() {
      String curTokenImage;
      int beginLine;
      int endLine;
      int beginColumn;
      int endColumn;
      if (this.jjmatchedPos < 0) {
         if (this.image == null) {
            curTokenImage = "";
         } else {
            curTokenImage = this.image.toString();
         }

         beginLine = endLine = this.input_stream.getBeginLine();
         beginColumn = endColumn = this.input_stream.getBeginColumn();
      } else {
         String im = jjstrLiteralImages[this.jjmatchedKind];
         curTokenImage = im == null ? this.input_stream.GetImage() : im;
         beginLine = this.input_stream.getBeginLine();
         beginColumn = this.input_stream.getBeginColumn();
         endLine = this.input_stream.getEndLine();
         endColumn = this.input_stream.getEndColumn();
      }

      Token t = Token.newToken(this.jjmatchedKind, curTokenImage);
      t.beginLine = beginLine;
      t.endLine = endLine;
      t.beginColumn = beginColumn;
      t.endColumn = endColumn;
      return t;
   }

   public Token getNextToken() {
      Token specialToken = null;
      int curPos = 0;

      label164:
      while(true) {
         Token matchedToken;
         try {
            this.curChar = this.input_stream.BeginToken();
         } catch (IOException var9) {
            this.jjmatchedKind = 0;
            matchedToken = this.jjFillToken();
            matchedToken.specialToken = specialToken;
            return matchedToken;
         }

         this.image = this.jjimage;
         this.image.setLength(0);
         this.jjimageLen = 0;

         while(true) {
            switch(this.curLexState) {
            case 0:
               try {
                  this.input_stream.backup(0);

                  while(this.curChar <= ' ' && (4294981120L & 1L << this.curChar) != 0L) {
                     this.curChar = this.input_stream.BeginToken();
                  }
               } catch (IOException var12) {
                  continue label164;
               }

               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_0();
               break;
            case 1:
               this.jjmatchedKind = 17;
               this.jjmatchedPos = -1;
               int curPos = false;
               curPos = this.jjMoveStringLiteralDfa0_1();
               break;
            case 2:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_2();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 3:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_3();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 4:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_4();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 5:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_5();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 6:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_6();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 7:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_7();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 8:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_8();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 9:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_9();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 10:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_10();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
               break;
            case 11:
               this.jjmatchedKind = Integer.MAX_VALUE;
               this.jjmatchedPos = 0;
               curPos = this.jjMoveStringLiteralDfa0_11();
               if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28) {
                  this.jjmatchedKind = 28;
               }
            }

            if (this.jjmatchedKind == Integer.MAX_VALUE) {
               break label164;
            }

            if (this.jjmatchedPos + 1 < curPos) {
               this.input_stream.backup(curPos - this.jjmatchedPos - 1);
            }

            if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 63)) != 0L) {
               matchedToken = this.jjFillToken();
               matchedToken.specialToken = specialToken;
               if (jjnewLexState[this.jjmatchedKind] != -1) {
                  this.curLexState = jjnewLexState[this.jjmatchedKind];
               }

               return matchedToken;
            }

            if ((jjtoSkip[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 63)) != 0L) {
               if ((jjtoSpecial[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 63)) != 0L) {
                  matchedToken = this.jjFillToken();
                  if (specialToken == null) {
                     specialToken = matchedToken;
                  } else {
                     matchedToken.specialToken = specialToken;
                     specialToken = specialToken.next = matchedToken;
                  }

                  this.SkipLexicalActions(matchedToken);
               } else {
                  this.SkipLexicalActions((Token)null);
               }

               if (jjnewLexState[this.jjmatchedKind] != -1) {
                  this.curLexState = jjnewLexState[this.jjmatchedKind];
               }
               break;
            }

            this.jjimageLen += this.jjmatchedPos + 1;
            if (jjnewLexState[this.jjmatchedKind] != -1) {
               this.curLexState = jjnewLexState[this.jjmatchedKind];
            }

            curPos = 0;
            this.jjmatchedKind = Integer.MAX_VALUE;

            try {
               this.curChar = this.input_stream.readChar();
            } catch (IOException var11) {
               break label164;
            }
         }
      }

      int error_line = this.input_stream.getEndLine();
      int error_column = this.input_stream.getEndColumn();
      String error_after = null;
      boolean EOFSeen = false;

      try {
         this.input_stream.readChar();
         this.input_stream.backup(1);
      } catch (IOException var10) {
         EOFSeen = true;
         error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
         if (this.curChar != '\n' && this.curChar != '\r') {
            ++error_column;
         } else {
            ++error_line;
            error_column = 0;
         }
      }

      if (!EOFSeen) {
         this.input_stream.backup(1);
         error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
      }

      throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
   }

   void SkipLexicalActions(Token matchedToken) {
      switch(this.jjmatchedKind) {
      default:
      }
   }

   private void jjCheckNAdd(int state) {
      if (this.jjrounds[state] != this.jjround) {
         this.jjstateSet[this.jjnewStateCnt++] = state;
         this.jjrounds[state] = this.jjround;
      }

   }

   private void jjAddStates(int start, int end) {
      do {
         this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
      } while(start++ != end);

   }

   private void jjCheckNAddTwoStates(int state1, int state2) {
      this.jjCheckNAdd(state1);
      this.jjCheckNAdd(state2);
   }

   private void jjCheckNAddStates(int start, int end) {
      do {
         this.jjCheckNAdd(jjnextStates[start]);
      } while(start++ != end);

   }
}
