package org.luaj.vm2.script;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import javax.script.AbstractScriptEngine;
import javax.script.Bindings;
import javax.script.Compilable;
import javax.script.CompiledScript;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineFactory;
import javax.script.ScriptException;
import javax.script.SimpleBindings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaClosure;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.ThreeArgFunction;
import org.luaj.vm2.lib.TwoArgFunction;
import org.luaj.vm2.lib.jse.CoerceJavaToLua;

@Environment(EnvType.CLIENT)
public class LuaScriptEngine extends AbstractScriptEngine implements ScriptEngine, Compilable {
   private static final String __ENGINE_VERSION__ = "Luaj-jse 3.0.1";
   private static final String __NAME__ = "Luaj";
   private static final String __SHORT_NAME__ = "Luaj";
   private static final String __LANGUAGE__ = "lua";
   private static final String __LANGUAGE_VERSION__ = "5.2";
   private static final String __ARGV__ = "arg";
   private static final String __FILENAME__ = "?";
   private static final ScriptEngineFactory myFactory = new LuaScriptEngineFactory();
   private LuajContext context = new LuajContext();

   public LuaScriptEngine() {
      this.context.setBindings(this.createBindings(), 100);
      this.setContext(this.context);
      this.put("javax.script.language_version", "5.2");
      this.put("javax.script.language", "lua");
      this.put("javax.script.engine", "Luaj");
      this.put("javax.script.engine_version", "Luaj-jse 3.0.1");
      this.put("javax.script.argv", "arg");
      this.put("javax.script.filename", "?");
      this.put("javax.script.name", "Luaj");
      this.put("THREADING", (Object)null);
   }

   public CompiledScript compile(String script) throws ScriptException {
      return this.compile((Reader)(new StringReader(script)));
   }

   public CompiledScript compile(Reader script) throws ScriptException {
      try {
         LuaScriptEngine.Utf8Encoder is = new LuaScriptEngine.Utf8Encoder(this, script);

         LuaScriptEngine.LuajCompiledScript var5;
         try {
            Globals g = this.context.globals;
            LuaFunction f = g.load(script, "script").checkfunction();
            var5 = new LuaScriptEngine.LuajCompiledScript(f, g);
         } catch (LuaError var10) {
            throw new ScriptException(var10.getMessage());
         } finally {
            is.close();
         }

         return var5;
      } catch (Exception var12) {
         throw new ScriptException("eval threw " + var12.toString());
      }
   }

   public Object eval(Reader reader, Bindings bindings) throws ScriptException {
      return ((LuaScriptEngine.LuajCompiledScript)this.compile(reader)).eval(this.context.globals, bindings);
   }

   public Object eval(String script, Bindings bindings) throws ScriptException {
      return this.eval((Reader)(new StringReader(script)), (Bindings)bindings);
   }

   protected ScriptContext getScriptContext(Bindings nn) {
      throw new IllegalStateException("LuajScriptEngine should not be allocating contexts.");
   }

   public Bindings createBindings() {
      return new SimpleBindings();
   }

   public Object eval(String script, ScriptContext context) throws ScriptException {
      return this.eval((Reader)(new StringReader(script)), (ScriptContext)context);
   }

   public Object eval(Reader reader, ScriptContext context) throws ScriptException {
      return this.compile(reader).eval(context);
   }

   public ScriptEngineFactory getFactory() {
      return myFactory;
   }

   private static LuaValue toLua(Object javaValue) {
      return javaValue == null ? LuaValue.NIL : (javaValue instanceof LuaValue ? (LuaValue)javaValue : CoerceJavaToLua.coerce(javaValue));
   }

   private static Object toJava(LuaValue luajValue) {
      switch(luajValue.type()) {
      case 0:
         return null;
      case 1:
      case 2:
      case 5:
      case 6:
      default:
         return luajValue;
      case 3:
         return luajValue.isinttype() ? new Integer(luajValue.toint()) : new Double(luajValue.todouble());
      case 4:
         return luajValue.tojstring();
      case 7:
         return luajValue.checkuserdata(Object.class);
      }
   }

   private static Object toJava(Varargs v) {
      int n = v.narg();
      switch(n) {
      case 0:
         return null;
      case 1:
         return toJava(v.arg1());
      default:
         Object[] o = new Object[n];

         for(int i = 0; i < n; ++i) {
            o[i] = toJava(v.arg(i + 1));
         }

         return o;
      }
   }

   @Environment(EnvType.CLIENT)
   private final class Utf8Encoder extends InputStream {
      private final Reader r;
      private final int[] buf = new int[2];
      private int n;

      private Utf8Encoder(final LuaScriptEngine param1, Reader r) {
         this.r = r;
      }

      public int read() throws IOException {
         if (this.n > 0) {
            return this.buf[--this.n];
         } else {
            int c = this.r.read();
            if (c < 128) {
               return c;
            } else {
               this.n = 0;
               if (c < 2048) {
                  this.buf[this.n++] = 128 | c & 63;
                  return 192 | c >> 6 & 31;
               } else {
                  this.buf[this.n++] = 128 | c & 63;
                  this.buf[this.n++] = 128 | c >> 6 & 63;
                  return 224 | c >> 12 & 15;
               }
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   class LuajCompiledScript extends CompiledScript {
      final LuaFunction function;
      final Globals compiling_globals;

      LuajCompiledScript(LuaFunction function, Globals compiling_globals) {
         this.function = function;
         this.compiling_globals = compiling_globals;
      }

      public ScriptEngine getEngine() {
         return LuaScriptEngine.this;
      }

      public Object eval() throws ScriptException {
         return this.eval(LuaScriptEngine.this.getContext());
      }

      public Object eval(Bindings bindings) throws ScriptException {
         return this.eval(((LuajContext)LuaScriptEngine.this.getContext()).globals, bindings);
      }

      public Object eval(ScriptContext context) throws ScriptException {
         return this.eval(((LuajContext)context).globals, context.getBindings(100));
      }

      Object eval(Globals g, Bindings b) throws ScriptException {
         g.setmetatable(new LuaScriptEngine.BindingsMetatable(b));
         LuaFunction fx = this.function;
         Object f;
         if (fx.isclosure()) {
            f = new LuaClosure(fx.checkclosure().p, g);
         } else {
            try {
               f = (LuaFunction)fx.getClass().newInstance();
            } catch (Exception var5) {
               throw new ScriptException(var5);
            }

            ((LuaFunction)f).initupvalue1(g);
         }

         return LuaScriptEngine.toJava(((LuaFunction)f).invoke(LuaValue.NONE));
      }
   }

   @Environment(EnvType.CLIENT)
   static class BindingsMetatable extends LuaTable {
      BindingsMetatable(Bindings bindings) {
         this.rawset(LuaValue.INDEX, new TwoArgFunction(this, bindings) {
            // $FF: synthetic field
            final Bindings val$bindings;

            {
               this.val$bindings = var2;
            }

            public LuaValue call(LuaValue table, LuaValue key) {
               return key.isstring() ? LuaScriptEngine.toLua(this.val$bindings.get(key.tojstring())) : this.rawget(key);
            }
         });
         this.rawset(LuaValue.NEWINDEX, new ThreeArgFunction(this, bindings) {
            // $FF: synthetic field
            final Bindings val$bindings;

            {
               this.val$bindings = var2;
            }

            public LuaValue call(LuaValue table, LuaValue key, LuaValue value) {
               if (key.isstring()) {
                  String k = key.tojstring();
                  Object v = LuaScriptEngine.toJava(value);
                  if (v == null) {
                     this.val$bindings.remove(k);
                  } else {
                     this.val$bindings.put(k, v);
                  }
               } else {
                  this.rawset(key, value);
               }

               return LuaValue.NONE;
            }
         });
      }
   }
}
