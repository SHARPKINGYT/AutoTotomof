package org.luaj.vm2.script;

import java.util.Arrays;
import java.util.List;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineFactory;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LuaScriptEngineFactory implements ScriptEngineFactory {
   private static final String[] EXTENSIONS = new String[]{"lua", ".lua"};
   private static final String[] MIMETYPES = new String[]{"text/lua", "application/lua"};
   private static final String[] NAMES = new String[]{"lua", "luaj"};
   private List<String> extensions;
   private List<String> mimeTypes;
   private List<String> names;

   public LuaScriptEngineFactory() {
      this.extensions = Arrays.asList(EXTENSIONS);
      this.mimeTypes = Arrays.asList(MIMETYPES);
      this.names = Arrays.asList(NAMES);
   }

   public String getEngineName() {
      return this.getScriptEngine().get("javax.script.engine").toString();
   }

   public String getEngineVersion() {
      return this.getScriptEngine().get("javax.script.engine_version").toString();
   }

   public List<String> getExtensions() {
      return this.extensions;
   }

   public List<String> getMimeTypes() {
      return this.mimeTypes;
   }

   public List<String> getNames() {
      return this.names;
   }

   public String getLanguageName() {
      return this.getScriptEngine().get("javax.script.language").toString();
   }

   public String getLanguageVersion() {
      return this.getScriptEngine().get("javax.script.language_version").toString();
   }

   public Object getParameter(String key) {
      return this.getScriptEngine().get(key).toString();
   }

   public String getMethodCallSyntax(String obj, String m, String... args) {
      StringBuffer sb = new StringBuffer();
      sb.append(obj + ":" + m + "(");
      int len = args.length;

      for(int i = 0; i < len; ++i) {
         if (i > 0) {
            sb.append(',');
         }

         sb.append(args[i]);
      }

      sb.append(")");
      return sb.toString();
   }

   public String getOutputStatement(String toDisplay) {
      return "print(" + toDisplay + ")";
   }

   public String getProgram(String... statements) {
      StringBuffer sb = new StringBuffer();
      int len = statements.length;

      for(int i = 0; i < len; ++i) {
         if (i > 0) {
            sb.append('\n');
         }

         sb.append(statements[i]);
      }

      return sb.toString();
   }

   public ScriptEngine getScriptEngine() {
      return new LuaScriptEngine();
   }
}
