package org.luaj.vm2.server;

import java.io.InputStream;
import java.io.Reader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.jse.CoerceJavaToLua;
import org.luaj.vm2.lib.jse.JsePlatform;

@Environment(EnvType.CLIENT)
public class DefaultLauncher implements Launcher {
   protected Globals g = JsePlatform.standardGlobals();

   public Object[] launch(String script, Object[] arg) {
      return this.launchChunk(this.g.load(script, "main"), arg);
   }

   public Object[] launch(InputStream script, Object[] arg) {
      return this.launchChunk(this.g.load(script, "main", "bt", this.g), arg);
   }

   public Object[] launch(Reader script, Object[] arg) {
      return this.launchChunk(this.g.load(script, "main"), arg);
   }

   private Object[] launchChunk(LuaValue chunk, Object[] arg) {
      LuaValue[] args = new LuaValue[arg.length];

      for(int i = 0; i < args.length; ++i) {
         args[i] = CoerceJavaToLua.coerce(arg[i]);
      }

      Varargs results = chunk.invoke(LuaValue.varargsOf(args));
      int n = results.narg();
      Object[] return_values = new Object[n];

      for(int i = 0; i < n; ++i) {
         LuaValue r = results.arg(i + 1);
         switch(r.type()) {
         case -2:
            return_values[i] = r.toint();
            break;
         case -1:
         case 2:
         case 5:
         case 6:
         default:
            return_values[i] = r;
            break;
         case 0:
            return_values[i] = null;
            break;
         case 1:
            return_values[i] = r.toboolean();
            break;
         case 3:
            return_values[i] = r.todouble();
            break;
         case 4:
            return_values[i] = r.tojstring();
            break;
         case 7:
            return_values[i] = r.touserdata();
         }
      }

      return return_values;
   }
}
