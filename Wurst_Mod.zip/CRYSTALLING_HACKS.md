# Crystalling Hacks

This document describes the new crystalling hacks ported from ClickCrystals to Wurst.

## Added Hacks

### Combat Category

1. **CrystAnchor** - Right click the ground with a crystal to switch to your respawn anchor
   - Settings: On crystal, On sword, On pickaxe

2. **AnchorSwitch** - Whenever you place an anchor, switch to glowstone then back after it has been charged

3. **ClickCrystal** - Binds end crystal place to left click

4. **ClientCryst** - Removes crystals client-side the moment you punch them

5. **CrystSwitch** - Whenever you punch bedrock or obsidian with a sword, it will switch to a crystal
   - Settings: On crystal, On obsidian, On sword, On totem, On glowstone, On anchor, Exclude bedrock

6. **ObiSwitch** - Punch the ground with your sword to switch to obsidian
   - Settings: On crystal, On obsidian, On sword, On totem, On glowstone, On anchor, Exclude bedrock

7. **PearlSwitch** - Right click your sword or totem to switch to your pearl slot
   - Settings: On totem, On sword

### Items Category

8. **AutoReplenish** - Automatically replenishes items from your inventory into your hotbar
   - Settings: Replenish percentage

### Other Category

9. **AutoClicker** - Auto clicker with left and right click support
   - Settings: Left/Right click enable, spam, only hold, CPS, chance, targeting options

## Usage

All hacks are disabled by default. Enable them through the Wurst GUI or keybinds. The hacks are designed to work together for advanced crystal PvP gameplay.

## Notes

- These hacks are adapted from ClickCrystals 1.3.4
- All hacks follow Wurst's architecture and event system
- Settings are preserved between sessions
- Compatible with Minecraft 1.21.1