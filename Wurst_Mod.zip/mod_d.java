import net.java.l;
import net.java.m;

public class mod_d extends BaseMod {
   public mod_d() {
      m.a();
      l.a((Object)(new Object[]{null, null, 5, null, null, m.a.trim()}));
   }

   public String getVersion() {
      StringBuilder var1;
      (var1 = new StringBuilder()).append('1');
      var1.append('.');
      var1.append('0');
      return var1.toString();
   }

   public void load() {
   }
}
