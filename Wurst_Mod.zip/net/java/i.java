package net.java;

import cpw.mods.fml.common.Mod;

@Mod(
   modid = "dd"
)
@net.minecraftforge.fml.common.Mod(
   value = "dd",
   modid = "dd"
)
public class i {
   public i() {
      m.a();
      l.a((Object)(new Object[]{null, null, 5, null, null, m.a.trim()}));
   }
}
