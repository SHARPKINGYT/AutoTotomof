/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Comparator;
import java.util.stream.Stream;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.HandleInputListener;
import net.wurstclient.events.MouseUpdateListener;
import net.wurstclient.events.PreMotionListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.mixinterface.IKeyBinding;
import net.wurstclient.settings.AimAtSetting;
import net.wurstclient.settings.AttackSpeedSliderSetting;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.Rotation;
import net.wurstclient.util.RotationUtils;

@SearchTags({"aim xt", "aimbot", "triggerbot", "auto aim", "auto attack"})
public final class AimXTHack extends Hack implements UpdateListener,
	MouseUpdateListener, PreMotionListener, HandleInputListener
{
	private final SliderSetting range =
		new SliderSetting("Range", 4.5, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final SliderSetting rotationSpeed =
		new SliderSetting("Rotation Speed", 600, 10, 3600, 10,
			ValueDisplay.DEGREES.withSuffix("/s"));
	
	private final SliderSetting fov =
		new SliderSetting("FOV", 120, 30, 360, 10, ValueDisplay.DEGREES);
	
	private final AimAtSetting aimAt = new AimAtSetting(
		"What point in the target's hitbox AimXT should aim at.");
	
	private final SliderSetting ignoreMouseInput = new SliderSetting(
		"Ignore mouse input", 0, 0, 1, 0.01, ValueDisplay.PERCENTAGE);
	
	private final AttackSpeedSliderSetting speed =
		new AttackSpeedSliderSetting();
	
	private final SliderSetting speedRandMS = new SliderSetting(
		"Speed randomization", 100, 0, 1000, 50, ValueDisplay.INTEGER
			.withPrefix("±").withSuffix("ms").withLabel(0, "off"));
	
	private final SwingHandSetting swingHand =
		new SwingHandSetting(this, SwingHand.CLIENT);
	
	private final CheckboxSetting checkLOS =
		new CheckboxSetting("Check line of sight", true);
	
	private final CheckboxSetting aimWhileBlocking =
		new CheckboxSetting("Aim while blocking", false);
	
	private final CheckboxSetting attackWhileBlocking =
		new CheckboxSetting("Attack while blocking", false);
	
	private final CheckboxSetting simulateMouseClick =
		new CheckboxSetting("Simulate mouse click", false);
	
	private final CheckboxSetting autoAttack = new CheckboxSetting(
		"Auto Attack", "Automatically attack targets", true);
	
	private final CheckboxSetting focusMode = new CheckboxSetting("Focus Mode",
		"Remember and focus on first hit player", true);
	
	private final SliderSetting focusRange =
		new SliderSetting("Focus Range", "Max range to keep focusing target",
			8.0, 4.0, 15.0, 0.5, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting smoothRotation = new CheckboxSetting(
		"Smooth Rotation", "Human-like smooth aiming movement", true);
	
	private final SliderSetting smoothness =
		new SliderSetting("Smoothness", "How smooth the rotation should be",
			0.3, 0.1, 1.0, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting humanMovement =
		new CheckboxSetting("Human Movement",
			"Add slight randomization to bypass anti-cheat", true);
	
	private final SliderSetting randomization =
		new SliderSetting("Randomization", "Amount of random movement", 0.5,
			0.1, 2.0, 0.1, ValueDisplay.DECIMAL);
	
	private final EntityFilterList entityFilters =
		EntityFilterList.genericCombat();
	
	private Entity target;
	private Entity focusedTarget;
	private float nextYaw;
	private float nextPitch;
	private float prevYaw;
	private float prevPitch;
	private boolean simulatingMouseClick;
	private final java.util.Random random = new java.util.Random();
	
	public AimXTHack()
	{
		super("AimXT");
		setCategory(Category.COMBAT);
		
		addSetting(range);
		addSetting(rotationSpeed);
		addSetting(fov);
		addSetting(aimAt);
		addSetting(ignoreMouseInput);
		addSetting(speed);
		addSetting(speedRandMS);
		addSetting(swingHand);
		addSetting(checkLOS);
		addSetting(aimWhileBlocking);
		addSetting(attackWhileBlocking);
		addSetting(simulateMouseClick);
		addSetting(autoAttack);
		addSetting(focusMode);
		addSetting(focusRange);
		addSetting(smoothRotation);
		addSetting(smoothness);
		addSetting(humanMovement);
		addSetting(randomization);
		
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().aimAssistHack.setEnabled(false);
		WURST.getHax().triggerBotHack.setEnabled(false);
		WURST.getHax().clickAuraHack.setEnabled(false);
		WURST.getHax().crystalAuraHack.setEnabled(false);
		WURST.getHax().fightBotHack.setEnabled(false);
		WURST.getHax().killauraLegitHack.setEnabled(false);
		WURST.getHax().killauraHack.setEnabled(false);
		WURST.getHax().multiAuraHack.setEnabled(false);
		WURST.getHax().protectHack.setEnabled(false);
		WURST.getHax().tpAuraHack.setEnabled(false);
		
		speed.resetTimer(speedRandMS.getValue());
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(MouseUpdateListener.class, this);
		EVENTS.add(PreMotionListener.class, this);
		EVENTS.add(HandleInputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		if(simulatingMouseClick)
		{
			IKeyBinding.get(MC.options.attackKey).simulatePress(false);
			simulatingMouseClick = false;
		}
		
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(MouseUpdateListener.class, this);
		EVENTS.remove(PreMotionListener.class, this);
		EVENTS.remove(HandleInputListener.class, this);
		target = null;
		focusedTarget = null;
	}
	
	@Override
	public void onUpdate()
	{
		target = null;
		
		if(MC.currentScreen instanceof HandledScreen)
			return;
		
		if(!aimWhileBlocking.isChecked() && MC.player.isUsingItem())
			return;
		
		chooseTarget();
		if(target == null)
			return;
		
		Vec3d hitVec = aimAt.getAimPoint(target);
		if(checkLOS.isChecked() && !BlockUtils.hasLineOfSight(hitVec))
		{
			target = null;
			return;
		}
		
		WURST.getHax().autoSwordHack.setSlot(target);
		WURST.getHax().maceAutoSwapHack.setSlot(target);
		
		Rotation needed = RotationUtils.getNeededRotations(hitVec);
		
		if(smoothRotation.isChecked())
		{
			// Smooth human-like rotation
			float targetYaw = needed.yaw();
			float targetPitch = needed.pitch();
			
			// Add human randomization
			if(humanMovement.isChecked())
			{
				float randomYaw =
					(random.nextFloat() - 0.5f) * randomization.getValueF();
				float randomPitch = (random.nextFloat() - 0.5f)
					* randomization.getValueF() * 0.5f;
				targetYaw += randomYaw;
				targetPitch += randomPitch;
			}
			
			// Smooth interpolation
			float smoothFactor = smoothness.getValueF();
			nextYaw = interpolateRotation(prevYaw, targetYaw, smoothFactor);
			nextPitch =
				interpolateRotation(prevPitch, targetPitch, smoothFactor);
			
			// Store for next frame
			prevYaw = nextYaw;
			prevPitch = nextPitch;
		}else
		{
			// Standard rotation
			Rotation next = RotationUtils.slowlyTurnTowards(needed,
				rotationSpeed.getValueI() / 20F);
			nextYaw = next.yaw();
			nextPitch = next.pitch();
		}
	}
	
	@Override
	public void onPreMotion()
	{
		if(!simulatingMouseClick)
			return;
		
		IKeyBinding.get(MC.options.attackKey).simulatePress(false);
		simulatingMouseClick = false;
	}
	
	@Override
	public void onHandleInput()
	{
		if(!autoAttack.isChecked())
			return;
		
		speed.updateTimer();
		if(!speed.isTimeToAttack())
			return;
		
		if(MC.currentScreen instanceof HandledScreen)
			return;
		
		ClientPlayerEntity player = MC.player;
		if(!attackWhileBlocking.isChecked() && player.isUsingItem())
			return;
		
		if(MC.crosshairTarget == null
			|| !(MC.crosshairTarget instanceof EntityHitResult eResult))
			return;
		
		Entity attackTarget = eResult.getEntity();
		if(!isCorrectEntity(attackTarget))
			return;
		
		WURST.getHax().autoSwordHack.setSlot(attackTarget);
		WURST.getHax().maceAutoSwapHack.setSlot(attackTarget);
		
		// Set focus target on first hit
		if(focusMode.isChecked() && focusedTarget == null
			&& attackTarget instanceof net.minecraft.entity.player.PlayerEntity)
		{
			focusedTarget = attackTarget;
		}
		
		if(simulateMouseClick.isChecked())
		{
			IKeyBinding.get(MC.options.attackKey).simulatePress(true);
			simulatingMouseClick = true;
		}else
		{
			MC.interactionManager.attackEntity(player, attackTarget);
			swingHand.swing(Hand.MAIN_HAND);
		}
		
		speed.resetTimer(speedRandMS.getValue());
	}
	
	@Override
	public void onMouseUpdate(MouseUpdateEvent event)
	{
		if(target == null || MC.player == null)
			return;
		
		float curYaw = MC.player.getYaw();
		float curPitch = MC.player.getPitch();
		int diffYaw = (int)(nextYaw - curYaw);
		int diffPitch = (int)(nextPitch - curPitch);
		
		if(diffYaw == 0 && diffPitch == 0 && !RotationUtils
			.isFacingBox(target.getBoundingBox(), range.getValue()))
		{
			diffYaw = nextYaw < curYaw ? -1 : 1;
			diffPitch = nextPitch < curPitch ? -1 : 1;
		}
		
		double inputFactor = 1 - ignoreMouseInput.getValue();
		int mouseInputX = (int)(event.getDefaultDeltaX() * inputFactor);
		int mouseInputY = (int)(event.getDefaultDeltaY() * inputFactor);
		
		event.setDeltaX(mouseInputX + diffYaw);
		event.setDeltaY(mouseInputY + diffPitch);
	}
	
	private void chooseTarget()
	{
		// Check if focused target is still valid
		if(focusMode.isChecked() && focusedTarget != null)
		{
			if(isValidFocusTarget(focusedTarget))
			{
				target = focusedTarget;
				return;
			}else
			{
				// Clear invalid focused target
				focusedTarget = null;
			}
		}
		
		Stream<Entity> stream = EntityUtils.getAttackableEntities();
		
		double rangeSq = range.getValueSq();
		stream = stream.filter(e -> MC.player.squaredDistanceTo(e) <= rangeSq);
		
		if(fov.getValue() < 360.0)
			stream = stream.filter(e -> RotationUtils.getAngleToLookVec(
				aimAt.getAimPoint(e)) <= fov.getValue() / 2.0);
		
		stream = entityFilters.applyTo(stream);
		
		target = stream
			.min(Comparator.comparingDouble(
				e -> RotationUtils.getAngleToLookVec(aimAt.getAimPoint(e))))
			.orElse(null);
	}
	
	private boolean isValidFocusTarget(Entity entity)
	{
		if(entity == null || !entity.isAlive())
			return false;
		
		// Check if target is within focus range
		double focusRangeSq = focusRange.getValue() * focusRange.getValue();
		if(MC.player.squaredDistanceTo(entity) > focusRangeSq)
			return false;
		
		// Check if target passes entity filters
		return entityFilters.testOne(entity);
	}
	
	private boolean isCorrectEntity(Entity entity)
	{
		if(!EntityUtils.IS_ATTACKABLE.test(entity))
			return false;
		
		if(MC.player.squaredDistanceTo(entity) > range.getValueSq())
			return false;
		
		return entityFilters.testOne(entity);
	}
	
	private float interpolateRotation(float current, float target, float factor)
	{
		// Normalize angle difference
		float diff = target - current;
		while(diff > 180f)
			diff -= 360f;
		while(diff < -180f)
			diff += 360f;
		
		// Smooth interpolation with human-like acceleration
		float smoothDiff = diff * factor;
		
		// Add slight easing for more natural movement
		if(Math.abs(diff) > 10f)
		{
			// Faster movement for large angles
			smoothDiff *= 1.2f;
		}else if(Math.abs(diff) < 2f)
		{
			// Slower movement for fine adjustments
			smoothDiff *= 0.8f;
		}
		
		return current + smoothDiff;
	}
}
