/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;

@SearchTags({"auto clicker", "auto click", "clicker"})
public final class AutoClickerHack extends Hack implements UpdateListener
{
	private final CheckboxSetting leftClick =
		new CheckboxSetting("Left click", "Enable left clicking", false);
	
	private final CheckboxSetting leftSpam =
		new CheckboxSetting("Left spam", "Spam left clicks", true);
	
	private final CheckboxSetting leftOnlyHold =
		new CheckboxSetting("Left only hold", "Spam only when held", true);
	
	private final SliderSetting leftCps = new SliderSetting("Left CPS",
		"Clicks per second", 10, 1, 50, 1, ValueDisplay.INTEGER);
	
	private final SliderSetting leftChance = new SliderSetting("Left chance",
		"Random chance", 1.0, 0.0, 1.0, 0.01, ValueDisplay.PERCENTAGE);
	
	private final CheckboxSetting rightClick =
		new CheckboxSetting("Right click", "Enable right clicking", false);
	
	private final CheckboxSetting rightSpam =
		new CheckboxSetting("Right spam", "Spam right clicks", true);
	
	private final CheckboxSetting rightOnlyHold =
		new CheckboxSetting("Right only hold", "Spam only when held", true);
	
	private final SliderSetting rightCps = new SliderSetting("Right CPS",
		"Clicks per second", 10, 1, 50, 1, ValueDisplay.INTEGER);
	
	private final SliderSetting rightChance = new SliderSetting("Right chance",
		"Random chance", 1.0, 0.0, 1.0, 0.01, ValueDisplay.PERCENTAGE);
	
	private final CheckboxSetting onlyWhenTarget = new CheckboxSetting(
		"Only when target", "Only when targeting an entity", false);
	
	private final CheckboxSetting noBabies = new CheckboxSetting("No babies",
		"Stop when targeting baby entity", true);
	
	private final SliderSetting maxAttackCooldown =
		new SliderSetting("Max attack cooldown", "Max attack cooldown", 0.0,
			0.0, 1.0, 0.01, ValueDisplay.PERCENTAGE);
	
	private final CheckboxSetting stopWhenMove =
		new CheckboxSetting("Stop when move", "Stop when player moves", false);
	
	private final CheckboxSetting stopWhenDamage =
		new CheckboxSetting("Stop when damage", "Stop when take damage", false);
	
	private final CheckboxSetting stopWhenTarget = new CheckboxSetting(
		"Stop when target", "Stop when targeting entity", false);
	
	private boolean leftToggle, rightToggle;
	private Vec3d prevPos;
	private float prevHp;
	private int tickLeft, tickRight;
	private final int[] noiseMapLeft = new int[20];
	private final int[] noiseMapRight = new int[20];
	
	public AutoClickerHack()
	{
		super("AutoClicker");
		setCategory(Category.OTHER);
		addSetting(leftClick);
		addSetting(leftSpam);
		addSetting(leftOnlyHold);
		addSetting(leftCps);
		addSetting(leftChance);
		addSetting(rightClick);
		addSetting(rightSpam);
		addSetting(rightOnlyHold);
		addSetting(rightCps);
		addSetting(rightChance);
		addSetting(onlyWhenTarget);
		addSetting(noBabies);
		addSetting(maxAttackCooldown);
		addSetting(stopWhenMove);
		addSetting(stopWhenDamage);
		addSetting(stopWhenTarget);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(!canClick())
			return;
		
		if(leftClick.isChecked())
		{
			leftToggle = true;
			clickLeft();
		}else if(leftToggle)
		{
			leftToggle = false;
			MC.options.attackKey.setPressed(false);
		}
		
		if(rightClick.isChecked())
		{
			rightToggle = true;
			clickRight();
		}else if(rightToggle)
		{
			rightToggle = false;
			MC.options.useKey.setPressed(false);
		}
	}
	
	private void clickLeft()
	{
		if(!leftSpam.isChecked())
		{
			MC.options.attackKey.setPressed(true);
			return;
		}
		if(leftOnlyHold.isChecked() && !MC.options.attackKey.isPressed())
			return;
		
		for(int i = 0; i < noiseMapLeft[tickLeft]; i++)
			if(Math.random() <= leftChance.getValue())
				MC.options.attackKey.setPressed(true);
			
		if(++tickLeft >= 20)
		{
			tickLeft = 0;
			distributeNoise((int)leftCps.getValue(), leftChance.getValue(),
				noiseMapLeft);
		}
	}
	
	private void clickRight()
	{
		if(!rightSpam.isChecked())
		{
			MC.options.useKey.setPressed(true);
			return;
		}
		if(rightOnlyHold.isChecked() && !MC.options.useKey.isPressed())
			return;
		
		for(int i = 0; i < noiseMapRight[tickRight]; i++)
			if(Math.random() <= rightChance.getValue())
				MC.options.useKey.setPressed(true);
			
		if(++tickRight >= 20)
		{
			tickRight = 0;
			distributeNoise((int)rightCps.getValue(), rightChance.getValue(),
				noiseMapRight);
		}
	}
	
	private void distributeNoise(int cps, double clickChance, int[] noiseMap)
	{
		float chance = cps / 20.0F / 20.0F;
		int distributions = 0;
		
		for(int i = 0; i < 20; i++)
			noiseMap[i] = 0;
		
		while(distributions < cps)
		{
			int randomIndex = (int)(Math.random() * 20);
			if(distributions < 20 && noiseMap[randomIndex] > 0)
				continue;
			if(Math.random() > chance * clickChance)
				continue;
			noiseMap[randomIndex]++;
			distributions++;
		}
	}
	
	private boolean canClick()
	{
		if(MC.player == null)
			return false;
		
		boolean noTarget = true;
		boolean isBaby = false;
		float hp = prevHp;
		Vec3d pos = prevPos;
		prevHp = MC.player.getHealth();
		prevPos = MC.player.getPos();
		
		if(MC.crosshairTarget instanceof EntityHitResult hit)
		{
			noTarget = false;
			isBaby =
				hit.getEntity() instanceof LivingEntity liv && liv.isBaby();
		}
		
		if(onlyWhenTarget.isChecked() && noTarget)
			return false;
		if(noBabies.isChecked() && isBaby)
			return false;
		if(maxAttackCooldown.getValue() > 0 && MC.player
			.getAttackCooldownProgress(1.0F) < maxAttackCooldown.getValue())
			return false;
		if(stopWhenDamage.isChecked() && MC.player.getHealth() < hp)
		{
			if(leftClick.isChecked() || rightClick.isChecked())
			{
				leftClick.setChecked(false);
				rightClick.setChecked(false);
			}
			return false;
		}
		if(stopWhenMove.isChecked() && pos != null
			&& MC.player.getPos().distanceTo(pos) > 0.1)
		{
			if(leftClick.isChecked() || rightClick.isChecked())
			{
				leftClick.setChecked(false);
				rightClick.setChecked(false);
			}
			return false;
		}
		return !stopWhenTarget.isChecked() || noTarget;
	}
}
