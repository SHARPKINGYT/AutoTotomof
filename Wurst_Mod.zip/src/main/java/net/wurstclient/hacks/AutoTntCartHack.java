/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.StopUsingItemListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;

import java.util.Random;

@SearchTags({"auto tnt cart", "tnt minecart", "instant tnt", "bow tnt"})
public final class AutoTntCartHack extends Hack
	implements StopUsingItemListener, UpdateListener
{
	private final CheckboxSetting onlyFlame = new CheckboxSetting(
		"Only Flame Bow", "Only activate when using a flame bow.", true);
	
	private final SliderSetting delay = new SliderSetting("Delay",
		"Delay in ticks before placing (0 = instant).", 0, 0, 5, 1,
		SliderSetting.ValueDisplay.INTEGER);
	
	private final CheckboxSetting switchBack = new CheckboxSetting(
		"Switch Back", "Instantly switch back to bow after placing.", true);
	
	private final CheckboxSetting ultraFast = new CheckboxSetting("Ultra Fast",
		"Maximum speed placement (same tick).", true);
	
	private final CheckboxSetting checkPlayers = new CheckboxSetting(
		"Check Players", "Only activate when no players nearby.", false);
	
	private final CheckboxSetting autoSwap = new CheckboxSetting("Auto Swap",
		"Automatically swap to rail/cart from hotbar.", true);
	
	private final Random random = new Random();
	private boolean shouldPlace = false;
	private int placeTimer = 0;
	private int originalSlot = -1;
	private BlockPos targetPos;
	private int sequenceStep = 0;
	private int stepTimer = 0;
	
	public AutoTntCartHack()
	{
		super("AutoTntCart");
		setCategory(Category.BLOCKS);
		addSetting(onlyFlame);
		addSetting(delay);
		addSetting(switchBack);
		addSetting(ultraFast);
		addSetting(checkPlayers);
		addSetting(autoSwap);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(StopUsingItemListener.class, this);
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(StopUsingItemListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
		shouldPlace = false;
		placeTimer = 0;
		sequenceStep = 0;
		stepTimer = 0;
	}
	
	@Override
	public void onStopUsingItem()
	{
		if(MC.player == null || MC.world == null)
			return;
		
		ItemStack heldItem = MC.player.getMainHandStack();
		if(!(heldItem.getItem() instanceof BowItem))
			return;
		
		if(onlyFlame.isChecked() && !hasFlameEnchantment(heldItem))
			return;
		
		if(MC.crosshairTarget == null
			|| MC.crosshairTarget.getType() != HitResult.Type.BLOCK)
			return;
		
		BlockHitResult blockHit = (BlockHitResult)MC.crosshairTarget;
		targetPos = blockHit.getBlockPos().offset(blockHit.getSide());
		
		if(!canPlaceAt(targetPos))
			return;
		
		if(checkPlayers.isChecked() && hasNearbyPlayers())
			return;
		
		originalSlot = MC.player.getInventory().selectedSlot;
		
		if(ultraFast.isChecked())
		{
			// Ultra-fast same-tick placement
			performUltraFastPlacement();
		}else
		{
			shouldPlace = true;
			placeTimer = delay.getValueI();
			sequenceStep = 0;
		}
	}
	
	@Override
	public void onUpdate()
	{
		if(!shouldPlace)
			return;
		
		if(placeTimer > 0)
		{
			placeTimer--;
			return;
		}
		
		// Fast sequence placement
		performFastPlacement();
		shouldPlace = false;
	}
	
	private void performUltraFastPlacement()
	{
		int railSlot = findItem(Items.RAIL);
		int cartSlot = findItem(Items.TNT_MINECART);
		
		if(railSlot == -1 || cartSlot == -1)
			return;
		
		// Ultra-fast same-tick placement
		if(autoSwap.isChecked())
			MC.player.getInventory().selectedSlot = railSlot;
		
		// Place rail instantly
		IMC.getInteractionManager().rightClickBlock(targetPos, Direction.UP,
			net.minecraft.util.math.Vec3d.ofCenter(targetPos));
		
		// Instant swap to cart
		if(autoSwap.isChecked())
			MC.player.getInventory().selectedSlot = cartSlot;
		
		// Place TNT cart instantly
		MC.interactionManager.interactBlock(MC.player, Hand.MAIN_HAND,
			new BlockHitResult(
				net.minecraft.util.math.Vec3d.ofCenter(targetPos), Direction.UP,
				targetPos, false));
		
		// Instant switch back
		if(switchBack.isChecked() && originalSlot != -1)
			MC.player.getInventory().selectedSlot = originalSlot;
	}
	
	private void performFastPlacement()
	{
		int railSlot = findItem(Items.RAIL);
		int cartSlot = findItem(Items.TNT_MINECART);
		
		if(railSlot == -1 || cartSlot == -1)
			return;
		
		// Fast placement with minimal delay
		if(autoSwap.isChecked())
			MC.player.getInventory().selectedSlot = railSlot;
		
		// Place rail
		IMC.getInteractionManager().rightClickBlock(targetPos, Direction.UP,
			net.minecraft.util.math.Vec3d.ofCenter(targetPos));
		
		// Quick swap to cart
		if(autoSwap.isChecked())
			MC.player.getInventory().selectedSlot = cartSlot;
		
		// Place TNT cart
		MC.interactionManager.interactBlock(MC.player, Hand.MAIN_HAND,
			new BlockHitResult(
				net.minecraft.util.math.Vec3d.ofCenter(targetPos), Direction.UP,
				targetPos, false));
		
		// Switch back
		if(switchBack.isChecked() && originalSlot != -1)
			MC.player.getInventory().selectedSlot = originalSlot;
	}
	
	private boolean canPlaceAt(BlockPos pos)
	{
		return MC.world.getBlockState(pos).isReplaceable() && MC.world
			.getBlockState(pos.down()).isSolidBlock(MC.world, pos.down());
	}
	
	private int findItem(net.minecraft.item.Item item)
	{
		for(int i = 0; i < 9; i++)
		{
			ItemStack stack = MC.player.getInventory().getStack(i);
			if(stack.getItem() == item)
				return i;
		}
		return -1;
	}
	
	private boolean hasFlameEnchantment(ItemStack stack)
	{
		return stack.getEnchantments().getEnchantments().stream()
			.anyMatch(enchantment -> enchantment.toString().contains("flame"));
	}
	
	private boolean hasNearbyPlayers()
	{
		return MC.world.getPlayers().stream()
			.anyMatch(player -> player != MC.player
				&& MC.player.squaredDistanceTo(player) < 64); // 8 block radius
	}
}
