/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.LeftClickListener;
import net.wurstclient.events.LeftClickListener.LeftClickEvent;
import net.wurstclient.hack.Hack;

@SearchTags({"client crystals", "client crystal", "instant crystal"})
public final class ClientCrystHack extends Hack implements LeftClickListener
{
	public ClientCrystHack()
	{
		super("ClientCryst");
		setCategory(Category.COMBAT);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(LeftClickListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(LeftClickListener.class, this);
	}
	
	@Override
	public void onLeftClick(LeftClickEvent event)
	{
		if(MC.player == null || MC.world == null)
			return;
		if(MC.isInSingleplayer())
			return;
		
		Entity target = MC.targetedEntity;
		if(!(target instanceof EndCrystalEntity crystal))
			return;
		
		crystal.remove(Entity.RemovalReason.KILLED);
		crystal.onRemoved();
	}
}
