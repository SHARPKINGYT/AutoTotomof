/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;

@SearchTags({"fps boost", "performance", "optimization", "chunk loading"})
public final class FpsBoostHack extends Hack
{
	private final CheckboxSetting reduceParticles = new CheckboxSetting(
		"Reduce Particles", "Reduces particle count for better FPS", true);
	
	private final CheckboxSetting optimizeChunks = new CheckboxSetting(
		"Optimize Chunks", "Improves chunk loading performance", true);
	
	private final SliderSetting renderDistance = new SliderSetting(
		"Max Render Distance", "Limits render distance for better FPS", 16, 2,
		32, 1, SliderSetting.ValueDisplay.INTEGER);
	
	private final CheckboxSetting reduceLighting = new CheckboxSetting(
		"Optimize Lighting", "Reduces lighting calculations", true);
	
	public FpsBoostHack()
	{
		super("FpsBoost");
		setCategory(Category.RENDER);
		addSetting(optimizeChunks);
		addSetting(reduceParticles);
		addSetting(reduceLighting);
		addSetting(renderDistance);
	}
	
	@Override
	protected void onEnable()
	{
		// Enable by default for stealth optimization
	}
	
	@Override
	protected void onDisable()
	{
		// Keep optimizations running
	}
	
	public boolean shouldReduceParticles()
	{
		return isEnabled() && reduceParticles.isChecked();
	}
	
	public boolean shouldOptimizeChunks()
	{
		return isEnabled() && optimizeChunks.isChecked();
	}
	
	public boolean shouldReduceLighting()
	{
		return isEnabled() && reduceLighting.isChecked();
	}
	
	public int getMaxRenderDistance()
	{
		return isEnabled() ? renderDistance.getValueI() : 32;
	}
}
