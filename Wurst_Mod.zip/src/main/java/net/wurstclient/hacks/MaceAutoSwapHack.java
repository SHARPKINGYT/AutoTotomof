/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.LeftClickListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;

@SearchTags({"mace auto swap", "auto mace", "density swap", "breach swap"})
public final class MaceAutoSwapHack extends Hack
	implements LeftClickListener, UpdateListener
{
	private final CheckboxSetting onlyPlayers = new CheckboxSetting(
		"Only Players", "Only swap when hitting players.", true);
	
	private final SliderSetting heightThreshold = new SliderSetting(
		"Height Threshold", "Blocks above ground to use density mace.", 3.0, 1,
		10, 0.5, SliderSetting.ValueDisplay.DECIMAL);
	
	private final CheckboxSetting instantSwap =
		new CheckboxSetting("Instant Swap", "Light speed mace swapping.", true);
	
	private final CheckboxSetting smartSwap = new CheckboxSetting("Smart Swap",
		"Intelligently choose density vs breach based on conditions.", true);
	
	private final CheckboxSetting autoSwapBack = new CheckboxSetting(
		"Auto Swap Back", "Instantly swap back to sword after hit.", true);
	
	private final SliderSetting swapBackDelay = new SliderSetting(
		"Swap Back Delay", "Ticks to wait before swapping back (0 = instant).",
		0, 0, 5, 1, SliderSetting.ValueDisplay.INTEGER);
	
	private final CheckboxSetting onlyOnHit = new CheckboxSetting("Only On Hit",
		"Only swap when actually hitting a player.", true);
	
	private int originalSlot = -1;
	private boolean shouldSwapBack = false;
	private int swapBackTimer = 0;
	
	public MaceAutoSwapHack()
	{
		super("MaceSwap");
		setCategory(Category.COMBAT);
		addSetting(onlyPlayers);
		addSetting(heightThreshold);
		addSetting(instantSwap);
		addSetting(smartSwap);
		addSetting(autoSwapBack);
		addSetting(swapBackDelay);
		addSetting(onlyOnHit);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(LeftClickListener.class, this);
		EVENTS.add(UpdateListener.class, this);
		resetState();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(LeftClickListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
		
		if(shouldSwapBack && originalSlot != -1 && MC.player != null)
		{
			MC.player.getInventory().selectedSlot = originalSlot;
			resetState();
		}
	}
	
	@Override
	public void onUpdate()
	{
		// No delays - everything is instant for maximum speed
		if(MC.player == null || onlyOnHit.isChecked())
			return;
		
		// Auto-swap for aim assist and trigger bot (instant)
		if(MC.crosshairTarget != null
			&& MC.crosshairTarget.getType() == HitResult.Type.ENTITY)
		{
			EntityHitResult entityHit = (EntityHitResult)MC.crosshairTarget;
			Entity target = entityHit.getEntity();
			
			if(shouldSwapForTarget(target))
			{
				performLightSpeedSwap(target);
			}
		}
	}
	
	@Override
	public void onLeftClick(LeftClickEvent event)
	{
		if(!onlyOnHit.isChecked())
			return;
		
		if(MC.player == null || MC.crosshairTarget == null)
			return;
		
		if(MC.crosshairTarget.getType() != HitResult.Type.ENTITY)
			return;
		
		EntityHitResult entityHit = (EntityHitResult)MC.crosshairTarget;
		Entity target = entityHit.getEntity();
		
		if(!shouldSwapForTarget(target))
			return;
		
		performLightSpeedSwap(target);
	}
	
	private void performLightSpeedSwap(Entity target)
	{
		int maceSlot = findBestMace(target);
		if(maceSlot == -1)
			return;
		
		originalSlot = MC.player.getInventory().selectedSlot;
		
		// Ultra-fast swap: mace -> hit -> back in same tick
		MC.player.getInventory().selectedSlot = maceSlot;
		
		// Force immediate attack with mace
		MC.interactionManager.attackEntity(MC.player, target);
		MC.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
		
		// Instant swap back (no delay)
		if(autoSwapBack.isChecked())
		{
			MC.player.getInventory().selectedSlot = originalSlot;
		}
		
		resetState();
	}
	
	public void setSlot(Entity target)
	{
		if(!isEnabled() || MC.player == null)
			return;
		
		if(!shouldSwapForTarget(target))
			return;
		
		// Instant swap and attack for external calls (AimXT, etc.)
		performLightSpeedSwap(target);
	}
	
	private boolean shouldSwapForTarget(Entity target)
	{
		if(!(target instanceof LivingEntity))
			return false;
		
		if(onlyPlayers.isChecked() && !(target instanceof PlayerEntity))
			return false;
		
		return true;
	}
	
	private int findBestMace(Entity target)
	{
		int densitySlot = -1;
		int breachSlot = -1;
		int regularSlot = -1;
		
		for(int i = 0; i < 9; i++)
		{
			ItemStack stack = MC.player.getInventory().getStack(i);
			if(stack.getItem() != Items.MACE)
				continue;
			
			if(hasDensityEnchantment(stack))
				densitySlot = i;
			else if(hasBreachEnchantment(stack))
				breachSlot = i;
			else if(regularSlot == -1)
				regularSlot = i;
		}
		
		if(!smartSwap.isChecked())
		{
			// Simple priority: breach > density > regular
			if(breachSlot != -1)
				return breachSlot;
			if(densitySlot != -1)
				return densitySlot;
			return regularSlot;
		}
		
		// Smart swapping logic
		boolean playerHasArmor = targetHasArmor(target);
		boolean playerIsHigh = isPlayerHigh();
		boolean playerIsFalling = MC.player.getVelocity().y < -0.5;
		
		// If player has armor, don't use breach (it's less effective)
		if(playerHasArmor && densitySlot != -1)
			return densitySlot;
		
		// If player is 3+ blocks up or falling fast, use density
		if((playerIsHigh || playerIsFalling) && densitySlot != -1)
			return densitySlot;
		
		// For low/ground players without armor, use breach for max damage
		if(!playerHasArmor && breachSlot != -1)
			return breachSlot;
		
		// Fallback priority
		if(breachSlot != -1)
			return breachSlot;
		if(densitySlot != -1)
			return densitySlot;
		return regularSlot;
	}
	
	private boolean isPlayerHigh()
	{
		double groundDistance = getDistanceToGround();
		return groundDistance >= heightThreshold.getValue()
			|| (!MC.player.isOnGround() && MC.player.fallDistance >= 3.0);
	}
	
	private double getDistanceToGround()
	{
		double playerY = MC.player.getY();
		for(int i = 0; i < 10; i++)
		{
			if(!MC.world.getBlockState(MC.player.getBlockPos().down(i)).isAir())
				return i;
		}
		return 10;
	}
	
	private boolean targetHasArmor(Entity target)
	{
		if(!(target instanceof LivingEntity living))
			return false;
		
		// Check if target has any armor equipped
		return !living.getArmorItems().iterator().next().isEmpty()
			|| living.getArmor() > 0;
	}
	
	private void resetState()
	{
		originalSlot = -1;
		shouldSwapBack = false;
		swapBackTimer = 0;
	}
	
	private boolean hasDensityEnchantment(ItemStack stack)
	{
		return stack.getEnchantments().getEnchantments().stream()
			.anyMatch(enchantment -> enchantment.equals(Enchantments.DENSITY));
	}
	
	private boolean hasBreachEnchantment(ItemStack stack)
	{
		return stack.getEnchantments().getEnchantments().stream()
			.anyMatch(enchantment -> enchantment.equals(Enchantments.BREACH));
	}
}
