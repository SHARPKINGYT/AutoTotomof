/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.PacketOutputListener.PacketOutputEvent;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"obsidian switch", "obi switch", "auto obsidian"})
public final class ObiSwitchHack extends Hack implements PacketOutputListener
{
	private final CheckboxSetting onCrystal =
		new CheckboxSetting("On crystal", "On use of crystals.", true);
	
	private final CheckboxSetting onObsidian =
		new CheckboxSetting("On obsidian", "On use of obsidian.", true);
	
	private final CheckboxSetting onSword =
		new CheckboxSetting("On sword", "On use of swords.", true);
	
	private final CheckboxSetting onTotem =
		new CheckboxSetting("On totem", "On use of totems.", true);
	
	private final CheckboxSetting onGlowstone =
		new CheckboxSetting("On glowstone", "On use of glowstone.", true);
	
	private final CheckboxSetting onAnchor =
		new CheckboxSetting("On anchor", "On use of anchors.", true);
	
	private final CheckboxSetting excludeBedrock = new CheckboxSetting(
		"Exclude bedrock", "Prevents triggers when targeting bedrock.", false);
	
	private static long cooldown;
	
	public ObiSwitchHack()
	{
		super("ObiSwitch");
		setCategory(Category.COMBAT);
		addSetting(onCrystal);
		addSetting(onObsidian);
		addSetting(onSword);
		addSetting(onTotem);
		addSetting(onGlowstone);
		addSetting(onAnchor);
		addSetting(excludeBedrock);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PacketOutputListener.class, this);
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		if(!(event.getPacket() instanceof PlayerActionC2SPacket packet))
			return;
		
		BlockPos pos = packet.getPos();
		
		if(packet
			.getAction() != PlayerActionC2SPacket.Action.START_DESTROY_BLOCK)
			return;
		if(InventoryUtils.indexOf(Items.OBSIDIAN, 36) == -1)
			return;
		
		if(cooldown > System.currentTimeMillis())
			return;
		cooldown = System.currentTimeMillis() + 200;
		
		if(canUse() && !isCrystallable(pos))
		{
			event.cancel();
			InventoryUtils.selectItem(Items.OBSIDIAN, 36);
			IMC.getInteractionManager().rightClickBlock(pos,
				packet.getDirection(),
				net.minecraft.util.math.Vec3d.ofCenter(pos));
		}
	}
	
	private boolean canUse()
	{
		String itemName =
			MC.player.getMainHandStack().getName().getString().toLowerCase();
		
		boolean useSword = itemName.contains("sword") && onSword.isChecked();
		boolean useCrystal =
			MC.player.isHolding(Items.END_CRYSTAL) && onCrystal.isChecked();
		boolean useTotem = itemName.contains("totem") && onTotem.isChecked();
		boolean useGlowstone =
			MC.player.isHolding(Items.GLOWSTONE) && onGlowstone.isChecked();
		boolean useAnchor =
			MC.player.isHolding(Items.RESPAWN_ANCHOR) && onAnchor.isChecked();
		boolean useObsidian =
			MC.player.isHolding(Items.OBSIDIAN) && onObsidian.isChecked();
		
		return useSword || useCrystal || useTotem || useGlowstone || useAnchor
			|| useObsidian;
	}
	
	private boolean isCrystallable(BlockPos pos)
	{
		return BlockUtils.getBlock(pos).equals(Blocks.OBSIDIAN)
			|| (!excludeBedrock.isChecked()
				&& BlockUtils.getBlock(pos).equals(Blocks.BEDROCK));
	}
}
