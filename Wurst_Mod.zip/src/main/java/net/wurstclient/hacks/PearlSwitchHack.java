/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.Hand;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.PacketOutputListener.PacketOutputEvent;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"pearl switch", "ender pearl switch", "auto pearl"})
public final class PearlSwitchHack extends Hack implements PacketOutputListener
{
	private final CheckboxSetting onTotem = new CheckboxSetting("On totem",
		"Activate on use of Totem Of Undying.", true);
	
	private final CheckboxSetting onSword =
		new CheckboxSetting("On sword", "Activate on use of Swords.", true);
	
	private static long cooldown;
	
	public PearlSwitchHack()
	{
		super("PearlSwitch");
		setCategory(Category.COMBAT);
		addSetting(onTotem);
		addSetting(onSword);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PacketOutputListener.class, this);
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		if(!(event.getPacket() instanceof PlayerInteractItemC2SPacket))
			return;
		
		if(InventoryUtils.indexOf(Items.ENDER_PEARL, 36) == -1)
			return;
		
		String itemName =
			MC.player.getMainHandStack().getName().getString().toLowerCase();
		boolean useTotem = onTotem.isChecked() && itemName.contains("totem");
		boolean useSword = onSword.isChecked() && itemName.contains("sword");
		
		if(useSword || useTotem)
		{
			if(cooldown > System.currentTimeMillis())
				return;
			cooldown = System.currentTimeMillis() + 200;
			
			event.cancel();
			InventoryUtils.selectItem(Items.ENDER_PEARL, 36);
			MC.interactionManager.interactItem(MC.player, Hand.MAIN_HAND);
		}
	}
}
