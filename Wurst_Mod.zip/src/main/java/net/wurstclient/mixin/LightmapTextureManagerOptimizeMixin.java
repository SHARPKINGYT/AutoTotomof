/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.render.LightmapTextureManager;
import net.wurstclient.WurstClient;

@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerOptimizeMixin
{
	private int updateCounter = 0;
	
	@Inject(at = @At("HEAD"), method = "update", cancellable = true)
	private void onUpdate(float delta, CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().fpsBoostHack.shouldReduceLighting())
		{
			// Update lighting less frequently for better FPS
			updateCounter++;
			if(updateCounter % 3 != 0)
				ci.cancel();
		}
	}
}
