/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.wurstclient.WurstClient;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin
{
	@Inject(at = @At("HEAD"),
		method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V",
		cancellable = true)
	private void onAddParticle(ParticleEffect parameters, double x, double y,
		double z, double velocityX, double velocityY, double velocityZ,
		CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().fpsBoostHack.shouldReduceParticles())
		{
			// Reduce particles by 75% for better FPS
			if(Math.random() < 0.75)
				ci.cancel();
		}
	}
}
